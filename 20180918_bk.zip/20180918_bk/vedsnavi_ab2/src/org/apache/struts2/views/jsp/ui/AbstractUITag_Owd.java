package org.apache.struts2.views.jsp.ui;
/*    */ import javax.servlet.jsp.tagext.DynamicAttributes;

/*    */ import org.apache.struts2.components.UIBean_Owd;
/*    */
/*    */
/*    */
/*    */ public abstract class AbstractUITag_Owd extends AbstractUITag implements DynamicAttributes {
/*    */    protected String owdid;
/*    */    protected Object owdrole;
/*    */
/*    */    protected void populateParams() {
/* 13 */       super.populateParams();
/*    */
/* 15 */       UIBean_Owd uiBean = (UIBean_Owd)this.component;
/* 16 */       uiBean.setOwdid(this.owdid);
/* 17 */       uiBean.setOwdrole(this.owdrole);
/*    */
/*    */    }
/*    */
/*    */    public void setOwdid(String owdid) {
/* 22 */       this.owdid = owdid;
/* 23 */    }
/*    */
/*    */    public void setOwdrole(Object owdrole) {
/* 26 */       this.owdrole = owdrole;
/* 27 */    }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from:
	Total time: 378 ms

	Decompiled with FernFlower.
*/