/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Ablog01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.log.action;

import jp.co.hitachi.a.b.log.bean.Ablog01DispBean;
import jp.co.hitachi.a.b.log.business.Ablog01Business;
import jp.co.hitachi.a.m.all.AmallConst.SystemName;
import jp.co.hitachi.a.m.all.AmallConst.SystemType;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallSystemErrLog;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Ablog01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Ablog01DispBean ablog01DispBean;
	/** ログインID */
	private String loginID = null;
	/** パスワード */
	private String password = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		String forwardName = FORWARD_GLOBALERROR;
		try {
			// セッション再作成
			reCreateSession(request);
			// セッション(DTO管理データ)作成
			createSession(request);
			// システム種別設定
			setM_systemKind(request, SystemType.BUSINESS); // 顧客OLをセット
			// トークン生成
			createToken(request);
			// クッキー生成
			createCookie(request, response);

			// ビジネス層の実行処理呼び出し処理
			forwardName = callexecute();

			// 実行結果をリクエストに設定
			setAblog01DispBean((Ablog01DispBean) request.getAttribute("Ablog01DispBean"));

			// システム名を設定
			ablog01DispBean.setH_systemName(SystemName.BUSINESS);

		} catch (AmallException e) {
			AmallSystemErrLog.createSystemErrLog(getM_systemKind(request), e, request);
		}

		return forwardName;
	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Ablog01Business dao = new Ablog01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行(ログイン画面のみ共通情報の取得不要)
		return dao.execute();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////


	public Ablog01DispBean getAblog01DispBean() {
		return ablog01DispBean;
	}

	public void setAblog01DispBean(Ablog01DispBean ablog01DispBean) {
		this.ablog01DispBean = ablog01DispBean;
	}

	public String getLoginID() {
		return loginID;
	}

	public void setLoginID(String loginID) {
		this.loginID = AmallUtilities.convEmpty(loginID);;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = AmallUtilities.convEmpty(password);;
	}


}
