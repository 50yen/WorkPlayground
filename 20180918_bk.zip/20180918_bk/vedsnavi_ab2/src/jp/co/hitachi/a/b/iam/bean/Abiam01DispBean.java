/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abiam01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.bean;

import java.util.ArrayList;
import java.util.List;

import jp.co.hitachi.a.b.iam.dto.AbiamDropDownList;
import jp.co.hitachi.a.m.cls.AmclsBeanBase;
import jp.co.hitachi.a.m.dto.AmdtoDropDownList;

/*****************************************************************************************
 * Abiam01DispBeanクラス<br>
 *****************************************************************************************/
public class Abiam01DispBean extends AmclsBeanBase {

	/** メンバ変数 */
	/** カテゴリプルダウンリスト */
	private List<AbiamDropDownList> categoryDropDownList = null;
	/** メニュープルダウンリスト */
	private List<AbiamDropDownList> menuDropDownList = null;
	/** 画面名プルダウンリスト */
	private List<AbiamDropDownList> screenDropDownList = null;
	/** 表示プルダウンリスト */
	private List<AmdtoDropDownList> dispDropDownList = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Abiam01DispBean() {
		super();
		categoryDropDownList = new ArrayList<>();
		menuDropDownList = new ArrayList<>();
		dispDropDownList = new ArrayList<>();
		screenDropDownList = new ArrayList<>();
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		super.clear();
		categoryDropDownList = null;
		menuDropDownList = null;
		screenDropDownList = null;
		dispDropDownList = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public List<AbiamDropDownList> getCategoryDropDownList() {
		return categoryDropDownList;
	}

	public void setCategoryDropDownList(List<AbiamDropDownList> categoryDropDownList) {
		this.categoryDropDownList = categoryDropDownList;
	}

	public List<AbiamDropDownList> getMenuDropDownList() {
		return menuDropDownList;
	}

	public void setMenuDropDownList(List<AbiamDropDownList> menuDropDownList) {
		this.menuDropDownList = menuDropDownList;
	}

	public List<AbiamDropDownList> getScreenDropDownList() {
		return screenDropDownList;
	}

	public void setScreenDropDownList(List<AbiamDropDownList> screenDropDownList) {
		this.screenDropDownList = screenDropDownList;
	}

	public List<AmdtoDropDownList> getDispDropDownList() {
		return dispDropDownList;
	}

	public void setDispDropDownList(List<AmdtoDropDownList> dispDropDownList) {
		this.dispDropDownList = dispDropDownList;
	}

}
