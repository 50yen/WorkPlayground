/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Accme01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cme.business;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.cme.action.Accme01Action;
import jp.co.hitachi.a.c.cme.bean.Accme01DispBean;
import jp.co.hitachi.a.c.cme.dto.Accme01Dto;
import jp.co.hitachi.a.c.cme.dto.AccmeItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.Encode;
import jp.co.hitachi.a.m.all.AmallConst.GeneralFlg;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallConst.confirmCls;
import jp.co.hitachi.a.m.all.AmallConst.statusCls;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallPage;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;
import jp.co.hitachi.a.m.dto.AmdtoPagingSql;

/*****************************************************************************************
 * Accme01Businessクラス<br>
 *****************************************************************************************/
public class Accme01Business extends AccmeBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Accme01DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 検索ボタン押下処理 */
	private static final String FORWARD_SEARCH = "SEARCH";
	/** ダウンロード処理 */
	private static final String FORWARD_DOWNLOAD = "DOWNLOAD";
	/** 前頁 */
	private static final String FORWARD_PAGEPREV = "PAGEPREV";
	/** 先頭頁処理 */
	private static final String FORWARD_PAGEFIRST = "PAGEFIRST";
	/** 次頁 */
	private static final String FORWARD_PAGENEXT = "PAGENEXT";
	/** 最終頁 */
	private static final String FORWARD_PAGELAST = "PAGELAST";
	/** 件数変更 */
	private static final String FORWARD_DISPRESULTS = "DISPRESULTS";
	/** 入力画面に移動(前方一致) */
	private static final String FORWARD_SELECT_PREFIX = "SELECT";
	/** 登録画面へ（新規） */
	private static final String FORWARD_SELECTDAY = "SELECTDAY";
	/** 登録画面へ（列選択時） */
	private static final String FORWARD_SELECTLINE = "SELECTLINE";
	/** 登録画面へ（列選択時） */
	private static final String FORWARD_GOTOACCME11 = "GOTOACCME11";
	/** 画面表示（再表示） */
	public static final String FORWARD_REDISP = "REDISP";

	/**
	 * 画面項目ID
	 */
	/** 画面名 */
	private static final String ITEM_ID_SCREEN_NAME = "ScreenName";
	/** 顧客コード */
	public static final String ITEM_ID_CST_CD = "customerSearchNm";
	/** 店舗CD */
	private static final String ITEM_ID_SHOP_CD = "shopSearchNm";
	/** 店舗枝番コード */
	public static final String ITEM_ID_SHOPSBNO_CD = "shopBranchSearchNm";
	/** 売上日From */
	private static final String ITEM_ID_SLD_FROM = "sldFrom";
	/** 売上日To */
	private static final String ITEM_ID_SLD_TO = "sldTo";
	/** ページ遷移ボタン（行選択なし） */
	private static final String ITEM_ID_REGIST_BTN = "registSelectBtn";

	/** メンバ変数 */
	/** アクションフォーム */
	private Accme01Action m_Accme01Form = null;
	/** 表示用画面Bean */
	private Accme01DispBean m_Accme01DispBean = null;
	/** ページング処理用 */
	private AmallPage m_Page = null;
	/** SQL作成用 */
	private AmdtoPagingSql m_Page_Sql = null;
	/** 画面DTO */
	Accme01Dto m_Accme01Dto;
	/** DTOキー名 */
	private String DTO_ACCME01 = "DTO_ACCME01";

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Accme01Business(
			Accme01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Accme01Business.class.getName();
		m_Accme01Form = form;
		m_Accme01DispBean = new Accme01DispBean();
		m_Page = new AmallPage();
		m_Page_Sql = new AmdtoPagingSql();
		setErrString(gid, m_Accme01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}
			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Accme01DispBean);

			/* 内部記憶情報の生成 */
			m_Accme01Dto = (Accme01Dto) getSpecifiedDTO(m_Gid, DTO_ACCME01);
			if (m_Accme01Dto == null || FORWARD_DISP.equals(m_Event)) {
				if (m_Accme01Dto != null) {
					delSpecifiedDTO(m_Gid);
				}
				m_Accme01Dto = new Accme01Dto();
				putSpecifiedDTO(m_Gid, DTO_ACCME01, m_Accme01Dto);
			}

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Accme01Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_SEARCH.equals(m_Event)) {
				// 検索ボタン押下の場合
				forwardStr = search();
			} else if (FORWARD_PAGEFIRST.equals(m_Event)) {
				// "<<"ボタン押下の場合
				forwardStr = pageFirst();
			} else if (FORWARD_PAGEPREV.equals(m_Event)) {
				// "<"ボタン押下の場合
				forwardStr = pagePrev();
			} else if (FORWARD_PAGENEXT.equals(m_Event)) {
				// ">"ボタン押下の場合
				forwardStr = pageNext();
			} else if (FORWARD_PAGELAST.equals(m_Event)) {
				// ">>"ボタン押下の場合
				forwardStr = pageLast();
			} else if (FORWARD_DISPRESULTS.equals(m_Event)) {
				// 表示件数変更の場合
				forwardStr = changeDispRslts();
			} else if (FORWARD_DOWNLOAD.equals(m_Event)) {
				// ダウンロード処理の場合
				forwardStr = download();
			} else if (FORWARD_SELECTDAY.equals(m_Event)) {
				// 「売上日を指定して登録」を選択した場合
				forwardStr = goToPage();
			} else if (FORWARD_SELECTLINE.equals(m_Event)) {
				// 「売上登録」を選択した場合
				forwardStr = goToPage();
			} else if (FORWARD_REDISP.equals(m_Event)) {
				// 戻るボタンで遷移してきた場合
				forwardStr = search();
			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Accme01DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 検索ボタン押下処理実行
	 * <p>
	 * 検索ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String search() throws AmallException, Exception {

		// 入力条件妥当性チェック
		if (!proprietyCheck()) {
			// 一覧初期化
			m_Accme01Form.setItemDispList(new ArrayList<>());

			return FORWARD_DISP;
		}

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * "<"ボタン押下処理実行
	 * <p>
	 * "<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pagePrev() throws AmallException, Exception {

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * "<<"ボタン押下処理実行
	 * <p>
	 * "<<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageFirst() throws AmallException, Exception {

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ">"ボタン押下処理実行
	 * <p>
	 * ">"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageNext() throws AmallException, Exception {

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ">>"ボタン押下処理実行
	 * <p>
	 * ">>"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageLast() throws AmallException, Exception {

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ダウンロード処理
	 * <p>
	 * ダウンロード処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String download() throws AmallException {

		// ファイルデータ作成
		List<String> data = new ArrayList<>();

		// 出力ファイル検索
		searchproc();

		if (m_Accme01Form.getItemDispList() != null) {
			// ヘッダセット
			StringBuffer header = new StringBuffer();
			List<AmdtoGeneralMst> headerList = AmallUtilities.getGeneralMstDataList(m_DbAccess,
					GeneralMstKey.CSV_HEADER_COLUMN, m_Gid, null, m_Accme01DispBean.getServiceDate());
			if (headerList != null) {
				for (AmdtoGeneralMst atgm : headerList) {
					if (atgm.getSortNo() > 1) {
						header.append(AmallConst.CSV_SEP);
					}
					header.append(atgm.getGeneralNm1());
				}
				data.add(header.toString());
			}

			// データセット
			for (AccmeItemDispDto list : m_Accme01Form.getItemDispList()) {
				data.add(
						list.getDispCstCd() + AmallConst.CSV_SEP +
								list.getDispCstNm() + AmallConst.CSV_SEP +
								list.getDispShopCd() + AmallConst.CSV_SEP +
								list.getDispShopNm() + AmallConst.CSV_SEP +
								list.getDispShopSbno() + AmallConst.CSV_SEP +
								list.getDispShopSbnm() + AmallConst.CSV_SEP +
								list.getFinFlg() + AmallConst.CSV_SEP +
								list.getStatusCls() + AmallConst.CSV_SEP +
								list.getSld() + AmallConst.CSV_SEP +
								list.getSpccmt10000YMai() + AmallConst.CSV_SEP +
								list.getSpccmt5000YMai() + AmallConst.CSV_SEP +
								list.getSpccmt2000YMai() + AmallConst.CSV_SEP +
								list.getSpccmt1000YMai() + AmallConst.CSV_SEP +
								list.getSpccmt500YMai() + AmallConst.CSV_SEP +
								list.getSpccmt100YMai() + AmallConst.CSV_SEP +
								list.getSpccmt50YMai() + AmallConst.CSV_SEP +
								list.getSpccmt10YMai() + AmallConst.CSV_SEP +
								list.getSpccmt5YMai() + AmallConst.CSV_SEP +
								list.getSpccmt1YMai() + AmallConst.CSV_SEP +
								list.getSpccmt());
			}
		}

		// ファイルデータ出力
		AmdtoGeneralMst dlFileDto = AmallUtilities.getGeneralMstDataRecord(m_DbAccess, GeneralMstKey.CSV_DOWNLOAD_FILE,
				m_Gid, null, m_Accme01DispBean.getServiceDate());
		m_Accme01Form.setDownloadFileData(data, dlFileDto.getGeneralNm1(), Encode.SHIFT_JIS);

		return FORWARD_DOWNLOAD;
	}

	/*************************************************************************************
	 * 表示件数変更処理実行
	 * <p>
	 * 表示件数変更処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String changeDispRslts() throws AmallException, Exception {

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ページ移動処理実行
	 * <p>
	 * ページ移動処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String goToPage() throws Exception {

		String methodName = "goToPage()";

		// TODO ページ遷移
		// TODO Accme11作成後にテスト
		try {
			// チェック済フラグ
			boolean checkFlg = false;

			// 列選択チェック
			if (m_Accme01Form.getItemDispList() != null) {
				for (AccmeItemDispDto checkdto : m_Accme01Form.getItemDispList()) {
					if (checkdto.isListCheck()) {
						checkFlg = true;
						break;
					}
				}
			}

			// 「売上日を指定」のボタンの場合
			if (FORWARD_SELECTDAY.equals(m_Event)) {
				if (checkFlg) {
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_DESELECT_COLUMN,
							getItemDispName(ITEM_ID_REGIST_BTN, m_Accme01DispBean));
					// 前検索結果DTOにセット
					m_Accme01Dto.setItemDispList(m_Accme01Form.getItemDispList());
					// 検索処理を呼ぶ
					searchproc();

					return FORWARD_DISP;
				}
			}
			// 「売上日を指定」のボタンの場合
			if (FORWARD_SELECTLINE.equals(m_Event)) {
				if (!checkFlg) {
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_NO_ROW_SELECT, "");
					// 検索処理を呼ぶ
					searchproc();

					return FORWARD_DISP;
				}
				// 選択列をdtoにセット
				List<AccmeItemDispDto> list = new ArrayList<>();
				// 前検索結果DTOにセット
				m_Accme01Dto.setItemDispList(m_Accme01Form.getItemDispList());

				for (AccmeItemDispDto itemList : m_Accme01Form.getItemDispList()) {
					// チェックボックスにチェックが入っているもののみDTOにセット
					if (itemList.isListCheck()) {
						AccmeItemDispDto dto = new AccmeItemDispDto();
						dto.setCstCd(itemList.getCstCd());
						dto.setShopCd(itemList.getShopCd());
						dto.setShopSbno(itemList.getShopSbno());
						dto.setSld(AmallUtilities.changeFormat422(itemList.getSld()));
						list.add(dto);
					}
				}
				putSpecifiedDTO(ACCME_INFO_KEY, list);
			}

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

		return FORWARD_GOTOACCME11;
	}

	/*************************************************************************************
	 * 入力項目妥当性チェック
	 * <p>
	 * 入力項目妥当性チェックを実行する
	 * </p>
	 * @return boolean
	 ************************************************************************************/
	private boolean proprietyCheck() throws AmallException {
		String methodName = "proprietyCheck()";
		try {

			// 返却用フラグ
			boolean ret = true;
			// 入力情報
			String cstCd = m_Accme01Form.getSearchCstCd();
			String cstNm = null;
			String shopCd = m_Accme01Form.getSearchShopCd();
			String shopNm = null;
			String shopSbno = m_Accme01Form.getSearchSbnoCd();
			String shopSbnm = null;
			String sldFrom = m_Accme01Form.getSldFrom();
			String sldTo = m_Accme01Form.getSldTo();

			// 入力値チェック(顧客コード)
			if (!AmallUtilities.isEmpty(cstCd)) {
				// 入力値が存在する場合
				if (!AmallUtilities.isHalfWidthCharacterKind(cstCd, AmallUtilities.H_NUM | AmallUtilities.H_ALP)) {
					// 半角英数以外が設定されている
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_CST_CD, m_Accme01DispBean), String.valueOf(InputNum.CST_CD));
					setError(m_Accme01DispBean, ITEM_ID_CST_CD);

					ret = false;
				} else if (AmallUtilities.getLengthAsHalf(cstCd) != InputNum.CST_CD) {
					// 10桁以外の数字が設定されている
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
							getItemDispName(ITEM_ID_CST_CD, m_Accme01DispBean), String.valueOf(InputNum.CST_CD));
					setError(m_Accme01DispBean, ITEM_ID_CST_CD);

					ret = false;
				}
			}

			// 入力値チェック(店舗コード)
			if (!AmallUtilities.isEmpty(shopCd)) {
				// 入力値が存在する場合
				if (!AmallUtilities.isHalfWidthCharacterKind(shopCd, AmallUtilities.H_NUM | AmallUtilities.H_ALP)) {
					// 半角英数字以外が設定されている
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_SHOP_CD, m_Accme01DispBean), String.valueOf(InputNum.SHOP_CD));
					setError(m_Accme01DispBean, ITEM_ID_SHOP_CD);
					ret = false;
				} else if (AmallUtilities.getLengthAsHalf(shopCd) > InputNum.SHOP_CD) {
					// 10桁より多い英数字が設定されている
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_SHOP_CD, m_Accme01DispBean), String.valueOf(InputNum.SHOP_CD));
					setError(m_Accme01DispBean, ITEM_ID_SHOP_CD);

					ret = false;
				}
				if (AmallUtilities.isEmpty(cstCd)) {
					// 顧客が空の場合
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
							getItemDispName(ITEM_ID_CST_CD, m_Accme01DispBean));
					setError(m_Accme01DispBean, ITEM_ID_CST_CD);
					ret = false;
				}
			}

			// 入力値チェック(店舗枝番コード)
			if (!AmallUtilities.isEmpty(shopSbno)) {
				// 入力値が存在する場合
				if (!AmallUtilities.isHalfWidthCharacterKind(shopSbno, AmallUtilities.H_NUM | AmallUtilities.H_ALP)) {
					// 半角英数以外が設定されている
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_SHOPSBNO_CD, m_Accme01DispBean),
							String.valueOf(InputNum.SHOP_BRANCH_CD));
					setError(m_Accme01DispBean, ITEM_ID_SHOPSBNO_CD);

					ret = false;
				} else if (AmallUtilities.getLengthAsHalf(shopSbno) > InputNum.SHOP_BRANCH_CD) {
					// 14桁より多い数字が設定されている
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_SHOPSBNO_CD, m_Accme01DispBean),
							String.valueOf(InputNum.SHOP_BRANCH_CD));
					setError(m_Accme01DispBean, ITEM_ID_SHOPSBNO_CD);
					ret = false;
				}
				if (AmallUtilities.isEmpty(shopCd)) {
					// 店舗が空の場合
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
							getItemDispName(ITEM_ID_SHOP_CD, m_Accme01DispBean));
					setError(m_Accme01DispBean, ITEM_ID_SHOP_CD);

					if (AmallUtilities.isEmpty(cstCd)) {
						// 顧客も空の場合
						setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
								getItemDispName(ITEM_ID_CST_CD, m_Accme01DispBean));
						setError(m_Accme01DispBean, ITEM_ID_CST_CD);
					}
					ret = false;
				}
			}

			// 名前検索処理
			if (ret) {
				Map<String, String> retMap = searchInfo(cstCd, shopCd, shopSbno, m_Accme01DispBean);
				cstNm = retMap.get("CST_NM");
				shopNm = retMap.get("SHOP_NM");
				shopSbnm = retMap.get("SHOP_SB_NM");
			}

			// 日付妥当性チェック
			if (!AmallUtilities.isEmpty(sldFrom)) {
				if (sldFrom.length() != 10) {
					if (sldFrom.length() == 8) {
						// 「/」が含まれていない日付の場合挿入
						sldFrom = AmallUtilities.changeFormat(sldFrom);
					} else {
						setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_DATE_ERROR, "", "");
						setError(m_Accme01DispBean, ITEM_ID_SLD_FROM);
						ret = false;
					}
				}
				if (!AmallUtilities.checkExistDate(sldFrom)) {
					// 正しい日付か
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_NOT_EXIST_DATE,
							getItemDispName(ITEM_ID_SLD_FROM, m_Accme01DispBean), "");
					setError(m_Accme01DispBean, ITEM_ID_SLD_FROM);
					ret = false;
				}
			}

			// 日付妥当性チェック
			if (!AmallUtilities.isEmpty(sldTo)) {
				if (sldTo.length() != 10) {
					if (sldTo.length() == 8) {
						// 「/」が含まれていない日付の場合挿入
						sldTo = AmallUtilities.changeFormat(sldTo);
					} else {
						setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_DATE_ERROR, "", "");
						setError(m_Accme01DispBean, ITEM_ID_SLD_FROM);
						ret = false;
					}
				}
				if (!AmallUtilities.checkExistDate(sldTo)) {
					// 正しい日付か
					setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_NOT_EXIST_DATE,
							getItemDispName(ITEM_ID_SLD_TO, m_Accme01DispBean), String.valueOf(InputNum.SHOP_CD));
					setError(m_Accme01DispBean, ITEM_ID_SLD_TO);
					ret = false;
				}

			}

			// From-To逆転
			if (!AmallUtilities.isEmpty(sldFrom) && !AmallUtilities.isEmpty(sldTo)) {
				if (AmallUtilities.checkExistDate(sldFrom) && AmallUtilities.checkExistDate(sldTo)) {
					if (AmallUtilities.diffDate(AmallUtilities.changeFormat422(sldFrom),
							AmallUtilities.changeFormat422(sldTo)) < 0) {
						setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_ERR_REV_LARGE_SMALL_DATE,
								"");
						setError(m_Accme01DispBean, ITEM_ID_SLD_FROM);
						setError(m_Accme01DispBean, ITEM_ID_SLD_TO);
						ret = false;
					}
				}

			}
			if (ret) {
				// フラグがtrueならば検索条件をDTOに追加
				m_Accme01Dto.setShopCd(shopCd);
				m_Accme01Dto.setShopNm(shopNm);
				m_Accme01Dto.setSldFrom(AmallUtilities.changeFormat422(sldFrom));
				m_Accme01Dto.setSldTo(AmallUtilities.changeFormat422(sldTo));
				m_Accme01Dto.setCstCd(cstCd);
				m_Accme01Dto.setCstNm(cstNm);
				m_Accme01Dto.setShopSbno(shopSbno);
				m_Accme01Dto.setShopSbnm(shopSbnm);
			}

			return ret;

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

	}

	/*************************************************************************************
	 * 検索処理実行
	 * <p>
	 * 検索処理を実行する
	 * </p>
	 * @param  なし
	 * @return なし
	 ************************************************************************************/
	private String searchproc() throws AmallException {
		// methodName
		String methodName = "searchproc()";
		// 明細部用LIST
		List<AccmeItemDispDto> detailList = new ArrayList<>();

		// 一覧初期化
		m_Accme01Form.setItemDispList(detailList);

		// システム日付取得
		String systemDt = m_Accme01DispBean.getServiceDate();

		// 検索条件
		String sldFrom = m_Accme01Dto.getSldFrom();
		String sldTo = m_Accme01Dto.getSldTo();
		String shopCd = m_Accme01Dto.getShopCd();
		String cstCd = m_Accme01Dto.getCstCd();
		String shopSbno = m_Accme01Dto.getShopSbno();

		try {

			// 検索フォーム値セット
			m_Accme01Form.setSearchCstCd(cstCd);
			m_Accme01Form.setSearchCstNm(m_Accme01Dto.getCstNm());
			m_Accme01Form.setSearchShopCd(shopCd);
			m_Accme01Form.setSearchShopNm(m_Accme01Dto.getShopNm());
			m_Accme01Form.setSearchSbnoCd(shopSbno);
			m_Accme01Form.setSearchSbnoNm(m_Accme01Dto.getShopSbnm());
			m_Accme01Form.setSldFrom(AmallUtilities.changeFormat(sldFrom));
			m_Accme01Form.setSldTo(AmallUtilities.changeFormat(sldTo));

			// SQL作成
			makeSearchSql(cstCd, shopCd, shopSbno, sldFrom, sldTo, systemDt);

			// select句
			String sqlSelect = m_Page_Sql.getSqlSelect();
			// from where 句
			String sqlCondition = m_Page_Sql.getSqlConditinon();
			// order 句
			String sqlOrder = m_Page_Sql.getSqlOrder();
			// param 句
			String[] sqlParam = m_Page_Sql.getSqlParam();
			// 表示件数
			int pageDispCnt = m_Page_Sql.getPageDispCnt();
			// ページ番号
			int pageNo = m_Accme01Dto.getDisplayNum();

			List<Map<String, String>> pageData = null;
			if (m_Event.equals(FORWARD_DISP)) { // 初期検索状態
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEFIRST)) { // "<<"ボタン押下時
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEPREV)) { // "<"ボタン押下時
				pageData = m_Page.getPrevPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGENEXT)) { // ">"ボタン押下時
				pageData = m_Page.getNextPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGELAST)) { // ">>"ボタン押下時
				pageData = m_Page.getLastPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGELAST)) { // ">>"ボタン押下時
				pageData = m_Page.getLastPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event != null && m_Event.startsWith(FORWARD_SELECT_PREFIX)) { // 画面遷移失敗時
				pageData = m_Page.getPageData(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.startsWith(FORWARD_REDISP)) { // 戻るボタンで戻ってきた場合
				pageData = m_Page.getPageData(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else { // 検索ボタン押下時、その他
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			}

			/* 表示頁NOのセット */
			m_Accme01Dto.setDisplayNum(m_Page.getNowPage());
			m_Accme01DispBean.setDisplayNum(m_Accme01Dto.getDisplayNum());

			/* ページ遷移ボタンセット */
			if (!m_Page.isPrevPageExist()) {
				m_Accme01DispBean.setPrevPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Accme01DispBean.setPrevPageFlg(AmallConst.GeneralFlg.OFF);
			}
			if (!m_Page.isNextPageExist()) {
				m_Accme01DispBean.setNextPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Accme01DispBean.setNextPageFlg(AmallConst.GeneralFlg.OFF);
			}

			// 件数セット
			m_Accme01DispBean.setDispCountDefault(String.valueOf(pageDispCnt));

			// ページ情報がない場合
			if (pageData == null) {
				// エラーメッセージをセット
				setMessageInfo(m_Accme01DispBean, AmallMessageConst.MSG_INF_SEARCH_CON_NO_DATA, "");
				return FORWARD_DISP;

			}

			/** 明細部リスト作成 **/
			if (m_Event.equals(FORWARD_DOWNLOAD)) {
				// DL用リスト作成
				detailList = makeDetailDlList(pageData);
			} else {
				// 明細リスト作成
				detailList = makeDetailList(pageData);
			}
			// チェックボックスチェック処理
			detailList = toCheck(detailList);

			// 一覧表示データセット
			m_Accme01Form.setItemDispList(detailList);

			/** 正常終了 */
			return FORWARD_DISP;

		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					getItemDispName(ITEM_ID_SCREEN_NAME, m_Accme01DispBean));
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * SQL作成
	 * <p>
	 * SQLを作成する
	 * </p>
	 * @param shopCd 店舗CD
	 * @param cldFrom 回収From
	 * @param cldTo 回収To
	 * @param defFlg 誤差フラグ
	 * @param systemDt システム日付
	 * @return なし
	 ************************************************************************************/
	protected void makeSearchSql(String cstCd, String shopCd, String shopSbno, String sldFrom, String sldTo,
			String systemDt)
			throws AmallException, Exception {
		// メソッド名
		String methodName = "makeSearchSql()";

		StringBuffer sql = new StringBuffer();
		// SQLバインド用リスト
		List<String> bindParam = new ArrayList<String>();

		try {

			// 1ページの表示件数
			if (m_Event.equals(FORWARD_SEARCH) || m_Event.equals(FORWARD_REDISP)) {
				// 検索ボタン押下時に表示検索がないときはデフォルト値とする
				int dispCnt = m_Accme01Form.getDispResults();
				if (dispCnt == 0) {
					m_Page_Sql.setPageDispCnt(Integer.parseInt(m_Accme01DispBean.getDispCountDefault()));
				} else {
					m_Page_Sql.setPageDispCnt(dispCnt);
				}
			} else {
				m_Page_Sql.setPageDispCnt(m_Accme01Form.getDispResults());
			}

			// SQL

			// SELECT 句
			sql.delete(0, sql.length());
			sql.append("SELECT");
			sql.append("    INFO.CST_CD AS CST_CD,");
			sql.append("    NCM.CST_NM AS CST_NM,");
			sql.append("    INFO.SHOP_CD AS SHOP_CD,");
			sql.append("    NSM.SHOP_NM AS SHOP_NM,");
			sql.append("    NSCM.COMPANY_SHOP_CD AS COMPANY_SHOP_CD,");
			sql.append("    NSCM.COMPANY_SHOP_NM AS COMPANY_SHOP_NM,");
			sql.append("    INFO.SHOP_SBNO AS SHOP_SBNO,");
			sql.append("    NSSM.SHOP_SB_NM AS SHOP_SB_NM,");
			sql.append("    NSSCM.COMPANY_SHOP_SB_CD AS COMPANY_SHOP_SB_CD,");
			sql.append("    NSSCM.COMPANY_SHOP_SB_NM AS COMPANY_SHOP_SB_NM,");
			sql.append("    INFO.SLD AS SLD,");
			sql.append("    CASE");
			sql.append("            WHEN NCSD.MCD_ODRN IS NULL THEN '0'");
			sql.append("            ELSE '1'");
			sql.append("        END");
			sql.append("    SLD_FLG,");
			sql.append("    NVL(NCED.FIN_FLG,0) AS FIN_FLG,");
			sql.append("    NVL(NCED.STATUS_CLS,'00') AS STATUS_CLS,");
			sql.append("    NVL(NCED.SPCCMT,0) AS SPCCMT,");
			sql.append("    NVL(NCED.SPCCMT_10000Y_MAI,0) AS SPCCMT_10000Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_5000Y_MAI,0) AS SPCCMT_5000Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_2000Y_MAI,0) AS SPCCMT_2000Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_1000Y_MAI,0) AS SPCCMT_1000Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_500Y_MAI,0) AS SPCCMT_500Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_100Y_MAI,0) AS SPCCMT_100Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_50Y_MAI,0) AS SPCCMT_50Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_10Y_MAI,0) AS SPCCMT_10Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_5Y_MAI,0) AS SPCCMT_5Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_1Y_MAI,0) AS SPCCMT_1Y_MAI");

			String sqlSelect = sql.toString();
			// FROM句
			sql.delete(0, sql.length());
			sql.append(" FROM");
			sql.append("    (");
			sql.append("        SELECT");
			sql.append("            CST_CD,");
			sql.append("            SHOP_CD,");
			sql.append("            SHOP_SBNO,");
			sql.append("            SLD");
			sql.append("        FROM");
			sql.append("            N_CLMY_SLD_DAT");
			sql.append("        WHERE");
			sql.append("            DEL_FLG = ?");
			bindParam.add(AmallConst.DEFAULT_DEL_FLG);
			sql.append("        UNION");
			sql.append("        SELECT");
			sql.append("            CST_CD,");
			sql.append("            SHOP_CD,");
			sql.append("            SHOP_SBNO,");
			sql.append("            SLD");
			sql.append("        FROM");
			sql.append("            N_CLMY_ENT_DAT");
			sql.append("        WHERE");
			sql.append("            DEL_FLG = ?");
			bindParam.add(AmallConst.DEFAULT_DEL_FLG);
			sql.append("    ) INFO");
			sql.append("    LEFT JOIN N_CLMY_SLD_DAT NCSD ON INFO.CST_CD = NCSD.CST_CD");
			sql.append("                                     AND INFO.SHOP_CD = NCSD.SHOP_CD");
			sql.append("                                     AND INFO.SHOP_SBNO = NCSD.SHOP_SBNO");
			sql.append("                                     AND INFO.SLD = NCSD.SLD");
			sql.append("    LEFT JOIN N_CLMY_ENT_DAT NCED ON INFO.CST_CD = NCED.CST_CD");
			sql.append("                                     AND INFO.SHOP_CD = NCED.SHOP_CD");
			sql.append("                                     AND INFO.SHOP_SBNO = NCED.SHOP_SBNO");
			sql.append("                                     AND INFO.SLD = NCED.SLD");
			sql.append("    LEFT JOIN N_CST_M NCM ON INFO.CST_CD = NCM.CST_CD");
			sql.append("                             AND NCM.DEL_FLG = ?");
			bindParam.add(AmallConst.DEFAULT_DEL_FLG);
			sql.append("    LEFT JOIN N_SHOP_M NSM ON INFO.CST_CD = NSM.CST_CD");
			sql.append("    AND INFO.SHOP_CD = NSM.SHOP_CD");
			sql.append("                              AND NSM.DEL_FLG = ?");
			bindParam.add(AmallConst.DEFAULT_DEL_FLG);
			sql.append("                              AND ? BETWEEN NSM.EFST_DY AND NSM.EFED_DY");
			bindParam.add(systemDt);
			sql.append("    LEFT JOIN N_SHOP_CNV_M NSCM ON NSM.CST_CD = NSCM.CST_CD");
			sql.append("                                   AND NSM.SHOP_CD = NSCM.SHOP_CD");
			sql.append("                                   AND NSCM.DEL_FLG = ?");
			bindParam.add(AmallConst.DEFAULT_DEL_FLG);
			sql.append("                                   AND ? BETWEEN NSCM.EFST_DY AND NSCM.EFED_DY");
			bindParam.add(systemDt);
			sql.append("    LEFT JOIN N_SHOP_SB_M NSSM ON INFO.CST_CD = NSSM.CST_CD");
			sql.append("                                  AND INFO.SHOP_CD = NSSM.SHOP_CD");
			sql.append("                                  AND INFO.SHOP_SBNO = NSSM.SHOP_SBNO");
			sql.append("                                  AND NSSM.DEL_FLG = ?");
			bindParam.add(AmallConst.DEFAULT_DEL_FLG);
			sql.append("                                  AND ? BETWEEN NSSM.EFST_DY AND NSSM.EFED_DY");
			bindParam.add(systemDt);
			sql.append("    LEFT JOIN N_SHOP_SB_CNV_M NSSCM ON NSSM.CST_CD = NSSCM.CST_CD");
			sql.append("                                       AND NSSM.SHOP_CD = NSSCM.SHOP_CD");
			sql.append("                                       AND NSSM.SHOP_SBNO = NSSCM.SHOP_SBNO");
			sql.append("                                       AND NSSCM.DEL_FLG = ?");
			bindParam.add(AmallConst.DEFAULT_DEL_FLG);
			sql.append("                                       AND ? BETWEEN NSSCM.EFST_DY AND NSSCM.EFED_DY");
			bindParam.add(systemDt);

			// WHERE 句
			sql.append(" WHERE");
			sql.append("    INFO.CST_CD IS NOT NULL");

			// 全店舗判定
			if (!m_Accme01DispBean.isShopCdAllFlg()) {
				// 全顧客・全店舗ではない場合
				sql.append("	AND (");
				boolean first = true;
				for (Entry<String, List<String>> entry : m_Accme01DispBean.getShopCdListMap().entrySet()) {

					String appCstCd = entry.getKey();
					for (String appShop : entry.getValue()) {
						if (first) {
							sql.append("		(");
							first = false;
						} else {
							sql.append("		OR (");
						}
						sql.append("			INFO.CST_CD = '").append(appCstCd).append("'");
						sql.append("			AND");
						sql.append("			INFO.SHOP_CD = '").append(appShop).append("'");
						sql.append("		)");
					}
				}
				sql.append("	)");
			}

			// 検索条件に値が入っている場合
			if (!AmallUtilities.isEmpty(sldFrom)) {
				// 売上From
				sql.append(" AND INFO.SLD >= ? ");
				bindParam.add(sldFrom);
			}
			if (!AmallUtilities.isEmpty(sldTo)) {
				// 売上To
				sql.append(" AND INFO.SLD <= ?");
				bindParam.add(sldTo);
			}
			if (!AmallUtilities.isEmpty(cstCd)) {
				// 顧客コードが存在する場合
				sql.append("	AND ");
				sql.append("		INFO.CST_CD = ?");
				bindParam.add(cstCd);
			}
			if (!AmallUtilities.isEmpty(shopCd)) {
				// 店舗コードが存在する場合(お客様店舗コードも検索対象)
				sql.append("	AND (");
				sql.append("		INFO.SHOP_CD = ?");
				sql.append("		OR");
				sql.append("		TRIM(nscm.COMPANY_SHOP_CD) = ?");
				sql.append("	)");
				bindParam.add(shopCd);
				bindParam.add(shopCd);
			}
			if (!AmallUtilities.isEmpty(shopSbno)) {
				// 店舗枝番コードが存在する場合(お客様レジ番号も検索対象)
				sql.append("	AND (");
				sql.append("		INFO.SHOP_SBNO = ?");
				sql.append("		OR");
				sql.append("		TRIM(nsscm.COMPANY_SHOP_SB_CD) = ?");
				sql.append("	)");
				bindParam.add(shopSbno);
				bindParam.add(shopSbno);
			}
			String sqlCondition = sql.toString();

			// ORDER 句
			sql.delete(0, sql.length());
			sql.append(" ORDER BY");
			sql.append("    INFO.CST_CD,");
			sql.append("    INFO.SHOP_CD,");
			sql.append("    INFO.SHOP_SBNO,");
			sql.append("    INFO.SLD");
			String sqlOrder = sql.toString();

			// リストを配列に
			String[] sqlParam = bindParam.toArray(new String[bindParam.size()]);

			// セット処理
			m_Page_Sql.setSqlSelect(sqlSelect);
			m_Page_Sql.setSqlConditinon(sqlCondition);
			m_Page_Sql.setSqlOrder(sqlOrder);
			m_Page_Sql.setSqlParam(sqlParam);

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 明細リスト作成処理
	 * <p>
	 * 明細リスト作成処理を実行する
	 * </p>
	 * @param	pageData	頁データ
	 * @return 明細ArrayList
	 ************************************************************************************/
	private List<AccmeItemDispDto> makeDetailList(List<Map<String, String>> pageData)
			throws AmallException {
		List<AccmeItemDispDto> retList = new ArrayList<>();
		String methodName = "makeDetailList()";
		try {
			// ページ情報をリストに追加
			for (Map<String, String> map : pageData) {
				AccmeItemDispDto listdto = new AccmeItemDispDto();

				// 確定
				if (!AmallUtilities.isEmpty(map.get("FIN_FLG"))) {
					if (GeneralFlg.ON.equals(map.get("FIN_FLG"))) {
						listdto.setFinFlg(confirmCls.CONFIRMED);
					} else {
						listdto.setFinFlg(confirmCls.NO_CONFIRM);
					}
				}

				// 状態
				if (!AmallUtilities.isEmpty(map.get("STATUS_CLS"))) {
					if (statusCls.NO_ENTERED_NUM.equals(map.get("STATUS_CLS"))) {
						// 未入力
						listdto.setStatusCls(statusCls.NO_ENTERED);
					} else if (statusCls.ENTERED_NUM.equals(map.get("STATUS_CLS"))) {
						// 入力済（初期入力）
						listdto.setStatusCls(statusCls.ENTERED);
					} else if (statusCls.MODIFIED_NUM.equals(map.get("STATUS_CLS"))) {
						// 修正済
						listdto.setStatusCls(statusCls.MODIFIED);
					} else if (statusCls.SENT_NUM.equals(map.get("STATUS_CLS"))) {
						// 送信済
						listdto.setStatusCls(statusCls.SENT);
					}
				}

				// 売上日
				listdto.setSld(AmallUtilities.changeFormat(map.get("SLD")));

				// 顧客CD
				listdto.setDispCstCd(map.get("CST_CD"));
				listdto.setCstCd(map.get("CST_CD"));
				// 顧客名
				listdto.setDispCstNm(map.get("CST_NM"));

				// 企業店舗コード、名称がある場合は企業店舗を優先
				if (!AmallUtilities.isEmpty(map.get("COMPANY_SHOP_CD"))
						|| !AmallUtilities.isEmpty(map.get("COMPANY_SHOP_NM"))) {
					// 企業店舗コード
					listdto.setDispShopCd(map.get("COMPANY_SHOP_CD"));
					// 企業店舗名称
					listdto.setDispShopNm(map.get("COMPANY_SHOP_NM"));
				} else {
					// 店舗コード
					listdto.setDispShopCd(AmallUtilities.changeFormatShopCd(map.get("SHOP_CD")));
					// 店舗名称
					listdto.setDispShopNm(map.get("SHOP_NM"));
				}
				// 遷移用店舗CD
				listdto.setShopCd(map.get("SHOP_CD"));

				// 企業枝番コード、名称がある場合は企業別枝番を優先
				if (!AmallUtilities.isEmpty(map.get("COMPANY_SHOP_SB_CD"))
						|| !AmallUtilities.isEmpty(map.get("COMPANY_SHOP_SB_NM"))) {
					// 企業別枝番コード
					listdto.setDispShopSbno(map.get("COMPANY_SHOP_SB_CD"));
					// 企業別枝番名称
					listdto.setDispShopSbnm(map.get("COMPANY_SHOP_SB_NM"));
				} else {
					// 枝番コード
					listdto.setDispShopSbno(AmallUtilities.changeFormatSbNo(map.get("SHOP_SBNO")));
					// 枝番名称
					listdto.setDispShopSbnm(map.get("SHOP_SB_NM"));
				}
				// 遷移用枝番
				listdto.setShopSbno(map.get("SHOP_SBNO"));

				// 合計金額
				String spccmt = String.format(AmallConst.THREE_SEPARATOR_FORMAT, Integer.parseInt(map.get("SPCCMT")));
				listdto.setSpccmt(spccmt + AmallConst.DEFAULT_MONEY_JA);
				// 1万円枚数
				String spccmt10000YMai = String.format(AmallConst.THREE_SEPARATOR_FORMAT,
						Integer.parseInt(map.get("SPCCMT_10000Y_MAI")));
				listdto.setSpccmt10000YMai(spccmt10000YMai + AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 5千円枚数
				String spccmt5000YMai = String.format(AmallConst.THREE_SEPARATOR_FORMAT,
						Integer.parseInt(map.get("SPCCMT_5000Y_MAI")));
				listdto.setSpccmt5000YMai(spccmt5000YMai + AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 2千円枚数
				String spccmt2000YMai = String.format(AmallConst.THREE_SEPARATOR_FORMAT,
						Integer.parseInt(map.get("SPCCMT_2000Y_MAI")));
				listdto.setSpccmt2000YMai(spccmt2000YMai + AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 1千円枚数
				String spccmt1000YMai = String.format(AmallConst.THREE_SEPARATOR_FORMAT,
						Integer.parseInt(map.get("SPCCMT_1000Y_MAI")));
				spccmt1000YMai = spccmt1000YMai + AmallConst.DEFAULT_MONEY_AMOUNT_JA;
				listdto.setSpccmt1000YMai(spccmt1000YMai);
				// 5百円枚数
				String spccmt500YMai = String.format(AmallConst.THREE_SEPARATOR_FORMAT,
						Integer.parseInt(map.get("SPCCMT_500Y_MAI")));
				listdto.setSpccmt500YMai(spccmt500YMai + AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 百円枚数
				String spccmt100YMai = String.format(AmallConst.THREE_SEPARATOR_FORMAT,
						Integer.parseInt(map.get("SPCCMT_100Y_MAI")));
				listdto.setSpccmt100YMai(spccmt100YMai + AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 5十円枚数
				String spccmt50YMai = String.format(AmallConst.THREE_SEPARATOR_FORMAT,
						Integer.parseInt(map.get("SPCCMT_50Y_MAI")));
				listdto.setSpccmt50YMai(spccmt50YMai + AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 十円枚数
				String spccmt10YMai = String.format(AmallConst.THREE_SEPARATOR_FORMAT,
						Integer.parseInt(map.get("SPCCMT_10Y_MAI")));
				listdto.setSpccmt10YMai(spccmt10YMai + AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 5円枚数
				String spccmt5YMai = String.format(AmallConst.THREE_SEPARATOR_FORMAT,
						Integer.parseInt(map.get("SPCCMT_5Y_MAI")));
				listdto.setSpccmt5YMai(spccmt5YMai + AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 1円枚数
				String spccmt1YMai = String.format(AmallConst.THREE_SEPARATOR_FORMAT,
						Integer.parseInt(map.get("SPCCMT_1Y_MAI")));
				listdto.setSpccmt1YMai(spccmt1YMai + AmallConst.DEFAULT_MONEY_AMOUNT_JA);

				// 返却リストに追加
				retList.add(listdto);
			}

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

		return retList;
	}

	/*************************************************************************************
	 * 明細リストチェック済作成処理
	 * <p>
	 * 明細リストのチェック済処理を実行する
	 * </p>
	 * @param	pageData	頁データ
	 * @return 明細ArrayList
	 ************************************************************************************/
	private List<AccmeItemDispDto> toCheck(List<AccmeItemDispDto> pageData)
			throws AmallException {
		List<AccmeItemDispDto> retList = new ArrayList<>();
		String methodName = "toCheck()";
		try {

			if (!(m_Event.equals(FORWARD_SELECTDAY) || m_Event.equals(FORWARD_REDISP))) {
				m_Accme01Dto.setItemDispList(new ArrayList<>());

			}
			if (m_Accme01Dto.getItemDispList() != null) {
				// ページ情報をリストに追加
				for (AccmeItemDispDto data : pageData) {
					for (AccmeItemDispDto list : m_Accme01Dto.getItemDispList()) {
						if (list.isListCheck()) {
							if (data.getCstCd().equals(list.getCstCd()) && data.getShopCd().equals(list.getShopCd())
									&& data.getShopSbno().equals(list.getShopSbno())
									&& data.getSld().equals(list.getSld())) {
								data.setListCheck(list.isListCheck());
							}
						}
					}
					retList.add(data);
				}
			}

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

		return pageData;
	}

	/*************************************************************************************
	 * DL用明細リスト作成処理
	 * <p>
	 * DL用明細リスト作成処理を実行する
	 * </p>
	 * @param	pageData	頁データ
	 * @return DL用明細ArrayList
	 ************************************************************************************/
	private List<AccmeItemDispDto> makeDetailDlList(List<Map<String, String>> pageData)
			throws AmallException {
		List<AccmeItemDispDto> retList = new ArrayList<>();
		String methodName = "makeDetailDlList(List<Map<String, String>> pageData)";
		try {
			// ページ情報をリストに追加
			for (Map<String, String> map : pageData) {
				AccmeItemDispDto listdto = new AccmeItemDispDto();

				// 顧客コード
				listdto.setDispCstCd(map.get("CST_CD"));
				// 顧客名
				listdto.setDispCstNm(map.get("CST_NM"));

				// 企業店舗コード、名称がある場合は企業店舗を優先
				if (!AmallUtilities.isEmpty(map.get("COMPANY_SHOP_CD"))
						|| !AmallUtilities.isEmpty(map.get("COMPANY_SHOP_NM"))) {
					// 企業店舗コード
					listdto.setDispShopCd(map.get("COMPANY_SHOP_CD"));
					// 企業店舗名称
					listdto.setDispShopNm(map.get("COMPANY_SHOP_NM"));
				} else {
					// 店舗コード
					listdto.setDispShopCd(map.get("SHOP_CD"));
					// 店舗名称
					listdto.setDispShopNm(map.get("SHOP_NM"));
				}

				// 企業枝番コード、名称がある場合は企業別枝番を優先
				if (!AmallUtilities.isEmpty(map.get("COMPANY_SHOP_SB_CD"))
						|| !AmallUtilities.isEmpty(map.get("COMPANY_SHOP_SB_NM"))) {
					// 企業別枝番コード
					listdto.setDispShopSbno(map.get("COMPANY_SHOP_SB_CD"));
					// 企業別枝番名称
					listdto.setDispShopSbnm(map.get("COMPANY_SHOP_SB_NM"));
				} else {
					// 枝番コード
					listdto.setDispShopSbno(map.get("SHOP_SBNO"));
					// 枝番名称
					listdto.setDispShopSbnm(map.get("SHOP_SB_NM"));
				}

				// 確定
				if (!AmallUtilities.isEmpty(map.get("FIN_FLG"))) {
					if (GeneralFlg.ON.equals(map.get("FIN_FLG"))) {
						listdto.setFinFlg(confirmCls.CONFIRMED);
					} else {
						listdto.setFinFlg(confirmCls.NO_CONFIRM);
					}
				}

				// 状態
				if (!AmallUtilities.isEmpty(map.get("STATUS_CLS"))) {
					if (statusCls.NO_ENTERED_NUM.equals(map.get("STATUS_CLS"))) {
						// 未入力
						listdto.setStatusCls(statusCls.NO_ENTERED);
					} else if (statusCls.ENTERED_NUM.equals(map.get("STATUS_CLS"))) {
						// 入力済（初期入力）
						listdto.setStatusCls(statusCls.ENTERED);
					} else if (statusCls.MODIFIED_NUM.equals(map.get("STATUS_CLS"))) {
						// 修正済
						listdto.setStatusCls(statusCls.MODIFIED);
					} else if (statusCls.SENT_NUM.equals(map.get("STATUS_CLS"))) {
						// 送信済
						listdto.setStatusCls(statusCls.SENT);
					}
				}

				// 売上日
				listdto.setSld(map.get("SLD"));

				// 1万円枚数
				listdto.setSpccmt10000YMai(map.get("SPCCMT_10000Y_MAI"));
				// 5千円枚数
				listdto.setSpccmt5000YMai(map.get("SPCCMT_5000Y_MAI"));
				// 2千円枚数
				listdto.setSpccmt2000YMai(map.get("SPCCMT_2000Y_MAI"));
				// 1千円枚数
				listdto.setSpccmt1000YMai(map.get("SPCCMT_1000Y_MAI"));
				// 5百円枚数
				listdto.setSpccmt500YMai(map.get("SPCCMT_500Y_MAI"));
				// 百円枚数
				listdto.setSpccmt100YMai(map.get("SPCCMT_100Y_MAI"));
				// 5十円枚数
				listdto.setSpccmt50YMai(map.get("SPCCMT_50Y_MAI"));
				// 十円枚数
				listdto.setSpccmt10YMai(map.get("SPCCMT_10Y_MAI"));
				// 5円枚数
				listdto.setSpccmt5YMai(map.get("SPCCMT_5Y_MAI"));
				// 1円枚数
				listdto.setSpccmt1YMai(map.get("SPCCMT_1Y_MAI"));
				// 合計金額
				listdto.setSpccmt(map.get("SPCCMT"));
				//
				// 返却リストに追加
				retList.add(listdto);
			}

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

		return retList;
	}

}