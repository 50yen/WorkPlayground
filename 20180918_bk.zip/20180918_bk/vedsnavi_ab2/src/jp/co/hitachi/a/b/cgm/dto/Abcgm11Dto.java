/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abcgm11Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.cgm.dto;

import java.util.ArrayList;
import java.util.List;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Abcgm11Dtoクラス<br>
 *****************************************************************************************/
public class Abcgm11Dto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 一覧保存データ */
	private List<AbcgmCstGrpDto> itemSavedList = null;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public Abcgm11Dto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		itemSavedList = new ArrayList<>();;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public synchronized List<AbcgmCstGrpDto> getItemSavedList() {
		return itemSavedList;
	}
	public synchronized void setItemSavedList(List<AbcgmCstGrpDto> itemSavedList) {
		this.itemSavedList = itemSavedList;
	}
}
