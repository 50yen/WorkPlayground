/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abiam01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.business;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.b.iam.action.Abiam01Action;
import jp.co.hitachi.a.b.iam.bean.Abiam01DispBean;
import jp.co.hitachi.a.b.iam.dto.Abiam01Dto;
import jp.co.hitachi.a.b.iam.dto.AbiamScreenAuthDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallConst.ScrExp;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;

/*****************************************************************************************
 * Abiam01Businessクラス<br>
 *****************************************************************************************/
public class Abiam01Business extends AbiamBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Abiam01DispBean";
	/** 内部記憶用DTO名 */
	private static final String DTO_ABIAM01 = "DTO_ABIAM01";
	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 検索 */
	public static final String FORWARD_SEARCH = "SEARCH";
	/** 登録 */
	public static final String FORWARD_REGIST = "REGIST";

	/**
	 * 画面項目ID
	 */
	/** カテゴリプルダウン */
	public static final String ITEM_ID_CATEGORY_DD = "categoryDropDown";
	/** メニュープルダウン */
	public static final String ITEM_ID_MENU_DD = "menuDropDown";
	/** 画面名プルダウン */
	public static final String ITEM_ID_SCREEN_DD = "screenDropDown";
	/** 一覧表示可否プルダウン */
	public static final String ITEM_ID_DISP_DD = "dispDropDownList";

	/** メンバ変数 */
	/** アクションフォーム */
	private Abiam01Action m_Abiam01Form = null;
	/** 表示用画面Bean */
	private Abiam01DispBean m_Abiam01DispBean = null;
	/** 内部記憶用DTO */
	private Abiam01Dto m_Abiam01Dto = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Abiam01Business(
			Abiam01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Abiam01Business.class.getName();
		m_Abiam01Form = form;
		m_Abiam01DispBean = new Abiam01DispBean();
		setErrString(gid, m_Abiam01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}
			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Abiam01DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Abiam01Form.getM_systemKind());
			m_DbAccess.initDB();

			// 共通処理
			getDropDownListData();

			// 内部記憶情報の生成
			m_Abiam01Dto = (Abiam01Dto) getSpecifiedDTO(m_Gid, DTO_ABIAM01);
			if (m_Abiam01Dto == null) {
				m_Abiam01Dto = new Abiam01Dto();
				putSpecifiedDTO(m_Gid, DTO_ABIAM01, m_Abiam01Dto);
			}

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_SEARCH.equals(m_Event)) {
				// 検索処理の場合

				// 検索結果を初期化
				List<AbiamScreenAuthDto> emptylist = new ArrayList<>();
				m_Abiam01Form.setScreenDispList(emptylist);

				// 検索実行
				forwardStr = search();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				forwardStr = regist();
			} else {
				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Abiam01DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 検索処理
	 * <p>
	 * 検索処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String search() throws AmallException, Exception {

		// カテゴリコード取得
		String categoryCd = m_Abiam01Form.getSelectedCategoryCd();
		// メニューコード取得
		String menuCd = m_Abiam01Form.getSelectedMenuCd();
		// 画面コード取得
		String screenCd = m_Abiam01Form.getSelectedScreenCd();


		// 入力チェック
		boolean chkFlg = true;
		// カテゴリコード 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(categoryCd)) {
			setMessageInfo(m_Abiam01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_CATEGORY_DD, m_Abiam01DispBean));
			setError(m_Abiam01DispBean, ITEM_ID_CATEGORY_DD);
			chkFlg = false;
		}


		// 画面コード指定時のメニューコード 必須ﾁｪｯｸ
		if (!AmallUtilities.isEmpty(screenCd) && AmallUtilities.isEmpty(menuCd) ) {
			setMessageInfo(m_Abiam01DispBean, AmallMessageConst.MSG_ERR_SPEC_NOT_COMBI, getItemDispName(ITEM_ID_MENU_DD, m_Abiam01DispBean),getItemDispName(ITEM_ID_SCREEN_DD, m_Abiam01DispBean));
			setError(m_Abiam01DispBean, ITEM_ID_MENU_DD);
			setError(m_Abiam01DispBean, ITEM_ID_SCREEN_DD);
			chkFlg = false;
		}
		// 入力チェック判定
		if (!chkFlg) {
			return FORWARD_DISP;
		}

		// 画面一覧検索
		List<String> screenList = getScreenGrpMst(categoryCd, menuCd, screenCd);

		// 結果チェック
		if (screenList.size() == 0) {
			// 0件だった場合
			setMessageInfo(m_Abiam01DispBean, AmallMessageConst.MSG_INF_SEARCH_CON_NO_DATA);
			return FORWARD_DISP;
		}

		// 表示項目取得+今回画面対象データリストをセッションに保存
		List<AbiamScreenAuthDto> screenDispList = getScreenRoleMst(screenList);

		// 結果チェック
		if (screenDispList.size() == 0) {
			// 0件だった場合
			setMessageInfo(m_Abiam01DispBean, AmallMessageConst.MSG_INF_SEARCH_CON_NO_DATA);
			return FORWARD_DISP;
		}

		// 一覧表示データセット
		m_Abiam01Form.setScreenDispList(screenDispList);
		// 検索ボタン押下時検索条件保存
		m_Abiam01Form.setSavedCategoryCd(categoryCd);
		m_Abiam01Form.setSavedMenuCd(menuCd);
		m_Abiam01Form.setSavedScreenCd(screenCd);

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 登録処理
	 * <p>
	 * 登録処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException, Exception {

		// == 検索条件・更新データ取得 ==
		// 今回対象画面データリストを取得


		// 入力データ取得
		List<AbiamScreenAuthDto> dataList = m_Abiam01Form.getScreenDispList();

		// == 入力チェック ==
		boolean chkFlg = true;
		// 取得データ分繰り返す

		for (int index = 0;index < dataList.size(); index++) {

			AbiamScreenAuthDto authDto = dataList.get(index);

			// 表示可否取得
			String dispCd = authDto.getDispCd();

			// 表示可否は必須
			if(dispCd == null || dispCd.length() == 0) {
				setMessageInfo(m_Abiam01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, authDto.getRoleNm() + "の" + getItemDispName(ITEM_ID_DISP_DD, m_Abiam01DispBean));
				setError(m_Abiam01DispBean, ITEM_ID_DISP_DD + index);
				chkFlg = false;
				continue;
			}
		}
		// 入力チェック判定
		if (!chkFlg) {
			// 入力チェックエラー有
			return FORWARD_DISP;
		}


		// == 登録処理 ==
		// 内部記憶より更新対象マップを取得
		Map<String, List<AbiamScreenAuthDto>> update = m_Abiam01Dto.getUpdateDataMap();

		boolean registFlg = true;
		for (AbiamScreenAuthDto authDto : dataList) {
			// 対象の権限ロールCDを取得
			String roleId = authDto.getRoleCd();
			// 入力されている表示可否を取得
			String dispCd = authDto.getDispCd();

			// マップより対象リストを取得
			List<AbiamScreenAuthDto> list = update.get(roleId);

			// 取得データが存在する場合
			if (list.size() > 0) {

				for (AbiamScreenAuthDto screenAuthDto : list) {
					// 処理分岐

					// 排他キーチェック
					Long versionkey = screenAuthDto.getExclusiveKey();

					if (versionkey != null) {
						// 排他キーが存在する場合はUpdate処理
						boolean ret = updateScrRoleMst(screenAuthDto, roleId, dispCd);
						// 処理結果チェック
						if (!ret) {
							// 処理中断
							registFlg = false;
							break;
						}
					} else {
						// 存在しない場合はInsert処理
						boolean ret = insertScrRoleMst(screenAuthDto, roleId, dispCd);
						// 処理結果チェック
						if (!ret) {
							// 処理中断
							registFlg = false;
							break;
						}
					}
				}
			}
		}
		// DB処理正常判定
		if (registFlg) {
			// コミット処理
			m_DbAccess.commit();
			// 正常完了処理メッセージ
			setMessageInfo(m_Abiam01DispBean, AmallMessageConst.MSG_INF_NML_REGIST_END_RELOGIN);

			// 再検索処理
			m_Abiam01Form.setSelectedCategoryCd(m_Abiam01Form.getSavedCategoryCd());
			m_Abiam01Form.setSelectedMenuCd(m_Abiam01Form.getSavedMenuCd());
			m_Abiam01Form.setSelectedScreenCd(m_Abiam01Form.getSavedScreenCd());

			search();
		}


		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * プルダウンリスト取得処理
	 * <p>
	 * 画面に表示するプルダウンリストの値を取得する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private void getDropDownListData() throws AmallException, Exception {

		// カテゴリ一覧を取得する
		m_Abiam01DispBean.setCategoryDropDownList(getMenuGrpList(true));

		// メニュー一覧を取得する
		m_Abiam01DispBean.setMenuDropDownList(getMenuGrpList(false));

		// 画面(メニュー)一覧を取得する
		m_Abiam01DispBean.setScreenDropDownList(getScreenMenuList());

		// 表示可否一覧を取得する
		m_Abiam01DispBean.setDispDropDownList(getDispProprietyList(m_Abiam01DispBean.getServiceDate()));


	}
	/*************************************************************************************
	 * 画面メニューグループマスタ(DB)取得
	 * <p>
	 * 画面メニューグループマスタ(DB)からデータを取得する
	 * 画面の検索条件と合致する画面コードの一覧を取得する、取得されるデータはメニュー表示可否ONの画面のみ
	 * </p>
	 * @param  categoryCd 画面グループコード(カテゴリ)
	 * @param  menuCd 画面グループコード(メニュー)
	 * @param  screenCd 画面コード
	 * @return List<String> 画面コードリスト
	 ************************************************************************************/
	private List<String> getScreenGrpMst(String categoryCd, String menuCd, String screenCd) throws AmallException, Exception {

		String methodName = "getScreenGrpMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	C.SCREEN_CD");
			sql.append("  FROM");
			sql.append("	(");
			sql.append("		SELECT");
			sql.append("			B.PARENT_MENU_GRP_CD");
			sql.append("			,B.MENU_GRP_CD");
			sql.append("			,A.SCREEN_CD");
			sql.append("		  FROM");
			sql.append("			(");
			sql.append("				SELECT");
			sql.append("					MENU_GRP_CD");
			sql.append("					,SCREEN_CD");
			sql.append("				  FROM");
			sql.append("					N_MENU_M");
			sql.append("				 WHERE");
			sql.append("					VISIBLE = ?");
			sql.append("					AND DEL_FLG = ?");
			sql.append("			) A,");
			sql.append("			N_MENU_GRP_M B");
			sql.append("		 WHERE");
			sql.append("			B.MENU_GRP_CD = A.MENU_GRP_CD");
			sql.append("			AND B.DEL_FLG = ?");
			sql.append("	) C,");
			sql.append("	N_MENU_GRP_M D");
			sql.append(" WHERE");
			sql.append("	D.MENU_GRP_CD = C.PARENT_MENU_GRP_CD");
			sql.append("	AND D.DEL_FLG = ?");
			// カテゴリコード
			if (!AmallUtilities.isEmpty(categoryCd)) {
				sql.append("	AND D.MENU_GRP_CD = ?");
				// メニューコード
				if (!AmallUtilities.isEmpty(menuCd)) {
					sql.append("	AND C.MENU_GRP_CD = ?");
					// 画面コード
					if (!AmallUtilities.isEmpty(screenCd)) {
						sql.append("	AND C.SCREEN_CD = ?");
					}
				}
			}
			m_DbAccess.createPreparedStatement(sql.toString());

			// 条件設定
			int setCnt = 0;
			// 表示可否
			m_DbAccess.setString(++setCnt, ScrExp.DISPLAY_ON);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// カテゴリコード
			if (!AmallUtilities.isEmpty(categoryCd)) {
				m_DbAccess.setString(++setCnt, categoryCd);
				// メニューコード
				if (!AmallUtilities.isEmpty(menuCd)) {
					m_DbAccess.setString(++setCnt, menuCd);
					// 画面コード
					if (!AmallUtilities.isEmpty(screenCd)) {
						m_DbAccess.setString(++setCnt, screenCd);
					}
				}
			}
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				// 画面コード
				String screenId = m_DbAccess.getString(rs, "SCREEN_CD");

				// リストに追加
				retList.add(screenId);

			}
			return retList;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_MENU_M,N_MENU_GRP_M,N_MENU_GRP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 画面権限マスタ(DB)取得
	 * <p>
	 * 画面権限マスタ(DB)からデータを取得する
	 * 取得した値はセッションに保存する、画面表示するのはサマリ情報
	 * </p>
	 * @param  screenCdList 画面コードリスト
	 * @return List<AbiamScreenAuthDto> 表示項目リスト
	 ************************************************************************************/
	private List<AbiamScreenAuthDto> getScreenRoleMst(List<String> screenCdList) throws AmallException, Exception {

		String methodName = "getScreenRoleMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<AbiamScreenAuthDto> retList = new ArrayList<>();
		// 保存用マップ
		Map<String, List<AbiamScreenAuthDto>> saveMap = new ConcurrentHashMap<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	A.ROLE_GRP_CD");
			sql.append(",	A.ROLE_GRP_NM");
			sql.append(",	A.SCREEN_CD");
			sql.append(",	B.VISIBLE");
			sql.append(",	B.EXCLUSIVE_KEY");
			sql.append("  FROM");
			sql.append("	(");
			sql.append("		SELECT");
			sql.append("			nrgm.ROLE_GRP_CD");
			sql.append(",			nrgm.ROLE_GRP_NM");
			sql.append(",			nsm.SCREEN_CD");
			sql.append("		FROM");
			sql.append("			N_SCREEN_M nsm");
			sql.append("			CROSS JOIN ");
			sql.append("				N_ROLE_GRP_M nrgm");
			sql.append("		WHERE");
			sql.append("			nsm.SCREEN_CD IN (");
			for (String screen : screenCdList) {
				sql.append("'").append(screen).append("',");
			}
			sql.append("'')");
			sql.append("			AND nsm.DEL_FLG = ?");
			sql.append("			AND nrgm.DEL_FLG = ?");
			sql.append("	) A");
			sql.append("	LEFT JOIN");
			sql.append("		N_SCREEN_ROLE_M B ");
			sql.append("	  ON");
			sql.append("		A.ROLE_GRP_CD = B.ROLE_GRP_CD");
			sql.append("		AND A.SCREEN_CD = B.SCREEN_CD");
			sql.append("		AND B.DEL_FLG = ?");
			sql.append(" ORDER BY");
			sql.append("		A.ROLE_GRP_CD");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			List<AbiamScreenAuthDto> addList = null;
			while (rs.next()) {

				// 権限グループCD
				String roleGrpCd = m_DbAccess.getString(rs, "ROLE_GRP_CD");

				// 対象の権限グループCDがMapに存在しない場合
				if(saveMap.containsKey(roleGrpCd) == false) {
					// リストの生成
					addList = new ArrayList<>();
				} else {
					// リストの取得
					addList = saveMap.get(roleGrpCd);
				}

				// DTOの生成
				AbiamScreenAuthDto dto = new AbiamScreenAuthDto();
				// 権限グループCD
				dto.setRoleCd(roleGrpCd);

				// 権限グループ名
				dto.setRoleNm(m_DbAccess.getString(rs, "ROLE_GRP_NM"));

				// 画面CD
				dto.setScreenCd(m_DbAccess.getString(rs, "SCREEN_CD"));

				// 表示可否
				dto.setDispCd(m_DbAccess.getString(rs, "VISIBLE"));

				// 排他キー
				Long key = rs.getLong("EXCLUSIVE_KEY");
				if (rs.wasNull()) {
					dto.setExclusiveKey(null);
				} else {
					dto.setExclusiveKey(key);
				}

				// リストに追加
				addList.add(dto);

				// マップに設定
				saveMap.put(roleGrpCd, addList);
			}

			// ソート処理
			Object[] mapkey = saveMap.keySet().toArray();
	        Arrays.sort(mapkey);

	        // サマリーデータを作成する
			for (int i = 0; i < mapkey.length ; i++) {
				AbiamScreenAuthDto setDto = new AbiamScreenAuthDto();

				// 値を取得
				List<AbiamScreenAuthDto> list = saveMap.get((String)mapkey[i]);

				// 先頭を取得
				AbiamScreenAuthDto first = list.get(0);
				// 権限ロール
				setDto.setRoleCd(first.getRoleCd());
				// 権限ロール名称
				setDto.setRoleNm(first.getRoleNm());
				// 表示可否
				setDto.setDispCd(ScrExp.DISPLAY_OFF);

				// 表示可否判定
				for (AbiamScreenAuthDto authDto : list) {

					// 一つでも未設定があった場合「表示」とする(メニュー表示としてデフォルト表示するデータのため)
					if(AmallUtilities.isEmpty(authDto.getDispCd())) {
						setDto.setDispCd(ScrExp.DISPLAY_ON);
						break;
					}					// 一つでも表示があった場合「表示」とする
					if(ScrExp.DISPLAY_ON.equals(authDto.getDispCd())) {
						setDto.setDispCd(authDto.getDispCd());
						break;
					}
					// 非表示の場合は最後まで非表示であれば「非表示」となる
					if(ScrExp.DISPLAY_OFF.equals(authDto.getDispCd())) {
						setDto.setDispCd(authDto.getDispCd());
					}
				}
				// リストに追加
				retList.add(setDto);
			}

			// 生成したデータを内部記憶に設定
			m_Abiam01Dto.setUpdateDataMap(saveMap);

			return retList;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_ROLE_GRP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 画面権限マスタ(DB)更新
	 * <p>
	 * 画面権限マスタ(DBを更新する
	 * </p>
	 * @param inputDto 保管データ(排他キー取得用)
	 * @param roleCd 対象権限コード
	 * @param dispCd 入力表示可否
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	private boolean updateScrRoleMst(AbiamScreenAuthDto inputDto, String roleCd, String dispCd) throws AmallException {

		String methodName = "updateScrRoleMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// SQL生成
			sql.append("UPDATE");
			sql.append("	N_SCREEN_ROLE_M");
			sql.append("   SET");
			// 表示可否
			sql.append("	VISIBLE = ?");
			// 共通部分
			sql.append(",	UPD_PGM_ID =  ?");
			sql.append(",	UPD_USER_ID =  ?");
			sql.append(",	UPD_DT =  SYSDATE");
			sql.append(",	EXCLUSIVE_KEY =  EXCLUSIVE_KEY + 1");

			// 条件指定
			sql.append(" WHERE");
			sql.append("	ROLE_GRP_CD =  ?");
			sql.append("	AND SCREEN_CD = ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND EXCLUSIVE_KEY = ?");


			// 更新値のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;
			// 表示可否
			m_DbAccess.setString(++setCnt, dispCd);
			// 更新プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 更新ユーザーID
			m_DbAccess.setString(++setCnt, m_Abiam01DispBean.getH_loginId());


			// WHERE句のパラメタ設定
			// 権限グループコード
			m_DbAccess.setString(++setCnt, roleCd);
			// 画面コード
			m_DbAccess.setString(++setCnt, inputDto.getScreenCd());
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 排他キー
			m_DbAccess.setLong(++setCnt, inputDto.getExclusiveKey());

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 排他チェック
			if(ret == 0) {
				// 更新対象無し(楽観排他)
				m_DbAccess.rollback();

				// エラー情報を設定
				setMessageInfo(m_Abiam01DispBean, AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST);

				// アクセスログ情報の作成
				AmallExceptionInfo amei = new AmallExceptionInfo();
				amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_ACS_OPT_ERROR, "N_SCREEN_ROLE_M"));
				setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

				return false;
			}

			// 更新結果判定
			if (ret != 1) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_SCREEN_ROLE_M");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_SCREEN_ROLE_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}
	/*************************************************************************************
	 * 画面権限マスタ(DB)登録
	 * <p>
	 * 画面権限マスタ(DB)にレコードを登録する
	 * </p>
	 * @param inputDto 保管データ(排他キー取得用)
	 * @param roleCd 対象権限コード
	 * @param dispCd 入力表示可否
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	private boolean insertScrRoleMst(AbiamScreenAuthDto inputDto, String roleCd, String dispCd) throws AmallException {

		String methodName = "insertScrRoleMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// SQL生成
			sql.append("INSERT INTO");
			sql.append("	N_SCREEN_ROLE_M (");
			sql.append("   		ROLE_GRP_CD");
			sql.append(",  		SCREEN_CD");
			sql.append(",  		VISIBLE");
			sql.append(",  		EXCLUSIVE_KEY");
			sql.append(",  		DEL_FLG");
			sql.append(",  		CR_PGM_ID");
			sql.append(",  		CR_USER_ID");
			sql.append(",  		CR_DT");
			sql.append(",  		UPD_PGM_ID");
			sql.append(",  		UPD_USER_ID");
			sql.append(",  		UPD_DT");
			sql.append("	) VALUES (");
			sql.append("		?");
			sql.append(",		?");
			sql.append(",		?");
			// 共通部分
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append("	)");

			// 登録値のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;
			// 権限グループコード
			m_DbAccess.setString(++setCnt, roleCd);
			// 画面コード
			m_DbAccess.setString(++setCnt, inputDto.getScreenCd());
			// 表示可否
			m_DbAccess.setString(++setCnt, dispCd);
			// 排他キー
			m_DbAccess.setLong(++setCnt, 0);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 登録プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 登録ユーザーID
			m_DbAccess.setString(++setCnt, m_Abiam01DispBean.getH_loginId());
			// 更新プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 更新ユーザーID
			m_DbAccess.setString(++setCnt, m_Abiam01DispBean.getH_loginId());

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 更新結果判定
			if (ret <= 0) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_SCREEN_ROLE_M");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_SCREEN_ROLE_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}

}