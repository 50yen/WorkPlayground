/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abcgm01Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.cgm.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Abcgm01Dtoクラス<br>
 *****************************************************************************************/
public class Abcgm01Dto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 顧客CD */
	private String cstCd = null;
	/** 表示件数 */
	private int dispResults = 0;
	/** ページ番号 */
	private int displayNum = 0;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public Abcgm01Dto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		cstCd = null;
		dispResults = 0;
		displayNum = 0;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getCstCd() {
		return cstCd;
	}
	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}
	public int getDisplayNum() {
		return displayNum;
	}
	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}
	public int getDispResults() {
		return dispResults;
	}
	public void setDispResults(int dispResults) {
		this.dispResults = dispResults;
	}
}
