/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech31Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.21 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Acech31Dtoクラス<br>
 *****************************************************************************************/
public class Acech31Dto extends AmclsDtoBase{

	/** メンバ変数 */

	/** 顧客CD */
	private String cstCd = null;
	/** 顧客名 */
	private String cstNm = null;
	/** 店舗CD */
	private String shopCd = null;
	/** 店舗名 */
	private String shopNm = null;
	/** 店舗枝番 */
	private String shopSbno = null;
	/** 表示店舗枝番 */
	private String dispShopSbno = null;
	/** 回収日 */
	private String cld = null;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public Acech31Dto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		cstCd = null;
		cstNm = null;
		shopCd = null;
		shopNm = null;
		shopSbno = null;
		cld = null;

	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getCstCd() {
		return cstCd;
	}
	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}
	public String getCstNm() {
		return cstNm;
	}
	public void setCstNm(String cstNm) {
		this.cstNm = cstNm;
	}
	public String getShopCd() {
		return shopCd;
	}
	public void setShopCd(String shopCd) {
		this.shopCd = shopCd;
	}
	public String getShopNm() {
		return shopNm;
	}
	public void setShopNm(String shopNm) {
		this.shopNm = shopNm;
	}
	public String getShopSbno() {
		return shopSbno;
	}
	public void setShopSbno(String shopSbno) {
		this.shopSbno = shopSbno;
	}
	public String getDispShopSbno() {
		return dispShopSbno;
	}
	public void setDispShopSbno(String dispShopSbno) {
		this.dispShopSbno = dispShopSbno;
	}
	public String getCld() {
		return cld;
	}
	public void setCld(String cld) {
		this.cld = cld;
	}


}
