/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AbiamBusinessBase.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.business;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.b.iam.dto.AbiamDropDownList;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallConst.ScrExp;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.cls.AmclsBusinessPcBase;
import jp.co.hitachi.a.m.dto.AmdtoDropDownList;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;

/*****************************************************************************************
 * AbiamBusinessBaseクラス<br>
 *****************************************************************************************/
public abstract class AbiamBusinessBase extends AmclsBusinessPcBase {

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  mapping
	 * @param  form
	 * @param  request
	 * @param  response
	 * @param  context
	 * @param  gid
	 * @param  event
	 * @return 無し
	 ************************************************************************************/
	public AbiamBusinessBase(HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);
	}


	/*************************************************************************************
	 * 画面一覧取得処理
	 * <p>
	 * 画面データの一覧を取得する
	 * 項目マスタにデータが存在する画面マスタの名称一覧とする
	 * プルダウンリストとして扱えるようにAmdtoDropDownList形式で返却
	 * </p>
	 * @param  なし
	 * @return AmdtoDropDownListのリスト
	 ************************************************************************************/
	protected List<AmdtoDropDownList> getScreenList() throws AmallException, Exception {

		String methodName = "getScreenList()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<AmdtoDropDownList> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	A.SCREEN_CD");
			sql.append(",	A.SCREEN_NM");
			sql.append("  FROM");
			sql.append("  	N_SCREEN_M A");
			sql.append(" WHERE");
			sql.append("	EXISTS (");
			sql.append("			SELECT");
			sql.append("				B.SCREEN_CD");
			sql.append("			  FROM");
			sql.append("				N_ITEM_M B");
			sql.append("			 WHERE");
			sql.append("				B.SCREEN_CD = A.SCREEN_CD");
			sql.append("				AND B.DEL_FLG = ?");
			sql.append("			)");
			sql.append("	AND A.DEL_FLG =  ?");
			sql.append(" ORDER BY");
			sql.append("	A.SCREEN_CD");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			m_DbAccess.setString(1, AmallConst.DEFAULT_DEL_FLG);
			m_DbAccess.setString(2, AmallConst.DEFAULT_DEL_FLG);
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				AmdtoDropDownList dto = new AmdtoDropDownList();
				// コード値
				dto.setId(m_DbAccess.getString(rs, "SCREEN_CD"));
				// 名称
				dto.setName(m_DbAccess.getString(rs, "SCREEN_NM"));
				// リストに追加
				retList.add(dto);
			}
			return retList;
		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}
	/*************************************************************************************
	 * 画面(メニュー)一覧取得処理
	 * <p>
	 * 画面(メニュー)データの一覧を取得する
	 * メニュー表示可否がON(1)のデータを取得する
	 * プルダウンリストとして扱えるようにAbiamDropDownList形式で返却
	 * </p>
	 * @param  なし
	 * @return AbiamDropDownListのリスト
	 ************************************************************************************/
	protected List<AbiamDropDownList> getScreenMenuList() throws AmallException, Exception {

		String methodName = "getScreenMenuList()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<AbiamDropDownList> retList = new ArrayList<>();
		// 空のリスト追加
		AbiamDropDownList empty = new AbiamDropDownList();
		empty.setId("");
		empty.setName("");
		empty.setDataVal("");
		retList.add(empty);

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	SCREEN_CD");
			sql.append(",	MENU_NM");
			sql.append(",	MENU_GRP_CD");
			sql.append("  FROM");
			sql.append("  	N_MENU_M");
			sql.append(" WHERE");
			sql.append("	VISIBLE = ?");
			sql.append("	AND DEL_FLG =  ?");
			sql.append(" ORDER BY");
			sql.append("	SCREEN_CD");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			m_DbAccess.setString(1, ScrExp.DISPLAY_ON);
			m_DbAccess.setString(2, AmallConst.DEFAULT_DEL_FLG);
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				AbiamDropDownList dto = new AbiamDropDownList();
				// コード値
				dto.setId(m_DbAccess.getString(rs, "SCREEN_CD"));
				// 名称
				dto.setName(m_DbAccess.getString(rs, "MENU_NM"));
				// 拡張データ
				dto.setDataVal(m_DbAccess.getString(rs, "MENU_GRP_CD"));

				// リストに追加
				retList.add(dto);
			}
			return retList;
		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}
	/*************************************************************************************
	 * 画面(メニューグループ)一覧取得処理
	 * <p>
	 * 画面(メニューグループ)データの一覧を取得する
	 * 親グループコードと値が一致しているorしていないデータの一覧を取得する
	 * メニューとして表示しない表示パターン3は除外する
	 * プルダウンリストとして扱えるようにAbiamDropDownList形式で返却
	 * </p>
	 * @param  category カテゴリフラグ true:カテゴリ false:メニュー
	 * @return AbiamDropDownListのリスト
	 ************************************************************************************/
	protected List<AbiamDropDownList> getMenuGrpList(boolean category) throws AmallException, Exception {

		String methodName = "getScreenMenuList()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<AbiamDropDownList> retList = new ArrayList<>();
		// 空のリスト追加
		AbiamDropDownList empty = new AbiamDropDownList();
		empty.setId("");
		empty.setName("");
		empty.setDataVal("");
		retList.add(empty);

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	MENU_GRP_CD");
			sql.append(",	MENU_GRP_NM");
			sql.append(",	PARENT_MENU_GRP_CD");
			sql.append("  FROM");
			sql.append("  	N_MENU_GRP_M");
			sql.append(" WHERE");
			if (category) {
				sql.append("	MENU_GRP_CD = PARENT_MENU_GRP_CD");
			} else {
				sql.append("	MENU_GRP_CD <> PARENT_MENU_GRP_CD");
			}
			sql.append("	AND (DISP_TYPE <>  ? OR DISP_TYPE IS NULL)");
			sql.append("	AND DEL_FLG =  ?");
			sql.append(" ORDER BY");
			sql.append("	MENU_GRP_CD");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			m_DbAccess.setString(1, ScrExp.DISP_TYPE_OFF);
			m_DbAccess.setString(2, AmallConst.DEFAULT_DEL_FLG);
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				AbiamDropDownList dto = new AbiamDropDownList();
				// コード値
				dto.setId(m_DbAccess.getString(rs, "MENU_GRP_CD"));
				// 名称
				dto.setName(m_DbAccess.getString(rs, "MENU_GRP_NM"));
				// 拡張データ
				dto.setDataVal(m_DbAccess.getString(rs, "PARENT_MENU_GRP_CD"));

				// リストに追加
				retList.add(dto);
			}
			return retList;
		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	/*************************************************************************************
	 * 権限ロール一覧取得処理
	 * <p>
	 * 権限ロールの一覧を取得する
	 * プルダウンリストとして扱えるようにAmdtoDropDownList形式で返却
	 * </p>
	 * @param  無し
	 * @return AmdtoDropDownListのリスト
	 ************************************************************************************/
	protected List<AmdtoDropDownList> getAuthRoleList() throws AmallException, Exception {


		String methodName = "getAuthRoleList()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<AmdtoDropDownList> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	ROLE_GRP_CD");
			sql.append(",	ROLE_GRP_NM");
			sql.append("  FROM");
			sql.append("  	N_ROLE_GRP_M");
			sql.append(" WHERE");
			sql.append("	DEL_FLG =  ?");
			sql.append(" ORDER BY");
			sql.append("	ROLE_GRP_CD");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			m_DbAccess.setString(1, AmallConst.DEFAULT_DEL_FLG);
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				AmdtoDropDownList dto = new AmdtoDropDownList();
				// コード値
				dto.setId(m_DbAccess.getString(rs, "ROLE_GRP_CD"));
				// 名称
				dto.setName(m_DbAccess.getString(rs, "ROLE_GRP_NM"));
				// リストに追加
				retList.add(dto);
			}
			return retList;
		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}

	/*************************************************************************************
	 * 表示可否一覧取得処理
	 * <p>
	 * 表示可否の一覧を取得する
	 * プルダウンリストとして扱えるようにAmdtoDropDownList形式で返却
	 * </p>
	 * @param  systemDt 業務日付
	 * @return AmdtoDropDownListのリスト
	 ************************************************************************************/
	protected List<AmdtoDropDownList> getDispProprietyList(String systemDt) {

		// 返却リストの作成
		List<AmdtoDropDownList> retList = new ArrayList<>();

		// 汎用マスタから取得
		List<AmdtoGeneralMst> mstListData = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.DISP_AUTH_LIST, null, null, systemDt);

		// プルダウンデータの生成
		for (AmdtoGeneralMst mst : mstListData) {
			AmdtoDropDownList dto = new AmdtoDropDownList();
			// コード値
			dto.setId(mst.getGeneralCd1());
			// 名称
			dto.setName(mst.getGeneralNm1());

			// リストに追加
			retList.add(dto);
		}
		return retList;

	}

	/*************************************************************************************
	 * 編集可否一覧取得処理
	 * <p>
	 * 表示可否の一覧を取得する
	 * プルダウンリストとして扱えるようにAmdtoDropDownList形式で返却
	 * </p>
	 * @param  systemDt 業務日付
	 * @return AmdtoDropDownListのリスト
	 ************************************************************************************/
	protected List<AmdtoDropDownList> getEditProprietyList(String systemDt) {
		// 返却リストの作成
		List<AmdtoDropDownList> retList = new ArrayList<>();

		// 汎用マスタから取得
		List<AmdtoGeneralMst> mstListData = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.EDIT_AUTH_LIST, null, null, systemDt);

		// プルダウンデータの生成
		for (AmdtoGeneralMst mst : mstListData) {
			AmdtoDropDownList dto = new AmdtoDropDownList();
			// コード値
			dto.setId(mst.getGeneralCd1());
			// 名称
			dto.setName(mst.getGeneralNm1());

			// リストに追加
			retList.add(dto);
		}
		return retList;
	}
	/*************************************************************************************
	 * 表示可否未設定一覧取得処理
	 * <p>
	 * 表示可否未設定の一覧を取得する
	 * プルダウンリストとして扱えるようにAmdtoDropDownList形式で返却
	 * </p>
	 * @param  systemDt 業務日付
	 * @return AmdtoDropDownListのリスト
	 ************************************************************************************/
	protected List<AmdtoDropDownList> getIndDispProprietyList(String systemDt) {

		// 返却リストの作成
		List<AmdtoDropDownList> retList = new ArrayList<>();

		// 汎用マスタから取得
		List<AmdtoGeneralMst> mstListData = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.IND_DISP_AUTH_LIST, null, null, systemDt);

		// プルダウンデータの生成
		for (AmdtoGeneralMst mst : mstListData) {
			AmdtoDropDownList dto = new AmdtoDropDownList();
			// コード値
			dto.setId(mst.getGeneralCd1());
			// 名称
			dto.setName(mst.getGeneralNm1());

			// リストに追加
			retList.add(dto);
		}
		return retList;

	}

	/*************************************************************************************
	 * 分類一覧取得処理
	 * <p>
	 * 分類の一覧を取得する
	 * プルダウンリストとして扱えるようにAmdtoDropDownList形式で返却
	 * </p>
	 * @param  systemDt 業務日付
	 * @return AmdtoDropDownListのリスト
	 ************************************************************************************/
	protected List<AmdtoDropDownList> getClsProprietyList(String systemDt) {

		// 返却リストの作成
		List<AmdtoDropDownList> retList = new ArrayList<>();

		// 初期値の設定
		AmdtoDropDownList init = new AmdtoDropDownList();
		// コード値
		init.setId(null);
		// 名称
		init.setName("");
		// リストに追加
		retList.add(init);

		// 汎用マスタから取得
		List<AmdtoGeneralMst> mstListData = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.IND_AUTH_PRIORITY, null, null, systemDt);

		// プルダウンデータの生成
		for (AmdtoGeneralMst mst : mstListData) {
			AmdtoDropDownList dto = new AmdtoDropDownList();
			// コード値
			dto.setId(mst.getGeneralCd1());
			// 名称
			dto.setName(mst.getGeneralNm1());

			// リストに追加
			retList.add(dto);
		}
		return retList;

	}
}
