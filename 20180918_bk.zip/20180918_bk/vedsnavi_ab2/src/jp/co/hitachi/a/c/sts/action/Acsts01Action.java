/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acsts01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.sts.action;

import jp.co.hitachi.a.c.sts.bean.Acsts01DispBean;
import jp.co.hitachi.a.c.sts.business.Acsts01Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Acsts01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Acsts01DispBean acsts01DispBean;

	/**
	 * 引継ぎ項目
	 */
	/** 画面タイプ */
	private String type = null;
	/** 検索データ */
	private String data = null;
	/** 検索値が入力されている親画面の入力欄のID */
	private String sndid = null;
	/** 検索結果を設定する親画面の表示欄のID */
	private String rcvid = null;
	/** 呼び出し元親画面の画面ID */
	private String callgid = null;
	/** 顧客コード */
	private String cstcdid = null;
	/** 顧客名 */
	private String cstnmid = null;
	/** 顧客データ */
	private String cstdata = null;
	/** 店舗コード */
	private String shopcdid = null;
	/** 店舗名 */
	private String shopnmid = null;
	/** 店舗データ */
	private String shopdata = null;

	/**
	 * 入力項目
	 */
	/** 顧客コード */
	private String inputCustomerCd = null;
	/** 顧客名 */
	private String inputCustomerNm = null;
	/** 店舗コード */
	private String inputShopCd = null;
	/** 店舗名 */
	private String inputShopNm = null;
	/** ユーザーID */
	private String inputUserId = null;
	/** ユーザー名 */
	private String inputUserNm = null;

	/** 保存顧客コード */
	private String savedCustomerCd = null;
	/** 保存顧客名 */
	private String savedCustomerNm = null;
	/** 保存店舗コード */
	private String savedShopCd = null;
	/** 保存店舗名 */
	private String savedShopNm = null;
	/** 保存ユーザーID */
	private String savedUserId = null;
	/** 保存ユーザー名 */
	private String savedUserNm = null;

	/** プルダウンリスト選択値 */
	private int dispResults = 0;
	/** ページ番号 */
	private int displayNum = 0;



	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAcsts01DispBean((Acsts01DispBean)request.getAttribute("Acsts01DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Acsts01Business dao = new Acsts01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Acsts01DispBean getAcsts01DispBean() {
		return acsts01DispBean;
	}

	public void setAcsts01DispBean(Acsts01DispBean acsts01DispBean) {
		this.acsts01DispBean = acsts01DispBean;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getSndid() {
		return sndid;
	}

	public void setSndid(String sndid) {
		this.sndid = sndid;
	}

	public String getRcvid() {
		return rcvid;
	}

	public void setRcvid(String rcvid) {
		this.rcvid = rcvid;
	}

	public String getCallgid() {
		return callgid;
	}

	public void setCallgid(String callgid) {
		this.callgid = callgid;
	}

	public String getCstcdid() {
		return cstcdid;
	}

	public void setCstcdid(String cstcdid) {
		this.cstcdid = cstcdid;
	}

	public String getCstnmid() {
		return cstnmid;
	}

	public void setCstnmid(String cstnmid) {
		this.cstnmid = cstnmid;
	}

	public String getCstdata() {
		return cstdata;
	}

	public void setCstdata(String cstdata) {
		this.cstdata = cstdata;
	}

	public String getShopcdid() {
		return shopcdid;
	}

	public void setShopcdid(String shopcdid) {
		this.shopcdid = shopcdid;
	}

	public String getShopnmid() {
		return shopnmid;
	}

	public void setShopnmid(String shopnmid) {
		this.shopnmid = shopnmid;
	}

	public String getShopdata() {
		return shopdata;
	}

	public void setShopdata(String shopdata) {
		this.shopdata = shopdata;
	}

	public String getInputCustomerCd() {
		return inputCustomerCd;
	}

	public void setInputCustomerCd(String inputCustomerCd) {
		this.inputCustomerCd = inputCustomerCd;
	}

	public String getInputCustomerNm() {
		return inputCustomerNm;
	}

	public void setInputCustomerNm(String inputCustomerNm) {
		this.inputCustomerNm = inputCustomerNm;
	}

	public String getInputShopCd() {
		return inputShopCd;
	}

	public void setInputShopCd(String inputShopCd) {
		this.inputShopCd = inputShopCd;
	}

	public String getInputShopNm() {
		return inputShopNm;
	}

	public void setInputShopNm(String inputShopNm) {
		this.inputShopNm = inputShopNm;
	}

	public String getInputUserId() {
		return inputUserId;
	}

	public void setInputUserId(String inputUserId) {
		this.inputUserId = inputUserId;
	}

	public String getInputUserNm() {
		return inputUserNm;
	}

	public void setInputUserNm(String inputUserNm) {
		this.inputUserNm = inputUserNm;
	}

	public String getSavedCustomerCd() {
		return savedCustomerCd;
	}

	public void setSavedCustomerCd(String savedCustomerCd) {
		this.savedCustomerCd = savedCustomerCd;
	}

	public String getSavedCustomerNm() {
		return savedCustomerNm;
	}

	public void setSavedCustomerNm(String savedCustomerNm) {
		this.savedCustomerNm = savedCustomerNm;
	}

	public String getSavedShopCd() {
		return savedShopCd;
	}

	public void setSavedShopCd(String savedShopCd) {
		this.savedShopCd = savedShopCd;
	}

	public String getSavedShopNm() {
		return savedShopNm;
	}

	public void setSavedShopNm(String savedShopNm) {
		this.savedShopNm = savedShopNm;
	}

	public String getSavedUserId() {
		return savedUserId;
	}

	public void setSavedUserId(String savedUserId) {
		this.savedUserId = savedUserId;
	}

	public String getSavedUserNm() {
		return savedUserNm;
	}

	public void setSavedUserNm(String savedUserNm) {
		this.savedUserNm = savedUserNm;
	}

	public int getDispResults() {
		return dispResults;
	}

	public void setDispResults(int dispResults) {
		this.dispResults = dispResults;
	}

	public int getDisplayNum() {
		return displayNum;
	}

	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}


}
