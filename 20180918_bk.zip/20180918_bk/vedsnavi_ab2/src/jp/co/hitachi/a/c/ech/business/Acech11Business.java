/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech11DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.business;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.ech.action.Acech11Action;
import jp.co.hitachi.a.c.ech.bean.Acech11DispBean;
import jp.co.hitachi.a.c.ech.dto.Acech11Dto;
import jp.co.hitachi.a.c.ech.dto.AcechItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.Encode;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallPage;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;
import jp.co.hitachi.a.m.dto.AmdtoPagingSql;

/*****************************************************************************************
 * Acech11Businessクラス<br>
 *****************************************************************************************/
public class Acech11Business extends AcechBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Acech11DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 検索ボタン押下処理 */
	private static final String FORWARD_SEARCH = "SEARCH";
	/** ダウンロード処理 */
	private static final String FORWARD_DOWNLOAD = "DOWNLOAD";
	/** 前頁 */
	private static final String FORWARD_PAGEPREV = "PAGEPREV";
	/** 先頭頁処理 */
	private static final String FORWARD_PAGEFIRST = "PAGEFIRST";
	/** 次頁 */
	private static final String FORWARD_PAGENEXT = "PAGENEXT";
	/** 最終頁 */
	private static final String FORWARD_PAGELAST = "PAGELAST";
	/** 件数変更 */
	private static final String FORWARD_DISPRESULTS = "DISPRESULTS";
	/** 回収実績エリア押下(レジ別一覧へ) */
	private static final String FORWARD_RESULT_REGI = "REGILIST";
	/** 戻るボタン押下 */
	private static final String FORWARD_RETURNPAGE = "RETURNPAGE";
	/** 「戻る」にてページ再表示 */
	public static final String FORWARD_REDISP = "REDISP";

	/**
	 * 画面項目ID
	 */
	/** 画面名 */
	private static final String ITEM_ID_SCREEN_NAME = "ScreenName";
	/** 店舗CD */
	private static final String ITEM_ID_SHOP_CD = "shopCd";
	/** 回収日From */
	private static final String ITEM_ID_CLD_FROM = "cldFrom";
	/** 回収日To */
	private static final String ITEM_ID_CLD_TO = "cldTo";
	/** 回収日 */
	private static final String ITEM_ID_CLD = "cld";

	/** メンバ変数 */
	/** アクションフォーム */
	private Acech11Action m_Acech11Form = null;
	/** 表示用画面Bean */
	private Acech11DispBean m_Acech11DispBean = null;
	/** ページング処理用 */
	private AmallPage m_Page = null;
	/** SQL作成用 */
	private AmdtoPagingSql m_Page_Sql = null;
	/** 画面DTO */
	Acech11Dto m_Acech11Dto;
	/** DTOキー名 */
	private String DTO_ACECH11 = "DTO_ACECH11";
	/** 遷移画面DTO */
	AcechItemDispDto acechInfoDto;
	/** 遷移先画面キー */
	private static final String ACECH_INFO_KEY = "AcechInfo";

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Acech11Business(
			Acech11Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Acech11Business.class.getName();
		m_Acech11Form = form;
		m_Acech11DispBean = new Acech11DispBean();
		m_Page = new AmallPage();
		m_Page_Sql = new AmdtoPagingSql();
		setErrString(gid, m_Acech11Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}
			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Acech11DispBean);

			/* 内部記憶情報の生成 */
			m_Acech11Dto = (Acech11Dto) getSpecifiedDTO(m_Gid, DTO_ACECH11);
			if (m_Acech11Dto == null || FORWARD_DISP.equals(m_Event)) {
				m_Acech11Dto = new Acech11Dto();
				putSpecifiedDTO(m_Gid, DTO_ACECH11, m_Acech11Dto);
			}

			// 遷移元情報取得
			acechInfoDto = (AcechItemDispDto) getSpecifiedDTO(ACECH_INFO_KEY);
			// 検索条件として追加
			if (acechInfoDto != null) {
				m_Acech11Dto.setCldFrom(acechInfoDto.getCld());
				m_Acech11Dto.setCldTo(acechInfoDto.getCld());
				// DTO削除
				delSpecifiedDTO(ACECH_INFO_KEY);
			}

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Acech11Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_SEARCH.equals(m_Event)) {
				// 検索ボタン押下の場合
				forwardStr = search();
			} else if (FORWARD_PAGEFIRST.equals(m_Event)) {
				// "<<"ボタン押下の場合
				forwardStr = pageFirst();
			} else if (FORWARD_PAGEPREV.equals(m_Event)) {
				// "<"ボタン押下の場合
				forwardStr = pagePrev();
			} else if (FORWARD_PAGENEXT.equals(m_Event)) {
				// ">"ボタン押下の場合
				forwardStr = pageNext();
			} else if (FORWARD_PAGELAST.equals(m_Event)) {
				// ">>"ボタン押下の場合
				forwardStr = pageLast();
			} else if (FORWARD_DISPRESULTS.equals(m_Event)) {
				// 表示件数変更の場合
				forwardStr = changeDispRslts();
			} else if (FORWARD_DOWNLOAD.equals(m_Event)) {
				// ダウンロード処理の場合
				forwardStr = download();
			} else if (FORWARD_RESULT_REGI.equals(m_Event)) {
				// レジボタン押下処理の場合
				forwardStr = details();
			} else if (m_Event.equals(FORWARD_RETURNPAGE)) {
				// 戻るボタン押下処理の場合
				forwardStr = returnPage();
			} else if (FORWARD_REDISP.equals(m_Event)) {
				// 戻るボタンでページに戻ってきた場合
				forwardStr = redisp();
			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Acech11DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		// 遷移元情報が存在しない場合
		if (acechInfoDto == null) {
			// エラーメッセージセット
			setMessageInfo(m_Acech11DispBean, AmallMessageConst.MSG_ERR_SELECT_CON_NO_DATA,
					getItemDispName(ITEM_ID_CLD, m_Acech11DispBean));
			return FORWARD_DISP;
		}

		// 検索処理
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ダウンロード処理
	 * <p>
	 * ダウンロード処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String download() throws AmallException {

		// ファイルデータ作成
		List<String> data = new ArrayList<>();

		// 出力ファイル検索
		searchproc();

		// データセット
		if (m_Acech11DispBean.getItemDispList() != null) {
			for (AcechItemDispDto list : m_Acech11DispBean.getItemDispList()) {
				data.add(
						list.getCstCd() + AmallConst.CSV_SEP +
								list.getCstNm() + AmallConst.CSV_SEP +
								list.getShopCd() + AmallConst.CSV_SEP +
								list.getShopNm() + AmallConst.CSV_SEP +
								list.getCld() + AmallConst.CSV_SEP +
								list.getSpccDfemt() + AmallConst.CSV_SEP +
								list.getSpccmTotal() + AmallConst.CSV_SEP +
								list.getSrmTotal());
			}
		}

		// ファイルデータ出力
		AmdtoGeneralMst dlFileDto = AmallUtilities.getGeneralMstDataRecord(m_DbAccess, GeneralMstKey.CSV_DOWNLOAD_FILE,
				m_Gid, null, m_Acech11DispBean.getServiceDate());
		m_Acech11Form.setDownloadFileData(data, dlFileDto.getGeneralNm1(), Encode.SHIFT_JIS);

		return FORWARD_DOWNLOAD;
	}

	/*************************************************************************************
	 * 検索ボタン押下処理実行
	 * <p>
	 * 検索ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String search() throws AmallException, Exception {

		// 入力条件妥当性チェック
		if (!proprietyCheck()) {
			return FORWARD_DISP;
		}

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * "<"ボタン押下処理実行
	 * <p>
	 * "<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pagePrev() throws AmallException, Exception {

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * "<<"ボタン押下処理実行
	 * <p>
	 * "<<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageFirst() throws AmallException, Exception {

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ">"ボタン押下処理実行
	 * <p>
	 * ">"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageNext() throws AmallException, Exception {

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ">>"ボタン押下処理実行
	 * <p>
	 * ">>"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageLast() throws AmallException, Exception {

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 表示件数変更処理実行
	 * <p>
	 * 表示件数変更処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String changeDispRslts() throws AmallException, Exception {

		// 検索処理を呼ぶ
		searchproc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 詳細ボタン押下処理
	 * <p>
	 * 詳細ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String details() throws AmallException {

		// 選択列をdtoにセット
		AcechItemDispDto dto = new AcechItemDispDto();
		dto.setCld(AmallUtilities.changeFormat422(m_Acech11Form.getDe_cld()));
		dto.setCstCd(m_Acech11Form.getDe_cstCd());
		dto.setShopCd(m_Acech11Form.getDe_shopCd());
		putSpecifiedDTO(ACECH_INFO_KEY, dto);

		return FORWARD_RESULT_REGI;
	}

	/*************************************************************************************
	 * 戻るボタン押下処理実行
	 * <p>
	 * 戻る変更押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String returnPage() throws AmallException {

		// 画面DTO削除
		deleteSpecifiedDTO(m_Gid);

		return FORWARD_RETURNPAGE;
	}

	/*************************************************************************************
	 * 再表示処理
	 * <p>
	 * 「戻る」ボタンで戻ってきた場合の再表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String redisp() throws AmallException {

		// 検索処理
		searchproc();

		return FORWARD_DISP;

	}

	/*************************************************************************************
	 * 入力項目妥当性チェック
	 * <p>
	 * 入力項目妥当性チェックを実行する
	 * </p>
	 * @return boolean
	 ************************************************************************************/
	private boolean proprietyCheck() throws AmallException {
		String methodName = "proprietyCheck()";
		try {

			// 返却用フラグ
			boolean ret = true;
			// 入力情報
			String shopCd = m_Acech11Form.getSearchShopCd();
			String cldFrom = m_Acech11Form.getCldFrom();
			String cldTo = m_Acech11Form.getCldTo();
			String shopNm = null;

			// 入力値チェック(店舗コード)
			if (!AmallUtilities.isEmpty(shopCd)) {
				// 入力値が存在する場合
				if (!AmallUtilities.isHalfWidthCharacterKind(shopCd, AmallUtilities.H_NUM | AmallUtilities.H_ALP)) {
					// 半角英数字以外が設定されている
					setMessageInfo(m_Acech11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_SHOP_CD, m_Acech11DispBean), String.valueOf(InputNum.SHOP_CD));
					setError(m_Acech11DispBean, ITEM_ID_SHOP_CD);
					ret = false;
				} else if (AmallUtilities.getLengthAsHalf(shopCd) > InputNum.SHOP_CD) {
					// 10桁より多い英数字が設定されている
					setMessageInfo(m_Acech11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_SHOP_CD, m_Acech11DispBean), String.valueOf(InputNum.SHOP_CD));
					setError(m_Acech11DispBean, ITEM_ID_SHOP_CD);

					ret = false;
				}
				// 店舗名検索処理
				if (ret) {
					shopNm = searchShopNm();
				}

			}

			// 日付妥当性チェック
			if (!AmallUtilities.isEmpty(cldFrom)) {
				if (cldFrom.length() != 10) {
					if (cldFrom.length() == 8) {
						// 「/」が含まれていない日付の場合挿入
						cldFrom = AmallUtilities.changeFormat(cldFrom);
					} else {
						setMessageInfo(m_Acech11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_DATE_ERROR, "", "");
						setError(m_Acech11DispBean, ITEM_ID_CLD_FROM);
						ret = false;
					}
				}
				if (!AmallUtilities.checkExistDate(cldFrom)) {
					// 正しい日付か
					setMessageInfo(m_Acech11DispBean, AmallMessageConst.MSG_ERR_NOT_EXIST_DATE,
							getItemDispName(ITEM_ID_CLD_FROM, m_Acech11DispBean), String.valueOf(InputNum.SHOP_CD));
					setError(m_Acech11DispBean, ITEM_ID_CLD_FROM);
					ret = false;
				}
			}

			// 日付妥当性チェック
			if (!AmallUtilities.isEmpty(cldTo)) {
				if (cldTo.length() != 10) {
					if (cldTo.length() == 8) {
						// 「/」が含まれていない日付の場合挿入
						cldTo = AmallUtilities.changeFormat(cldTo);
					} else {
						setMessageInfo(m_Acech11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_DATE_ERROR, "", "");
						setError(m_Acech11DispBean, ITEM_ID_CLD_FROM);
						ret = false;
					}
				}
				if (!AmallUtilities.checkExistDate(cldTo)) {
					// 正しい日付か
					setMessageInfo(m_Acech11DispBean, AmallMessageConst.MSG_ERR_NOT_EXIST_DATE,
							getItemDispName(ITEM_ID_CLD_TO, m_Acech11DispBean), String.valueOf(InputNum.SHOP_CD));
					setError(m_Acech11DispBean, ITEM_ID_CLD_TO);
					ret = false;
				}

			}

			if (!AmallUtilities.isEmpty(cldFrom) && !AmallUtilities.isEmpty(cldTo)) {
				if (AmallUtilities.checkExistDate(cldFrom) && AmallUtilities.checkExistDate(cldTo)) {
					if (AmallUtilities.diffDate(AmallUtilities.changeFormat422(cldFrom),
							AmallUtilities.changeFormat422(cldTo)) < 0) {
						// From-To逆転
						setMessageInfo(m_Acech11DispBean, AmallMessageConst.MSG_ERR_REV_LARGE_SMALL_DATE,
								"");
						setError(m_Acech11DispBean, ITEM_ID_CLD_FROM);
						setError(m_Acech11DispBean, ITEM_ID_CLD_TO);
						ret = false;
					}
				}

			}
			if (ret) {
				// フラグがtrueならば検索条件をDTOに追加
				m_Acech11Dto.setShopCd(shopCd);
				m_Acech11Dto.setShopNm(shopNm);
				m_Acech11Dto.setCldFrom(AmallUtilities.changeFormat422(cldFrom));
				m_Acech11Dto.setCldTo(AmallUtilities.changeFormat422(cldTo));
				m_Acech11Dto.setDefFlg(m_Acech11Form.getDefFlg());
			}

			return ret;

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

	}

	/*************************************************************************************
	 * 検索処理実行
	 * <p>
	 * 検索処理を実行する
	 * </p>
	 * @param  なし
	 * @return なし
	 ************************************************************************************/
	private String searchproc() throws AmallException {
		// methodName
		String methodName = "searchproc()";
		// 明細部用LIST
		List<AcechItemDispDto> detailList = new ArrayList<>();

		// システム日付取得
		String systemDt = m_Acech11DispBean.getServiceDate();

		// 検索条件
		String cldFrom = m_Acech11Dto.getCldFrom();
		String cldTo = m_Acech11Dto.getCldTo();
		String shopCd = m_Acech11Dto.getShopCd();
		boolean defFlg = m_Acech11Dto.isDefFlg();

		try {

			// 検索フォーム値セット
			m_Acech11Form.setSearchShopCd(shopCd);
			m_Acech11Form.setSearchShopNm(m_Acech11Dto.getShopNm());
			m_Acech11Form.setCldFrom(AmallUtilities.changeFormat(cldFrom));
			m_Acech11Form.setCldTo(AmallUtilities.changeFormat(cldTo));
			m_Acech11Form.setDefFlg(defFlg);

			// SQL作成
			makeSearchSql(shopCd, cldFrom, cldTo, defFlg, systemDt);

			// select句
			String sqlSelect = m_Page_Sql.getSqlSelect();
			// from where 句
			String sqlCondition = m_Page_Sql.getSqlConditinon();
			// order 句
			String sqlOrder = m_Page_Sql.getSqlOrder();
			// param 句
			String[] sqlParam = m_Page_Sql.getSqlParam();
			// 表示件数
			int pageDispCnt = m_Page_Sql.getPageDispCnt();
			// ページ番号
			int pageNo = m_Acech11Dto.getDisplayNum();

			List<Map<String, String>> pageData;
			if (m_Event.equals(FORWARD_DISP)) { // 初期検索状態
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEFIRST)) { // "<<"ボタン押下時
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEPREV)) { // "<"ボタン押下時
				pageData = m_Page.getPrevPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGENEXT)) { // ">"ボタン押下時
				pageData = m_Page.getNextPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGELAST)) { // ">>"ボタン押下時
				pageData = m_Page.getLastPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else { // 検索ボタン押下時、その他
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			}

			/* 表示頁NOのセット */
			m_Acech11Dto.setDisplayNum(m_Page.getNowPage());
			m_Acech11DispBean.setDisplayNum(m_Acech11Dto.getDisplayNum());

			/* ページ遷移ボタンセット */
			if (!m_Page.isPrevPageExist()) {
				m_Acech11DispBean.setPrevPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Acech11DispBean.setPrevPageFlg(AmallConst.GeneralFlg.OFF);
			}
			if (!m_Page.isNextPageExist()) {
				m_Acech11DispBean.setNextPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Acech11DispBean.setNextPageFlg(AmallConst.GeneralFlg.OFF);
			}

			// 件数セット
			m_Acech11DispBean.setDispCountDefault(String.valueOf(pageDispCnt));

			// ページ情報がない場合
			if (pageData == null) {
				// エラーメッセージをセット
				setMessageInfo(m_Acech11DispBean, AmallMessageConst.MSG_INF_SEARCH_CON_NO_DATA, "");
				return FORWARD_DISP;

			}

			/** 明細部リスト作成 **/
			if (m_Event.equals(FORWARD_DOWNLOAD)) {
				// DL用リスト作成
				detailList = makeDetailDlList(pageData);
			} else {
				detailList = makeDetailList(pageData);
			}

			/* 表示Beanに一覧データをセット */
			m_Acech11DispBean.setItemDispList(detailList);

			/** 正常終了 */
			return FORWARD_DISP;

		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					getItemDispName(ITEM_ID_SCREEN_NAME, m_Acech11DispBean));
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * SQL作成
	 * <p>
	 * SQLを作成する
	 * </p>
	 * @param shopCd 店舗CD
	 * @param cldFrom 回収From
	 * @param cldTo 回収To
	 * @param defFlg 誤差フラグ
	 * @param systemDt システム日付
	 * @return なし
	 ************************************************************************************/
	protected void makeSearchSql(String shopCd, String cldFrom, String cldTo, boolean defFlg, String systemDt)
			throws AmallException, Exception {
		// メソッド名
		String methodName = "makeSearchSql()";

		StringBuffer sql = new StringBuffer();
		// SQLバインド用リスト
		List<String> bindParam = new ArrayList<String>();

		try {

			// 1ページの表示件数
			// 初期表示はデフォルト値を設定する
			if (m_Event.equals(FORWARD_DISP) || m_Event.equals(FORWARD_REDISP)) {
				m_Page_Sql.setPageDispCnt(Integer.parseInt(m_Acech11DispBean.getDispCountDefault()));
			} else if (m_Event.equals(FORWARD_SEARCH)) {
				// 検索ボタン押下時に表示検索がないときはデフォルト値とする
				int dispCnt = m_Acech11Form.getDispResults();
				if (dispCnt == 0) {
					m_Page_Sql.setPageDispCnt(Integer.parseInt(m_Acech11DispBean.getDispCountDefault()));
				} else {
					m_Page_Sql.setPageDispCnt(dispCnt);
				}
			} else {
				m_Page_Sql.setPageDispCnt(m_Acech11Form.getDispResults());
			}

			// SQL SELECT
			sql.delete(0, sql.length());
			sql.append("SELECT *");
			String sqlSelect = sql.toString();

			// SQL FROM
			sql.delete(0, sql.length());
			sql.append(" FROM (");
			sql.append("SELECT");
			sql.append(" ncd.CST_CD AS CST_CD");
			sql.append(", ncm.CST_NM AS CST_NM");
			sql.append(", ncd.SHOP_CD AS SHOP_CD");
			sql.append(", nsm.SHOP_NM AS SHOP_NM");
			sql.append(", nscm.COMPANY_SHOP_CD AS COMPANY_SHOP_CD");
			sql.append(", nscm.COMPANY_SHOP_NM AS COMPANY_SHOP_NM");
			sql.append(", ncd.CLD AS CLD");
			sql.append(", SUM(ncd.SPCC_DFEMT) AS SPCC_DFEMT");
			sql.append(", SUM(ncd.SRMT) AS SRMT");
			sql.append(", SUM(ncd.SPCCMT) AS SPCCMT");

			// 副問い合わせ
			sql.append(", (");
			sql.append("SELECT");
			sql.append(" NVL(sub.SPCC_DFEMT,0)");
			sql.append(" FROM");
			sql.append("  N_CLMY_DAT sub");
			sql.append(" WHERE");
			sql.append("  sub.spcc_dfemt != 0");
			sql.append("  AND   sub.CST_CD = ncd.CST_CD");
			sql.append("  AND   sub.SHOP_CD = ncd.SHOP_CD");
			sql.append("  AND   sub.CLD = ncd.CLD");
			sql.append("  AND	sub.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append("  AND   ROWNUM = 1");
			sql.append(" ) AS DEF_FLG");

			// FROM句
			sql.append(" FROM");
			sql.append(" N_CLMY_DAT ncd");
			sql.append(" LEFT JOIN");
			sql.append(" 	N_CST_M ncm");
			sql.append(" 	ON ncd.CST_CD = ncm.CST_CD");
			sql.append(" 	AND ncm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" LEFT JOIN");
			sql.append(" 	N_SHOP_M nsm");
			sql.append(" 	ON ncd.CST_CD = nsm.CST_CD");
			sql.append(" 	AND ncd.SHOP_CD = nsm.SHOP_CD");
			sql.append(" 	AND nsm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" 	AND ? BETWEEN");
			bindParam.add(systemDt);
			sql.append(" 	 	nsm.EFST_DY AND nsm.EFED_DY");
			sql.append(" LEFT JOIN");
			sql.append(" 	N_SHOP_CNV_M nscm");
			sql.append(" 	ON ncd.CST_CD = nscm.CST_CD");
			sql.append(" 	AND nsm.SHOP_CD = nscm.SHOP_CD");
			sql.append(" 	AND nscm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" 	AND ? BETWEEN");
			bindParam.add(systemDt);
			sql.append(" 	 	nscm.EFST_DY AND nscm.EFED_DY");

			// WHERE 句
			sql.append(" WHERE");
			sql.append(" ncd.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);

			// 全店舗判定
			if (!m_Acech11DispBean.isShopCdAllFlg()) {
				// 全顧客・全店舗ではない場合
				sql.append("	AND (");
				boolean first = true;
				for (Entry<String, List<String>> entry : m_Acech11DispBean.getShopCdListMap().entrySet()) {

					String appCstCd = entry.getKey();
					for (String appShop : entry.getValue()) {
						if (first) {
							sql.append("		(");
							first = false;
						} else {
							sql.append("		OR (");
						}
						sql.append("			nsm.CST_CD = '").append(appCstCd).append("'");
						sql.append("			AND");
						sql.append("			nsm.SHOP_CD = '").append(appShop).append("'");
						sql.append("		)");
					}
				}
				sql.append("	)");
			}


			// 検索条件に値が入っている場合
			if (!AmallUtilities.isEmpty(cldFrom)) {
				// 回収From
				sql.append(" AND ncd.CLD >= ?");
				bindParam.add(cldFrom);
			}
			if (!AmallUtilities.isEmpty(cldTo)) {
				// 回収To
				sql.append(" AND ncd.CLD <= ?");
				bindParam.add(cldTo);
			}
			if (!AmallUtilities.isEmpty(shopCd)) {
				// 店舗コードが存在する場合(お客様店舗コードも検索対象)
				sql.append("	AND (");
				sql.append("		ncd.SHOP_CD = ?");
				sql.append("		OR");
				sql.append("		TRIM(nscm.COMPANY_SHOP_CD) = ?");
				sql.append("	)");
				bindParam.add(shopCd);
				bindParam.add(shopCd);
			}
			sql.append(" GROUP BY" +
					"    ncd.CST_CD," +
					"    ncm.CST_NM," +
					"    ncd.SHOP_CD," +
					"    nsm.SHOP_NM," +
					"    nscm.COMPANY_SHOP_CD," +
					"    nscm.COMPANY_SHOP_NM," +
					"    ncd.CLD");

			// SQL ORDER
			sql.append(" ORDER BY ncd.CST_CD,  ncd.SHOP_CD, ncd.CLD");
			sql.append(" )");
			// 誤差チェック
			if (defFlg) {
				sql.append(" WHERE");
				sql.append(" DEF_FLG IS NOT NULL");
			}
			String sqlCondition = sql.toString();

			// リストを配列に
			String[] sqlParam = bindParam.toArray(new String[bindParam.size()]);

			// セット処理
			m_Page_Sql.setSqlSelect(sqlSelect);
			m_Page_Sql.setSqlConditinon(sqlCondition);
			m_Page_Sql.setSqlOrder("");
			m_Page_Sql.setSqlParam(sqlParam);

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 明細リスト作成処理
	 * <p>
	 * 明細リスト作成処理を実行する
	 * </p>
	 * @param	pageData	頁データ
	 * @return 明細ArrayList
	 ************************************************************************************/
	private List<AcechItemDispDto> makeDetailList(List<Map<String, String>> pageData)
			throws AmallException {
		List<AcechItemDispDto> retList = new ArrayList<>();
		String methodName = "makeDetailList()";
		try {
			// ページ情報をリストに追加
			for (Map<String, String> map : pageData) {
				AcechItemDispDto listdto = new AcechItemDispDto();
				// お客様CD
				listdto.setCstCd(map.get("CST_CD"));
				// お客様名
				listdto.setCstNm(map.get("CST_NM"));

				// 企業店舗コード、名称がある場合は企業店舗を優先
				if (!AmallUtilities.isEmpty(map.get("COMPANY_SHOP_CD"))
						|| !AmallUtilities.isEmpty(map.get("COMPANY_SHOP_NM"))) {
					// 企業店舗コード
					listdto.setShopCd(map.get("COMPANY_SHOP_CD"));
					// 企業店舗名称
					listdto.setShopNm(map.get("COMPANY_SHOP_NM"));
				} else {
					// 店舗コード
					listdto.setShopCd(AmallUtilities.changeFormatShopCd(map.get("SHOP_CD")));
					// 店舗名称
					listdto.setShopNm(map.get("SHOP_NM"));
				}
				// 遷移用店舗CD
				listdto.setShopCdsp(map.get("SHOP_CD"));

				// 回収日
				listdto.setCld(AmallUtilities.changeFormat(map.get("CLD")));

				// 差額
				if (!AmallUtilities.isEmpty(map.get("DEF_FLG"))) {
					// 差額がある場合フラグをオン
					listdto.setDefFlg(AmallConst.GeneralFlg.ON);
				}
				listdto.setSpccDfemt(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, Integer.parseInt(map.get("SPCC_DFEMT")))
								+ AmallConst.DEFAULT_MONEY_JA);
				// 金種票登録合計
				listdto.setSrmTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, Integer.parseInt(map.get("SRMT")))
								+ AmallConst.DEFAULT_MONEY_JA);
				// 精査金額計
				listdto.setSpccmTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, Integer.parseInt(map.get("SPCCMT")))
								+ AmallConst.DEFAULT_MONEY_JA);
				// 返却リストに追加
				retList.add(listdto);
			}

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

		return retList;
	}

	/*************************************************************************************
	 * DL用明細リスト作成処理
	 * <p>
	 * DL用明細リスト作成処理を実行する
	 * </p>
	 * @param	pageData	頁データ
	 * @return DL用明細ArrayList
	 ************************************************************************************/
	private List<AcechItemDispDto> makeDetailDlList(List<Map<String, String>> pageData)
			throws AmallException {
		List<AcechItemDispDto> retList = new ArrayList<>();
		String methodName = "makeDetailDlList(List<Map<String, String>> pageData)";
		try {
			// ページ情報をリストに追加
			for (Map<String, String> map : pageData) {
				AcechItemDispDto listdto = new AcechItemDispDto();
				// お客様CD
				listdto.setCstCd(map.get("CST_CD"));
				// お客様名
				listdto.setCstNm(map.get("CST_NM"));

				// 企業店舗コードがある場合は企業店舗コードを優先
				if (!AmallUtilities.isEmpty(map.get("COMPANY_SHOP_CD"))
						|| !AmallUtilities.isEmpty(map.get("COMPANY_SHOP_NM"))) {
					// 企業店舗コード
					listdto.setShopCd(map.get("COMPANY_SHOP_CD"));
					// 企業店舗名称
					listdto.setShopNm(map.get("COMPANY_SHOP_NM"));
				} else {
					// 店舗コード
					listdto.setShopCd(AmallUtilities.changeFormatShopCd(map.get("SHOP_CD")));
					// 店舗名称
					listdto.setShopNm(map.get("SHOP_NM"));
				}

				// 回収日
				listdto.setCld(AmallUtilities.changeFormat(map.get("CLD")));
				// 差額
				listdto.setSpccDfemt(map.get("SPCC_DFEMT"));
				// 金種票登録合計
				listdto.setSrmTotal(map.get("SRMT"));
				// 精査金額計
				listdto.setSpccmTotal(map.get("SPCCMT"));
				// 返却リストに追加
				retList.add(listdto);
			}

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

		return retList;
	}

	/*************************************************************************************
	 * 店舗名検索処理
	 * <p>
	 * 店舗名検索処理を実行する
	 * </p>
	 * @param	なし
	 * @return String 店舗名
	 ************************************************************************************/
	private String searchShopNm() throws AmallException {
		// メソッド名
		String methodName = "searchShopNm()";
		// 結果
		ResultSet rs = null;
		// 返却用文字列
		String shopNm = null;

		// システム日付
		String systemDt = m_Acech11DispBean.getServiceDate();
		// 店舗CD
		String shopCd = m_Acech11Form.getSearchShopCd();

		try {

			if (shopCd == null) {
				return null;
			}

			StringBuffer sql = new StringBuffer();
			List<String> bindParam = new ArrayList<String>();

			sql.append("SELECT");
			sql.append(" nsm.SHOP_NM AS SHOP_NM");
			sql.append(", nscm.COMPANY_SHOP_NM AS COMPANY_SHOP_NM");

			sql.append(" FROM");
			sql.append("  N_SHOP_M nsm");
			sql.append(" LEFT JOIN");
			sql.append("  N_SHOP_CNV_M nscm");
			sql.append("  ON nsm.CST_CD = nscm.CST_CD");
			sql.append("  AND nsm.SHOP_CD = nscm.SHOP_CD");
			sql.append("  AND ? BETWEEN");
			bindParam.add(systemDt);
			sql.append("	nscm.EFST_DY AND nscm.EFED_DY");
			sql.append("  AND nscm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" WHERE");
			sql.append(" ? BETWEEN");
			bindParam.add(systemDt);
			sql.append("	nsm.EFST_DY AND nsm.EFED_DY");
			sql.append("  AND nsm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);

			// 全店舗判定
			if (!m_Acech11DispBean.isShopCdAllFlg()) {
				// 全顧客・全店舗ではない場合
				sql.append("	AND (");
				boolean first = true;
				for (Entry<String, List<String>> entry : m_Acech11DispBean.getShopCdListMap().entrySet()) {

					String appCstCd = entry.getKey();
					for (String appShop : entry.getValue()) {
						if (first) {
							sql.append("		(");
							first = false;
						} else {
							sql.append("		OR (");
						}
						sql.append("			nsm.CST_CD = '").append(appCstCd).append("'");
						sql.append("			AND");
						sql.append("			nsm.SHOP_CD = '").append(appShop).append("'");
						sql.append("		)");
					}
				}
				sql.append("	)");
			}


			// 店舗コード
			sql.append("	AND (");
			sql.append("		nsm.SHOP_CD = ?");
			sql.append("		OR");
			sql.append("		TRIM(nscm.COMPANY_SHOP_CD) = ?");
			sql.append("	)");
			bindParam.add(shopCd);
			bindParam.add(shopCd);

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < bindParam.size(); i++) {
				m_DbAccess.setString(i + 1, bindParam.get(i));
			}

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 実行結果チェック
			while (rs.next()) {
				// データセット
				if (!AmallUtilities.isEmpty(m_DbAccess.getString(rs, "COMPANY_SHOP_NM"))) {
					shopNm = m_DbAccess.getString(rs, "COMPANY_SHOP_NM");
				} else {
					shopNm = m_DbAccess.getString(rs, "SHOP_NM");
				}
			}

			/* StringBuffer 開放  */
			sql.delete(0, sql.length());
			sql = null;

		} catch (AmallException ame) {
			m_DbAccess.rollback();
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					getItemDispName(ITEM_ID_SCREEN_NAME, m_Acech11DispBean));
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

		return shopNm;
	}

}