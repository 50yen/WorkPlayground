/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acsgm01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.sgm.action;

import jp.co.hitachi.a.c.sgm.bean.Acsgm01DispBean;
import jp.co.hitachi.a.c.sgm.business.Acsgm01Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Acsgm01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Acsgm01DispBean acsgm01DispBean;

	/** 顧客入力値 */
	private String inputedCstCd = null;
	/** 顧客名称 */
	private String dispCstNm = null;
	/** 店舗入力値 */
	private String inputedShopCd = null;
	/** 店舗名称 */
	private String dispShopNm = null;
	/** 表示件数 */
	private int dispResults = 0;
	/** ページ番号 */
	private int displayNum = 0;
	/** 店舗グループCD(Hidden) */
	private String shopGrpCdHid = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAcsgm01DispBean((Acsgm01DispBean)request.getAttribute("Acsgm01DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Acsgm01Business dao = new Acsgm01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Acsgm01DispBean getAcsgm01DispBean() {
		return acsgm01DispBean;
	}

	public void setAcsgm01DispBean(Acsgm01DispBean acsgm01DispBean) {
		this.acsgm01DispBean = acsgm01DispBean;
	}

	public String getInputedCstCd() {
		return inputedCstCd;
	}

	public void setInputedCstCd(String inputedCstCd) {
		this.inputedCstCd = inputedCstCd;
	}

	public String getDispCstNm() {
		return dispCstNm;
	}

	public void setDispCstNm(String dispCstNm) {
		this.dispCstNm = dispCstNm;
	}

	public String getInputedShopCd() {
		return inputedShopCd;
	}

	public void setInputedShopCd(String inputedShopCd) {
		this.inputedShopCd = inputedShopCd;
	}

	public int getDispResults() {
		return dispResults;
	}

	public void setDispResults(int dispResults) {
		this.dispResults = dispResults;
	}

	public int getDisplayNum() {
		return displayNum;
	}

	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}

	public String getDispShopNm() {
		return dispShopNm;
	}

	public void setDispShopNm(String dispShopNm) {
		this.dispShopNm = dispShopNm;
	}

	public String getShopGrpCdHid() {
		return shopGrpCdHid;
	}

	public void setShopGrpCdHid(String shopGrpCdHid) {
		this.shopGrpCdHid = shopGrpCdHid;
	}



}
