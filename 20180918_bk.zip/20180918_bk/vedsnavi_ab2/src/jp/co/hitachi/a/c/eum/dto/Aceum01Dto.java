/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aceum01Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Aceum01Dtoクラス<br>
 *****************************************************************************************/
public class Aceum01Dto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 保存顧客コード */
	private String savedCustomerCd = null;
	/** 保存顧客名 */
	private String savedCustomerNm = null;
	/** 保存店舗コード */
	private String savedShopCd = null;
	/** 保存店舗名 */
	private String savedShopNm = null;
	/** 保存ユーザーID */
	private String savedUserId = null;
	/** 保存ユーザー名 */
	private String savedUserNm = null;
	/** 権限ロールプルダウン選択値(検索ボタン押下保存値) */
	private String savedRoleCd = null;
	/** 保存パスワードロック */
	private boolean savedPassLockFlg = false;
	/** 保存アカウントロック */
	private boolean savedActLockFlg = false;

	/** ページ表示No */
	private int displayNum = 1;
	/** 表示件数 */
	private int displayCount = 0;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public Aceum01Dto(){
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		savedCustomerCd = null;
		savedCustomerNm = null;
		savedShopCd = null;
		savedShopNm = null;
		savedUserId = null;
		savedUserNm = null;
		savedRoleCd = null;
		savedPassLockFlg = false;
		savedActLockFlg = false;
		displayNum = 0;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getSavedCustomerCd() {
		return savedCustomerCd;
	}
	public void setSavedCustomerCd(String savedCustomerCd) {
		this.savedCustomerCd = savedCustomerCd;
	}
	public String getSavedCustomerNm() {
		return savedCustomerNm;
	}
	public void setSavedCustomerNm(String savedCustomerNm) {
		this.savedCustomerNm = savedCustomerNm;
	}
	public String getSavedShopCd() {
		return savedShopCd;
	}
	public void setSavedShopCd(String savedShopCd) {
		this.savedShopCd = savedShopCd;
	}
	public String getSavedShopNm() {
		return savedShopNm;
	}
	public void setSavedShopNm(String savedShopNm) {
		this.savedShopNm = savedShopNm;
	}
	public String getSavedUserId() {
		return savedUserId;
	}
	public void setSavedUserId(String savedUserId) {
		this.savedUserId = savedUserId;
	}
	public String getSavedUserNm() {
		return savedUserNm;
	}
	public void setSavedUserNm(String savedUserNm) {
		this.savedUserNm = savedUserNm;
	}
	public String getSavedRoleCd() {
		return savedRoleCd;
	}
	public void setSavedRoleCd(String savedRoleCd) {
		this.savedRoleCd = savedRoleCd;
	}
	public boolean isSavedPassLockFlg() {
		return savedPassLockFlg;
	}
	public void setSavedPassLockFlg(boolean savedPassLockFlg) {
		this.savedPassLockFlg = savedPassLockFlg;
	}
	public boolean isSavedActLockFlg() {
		return savedActLockFlg;
	}
	public void setSavedActLockFlg(boolean savedActLockFlg) {
		this.savedActLockFlg = savedActLockFlg;
	}
	public int getDisplayNum() {
		return displayNum;
	}
	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}
	public int getDisplayCount() {
		return displayCount;
	}
	public void setDisplayCount(int displayCount) {
		this.displayCount = displayCount;
	}
}
