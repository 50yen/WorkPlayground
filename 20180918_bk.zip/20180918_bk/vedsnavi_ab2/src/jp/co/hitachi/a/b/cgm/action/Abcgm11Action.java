/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abcgm11Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.cgm.action;

import java.util.List;

import jp.co.hitachi.a.b.cgm.bean.Abcgm11DispBean;
import jp.co.hitachi.a.b.cgm.business.Abcgm11Business;
import jp.co.hitachi.a.b.cgm.dto.AbcgmCstGrpDto;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Abcgm11Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Abcgm11DispBean abcgm11DispBean;

	/** 顧客グループコード */
	private String cstGrpCd = null;
	/** 顧客グループ名 */
	private String cstGrpNm = null;
	/** 更新日時 */
	private String updateDateDisp = null;
	/** 更新者 */
	private String updateUserDisp = null;

	/** 一覧表示データ */
	private List<AbcgmCstGrpDto> itemDispList = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAbcgm11DispBean((Abcgm11DispBean)request.getAttribute("Abcgm11DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Abcgm11Business dao = new Abcgm11Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Abcgm11DispBean getAbcgm11DispBean() {
		return abcgm11DispBean;
	}

	public void setAbcgm11DispBean(Abcgm11DispBean abcgm11DispBean) {
		this.abcgm11DispBean = abcgm11DispBean;
	}

	public String getCstGrpCd() {
		return cstGrpCd;
	}

	public void setCstGrpCd(String cstGrpCd) {
		this.cstGrpCd = cstGrpCd;
	}

	public String getCstGrpNm() {
		return cstGrpNm;
	}

	public void setCstGrpNm(String cstGrpNm) {
		this.cstGrpNm = cstGrpNm;
	}

	public String getUpdateDateDisp() {
		return updateDateDisp;
	}

	public void setUpdateDateDisp(String updateDateDisp) {
		this.updateDateDisp = updateDateDisp;
	}

	public String getUpdateUserDisp() {
		return updateUserDisp;
	}

	public void setUpdateUserDisp(String updateUserDisp) {
		this.updateUserDisp = updateUserDisp;
	}

	public List<AbcgmCstGrpDto> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<AbcgmCstGrpDto> itemDispList) {
		this.itemDispList = itemDispList;
	}

}
