/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Accsi02Action.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.csi.action;

import jp.co.hitachi.a.c.csi.bean.Accsi02DispBean;
import jp.co.hitachi.a.c.csi.business.Accsi02Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Accsi02Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Accsi02DispBean accsi02DispBean;

	/**
	 * 引継ぎ項目
	 */
	/** 画面タイプ */
	private String type = null;
	/** 検索データ */
	private String data = null;
	/** 検索値が入力されている親画面の入力欄のID */
	private String sndid = null;
	/** 検索結果を設定する親画面の表示欄のID */
	private String rcvid = null;
	/** 呼び出し元親画面の画面ID */
	private String callgid = null;

	/**
	 * 入力項目
	 */
	/** 顧客コード */
	private String inputCustomerCd = null;
	/** 顧客名 */
	private String inputCustomerNm = null;

	/** 保存顧客コード */
	private String savedCustomerCd = null;
	/** 保存顧客名 */
	private String savedCustomerNm = null;


	/** プルダウンリスト選択値 */
	private int dispResults = 0;
	/** ページ番号 */
	private int displayNum = 0;



	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAccsi02DispBean((Accsi02DispBean)request.getAttribute("Accsi02DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Accsi02Business dao = new Accsi02Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Accsi02DispBean getAccsi02DispBean() {
		return accsi02DispBean;
	}

	public void setAccsi02DispBean(Accsi02DispBean accsi02DispBean) {
		this.accsi02DispBean = accsi02DispBean;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getSndid() {
		return sndid;
	}

	public void setSndid(String sndid) {
		this.sndid = sndid;
	}

	public String getRcvid() {
		return rcvid;
	}

	public void setRcvid(String rcvid) {
		this.rcvid = rcvid;
	}

	public String getCallgid() {
		return callgid;
	}

	public void setCallgid(String callgid) {
		this.callgid = callgid;
	}

	public String getInputCustomerCd() {
		return inputCustomerCd;
	}

	public void setInputCustomerCd(String inputCustomerCd) {
		this.inputCustomerCd = inputCustomerCd;
	}

	public String getInputCustomerNm() {
		return inputCustomerNm;
	}

	public void setInputCustomerNm(String inputCustomerNm) {
		this.inputCustomerNm = inputCustomerNm;
	}

	public String getSavedCustomerCd() {
		return savedCustomerCd;
	}

	public void setSavedCustomerCd(String savedCustomerCd) {
		this.savedCustomerCd = savedCustomerCd;
	}

	public String getSavedCustomerNm() {
		return savedCustomerNm;
	}

	public void setSavedCustomerNm(String savedCustomerNm) {
		this.savedCustomerNm = savedCustomerNm;
	}

	public int getDispResults() {
		return dispResults;
	}

	public void setDispResults(int dispResults) {
		this.dispResults = dispResults;
	}

	public int getDisplayNum() {
		return displayNum;
	}

	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}


}
