/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallMessage.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

import jp.co.hitachi.a.m.all.AmallConst.LogType;
import jp.co.hitachi.a.m.all.AmallConst.MsgCode;
import jp.co.hitachi.cocktail.jxpand.manage.JXMessage;
import jp.co.hitachi.cocktail.jxpand.manage.JXMessageInfo;

/*****************************************************************************************
 * メッセージ取得クラス<br>
 *****************************************************************************************/
public class AmallMessage {

	/*************************************************************************************
	 * メッセージタイプ取得
	 * <p>
	 * メッセージデータからメッセージタイプを取得する
	 * </p>
	 * @param key キー値
	 * @return  int メッセージタイプ
	 ************************************************************************************/
	public static int getMessageType(String key) {
		try {
			int retMsgType = MsgCode.NORMAL;

			JXMessageInfo jxm = null;
			jxm = JXMessage.searchMessageInfo(key);

			// 分類取得
			String cfg = jxm.getCategory();
			if(LogType.ERROR.equals(cfg)) {
				retMsgType = MsgCode.ERROR;
			} else if(LogType.WARN.equals(cfg)) {
				retMsgType = MsgCode.WARNING;
			} else if(LogType.INFO.equals(cfg)) {
				retMsgType = MsgCode.INFO;
			}

			return retMsgType;
		} catch (Exception e) {
			return MsgCode.ERROR;
		}
	}
	/*************************************************************************************
	 * メッセージカテゴリ取得
	 * <p>
	 * メッセージデータからメッセージカテゴリ(ERROR/INFO/WARN)を取得する
	 * </p>
	 * @param key キー値
	 * @return  String メッセージカテゴリ
	 ************************************************************************************/
	public static String getMessageCategory(String key) {
		try {

			JXMessageInfo jxm = null;
			jxm = JXMessage.searchMessageInfo(key);

			String cfg = jxm.getCategory();

			return cfg;
		} catch (Exception e) {
			return LogType.ERROR;
		}
	}
	/*************************************************************************************
	 * メッセージ取得
	 * <p>
	 * メッセージテーブルから値を取得する
	 * </p>
	 * @param key キー値
	 * @return
	 ************************************************************************************/
	public static String getMessage(String key) {
		try {
			JXMessageInfo jxm = null;
			jxm = JXMessage.searchMessageInfo(key);
			return jxm.getMessage();
		} catch (Exception e) {
			return "該当のメッセージが存在しません。[" + key +  "]";
		}
	}

	/*************************************************************************************
	 * メッセージ取得（引数あり）
	 * <p>
	 * メッセージテーブルから値を取得する（引数あり）
	 * </p>
	 * @param key キー値
	 * @param params 置換変数(可変)
	 * @return
	 ************************************************************************************/
	public static String getMessage(String key, String... params) {
		try {
			JXMessageInfo jxm = null;
			jxm = JXMessage.searchMessageInfo(key);

			Object[] obj = new Object[params.length];
			int i = 0;
			for (String param : params) {
				obj[i] = param;
				i++;
			}

			return jxm.getMessage(obj);
		} catch (Exception e) {
			return "該当のメッセージが存在しません。[" + key +  "]";
		}

	}
}