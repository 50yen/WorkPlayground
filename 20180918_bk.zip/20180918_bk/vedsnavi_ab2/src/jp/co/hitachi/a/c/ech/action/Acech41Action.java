/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech41Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.action;

import jp.co.hitachi.a.c.ech.bean.Acech41DispBean;
import jp.co.hitachi.a.c.ech.business.Acech41Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Acech41Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Acech41DispBean acech41DispBean;


	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAcech41DispBean((Acech41DispBean)request.getAttribute("Acech41DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Acech41Business dao = new Acech41Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Acech41DispBean getAcech41DispBean() {
		return acech41DispBean;
	}

	public void setAcech41DispBean(Acech41DispBean acech41DispBean) {
		this.acech41DispBean = acech41DispBean;
	}




}
