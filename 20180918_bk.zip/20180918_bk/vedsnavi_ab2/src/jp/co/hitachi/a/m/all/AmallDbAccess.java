/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallDbAccess.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import jp.co.hitachi.prego.exception.PgException;
import jp.co.hitachi.prego.jb.common.SystemInfoIn;
import jp.co.hitachi.prego2.jb.framework.PgFrameworkBaseV2;
//import oracle.jdbc.driver.OracleCallableStatement;
import oracle.jdbc.OracleCallableStatement;

/*****************************************************************************************
 * DBアクセスクラス<br>
 *****************************************************************************************/
public final class AmallDbAccess extends PgFrameworkBaseV2 {

	/** メンバ定数 */
	/** DB接続情報プロパティファイル名 */
	private final String DB_PROPERTIES = "prego_jb";

	/** メンバ変数 */
	/** DBアクセスクラス:SystemInfoIn */
	private SystemInfoIn m_SystemInfoIn = null;
	/** DBアクセスクラス:Connection */
	private Connection m_Connection = null;
	/** DBアクセスクラス:PreparedStatement */
	private PreparedStatement m_PreparedStatement = null;
	/** DBアクセスクラス:CallableStatement */
	private CallableStatement m_CallableStatement = null;

	/** ユーザーID */
	private String m_UserID = null;
	/** セッションID */
	private String m_SessionID = null;
	/** クラス名称 */
	private String m_ClassName = AmallDbAccess.class.getName();
	/** SQLコマンド格納エリア */
	private String m_SqlCmd = null;
	/** Callableコマンド */
	private String m_CallableCmd = null;
	/** パラメータ格納エリア */
	private ArrayList<String[]> m_ParameterList = new ArrayList<String[]>();
	/** パラメータコマンド格納エリア*/
	private ArrayList<String[]> m_ParameterCallableList = new ArrayList<String[]>();
	/** BATCH格納エリア	*/
	private ArrayList<String[]> m_BatchList = null;
	/** アクセスログ格納エリア */
	private AmallAccessLog m_AccessLog = new AmallAccessLog();
	/** ログ出力フラグ */
	private boolean m_LogOutFlag = true;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmallDbAccess() {
		m_SystemInfoIn = null;
		m_Connection = null;
		m_PreparedStatement = null;
		m_CallableStatement = null;
		m_UserID = "";
		m_SessionID = "";
		m_SqlCmd = "";
		m_CallableCmd = "";
		m_ParameterList = new ArrayList<String[]>();
		m_ParameterCallableList = new ArrayList<String[]>();
		m_BatchList = new ArrayList<String[]>();
		m_AccessLog = new AmallAccessLog();
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param UserID    PgFrameworkBaseV2のログ出力で使用する
	 * @param SessionID PgFrameworkBaseV2のログ出力で使用する
	 * @return 無し
	 ************************************************************************************/
	public AmallDbAccess(String UserID, String SessionID) {
		m_SystemInfoIn = null;
		m_Connection = null;
		m_PreparedStatement = null;
		m_CallableStatement = null;
		m_UserID = new String(UserID);
		m_SessionID = new String(SessionID);
		m_SqlCmd = "";
		m_CallableCmd = null;
		m_ParameterList = new ArrayList<String[]>();
		m_ParameterCallableList = new ArrayList<String[]>();
		m_BatchList = new ArrayList<String[]>();
		m_AccessLog = new AmallAccessLog();
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  int systemKind システム種類
	 * @return 無し
	 ************************************************************************************/
	public AmallDbAccess(int systemKind) {
		m_SystemInfoIn = null;
		m_Connection = null;
		m_PreparedStatement = null;
		m_CallableStatement = null;
		m_UserID = "";
		m_SessionID = "";
		m_SqlCmd = "";
		m_CallableCmd = "";
		m_ParameterList = new ArrayList<String[]>();
		m_ParameterCallableList = new ArrayList<String[]>();
		m_BatchList = new ArrayList<String[]>();
		m_AccessLog = new AmallAccessLog(systemKind);
	}

	/*************************************************************************************
	 * ＤＢコネクション開放処理
	 * <p>
	 * ＤＢのコネクションを開放する
	 * </p>
	 * @param 無し
	 * @return 処理結果
	 *          true  : 成功
	 *          false : 失敗
	 ************************************************************************************/
	private void clear() throws AmallException {
		String methodName = "clear()";
		try {
			if (m_PreparedStatement != null) {
				m_PreparedStatement.close();
			}

			if (m_CallableStatement != null) {
				m_CallableStatement.close();
			}

			if (systemInfoIn.isTransactCtrl()) {
				super.closeTransactWithRollback();
			}

			super.traceEnd();

		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} catch (PgException e) {
			this.clear();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {

		}
		return;
	}

	/*************************************************************************************
	 * ＤＢ接続判定処理
	 * <p>
	 * ＤＢ接続されているか否かを判定する
	 * </p>
	 * @param 無し
	 * @return 処理結果
	 *          true  : 接続済
	 *          false : 未接続
	 ************************************************************************************/
	public boolean isConnection() {
		if (m_Connection != null)
			return true;
		else
			return false;
	}

	/*************************************************************************************
	 * m_PreparedStatement生成判定処理
	 * <p>
	 * m_PreparedStatementが生成されているか否か
	 * </p>
	 * @param 無し
	 * @return 処理結果
	 *          true  : 作生成
	 *          false : 未生成
	 ************************************************************************************/
	public boolean isPreparedStatement() {
		if (m_PreparedStatement != null)
			return true;
		else
			return false;
	}

	/*************************************************************************************
	 * m_CallableStatement生成判定処理
	 * <p>
	 * m_CallableStatementが生成されているか否か
	 * </p>
	 * @param 無し
	 * @return 処理結果
	 *          true  : 作生成
	 *          false : 未生成
	 ************************************************************************************/
	public boolean isCallableStatement() {
		if (m_CallableStatement != null)
			return true;
		else
			return false;
	}

	/*************************************************************************************
	 * ＤＢ接続初期処理
	 * <p>
	 * ＤＢ接続の初期処理を行う
	 * </p>
	 * @param dbConnectKey プロパティファイル名
	 * @return 無し
	 ************************************************************************************/
	public void initDB() throws AmallException {
		String methodName = "initDB()";
		try {
			m_SystemInfoIn = new SystemInfoIn();
			m_SystemInfoIn.setTransactCtrl(true);
			m_SystemInfoIn.setUserID(m_UserID);
			m_SystemInfoIn.setSessionID(m_SessionID);
			super.setLogInfo(m_SystemInfoIn, super.getClassName(), methodName);
			super.traceStart();

			if (m_SystemInfoIn.isTransactCtrl()) {
				super.connectDB(DB_PROPERTIES);
			} else {
				super.backupConnection();
			}
			m_Connection = systemInfoIn.getConnection();
			if (m_Connection == null) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_MEM_CON_ERROR);
				throw ee;
			}
			m_Connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);

		} catch (AmallException ame) {
			throw ame;
		} catch (PgException e) {
			this.clear();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {

		}

		return;
	}

	/*************************************************************************************
	 * ＤＢ接続後処理
	 * <p>
	 * ＤＢ接続の後処理を行う
	 * </p>
	 * @param 無し
	 * @return 無し
	 ************************************************************************************/
	public void exitDB() throws AmallException {
		this.clear();
		m_SystemInfoIn = null;
		m_Connection = null;
		m_PreparedStatement = null;
		m_CallableStatement = null;
		m_UserID = null;
		m_SessionID = null;
		m_ParameterList = null;
		m_ParameterCallableList = null;
		m_BatchList = null;
		return;
	}
	/*************************************************************************************
	 * m_PreparedStatement生成処理(ページング用)
	 * <p>
	 * m_PreparedStatementを生成する、ページングSQL実行(TYPE_SCROLL_SENSITIVE)用
	 * </p>
	 * @param SQL文
	 * @return 無し
	 ************************************************************************************/
	public void createPreparedStatementPaging(String sqlQuery) throws AmallException {
		// ページングSQL実行用
		createPreparedStatement(sqlQuery , true);
		return;
	}
	/*************************************************************************************
	 * m_PreparedStatement生成処理
	 * <p>
	 * m_PreparedStatementを生成する、通常SQL実行(TYPE_FORWARD_ONLY)用
	 * </p>
	 * @param SQL文
	 * @return 無し
	 ************************************************************************************/
	public void createPreparedStatement(String sqlQuery) throws AmallException {
		// 通常SQL用
		createPreparedStatement(sqlQuery , false);
		return;
	}
	/*************************************************************************************
	 * m_PreparedStatement生成処理
	 * <p>
	 * m_PreparedStatementを生成する
	 * </p>
	 * @param 無し
	 * @return 無し
	 ************************************************************************************/
	private void createPreparedStatement(String sqlQuery, boolean flg) throws AmallException {
		String methodName = "createPreparedStatement()";
		try {
			if (!isConnection()) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_MEM_CON_ERROR);
				throw ee;
			}
			if (sqlQuery == null) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ARG_QRY_ERROR);
				throw ee;
			}
			if (m_PreparedStatement != null) {
				m_PreparedStatement.close();
				m_PreparedStatement = null;
			}

			m_SqlCmd = "";
			m_ParameterList.clear();

			//	SQL実行
			if (flg) {
				m_PreparedStatement = m_Connection.prepareStatement(sqlQuery,
						ResultSet.TYPE_SCROLL_SENSITIVE,
						ResultSet.CONCUR_READ_ONLY);
			} else {
				m_PreparedStatement = m_Connection.prepareStatement(sqlQuery);
			}
			m_SqlCmd = sqlQuery;

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {

		}
		return;
	}

	/*************************************************************************************
	 * m_CallableStatement生成処理
	 * <p>
	 * m_CallableStatementを生成する
	 * </p>
	 * @param 無し
	 * @return 無し
	 ************************************************************************************/
	public void createCallableStatement(String sqlCall) throws AmallException {
		String methodName = "createCallableStatement()";
		try {
			if (!isConnection()) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_MEM_CON_ERROR);
				throw ee;
			}
			if (sqlCall == null) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ARG_CAL_ERROR);
				throw ee;
			}
			if (m_CallableStatement != null) {
				m_CallableStatement.close();
				m_CallableStatement = null;
			}
			m_CallableStatement = m_Connection.prepareCall(sqlCall);
			m_CallableCmd = sqlCall;

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {

		}
		return;
	}

	/*************************************************************************************
	 * m_CallableStatement取得
	 * <p>
	 * m_CallableStatementを取得する
	 * </p>
	 * @param 無し
	 * @return m_CallableStatement
	 ************************************************************************************/
	public CallableStatement getCallableStatement() {
		return m_CallableStatement;
	}

	/*************************************************************************************
	 * SQL実行
	 * <p>
	 * SQL文を実行する(通常静的 SQL SELECT 文)
	 * </p>
	 * @param 無し
	 * @return 実行結果 ResultSet
	 ************************************************************************************/
	public ResultSet executeQuery() throws AmallException {
		String methodName = "executeQuery()";
		ResultSet rset = null;

		try {
			if (!isConnection()) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_MEM_CON_ERROR);
				throw ee;
			}
			if (!isPreparedStatement()) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_MEM_PRE_ERROR);
				throw ee;
			}

			m_AccessLog.putExecuteLog(this, m_SqlCmd, getParameterString()); //コマンド
			rset = m_PreparedStatement.executeQuery(); //SQL実行

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			m_AccessLog.putErrorLog(e.getMessage());
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
		}
		return rset;
	}

	/*************************************************************************************
	 * SQL実行
	 * <p>
	 * SQL文を実行する(ストアードプログラム)
	 * </p>
	 * @param 無し
	 * @return 実行結果 Boolean
	 ************************************************************************************/
	public boolean execute() throws AmallException {
		String methodName = "execute()";
		boolean ret = false;
		try {
			if (!isConnection()) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_MEM_CON_ERROR);
				throw ee;
			}
			if (!isCallableStatement()) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_MEM_CAL_ERROR);
				throw ee;
			}
			if (m_LogOutFlag) {
				m_AccessLog.putExecuteLog(this, m_CallableCmd, getParameterCallableString()); //コマンド
			}
			ret = m_CallableStatement.execute();

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {

		}
		return ret;
	}

	/*************************************************************************************
	 * SQL実行
	 * <p>
	 * SQL文を実行する(SQL INSERT 文、UPDATE 文、または DELETE 文、あるいは何も返さない SQL 文)
	 * </p>
	 * @param 無し
	 * @return 実行結果 int[]
	 ************************************************************************************/
	public int[] executeUpdate() throws AmallException {
		String methodName = "executeUpdate()";
		int[] cnt = null;
		try {
			if (!isConnection()) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_MEM_CON_ERROR);
				throw ee;
			}
			if (!isPreparedStatement()) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_MEM_PRE_ERROR);
				throw ee;
			}
			//             this.addBatch();
			cnt = m_PreparedStatement.executeBatch();
			if (cnt != null) {
				for (int i = 0; i < cnt.length; i++) {
					String batch[] = (String[]) m_BatchList.get(i);
					m_AccessLog.putExecuteLog(this, batch[0], batch[1]); //コマンド
				}
			}
			m_BatchList.clear();
			m_BatchList = null;

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			m_AccessLog.putErrorLog(e.getMessage());
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
		}
		return cnt;
	}

	/*************************************************************************************
	 * SQL（1文）実行
	 * <p>
	 * SQL文を実行する(SQL INSERT 文、UPDATE 文、または DELETE 文、あるいは何も返さない SQL 文)
	 * </p>
	 * @param 無し
	 * @return 実行結果 int[]
	 ************************************************************************************/
	public int executeUpdateSql() throws AmallException {
		String methodName = "executeUpdateSql";
		int cnt = 0;
		try {
			if (!isConnection()) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_MEM_CON_ERROR);
				throw ee;
			}
			if (!isPreparedStatement()) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_MEM_PRE_ERROR);
				throw ee;
			}
			m_AccessLog.putExecuteLog(this, m_SqlCmd, getParameterString()); //コマンド
			cnt = m_PreparedStatement.executeUpdate(); //実行

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			m_AccessLog.putErrorLog(e.getMessage());
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
		}
		return cnt;
	}

	/*************************************************************************************
	 * カーソル取得処理
	 * <p>
	 * PL/SQL実行結果のカーソルを取得する
	 * </p>
	 * @param paramPos カーソルのバインド位置
	 * @return 実行結果 ResultSet
	 ************************************************************************************/
	public ResultSet getRefCursor(Integer paramPos) throws AmallException {
		String methodName = "getRefCursor";
		try {
			return ((OracleCallableStatement) m_CallableStatement).getCursor(paramPos);
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
		}
	}

	/*************************************************************************************
	 * 一括実行SQL文追加処理
	 * <p>
	 * 一括実行するSQL文を追加する(SQL INSERT 文、UPDATE 文、または DELETE 文、
	 * あるいは何も返さない SQL 文)
	 * </p>
	 * @param x 値
	 * @return  無
	 ************************************************************************************/
	public void addBatch() throws SQLException {
		String batch[] = new String[2];
		batch[0] = m_SqlCmd; //SQLコマンド取得
		batch[1] = getParameterString(); //パラメータ取得
		m_BatchList.add(batch); //アクセスログ格納
		m_PreparedStatement.addBatch(); //バッチ格納

		//    	 m_SqlCmd = "";						//コマンド格納部分クリア
		m_ParameterList.clear(); //パラメータ格納部分クリア
	}

	/*************************************************************************************
	 * コミット処理
	 * <p>
	 * コミットを行う
	 * </p>
	 * @param 無し
	 * @return 無し
	 ************************************************************************************/
	public void commit() throws AmallException {
		String methodName = "commit()";
		try {
			super.commitConnection();
		} catch (PgException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {

		}
		return;
	}

	/*************************************************************************************
	 * ロールバック処理
	 * <p>
	 * ロールバックを行う
	 * </p>
	 * @param 無し
	 * @return 無し
	 ************************************************************************************/
	public void rollback() throws AmallException {
		String methodName = "rollback()";
		try {
			super.rollbackConnection();
		} catch (PgException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {

		}
		return;
	}

	/*************************************************************************************
	 * SHORTパラメータ格納
	 * <p>
	 * SHORTパラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param x				値
	 * @return 無
	 ************************************************************************************/
	public void setShort(int parameterIndex, short x) throws SQLException {
		String val = Short.toString(x);
		setParam(parameterIndex, "short", val);
		m_PreparedStatement.setShort(parameterIndex, x);
	}

	/*************************************************************************************
	 * INTパラメータ格納
	 * <p>
	 * INTパラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param x				値
	 * @return 無
	 ************************************************************************************/
	public void setInt(int parameterIndex, int x) throws SQLException {
		String val = Integer.toString(x);
		setParam(parameterIndex, "int", val);
		m_PreparedStatement.setInt(parameterIndex, x);
	}

	/*************************************************************************************
	 * LONGパラメータ格納
	 * <p>
	 * LONGパラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param x				値
	 * @return 無
	 ************************************************************************************/
	public void setLong(int parameterIndex, long x) throws SQLException {
		String val = Long.toString(x);
		setParam(parameterIndex, "long", val);
		m_PreparedStatement.setLong(parameterIndex, x);
	}

	/*************************************************************************************
	 * 文字パラメータ格納
	 * <p>
	 * 文字パラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param x				値
	 * @return 無
	 ************************************************************************************/
	public void setString(int parameterIndex, String x) throws SQLException {
		String val = x;
		setParam(parameterIndex, "String", val);
		m_PreparedStatement.setString(parameterIndex, x);
	}

	/*************************************************************************************
	 * 日付パラメータ格納
	 * <p>
	 * 日付パラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param x				値
	 * @return 無
	 ************************************************************************************/
	public void setDate(int parameterIndex, Date x) throws SQLException {
		String val = x.toString();
		setParam(parameterIndex, "Date", val);
		m_PreparedStatement.setDate(parameterIndex, x);
	}

	/*************************************************************************************
	 * 文字列NULL値変換
	 * <p>
	 * NULL値を空文字にして対象文字列を返す
	 * </p>
	 * @param  ResultSet rs
	 * @param  String    x
	 * @return String    str
	 ************************************************************************************/
	public String getString(ResultSet rs, String x) throws SQLException {
		String str = AmallUtilities.convEmpty(rs.getString(x));
		if (str.length() != 0) {
			//str = AmallUtilities.toMS932(str);
		}
		return str;
	}

	/*************************************************************************************
	 * 内部パラメータ格納
	 * <p>
	 * ログ出力用のパラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param ptype			型
	 * @param val				値
	 * @return 無
	 ************************************************************************************/
	private void setParam(int parameterIndex, String ptype, String val) {
		String param[] = new String[3];
		param[0] = Integer.toString(parameterIndex);
		param[1] = ptype;
		param[2] = val;
		m_ParameterList.add(param);
	}

	/*************************************************************************************
	 * 内部パラメータ値取得処理
	 * <p>
	 * ログ出力用の内部パラメータ値を取得する
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public String getParameterString() {
		StringBuffer paraWork = new StringBuffer();
		for (int i = 0; i < m_ParameterList.size(); i++) {
			String param[] = m_ParameterList.get(i);
			paraWork.append("PARAM");
			paraWork.append(param[0]);
			paraWork.append("(");
			paraWork.append(param[1]);
			paraWork.append(")='");
			paraWork.append(param[2]);
			paraWork.append("' ");
		}
		return paraWork.toString();
	}

	/*************************************************************************************
	 * イベント開始ログ(テーブル出力のみ)
	 * <p>
	 * イベント開始ログ(テーブル出力のみ)を行う
	 * </p>
	 * @param dba	DBハンドル
	 * @return		出力結果(=0:正常,=-1:出力先テーブル設定無)
	 * @throws AmallException
	 ************************************************************************************/
	public int putEventStartLog(String loginId, //ログインID
			String referCd, //照会条件
			String messageLvl, //メッセージレベル
			String businessName, //業務名
			String logInfoHead, //ログ情報ヘッダ
			String logInfo, //ログ情報
			String updateStaff //更新者
	) throws AmallException {
		int rtc = m_AccessLog.putEventStartLog(this,
				loginId, //ログインID
				referCd, //照会条件
				messageLvl, //メッセージレベル
				businessName, //業務名
				logInfoHead, //ログ情報ヘッダ
				logInfo, //ログ情報
				updateStaff //更新者
		);

		return rtc;
	}

	/*************************************************************************************
	 * イベント終了ログ(テーブル出力のみ)
	 * <p>
	 * イベント終了ログ(テーブル出力のみ)を行う
	 * </p>
	 * @param dba	DBハンドル
	 * @return		出力結果(=0:正常,=-1:出力先テーブル設定無)
	 * @throws AmallException
	 ************************************************************************************/
	public int putEventEndLog(String loginId, //ログインID
			String referCd, //照会条件
			String messageLvl, //メッセージレベル
			String businessName, //業務名
			String logInfoHead, //ログ情報ヘッダ
			String logInfo, //ログ情報
			String updateStaff //更新者
	) throws AmallException {
		int rtc = m_AccessLog.putEventEndLog(this,
				loginId, //ログインID
				referCd, //照会条件
				messageLvl, //メッセージレベル
				businessName, //業務名
				logInfoHead, //ログ情報ヘッダ
				logInfo, //ログ情報
				updateStaff //更新者
		);
		return rtc;
	}

	/*************************************************************************************
	 * エラー出力ログ
	 * <p>
	 * エラー出力ログを行う
	 * </p>
	 * @param errorInfo	エラー情報
	 * @return			出力結果(=0:正常)
	 ************************************************************************************/
	public int putErrorLog(String errorInfo) {
		return m_AccessLog.putErrorLog(errorInfo);
	}

	/*************************************************************************************
	 * 枝番取得
	 * <p>
	 * 枝番取得を行う
	 * </p>
	 * @param  なし
	 * @return edaNo
	 ************************************************************************************/
	public long getEdaNo() {
		return m_AccessLog.getEdaNo();
	}

	/*************************************************************************************
	 * 枝番設定
	 * <p>
	 * 枝番設定を行う
	 * </p>
	 * @param edaNo 枝番
	 * @return なし
	 ************************************************************************************/
	public void setEdaNo(long edaNo) {
		m_AccessLog.setEdaNo(edaNo);
	}

	/*************************************************************************************
	 * ログシーケンス取得
	 * <p>
	 * ログシーケンス取得を行う
	 * </p>
	 * @param  なし
	 * @return logSeq
	 ************************************************************************************/
	public long getLogSeq() {
		return m_AccessLog.getLogSeq();
	}

	/*************************************************************************************
	 * ログ出力チェック
	 * <p>
	 * ログ出力チェックを行う
	 * </p>
	 * @param  なし
	 * @return logOutput ログ出力(=true:有,=false:無)
	 ************************************************************************************/
	public boolean isLogOutput() {
		return m_AccessLog.isLogOutput();
	}

	/*************************************************************************************
	 * ログ出力設定
	 * <p>
	 * ログ出力設定を行う
	 * </p>
	 * @param logOutput ログ出力(=true:有,=false:無)
	 * @return なし
	 ************************************************************************************/
	public void setLogOutput(boolean logOutput) {
		m_AccessLog.setLogOutput(logOutput);
	}

	/*************************************************************************************
	 * ログ出力先テーブル設定
	 * <p>
	 * ログ出力先テーブル設定を行う
	 * </p>
	 * @param logTable	ログ出力先テーブル
	 * @return なし
	 ************************************************************************************/
	public void setLogTable(String logTable) {
		m_AccessLog.setLogTable(logTable);
	}

	/*************************************************************************************
	 * パラメータクリア
	 * <p>
	 * パラメータクリアを行う
	 * </p>
	 * @param  なし
	 * @return なし
	 ************************************************************************************/
	public void parameterClear() {
		m_ParameterList.clear();
	}

	/*************************************************************************************
	 * m_LogOutFlag　getter
	 * <p>
	 * m_LogOutFlagのgetterメソッド
	 * </p>
	 * @param  なし
	 * @return m_LogOutFlag
	 ************************************************************************************/
	public boolean isM_LogOutFlag() {
		return m_LogOutFlag;
	}

	/*************************************************************************************
	 * m_LogOutFlag　setter
	 * <p>
	 * m_LogOutFlagのsetterメソッド
	 * </p>
	 * @param  logOutFlag
	 * @return なし
	 ************************************************************************************/
	public void setM_LogOutFlag(boolean logOutFlag) {
		m_LogOutFlag = logOutFlag;
	}

	/*************************************************************************************
	 * SHORTパラメータ格納
	 * <p>
	 * SHORTパラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param x				値
	 * @return 無
	 ************************************************************************************/
	public void setCallableShort(int parameterIndex, short x) throws SQLException {
		String val = Short.toString(x);
		setParamCallable(parameterIndex, "short", val);
		m_CallableStatement.setShort(parameterIndex, x);
	}

	/*************************************************************************************
	 * INTパラメータ格納
	 * <p>
	 * INTパラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param x				値
	 * @return 無
	 ************************************************************************************/
	public void setCallableInt(int parameterIndex, int x) throws SQLException {
		String val = Integer.toString(x);
		setParamCallable(parameterIndex, "int", val);
		m_CallableStatement.setInt(parameterIndex, x);
	}

	/*************************************************************************************
	 * LONGパラメータ格納
	 * <p>
	 * LONGパラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param x				値
	 * @return 無
	 ************************************************************************************/
	public void setCallableLong(int parameterIndex, long x) throws SQLException {
		String val = Long.toString(x);
		setParamCallable(parameterIndex, "long", val);
		m_CallableStatement.setLong(parameterIndex, x);
	}

	/*************************************************************************************
	 * 文字パラメータ格納
	 * <p>
	 * 文字パラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param x				値
	 * @return 無
	 ************************************************************************************/
	public void setCallableString(int parameterIndex, String x) throws SQLException {
		String val = x;
		setParamCallable(parameterIndex, "String", val);
		m_CallableStatement.setString(parameterIndex, x);
	}

	/*************************************************************************************
	 * 日付パラメータ格納
	 * <p>
	 * 日付パラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param x				値
	 * @return 無
	 ************************************************************************************/
	public void setCallableDate(int parameterIndex, Date x) throws SQLException {
		String val = x.toString();
		setParamCallable(parameterIndex, "Date", val);
		m_CallableStatement.setDate(parameterIndex, x);
	}

	/*************************************************************************************
	 * 内部パラメータ格納
	 * <p>
	 * ログ出力用のパラメータを格納する
	 * </p>
	 * @param parameterIndex	格納位置
	 * @param ptype			型
	 * @param val				値
	 * @return 無
	 ************************************************************************************/
	private void setParamCallable(int parameterIndex, String ptype, String val) {
		String param[] = new String[3];
		param[0] = Integer.toString(parameterIndex);
		param[1] = ptype;
		param[2] = val;
		m_ParameterCallableList.add(param);
	}

	/*************************************************************************************
	* 内部パラメータ値取得処理
	* <p>
	* ログ出力用の内部パラメータ値を取得する
	* </p>
	* @param  無し
	* @return 無し
	************************************************************************************/
	public String getParameterCallableString() {
		StringBuffer paraWork = new StringBuffer();
		for (int i = 0; i < m_ParameterCallableList.size(); i++) {
			String param[] = m_ParameterCallableList.get(i);
			paraWork.append("PARAM");
			paraWork.append(param[0]);
			paraWork.append("(");
			paraWork.append(param[1]);
			paraWork.append(")='");
			paraWork.append(param[2]);
			paraWork.append("' ");
		}
		return paraWork.toString();
	}
}
