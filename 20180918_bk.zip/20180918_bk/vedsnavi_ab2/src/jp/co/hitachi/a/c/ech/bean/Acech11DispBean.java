/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech11DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.bean;

import java.util.List;

import jp.co.hitachi.a.c.ech.dto.AcechItemDispDto;
import jp.co.hitachi.a.m.cls.AmclsBeanBase;

/*****************************************************************************************
 * Acech11DispBeanクラス<br>
 *****************************************************************************************/
public class Acech11DispBean extends AmclsBeanBase {

	/** メンバ変数 */
	/** 初期　回収FROM */
	private String cldFrom = null;
	/** 初期　回収TO */
	private String cldTo = null;

	/** 現ページ */
	private int displayNum = 0;
	/** 前ページフラグ */
	private String prevPageFlg = null;
	/** 次ページフラグ */
	private String nextPageFlg = null;
	/** 一覧表示 */
	private List<AcechItemDispDto> itemDispList = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Acech11DispBean() {
		clear();
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		super.clear();
		cldFrom = null;
		cldTo = null;
		displayNum = 0;
		prevPageFlg = null;
		nextPageFlg = null;
		itemDispList = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getCldFrom() {
		return cldFrom;
	}

	public void setCldFrom(String cldFrom) {
		this.cldFrom = cldFrom;
	}

	public String getCldTo() {
		return cldTo;
	}

	public void setCldTo(String cldTo) {
		this.cldTo = cldTo;
	}

	public int getDisplayNum() {
		return displayNum;
	}

	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}

	public String getPrevPageFlg() {
		return prevPageFlg;
	}

	public void setPrevPageFlg(String prevPageFlg) {
		this.prevPageFlg = prevPageFlg;
	}

	public String getNextPageFlg() {
		return nextPageFlg;
	}

	public void setNextPageFlg(String nextPageFlg) {
		this.nextPageFlg = nextPageFlg;
	}

	public List<AcechItemDispDto> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<AcechItemDispDto> itemDispList) {
		this.itemDispList = itemDispList;
	}

}
