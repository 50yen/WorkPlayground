/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Accme11Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cme.action;

import java.util.List;

import jp.co.hitachi.a.c.cme.bean.Accme11DispBean;
import jp.co.hitachi.a.c.cme.business.Accme11Business;
import jp.co.hitachi.a.c.cme.dto.Accme11Dto;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Accme11Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Accme11DispBean accme11DispBean;

	/** 顧客CD */
	private String cstCd = null;
	/** 顧客名 */
	private String cstNm = null;
	/** 店舗CD */
	private String shopCd = null;
	/** 店舗名 */
	private String shopNm = null;
	/** 店舗CD(表示) */
	private String dispShopCd = null;
	/** 店舗枝番 */
	private String shopSbno = null;
	/** 店舗枝番名 */
	private String shopSbnm = null;
	/** 店舗枝番(表示) */
	private String dispShopSbno = null;
	/** 売上日 */
	private String sld = null;

	/** 選択リスト */
	private List<Accme11Dto> itemDispList = null;
	/** 合計金額 */
	private String spccmt = null;
	/** 合計金額 */
	private int autoSpccmt = 0;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
		String forwardName = super.execute();
		// 実行結果を画面表示Beanに登録
		setAccme11DispBean((Accme11DispBean) request.getAttribute("Accme11DispBean"));
		return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Accme11Business dao = new Accme11Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Accme11DispBean getAccme11DispBean() {
		return accme11DispBean;
	}

	public void setAccme11DispBean(Accme11DispBean accme11DispBean) {
		this.accme11DispBean = accme11DispBean;
	}

	public String getCstCd() {
		return cstCd;
	}

	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}

	public String getCstNm() {
		return cstNm;
	}

	public void setCstNm(String cstNm) {
		this.cstNm = cstNm;
	}

	public String getShopCd() {
		return shopCd;
	}

	public void setShopCd(String shopCd) {
		this.shopCd = shopCd;
	}

	public String getShopNm() {
		return shopNm;
	}

	public void setShopNm(String shopNm) {
		this.shopNm = shopNm;
	}

	public String getShopSbno() {
		return shopSbno;
	}

	public void setShopSbno(String shopSbno) {
		this.shopSbno = shopSbno;
	}

	public String getShopSbnm() {
		return shopSbnm;
	}

	public void setShopSbnm(String shopSbnm) {
		this.shopSbnm = shopSbnm;
	}

	public String getSld() {
		return sld;
	}

	public void setSld(String sld) {
		this.sld = sld;
	}

	public List<Accme11Dto> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<Accme11Dto> itemDispList) {
		this.itemDispList = itemDispList;
	}

	public String getSpccmt() {
		return spccmt;
	}

	public void setSpccmt(String spccmt) {
		this.spccmt = spccmt;
	}

	public int getAutoSpccmt() {
		return autoSpccmt;
	}

	public void setAutoSpccmt(int autoSpccmt) {
		this.autoSpccmt = autoSpccmt;
	}

	public String getDispShopCd() {
		return dispShopCd;
	}

	public void setDispShopCd(String dispShopCd) {
		this.dispShopCd = dispShopCd;
	}

	public String getDispShopSbno() {
		return dispShopSbno;
	}

	public void setDispShopSbno(String dispShopSbno) {
		this.dispShopSbno = dispShopSbno;
	}

}
