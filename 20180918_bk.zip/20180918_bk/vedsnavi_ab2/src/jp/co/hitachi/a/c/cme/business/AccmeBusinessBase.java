/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AccmeBusinessBase.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cme.business;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.cme.dto.AccmeItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.cls.AmclsBeanBase;
import jp.co.hitachi.a.m.cls.AmclsBusinessPcBase;

/*****************************************************************************************
 * AccmeBusinessBaseクラス<br>
 *****************************************************************************************/
public abstract class AccmeBusinessBase extends AmclsBusinessPcBase {

	/** 遷移先画面キー */
	protected static final String ACCME_INFO_KEY = "AccmeInfo";

	/**
	 * 画面項目ID
	 */
	/** 画面名 */
	private static final String ITEM_ID_SCREEN_NAME = "ScreenName";

	/** 共通画面DTO */
	AccmeItemDispDto accmeInfoDto;

	AmclsBeanBase amBeanBase;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  mapping
	 * @param  form
	 * @param  request
	 * @param  response
	 * @param  context
	 * @param  gid
	 * @param  event
	 * @return 無し
	 ************************************************************************************/
	public AccmeBusinessBase(HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);
	}

	/*************************************************************************************
	 * 顧客名・店舗名・レジ名検索処理
	 * <p>
	 *顧客名・店舗名・レジ名検索処理を実行する
	 * </p>
	 * @param	なし
	 * @return String 店舗名
	 ************************************************************************************/
	protected Map<String, String> searchInfo(String cstCd, String shopCd, String shopSbno, AmclsBeanBase dispbean)
			throws AmallException, Exception {
		// メソッド名
		String methodName = "searchInfo()";
		// 結果
		ResultSet rs = null;
		// 返却用文字列
		Map<String, String> retMap = new ConcurrentHashMap<>();

		// システム日付
		String systemDt = dispbean.getServiceDate();

		try {

			StringBuffer sql = new StringBuffer();
			List<String> bindParam = new ArrayList<String>();

			// SQL SELECT
			sql.delete(0, sql.length());

			sql.append("SELECT");
			sql.append("	ncm.CST_CD");
			sql.append(",	ncm.CST_NM");
			sql.append(",	nsm.SHOP_CD");
			sql.append(",	nsm.SHOP_NM");
			sql.append(",	TRIM(nscm.COMPANY_SHOP_CD) AS COMPANY_SHOP_CD");
			sql.append(",	TRIM(nscm.COMPANY_SHOP_NM) AS COMPANY_SHOP_NM");
			sql.append(",	nssm.SHOP_SBNO");
			sql.append(",	nssm.SHOP_SB_NM");
			sql.append(",	TRIM(nsscm.COMPANY_SHOP_SB_CD) AS COMPANY_SHOP_SB_CD");
			sql.append(",	TRIM(nsscm.COMPANY_SHOP_SB_NM) AS COMPANY_SHOP_SB_NM");

			// SQL FROM & WHERE
			sql.append("  FROM");
			sql.append("	N_SHOP_SB_M nssm");
			sql.append("	INNER JOIN");
			sql.append("		N_CST_M ncm");
			sql.append("	  ON");
			sql.append("		nssm.CST_CD = ncm.CST_CD");
			sql.append("		AND ncm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	INNER JOIN");
			sql.append("		N_SHOP_M nsm");
			sql.append("	  ON");
			sql.append("		nssm.CST_CD = nsm.CST_CD");
			sql.append("		AND nssm.SHOP_CD = nsm.SHOP_CD");
			// 有効期間
			sql.append("		AND ? BETWEEN nsm.EFST_DY AND nsm.EFED_DY");
			bindParam.add(systemDt);
			sql.append("		AND nsm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_CNV_M nscm");
			sql.append("	  ON");
			sql.append("		nssm.CST_CD = nscm.CST_CD");
			sql.append("		AND nssm.SHOP_CD = nscm.SHOP_CD");
			// 有効期間
			sql.append("		AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
			bindParam.add(systemDt);
			sql.append("		AND nscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_SB_CNV_M nsscm");
			sql.append("	  ON");
			sql.append("		nssm.CST_CD = nsscm.CST_CD");
			sql.append("		AND nssm.SHOP_CD = nsscm.SHOP_CD");
			sql.append("		AND nssm.SHOP_SBNO = nsscm.SHOP_SBNO");
			// 有効期間
			sql.append("		AND ? BETWEEN nsscm.EFST_DY AND nsscm.EFED_DY");
			bindParam.add(systemDt);
			sql.append("		AND nsscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append(" WHERE");
			// 削除フラグ
			sql.append("	 nssm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");

			if (!AmallUtilities.isEmpty(cstCd)) {
				// 顧客コードが存在する場合
				sql.append("	AND ncm.CST_CD = ?");
				bindParam.add(cstCd);
			}

			if (!AmallUtilities.isEmpty(shopCd)) {
				// 店舗コードが存在する場合(お客様店舗コードも検索対象)
				sql.append("	AND (");
				sql.append("		nsm.SHOP_CD = ?");
				sql.append("		OR");
				sql.append("		TRIM(nscm.COMPANY_SHOP_CD) = ?");
				sql.append("	)");
				bindParam.add(shopCd);
				bindParam.add(shopCd);
			}
			if (!AmallUtilities.isEmpty(shopSbno)) {
				// 店舗枝番コードが存在する場合(お客様店舗コードも検索対象)
				sql.append("	AND (");
				sql.append("		nssm.SHOP_SBNO = ?");
				sql.append("		OR");
				sql.append("		TRIM(nsscm.COMPANY_SHOP_SB_CD) = ?");
				sql.append("	)");
				bindParam.add(shopSbno);
				bindParam.add(shopSbno);
			}

			// 有効期間
			sql.append("	AND ? BETWEEN nssm.EFST_DY AND nssm.EFED_DY");
			bindParam.add(systemDt);

			// 店舗範囲設定
			// 全店舗判定
			if (!dispbean.isShopCdAllFlg()) {
				// 全顧客・全店舗ではない場合
				sql.append("	AND (");
				boolean first = true;
				for (Entry<String, List<String>> entry : dispbean.getShopCdListMap().entrySet()) {

					String appCstCd = entry.getKey();
					for (String appShop : entry.getValue()) {
						if (first) {
							sql.append("		(");
							first = false;
						} else {
							sql.append("		OR (");
						}
						sql.append("			ncm.CST_CD = '").append(appCstCd).append("'");
						sql.append("			AND");
						sql.append("			nsm.SHOP_CD = '").append(appShop).append("'");
						sql.append("		)");
					}
				}
				sql.append("	)");
			}

			// SQL ORDER
			sql.append("  ORDER BY");
			sql.append("	ncm.CST_CD");
			sql.append(",	nsm.SHOP_CD");

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < bindParam.size(); i++) {
				m_DbAccess.setString(i + 1, bindParam.get(i));
			}

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 実行結果チェック
			while (rs.next()) {
				// データセット
				if (!AmallUtilities.isEmpty(cstCd)) {
					if (!AmallUtilities.isEmpty(m_DbAccess.getString(rs, "CST_NM"))) {
						retMap.put("CST_NM", m_DbAccess.getString(rs, "CST_NM"));
					}
				}
				// データセット
				if (!AmallUtilities.isEmpty(shopCd)) {
					if (!AmallUtilities.isEmpty(m_DbAccess.getString(rs, "COMPANY_SHOP_NM"))) {
						retMap.put("SHOP_NM", m_DbAccess.getString(rs, "COMPANY_SHOP_NM"));
					} else {
						retMap.put("SHOP_NM", m_DbAccess.getString(rs, "SHOP_NM"));
					}
				}
				// データセット
				if (!AmallUtilities.isEmpty(shopSbno)) {
					if (!AmallUtilities.isEmpty(m_DbAccess.getString(rs, "COMPANY_SHOP_SB_NM"))) {
						retMap.put("SHOP_SB_NM", m_DbAccess.getString(rs, "COMPANY_SHOP_SB_NM"));
					} else {
						retMap.put("SHOP_SB_NM", m_DbAccess.getString(rs, "SHOP_SB_NM"));
					}
				}
			}

			/* StringBuffer 開放  */
			sql.delete(0, sql.length());
			sql = null;

		} catch (AmallException ame) {
			m_DbAccess.rollback();
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					getItemDispName(ITEM_ID_SCREEN_NAME, dispbean));
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

		return retMap;
	}


}
