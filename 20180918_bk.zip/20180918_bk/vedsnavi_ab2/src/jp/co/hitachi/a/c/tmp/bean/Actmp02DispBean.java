/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Actmp02DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.tmp.bean;

import java.util.List;

import jp.co.hitachi.a.c.tmp.dto.ActmpItemDispDto;
import jp.co.hitachi.a.m.cls.AmclsBeanBase;
import jp.co.hitachi.a.m.dto.AmdtoCalender;
import jp.co.hitachi.a.m.dto.AmdtoDropDownList;

/*****************************************************************************************
 * Actmp02DispBeanクラス<br>
 *****************************************************************************************/
public class Actmp02DispBean extends AmclsBeanBase {

	/** メンバ変数 */

	/** 情報表示エリア表示文字1 */
	private String divDispData1 = null;
	/** 情報表示エリア表示文字2 */
	private String divDispData2 = null;

	/** カレンダー */
	private List<List<AmdtoCalender>> calDataList = null;


	/** プルダウンリスト */
	private List<AmdtoDropDownList> downlist = null;


	/** 入力ラベル青1-5 */
	private String inputLbl1 = null;
	private String inputLbl2 = null;
	private String inputLbl3 = null;
	private String inputLbl4 = null;
	private String inputLbl5 = null;

	/** 一覧表示 */
	private List<ActmpItemDispDto> itemDispList = null;


	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Actmp02DispBean() {
		super();
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		super.clear();
	}

	public String getDivDispData1() {
		return divDispData1;
	}

	public void setDivDispData1(String divDispData1) {
		this.divDispData1 = divDispData1;
	}

	public String getDivDispData2() {
		return divDispData2;
	}

	public void setDivDispData2(String divDispData2) {
		this.divDispData2 = divDispData2;
	}

	public List<List<AmdtoCalender>> getCalDataList() {
		return calDataList;
	}

	public void setCalDataList(List<List<AmdtoCalender>> calDataList) {
		this.calDataList = calDataList;
	}

	public List<AmdtoDropDownList> getDownlist() {
		return downlist;
	}

	public void setDownlist(List<AmdtoDropDownList> downlist) {
		this.downlist = downlist;
	}

	public String getInputLbl1() {
		return inputLbl1;
	}

	public void setInputLbl1(String inputLbl1) {
		this.inputLbl1 = inputLbl1;
	}

	public String getInputLbl2() {
		return inputLbl2;
	}

	public void setInputLbl2(String inputLbl2) {
		this.inputLbl2 = inputLbl2;
	}

	public String getInputLbl3() {
		return inputLbl3;
	}

	public void setInputLbl3(String inputLbl3) {
		this.inputLbl3 = inputLbl3;
	}

	public String getInputLbl4() {
		return inputLbl4;
	}

	public void setInputLbl4(String inputLbl4) {
		this.inputLbl4 = inputLbl4;
	}

	public String getInputLbl5() {
		return inputLbl5;
	}

	public void setInputLbl5(String inputLbl5) {
		this.inputLbl5 = inputLbl5;
	}

	public List<ActmpItemDispDto> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<ActmpItemDispDto> itemDispList) {
		this.itemDispList = itemDispList;
	}



}
