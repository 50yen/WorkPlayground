/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AbiamScreenAuthDto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * AbiamScreenAuthDtoクラス<br>
 *****************************************************************************************/
public class AbiamScreenAuthDto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 権限ロール */
	private String roleCd = null;
	/** 権限ロール名称 */
	private String roleNm = null;
	/** 画面コード */
	private String screenCd = null;
	/** 表示可否 */
	private String dispCd = null;
	/** 排他キー */
	private Long exclusiveKey = null;


	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public AbiamScreenAuthDto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		roleCd = null;
		roleNm = null;
		screenCd = null;
		dispCd = null;
		exclusiveKey = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getRoleCd() {
		return roleCd;
	}
	public void setRoleCd(String roleCd) {
		this.roleCd = roleCd;
	}
	public String getRoleNm() {
		return roleNm;
	}
	public void setRoleNm(String roleNm) {
		this.roleNm = roleNm;
	}
	public String getScreenCd() {
		return screenCd;
	}
	public void setScreenCd(String screenCd) {
		this.screenCd = screenCd;
	}
	public String getDispCd() {
		return dispCd;
	}
	public void setDispCd(String dispCd) {
		this.dispCd = dispCd;
	}
	public Long getExclusiveKey() {
		return exclusiveKey;
	}
	public void setExclusiveKey(Long exclusiveKey) {
		this.exclusiveKey = exclusiveKey;
	}
}
