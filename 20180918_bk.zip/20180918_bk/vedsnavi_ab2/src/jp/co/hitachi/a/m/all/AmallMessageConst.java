/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallMessageConst.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

/*****************************************************************************************
 * メッセージ定数クラス<br>
 *****************************************************************************************/
public class AmallMessageConst {
	/*************************************************************************************
	 * システム共通メッセージ定数(システムエラーログ)
	 ************************************************************************************/
	/** 画面遷移アクセスキー不正 */
	public static final String MSG_SYS_SCREEN_MOVE_ACCESS_ERROR = "Maps001";
	/** セッションタイムアウト */
	public static final String MSG_SYS_SESSION_TIMEOUT_ERROR = "Maps002";
	/** トークン生成エラー */
	public static final String MSG_SYS_TOKEN_CREATE_ERROR = "Maps003";
	/** cookieが有効ではありません */
	public static final String MSG_SYS_INVALID_COOKIE_ERROR = "Maps004";
	/** HttpSession取得エラー(null) */
	public static final String MSG_SYS_SESSION_GET_ERROR = "Maps005";
	/** DTO管理データ取得エラー:{0} */
	public static final String MSG_SYS_DTO_MNG_DATA_GET_ERROR = "Maps006";
	/** DTO管理データクリアエラー */
	public static final String MSG_SYS_MNG_DATA_CLEAR_ERROR = "Maps007";
	/** DBアクセス メンバ変数エラー:m_Connection(null) */
	public static final String MSG_SYS_DB_MEM_CON_ERROR = "Maps008";
	/** DBアクセス メンバ変数エラー:m_PreparedStatement(null) */
	public static final String MSG_SYS_DB_MEM_PRE_ERROR = "Maps009";
	/** DBアクセス メンバ変数エラー:m_CallableStatement(null) */
	public static final String MSG_SYS_DB_MEM_CAL_ERROR = "Maps010";
	/** DBアクセス 引数エラー:sqlQuery(null) */
	public static final String MSG_SYS_DB_ARG_QRY_ERROR = "Maps011";
	/** DBアクセス 引数エラー:sqlCall(null) */
	public static final String MSG_SYS_DB_ARG_CAL_ERROR = "Maps012";
	/** DBアクセス 楽観的排他エラー {0} */
	public static final String MSG_SYS_DB_ACS_OPT_ERROR = "Maps013";
	/** DBアクセス 更新エラー {0} */
	public static final String MSG_SYS_DB_ACS_UPDATE_ERROR = "Maps014";
	/** DBアクセス 登録エラー {0} */
	public static final String MSG_SYS_DB_ACS_INSERT_ERROR = "Maps015";
	/** DBアクセス 取得エラー {0} */
	public static final String MSG_SYS_DB_ACS_SELECT_ERROR = "Maps016";
	/** 画面イベント処理 : 画面イベント取得エラー(event={0}) */
	public static final String MSG_SYS_SCREEN_EVENT_GET_ERROR = "Maps017";
	/** 画面イベント処理 : 画面イベント処理エラー */
	public static final String MSG_SYS_SCREEN_EVENT_PROC_ERROR = "Maps018";
	/** ファイル作成処理エラー */
	public static final String MSG_SYS_CREATE_FILE_STREAM_ERROR = "Maps019";
	/** ログイン情報取得エラー */
	public static final String MSG_SYS_LOGIN_INFO_GET_ERROR = "Maps020";
	/** ログイン処理エラー */
	public static final String MSG_SYS_LOGIN_PROC_ERROR = "Maps021";
	/** ログイン管理(DB)更新エラー {0} */
	public static final String MSG_SYS_DB_UPDATE_ERROR = "Maps022";
	/** ログイン管理(DB)楽観的排他エラー {0} */
	public static final String MSG_SYS_DB_UPDATE_OPTIMISTIC_ERROR = "Maps023";
	/** チェック処理：入力値チェック処理エラー {0} */
	public static final String MSG_SYS_INPUT_CHECK_PROC_ERROR = "Maps024";
	/** {0}作成エラー */
	public static final String MSG_SYS_CLASS_CREATE_ERROR = "Maps025";

	/*************************************************************************************
	 * 業務メッセージ定数
	 ************************************************************************************/
	/** 処理が正常に終了しました。 */
	public static final String MSG_INF_NML_END = "Mapi001";
	/** アップロードは正常に終了しました。 */
	public static final String MSG_INF_UP_NML_END = "Mapi002";
	/** ダウンロードは正常に終了しました。 */
	public static final String MSG_INF_DOWN_NML_END = "Mapi003";
	/** 印刷が正常に終了しました。 */
	public static final String MSG_INF_PRINT_NML_END = "Mapi004";
	/** 指定された検索条件に一致するデータは存在しませんでした。 */
	public static final String MSG_INF_SEARCH_CON_NO_DATA = "Mapi005";
	/** 指定された条件に一致する{0}はありませんでした。 */
	public static final String MSG_INF_SEARCH_CON_NO_DATA_ARG = "Mapi006";
	/** 前画面には表示情報は存在しませんでした。 */
	public static final String MSG_INF_SCREEN_NEXT_NO_DATA = "Mapi007";
	/** 次画面には表示情報は存在しませんでした。 */
	public static final String MSG_INF_SCREEN_PREV_NO_DATA = "Mapi008";
	/** {0}カレンダーは、{1}ヶ月度前まで表示可能です。 */
	public static final String MSG_INF_CALENDER_DISP_ENABLE_ARG = "Mapi009";
	/** 変更箇所は存在しないため、登録処理を行う必要はありません。 */
	public static final String MSG_INF_NO_CHANGE_POINT = "Mapi010";
	/** 対象データを登録しますか？ */
	public static final String MSG_INF_REGIST_DATA = "Mapi011";
	/** 対象データを削除しますがよろしいですか？ */
	public static final String MSG_INF_REMOVE_DATA = "Mapi012";
	/** 対象データを更新しますか？ */
	public static final String MSG_INF_UPDATE_DATA = "Mapi013";
	/** パスワードが変更されました｡ */
	public static final String MSG_INF_PASSWORD_UPDATE = "Mapi014";
	/** パスワードが変更されました｡{0}秒後に自動的にトップ画面へ遷移します。 */
	public static final String MSG_INF_PASSWORD_UPDATE_AUTO_MOVE = "Mapi015";
	/** 登録が正常に完了しました。 */
	public static final String MSG_INF_NML_REGIST_END = "Mapi016";
	/** 登録が正常に完了しました。再ログイン後に反映されます。 */
	public static final String MSG_INF_NML_REGIST_END_RELOGIN = "Mapi017";
	/** コピーを作成しますが、よろしいですか？ */
	public static final String MSG_INF_COPY_DATA = "Mapi018";
	/** 削除が正常に完了しました。 */
	public static final String MSG_INF_DEL_NML_END = "Mapi019";
	/** 対象データを削除しますがよろしいですか？完了後は一つ前の画面に遷移します。 */
	public static final String MSG_INF_REMOVE_DATA_AND_TRANS = "Mapi020";
	/** 入力した変更後の合計金額と、元の金額合計が異なりますがよろしいですか？ */
	public static final String MSG_WRN_TOTAL_MONEY_DIFF = "Mapw001";
	/** 内容が変更されています。移動すると変更した内容は破棄されます。よろしいですか？ */
	public static final String MSG_WRN_CHANGE_DATA_DISCARD = "Mapw002";
	/** 変更入力した内容が未登録の状態で画面を遷移しようとしています。よろしいですか？変更内容を登録確定したい場合は、１画面単位で登録処理を行う必要があります。 */
	public static final String MSG_WRN_NOT_REGIST_DATA_DISCARD = "Mapw003";
	/** ブラウザの「戻る」や「更新」を行うと、再度ログイン画面から行う必要があります。よろしいですか？ */
	public static final String MSG_WRN_BACK_REFRESH_RELOGIN = "Mapw004";
	/** パスワードの有効期限が切れています。パスワードを変更してください。 */
	public static final String MSG_WRN_PASSWORD_EXPIRED = "Mapw005";
	/** パスワードが仮パスワードとなっています。パスワードを変更してください。 */
	public static final String MSG_WRN_NOW_TMP_PASSWORD = "Mapw006";
	/** 現在のパスワードを削除し、仮パスワードを登録しますがよろしいですか？なお、仮パスワード発行後は、現在のパスワードはご使用になれませんのでご注意下さい。 */
	public static final String MSG_WRN_REGIST_TMP_PASSWORD = "Mapw007";
	/** {0}は必須入力です。入力して下さい。 */
	public static final String MSG_ERR_INPUT_CHK_REQUIRD = "Mape001";
	/** {0}には、{1}文字以内の全角文字を入力して下さい。 */
	public static final String MSG_ERR_INPUT_CHK_FULL_STR_WTN = "Mape002";
	/** {0}には、{1}文字以内の半角英数字を入力して下さい。 */
	public static final String MSG_ERR_INPUT_CHK_HALF_STR_WTN = "Mape003";
	/** {0}には、{1}文字以内の半角数字を入力して下さい。 */
	public static final String MSG_ERR_INPUT_CHK_HALF_NUM_WTN = "Mape004";
	/** {0}には、{1}文字の全角文字を入力して下さい。 */
	public static final String MSG_ERR_INPUT_CHK_FULL_STR = "Mape005";
	/** {0}には、{1}文字の半角英数字を入力して下さい。 */
	public static final String MSG_ERR_INPUT_CHK_HALF_STR = "Mape006";
	/** {0}には、{1}文字の半角数字を入力して下さい。 */
	public static final String MSG_ERR_INPUT_CHK_HALF_NUM = "Mape007";
	/** {0}には、{1}文字以内の文字を入力して下さい。 */
	public static final String MSG_ERR_INPUT_CHK_STR_WTN = "Mape008";
	/** {0}に不正な文字が入力されています。正しい値を指定して下さい。 */
	public static final String MSG_ERR_INPUT_CHK_INVALID_STR = "Mape009";
	/** 登録する行を指定して下さい。 */
	public static final String MSG_ERR_NO_ROW_SELECT = "Mape010";
	/** 指定した日付の範囲の大小関係に誤りがあります。正しく入力し直して下さい。 */
	public static final String MSG_ERR_REV_LARGE_SMALL_DATE = "Mape011";
	/** 指定した{0}の範囲の大小関係に誤りがあります。正しく入力し直して下さい。 */
	public static final String MSG_ERR_REV_LARGE_SMALL_ARG = "Mape012";
	/** 日付の範囲指定を行う場合は最長{0}までとなります。入力し直して下さい。 */
	public static final String MSG_ERR_BETWEEN_DATE_MAX = "Mape013";
	/** {0}より前の日付は指定できません。正しい日付を入力して下さい。 */
	public static final String MSG_ERR_LASTEST_DATE = "Mape014";
	/** 指定された日付は存在しません。正しい日付を入力して下さい。 */
	public static final String MSG_ERR_NOT_EXIST_DATE = "Mape015";
	/** 未来の日付は指定できません。正しい日付を入力して下さい。 */
	public static final String MSG_ERR_FUTURE_DATE = "Mape016";
	/** 日付の入力形式に誤りがあります。正しく入力し直して下さい。 */
	public static final String MSG_ERR_DATE_FORMAT = "Mape017";
	/** 差分金額が発生しています。差分金額が0になるよう金種、又は合計金額を入力し直して下さい。 */
	public static final String MSG_ERR_OCCUR_MONAY_DIFF = "Mape018";
	/** 金種の合計が{0}桁以上の金額となっています。金種を入力し直して下さい。 */
	public static final String MSG_ERR_OVER_MONEY_ARG = "Mape019";
	/** アップロードが失敗しました。要因を取除き再度実施して下さい。 */
	public static final String MSG_ERR_UP_FAIL_END = "Mape020";
	/** ダウンロードが失敗しました。要因を取除き再度実施して下さい。 */
	public static final String MSG_ERR_DOWN_FAIL_END = "Mape021";
	/** {0}が失敗しました。要因を取除き再度実施して下さい。 */
	public static final String MSG_ERR_FAILE_FAIL_END_ARG = "Mape022";
	/** 入力ファイルの形式が不正です。正しい形式で実施して下さい。 */
	public static final String MSG_ERR_INPUT_FILE_FORMAT = "Mape023";
	/** 入力ファイル{0}の{1}が不正です。正しい値を設定して下さい。 */
	public static final String MSG_ERR_INPUT_FILE_ARG = "Mape024";
	/** 帳票生成に失敗しました。 */
	public static final String MSG_ERR_CREATE_OUTPUT_FORM = "Mape025";
	/** 新規登録のため、削除はできません。 */
	public static final String MSG_ERR_NOT_DELETE_NEW_DATA = "Mape026";
	/** 指定した店舗グループに重複があります。 */
	public static final String MSG_ERR_SHOP_LIST_OVERLAP = "Mape027";
	/** 指定した{0}に重複があります。 */
	public static final String MSG_ERR_OVERLAP_DATA_ARG = "Mape028";
	/** 指定した顧客と顧客グループの組合せに誤りがあります。 */
	public static final String MSG_ERR_CUSTOMER_COMBI = "Mape029";
	/** 指定した店舗と店舗グループの組合せに誤りがあります。 */
	public static final String MSG_ERR_SHOP_NOT_COMBI = "Mape030";
	/** 指定した{0}と{1}の組合せに誤りがあります。 */
	public static final String MSG_ERR_SPEC_NOT_COMBI = "Mape031";
	/** 顧客と店舗は対で選択して下さい。 */
	public static final String MSG_ERR_CUSTOMER_SHOP_COMBI = "Mape032";
	/** {0}と{1}は対で選択して下さい。 */
	public static final String MSG_ERR_SPEC_COMBI = "Mape033";
	/** 入力されたユーザーＩＤ、又はパスワードが間違っています。再度入力して下さい。 */
	public static final String MSG_ERR_LOGIN_COLLECT = "Mape034";
	/** ログインすることができません｡ロックアウトされています。システム管理者に問い合わせてください。 */
	public static final String MSG_ERR_LOGIN_LOCK_OUT = "Mape035";
	/** 新パスワードとユーザーIDが同じです。異なるパスワードに変更してください。 */
	public static final String MSG_ERR_NOT_SAME_PASSWORD = "Mape036";
	/** 新パスワードは、8文字以上で英大文字・英小文字・数字をそれぞれ1文字以上含むものを指定して下さい。 */
	public static final String MSG_ERR_PASSWORD_COMBI = "Mape037";
	/** 新パスワードは、3文字以上連続する文字を指定しないで下さい。 */
	public static final String MSG_ERR_PASSWORD_SERIAL = "Mape038";
	/** 新パスワードに入力された文字列は、パスワードとして使用が制限されています。 */
	public static final String MSG_ERR_PASSWORD_DISABLE = "Mape039";
	/** 再パスワードが間違っています。新パスワードと同じものを入力して下さい。 */
	public static final String MSG_ERR_PASSWORD_NOT_SAME = "Mape040";
	/** パスワードを続けて間違えたためロックされました。しばらくしてからもう一度、ログインし直して下さい。（解除待ち時間{0}分） */
	public static final String MSG_ERR_PASSWORD_MISS_LOCK_OUT = "Mape041";
	/** パスワードとパスワード再入力を入力して下さい。 */
	public static final String MSG_ERR_PASSWORD_RE_ENTER = "Mape042";
	/** パスワード変更ができません｡現在使用しているパスワードと[0]が一致しません。 */
	public static final String MSG_ERR_PASSWORD_NOT_CHANGE = "Mape043";
	/** ユーザーＩＤは、すべて同一文字を指定しないで下さい。 */
	public static final String MSG_ERR_USER_ID_NOT_SAME = "Mape044";
	/** データベースのアクセスで異常が発生しました。 */
	public static final String MSG_ERR_DB_ACCESS = "Mape045";
	/** 登録しようとした情報は、本処理中に他のユーザに変更された可能性があります。内容を確認して下さい。 */
	public static final String MSG_ERR_OPT_EXCLUSION = "Mape046";
	/** 登録しようとしたデータはすでに登録済みです。 */
	public static final String MSG_ERR_DATA_REGISTERED = "Mape047";
	/** 本処理中に他のユーザに変更された可能性があります。内容を確認して下さい。 */
	public static final String MSG_ERR_OPT_EXCLUSION_NOT_REGIST = "Mape048";
	/** 新パスワードに過去に使用したパスワードは指定できません。 */
	public static final String MSG_ERR_PASSWORD_OLD_NOT_SAME = "Mape049";
	/** 本処理中に他のユーザに変更された可能性があります。セキュリティのため{0}秒後に自動的にログアウトします。 */
	public static final String MSG_ERR_OPT_PASSWORD_UPDATE = "Mape050";
	/** 選択された{0}に一致するデータはありませんでした。 */
	public static final String MSG_ERR_SELECT_CON_NO_DATA = "Mape051";
	/** 指定する日付は「yyyyMMdd」または「yyyy/MM/dd」の形式で入力してください。 */
	public static final String MSG_ERR_INPUT_CHK_DATE_ERROR = "Mape052";
	/** 入力した文字数が最大値を超えています。 */
	public static final String MSG_ERR_INPUT_CHK_MAX_STR = "Mape053";
	/** {0}に不正な文字が入力されています。 */
	public static final String MSG_ERR_INPUT_CHK_INVALID_STRING = "Mape054";
	/** {0}が特定できません。{1}を実行して絞り込みを行ってください。 */
	public static final String MSG_ERR_CAN_NOT_IDENTIFY_DATA = "Mape055";
	/** 「{0}」は対象を選択した状態では実施できません。 */
	public static final String MSG_ERR_DESELECT_COLUMN = "Mape056";
	/** {0}対象が選択されていません。選択して下さい。 */
	public static final String MSG_ERR_NOT_SELECT_COLUMN = "Mape057";
	/** 対象データのコピーに失敗しました。 */
	public static final String MSG_ERR_FAIL_COPY = "Mape058";
	/** {0}は半角数字のみを入力してください。 */
	public static final String MSG_ERR_INPUT_NUMBER_ONLY = "Mape059";
	/** 入力された合計金額と枚数から算出された合計金額に違いがあります。内容を確認してください。 */
	public static final String MSG_ERR_COMPARE_SPCCMT_ERROR = "Mape060";
	/** 登録する内容がありません。 */
	public static final String MSG_ERR_REGIST_NOTHING_DATA = "Mape061";
	/** 登録する内容の中に同一のデータが存在します。内容を確認してください。 */
	public static final String MSG_ERR_REGIST_DUPLICATION_DATA = "Mape062";
	/** 登録する内容の中に{0}のデータが存在します。内容を確認してください。 */
	public static final String MSG_ERR_REGIST_EXISTENCE_DATA = "Mape063";
	/** {0}には、{1}文字の半角英字を入力して下さい。 */
	public static final String MSG_ERR_INPUT_CHK_HALF_ALP = "Mape064";
	/** {0}には、大文字は使用できません。 */
	public static final String MSG_ERR_INPUT_CHK_BIG_CHAR_NOT = "Mape065";
	/** {0}には、同一文字が連続したものは使用できません。 */
	public static final String MSG_ERR_INPUT_CHK_CONTINUE_CHAR = "Mape066";
	/** 指定されたIDは既に使用されています。 */
	public static final String MSG_ERR_ALREADY_USE_CHECK = "Mape067";


	/*************************************************************************************
	 * エラーログファイル出力文字列定数
	 ************************************************************************************/
	/** 発生日時 */
	public static final String ERR_LOG_H_DATE = "発生日時";
	/** ログインID */
	public static final String ERR_LOG_H_LOGIN_ID = "ログインID";
	/** 区分 */
	public static final String ERR_LOG_H_KBN = "区分";
	/** 業務名 */
	public static final String ERR_LOG_H_GYOMU_NM = "業務名";
	/** ログ情報ヘッダ */
	public static final String ERR_LOG_H_LOG_HEAD = "ログ情報ヘッダ";
	/** ログ情報 */
	public static final String ERR_LOG_H_LOG_INFO = "ログ情報";
	/** 発生した例外 */
	public static final String ERR_LOG_H_EXCEPTION = "発生した例外";
	/** 例外が発生したクラス名称 */
	public static final String ERR_LOG_H_CLASS_NM = "例外が発生したクラス名称";
	/** 例外が発生したメソッド名称 */
	public static final String ERR_LOG_H_METHOD_NM = "例外が発生したメソッド名称";
	/** メッセージID */
	public static final String ERR_LOG_H_MESSAGE_ID = "メッセージID";
	/** メッセージ内容 */
	public static final String ERR_LOG_H_MESSAGE = "メッセージ内容";
	/** メッセージ種別 */
	public static final String ERR_LOG_H_MESSAGE_KIND = "メッセージ種別";
	/** ログ開始 */
	public final static String ERR_LOG_STATUS_START = "開始";
	/** ログ終了 */
	public final static String ERR_LOG_STATUS_END = "終了";
	/** ログ異常終了 */
	public final static String ERR_LOG_STATUS_ERROR = "異常終了";

}
