/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) ActopBusinessBase.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.top.business;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsBusinessPcBase;

/*****************************************************************************************
 * AclogBusinessBaseクラス<br>
 *****************************************************************************************/
public abstract class ActopBusinessBase extends AmclsBusinessPcBase {

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  mapping
	 * @param  form
	 * @param  request
	 * @param  response
	 * @param  context
	 * @param  gid
	 * @param  event
	 * @return 無し
	 ************************************************************************************/
	public ActopBusinessBase(HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);
	}
}
