/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AceumShopGrpDto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * ドロップダウン情報 <br>
 *****************************************************************************************/
public class AceumShopGrpDto extends AmclsDtoBase {

	/** メンバ変数 */
	/** 店舗グループコード */
	private String shopGrpCd = null;
	/** 店舗グループ名 */
	private String shopGrpNm = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AceumShopGrpDto() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		this.shopGrpCd = null;
		this.shopGrpNm = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getShopGrpCd() {
		return shopGrpCd;
	}

	public void setShopGrpCd(String shopGrpCd) {
		this.shopGrpCd = shopGrpCd;
	}

	public String getShopGrpNm() {
		return shopGrpNm;
	}

	public void setShopGrpNm(String shopGrpNm) {
		this.shopGrpNm = shopGrpNm;
	}

}
