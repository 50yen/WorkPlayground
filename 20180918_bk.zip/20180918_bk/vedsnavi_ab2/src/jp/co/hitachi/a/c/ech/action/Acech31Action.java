/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech31Action.java
 *
 * ----------------------------------------------------
 * 2018.08.21 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.action;

import jp.co.hitachi.a.c.ech.bean.Acech31DispBean;
import jp.co.hitachi.a.c.ech.business.Acech31Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Acech31Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Acech31DispBean acech31DispBean;

	/** 顧客CD */
	private String cstCd = null;
	/** 顧客名 */
	private String cstNm = null;
	/** 店舗CD */
	private String shopCd = null;
	/** 店舗名 */
	private String shopNm = null;
	/** 店舗枝番 */
	private String shopSbno = null;
	/** 表示店舗枝番 */
	private String dispShopSbno = null;
	/** 回収日 */
	private String cld = null;
	/** プルダウンリスト選択値 */
	private int dispResults = 0;
	/** ページ番号 */
	private int displayNum = 0;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAcech31DispBean((Acech31DispBean)request.getAttribute("Acech31DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Acech31Business dao = new Acech31Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Acech31DispBean getAcech31DispBean() {
		return acech31DispBean;
	}

	public void setAcech31DispBean(Acech31DispBean acech31DispBean) {
		this.acech31DispBean = acech31DispBean;
	}

	public int getDispResults() {
		return dispResults;
	}

	public void setDispResults(int dispResults) {
		this.dispResults = dispResults;
	}

	public int getDisplayNum() {
		return displayNum;
	}

	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}

	public String getCstCd() {
		return cstCd;
	}

	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}

	public String getCstNm() {
		return cstNm;
	}

	public void setCstNm(String cstNm) {
		this.cstNm = cstNm;
	}

	public String getShopCd() {
		return shopCd;
	}

	public void setShopCd(String shopCd) {
		this.shopCd = shopCd;
	}

	public String getShopNm() {
		return shopNm;
	}

	public void setShopNm(String shopNm) {
		this.shopNm = shopNm;
	}

	public String getShopSbno() {
		return shopSbno;
	}

	public void setShopSbno(String shopSbno) {
		this.shopSbno = shopSbno;
	}

	public String getDispShopSbno() {
		return dispShopSbno;
	}

	public void setDispShopSbno(String dispShopSbno) {
		this.dispShopSbno = dispShopSbno;
	}

	public String getCld() {
		return cld;
	}

	public void setCld(String cld) {
		this.cld = cld;
	}


}
