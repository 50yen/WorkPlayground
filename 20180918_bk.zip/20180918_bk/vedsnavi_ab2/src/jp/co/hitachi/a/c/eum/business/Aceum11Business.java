/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aceum11DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.business;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.eum.action.Aceum11Action;
import jp.co.hitachi.a.c.eum.bean.Aceum11DispBean;
import jp.co.hitachi.a.c.eum.dto.Aceum11Dto;
import jp.co.hitachi.a.c.eum.dto.AceumItemDispDto;
import jp.co.hitachi.a.c.eum.dto.AceumShopGrpDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.AuthRole;
import jp.co.hitachi.a.m.all.AmallConst.GeneralFlg;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallConst.LoginFlg;
import jp.co.hitachi.a.m.all.AmallConst.MsgCode;
import jp.co.hitachi.a.m.all.AmallConst.SystemType;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallPasswordControl;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoDropDownList;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;
import jp.co.hitachi.a.m.dto.AmdtoLoginInfo;
import jp.co.hitachi.a.m.dto.AmdtoRadioList;

/*****************************************************************************************
 * Aceum11Businessクラス<br>
 *****************************************************************************************/
public class Aceum11Business extends AceumBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Aceum11DispBean";
	/** 表示モード:新規 */
	private static final int MODE_NEW = 0;
	/** 表示モード:更新 */
	private static final int MODE_UPDATE = 1;

	/** ユーザーID関連:前半 */
	private static final String MSG_HEAD = "(前半)";
	/** ユーザーID関連:後半 */
	private static final String MSG_BACK = "(後半)";
	/** ユーザーID関連:OK */
	private static final String DISP_OK = "OK";
	/** ユーザーID関連:OK CSS名 */
	private static final String DISP_OK_STYLE = "checkOk";
	/** ユーザーID関連:NG */
	private static final String DISP_NG = "NG";
	/** ユーザーID関連:NG CSS名 */
	private static final String DISP_NG_STYLE = "checkNg";
	/** ユーザーID関連:企業管理者 後半ID固定値 */
	private static final String CST_MNG_ID_BACK = "00001";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	private static final String FORWARD_DISP = "DISP";
	/** ユーザーIDチェック */
	private static final String FORWARD_IDCHECK = "IDCHECK";
	/** 店舗グループ追加 */
	private static final String FORWARD_ADDSHOPGRP = "ADDSHOPGRP";
	/** 登録 */
	private static final String FORWARD_REGIST = "REGIST";
	/** 削除 */
	private static final String FORWARD_DELETE = "DELETE";
	/** 戻る */
	private static final String FORWARD_BACK = "RETURNPAGE";
	/** 戻る(削除処理完了時) */
	private static final String FORWARD_RETURN_DEL = "DELRETURN";

	/**
	 * 画面項目ID
	 */
	/** ユーザーID */
	private static final String ITEM_ID_USER_ID = "userIdInput";
	/** チェックボタン結果 */
	private static final String ITEM_ID_USER_CHECK_LABEL = "userIdLabel";
	/** ユーザー名 */
	private static final String ITEM_ID_USER_NM = "userNmInput";
	/** 権限 */
	private static final String ITEM_ID_ROLE = "roleDropDown";
	/** 顧客コード */
	private static final String ITEM_ID_CST_CD = "customerSearchNm";
	/** 顧客検索ボタン */
	private static final String ITEM_ID_CST_SEARCH = "customerSearchChildBtn";
	/** 店舗グループ */
	private static final String ITEM_ID_SHOP_GRP_CD = "shopGrpSearchNm";
	/** 店舗コード */
	private static final String ITEM_ID_SHOP_CD = "shopSearchNm";
	/** 店舗検索ボタン */
	private static final String ITEM_ID_SHOP_SEARCH = "shopSearchChildBtn";
	/** コメント */
	private static final String ITEM_ID_CMT = "cmtInput";
	/** パスワード */
	public static final String ITEM_ID_PASS = "passwordInput";
	/** 再パスワード */
	public static final String ITEM_ID_RE_PASS = "rePasswordInput";
	/** パスワード有効期限 */
	public static final String ITEM_ID_PASSEXP = "passwordExpDate";
	/** パスワード有効期間 */
	public static final String ITEM_ID_PASSVALID = "passwordValidDate";
	/** パスワードロック */
	public static final String ITEM_ID_PASS_LOCK = "passwordLock";
	/** アカウントロック */
	public static final String ITEM_ID_ACT_LOCK = "accountLock";



	/** DTOキー名 */
	private static final String DTO_KEY = "DTO_ACEUM11";


	/** メンバ変数 */
	/** アクションフォーム */
	private Aceum11Action m_Aceum11Form = null;
	/** 表示用画面Bean */
	private Aceum11DispBean m_Aceum11DispBean = null;
	/** 画面DTO */
	private Aceum11Dto m_Aceum11Dto;
	/** 特殊権限ロール */
	List<AmdtoGeneralMst> m_RoleGeneralMstList = new ArrayList<>();

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Aceum11Business(
			Aceum11Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Aceum11Business.class.getName();
		m_Aceum11Form = form;
		m_Aceum11DispBean = new Aceum11DispBean();
		m_Aceum11Dto = new Aceum11Dto();
		setErrString(gid, m_Aceum11Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Aceum11DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Aceum11Form.getM_systemKind());
			m_DbAccess.initDB();

			/* 内部記憶情報の生成 */
			m_Aceum11Dto = (Aceum11Dto) getSpecifiedDTO(m_Gid, DTO_KEY);
			if (m_Aceum11Dto == null || FORWARD_DISP.equals(m_Event)) {
				deleteSpecifiedDTO(m_Gid);
				m_Aceum11Dto = new Aceum11Dto();
				putSpecifiedDTO(m_Gid, DTO_KEY, m_Aceum11Dto);
			}

			// 遷移元情報取得
			aceumInfoDto = (AceumItemDispDto) getSpecifiedDTO(ACEUM_INFO_KEY);
			if (aceumInfoDto != null) {
				m_Aceum11Dto.setUserId(aceumInfoDto.getUserId());
				m_Aceum11Dto.setSystemKind(aceumInfoDto.getSystemKind());
				// DTO削除
				delSpecifiedDTO(ACEUM_INFO_KEY);
			}

			// 共通取得処理
			getCommonData();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_IDCHECK.equals(m_Event)) {
				// チェックボタン押下の場合
				forwardStr = idCheck();
			} else if (FORWARD_ADDSHOPGRP.equals(m_Event)) {
				// 店舗グループ追加ボタン押下の場合
				forwardStr = addShopGrp();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				// 登録ボタン押下の場合
				forwardStr = regist();
			} else if (FORWARD_DELETE.equals(m_Event)) {
				// 削除ボタン押下の場合
				forwardStr = delete();
			} else if (FORWARD_BACK.equals(m_Event)) {
				// 戻るボタン押下の場合
				forwardStr = back();
			} else {
				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {

			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Aceum11DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * 入力値が存在する場合は初期検索を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException, Exception {

		// 新規更新判定
		if (AmallUtilities.isEmpty(m_Aceum11Dto.getUserId())) {
			// ユーザーIDがない場合は新規モードにする
			m_Aceum11Form.setDispMode(MODE_NEW);
			m_Aceum11Dto.setDispMode(MODE_NEW);
		} else {
			// ユーザーIDがある場合は更新モードにする
			m_Aceum11Form.setDispMode(MODE_UPDATE);
			m_Aceum11Dto.setDispMode(MODE_UPDATE);

			// 初期検索
			// ユーザーマスタ検索
			getUserMst(m_Aceum11Dto.getUserId(), m_Aceum11Dto.getSystemKind(), m_Aceum11DispBean.getServiceDate());
			// 店舗グループマスタ検索(エリア管理のみ)
			if (AuthRole.CST_AREA.equals(m_Aceum11Form.getSelectedRoleCd())) {
				getShopGrpMngMst(m_Aceum11Dto.getUserId(), m_Aceum11DispBean.getServiceDate());
			}
		}

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 共通情報取得処理
	 * <p>
	 * 画面に表示するプルダウンリスト等の値を取得する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private void getCommonData() throws AmallException, Exception {

		// 表示モード
		if(m_Aceum11Dto.getDispMode() != 0) {
			m_Aceum11Form.setDispMode(MODE_UPDATE);
		}

		// 顧客コード
		if(!AmallUtilities.isEmpty(m_Aceum11Form.getInputedCstCd())) {
			// 顧客名設定(取得できない判定はしない)
			chkUniqCst(m_Aceum11Form.getInputedCstCd());
		}

		// 店舗コード
		if(!AmallUtilities.isEmpty(m_Aceum11Form.getInputedCstCd()) && !AmallUtilities.isEmpty(m_Aceum11Form.getInputedShopCd())) {
			// 店舗名設定(取得できない判定はしない)
			chkUniqShop(m_Aceum11Form.getInputedCstCd(), m_Aceum11Form.getInputedShopCd());
		}

		// 権限一覧を取得する
		// 内部記憶に存在する場合はそちらを使用する
		if(m_Aceum11Dto.getRoleDropDownList() != null) {
			// 権限一覧の設定
			m_Aceum11DispBean.setRoleDropDownList(m_Aceum11Dto.getRoleDropDownList());

		} else {
			List<AmdtoDropDownList> roleList =  getAuthRoleList(m_Aceum11Form.getM_systemKind());

			// 汎用マスタ取得(特殊権限ロール)
			m_RoleGeneralMstList = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.PASSWORD_LOCK_RADIO, null, null, m_Aceum11DispBean.getServiceDate());

			// システム種別が顧客OLの場合は特殊権限ロールを排除する
			if (SystemType.CUSTOMER == m_Aceum11Form.getM_systemKind()) {
				for (AmdtoDropDownList downData : roleList) {
					for (AmdtoGeneralMst removeData : m_RoleGeneralMstList) {
						// 削除対象権限か確認
						if (removeData.getGeneralCd1().equals(downData.getId())) {
							// 一致した場合 リストから削除
							roleList.remove(roleList.indexOf(downData));
						}
					}
				}
			}

			// 権限一覧の設定
			m_Aceum11DispBean.setRoleDropDownList(roleList);
			m_Aceum11Dto.setRoleDropDownList(roleList);
		}

		// パスワードロックラジオボタン
		// 内部記憶に存在する場合はそちらを使用する
		if(m_Aceum11Dto.getRadioPwdLockList() != null) {

			// Beanに設定
			m_Aceum11DispBean.setRadioPwdLockList(m_Aceum11Dto.getRadioPwdLockList());

		} else {
			// 汎用マスタ取得(パスワードロックラジオボタン)
			List<AmdtoGeneralMst> pwdGeneralMstList = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.PASSWORD_LOCK_RADIO, null, null, m_Aceum11DispBean.getServiceDate());

			// 設定用リスト生成
			List<AmdtoRadioList> pwdList = new ArrayList<>();
			// 取得データ繰り返し
			for (AmdtoGeneralMst pwdMst : pwdGeneralMstList) {
				AmdtoRadioList dto = new AmdtoRadioList();
				// コード値
				dto.setId(pwdMst.getGeneralCd1());
				// 表示
				dto.setName(pwdMst.getGeneralNm1());

				// デフォルト区分
				if(GeneralFlg.ON.equals(pwdMst.getDefaultFlg())) {
					// 初期値
					if (m_Aceum11Form.getSelectedPwdLockRadio() == null) {
						m_Aceum11Form.setSelectedPwdLockRadio(pwdMst.getGeneralCd1());

					}
				}
				// リストに設定
				pwdList.add(dto);
			}
			// Beanに設定
			m_Aceum11DispBean.setRadioPwdLockList(pwdList);
			m_Aceum11Dto.setRadioPwdLockList(pwdList);
		}

		// アカウントロックラジオボタン
		// 内部記憶に存在する場合はそちらを使用する
		if(m_Aceum11Dto.getRadioActLockList() != null) {

			// Beanに設定
			m_Aceum11DispBean.setRadioActLockList(m_Aceum11Dto.getRadioActLockList());

		} else {
			// 汎用マスタ取得(アカウントロックラジオボタン)
			List<AmdtoGeneralMst> actGeneralMstList = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.ACCOUNT_LOCK_RADIO, null, null, m_Aceum11DispBean.getServiceDate());

			// 設定用リスト生成
			List<AmdtoRadioList> actList = new ArrayList<>();
			for (AmdtoGeneralMst actMst : actGeneralMstList) {
				AmdtoRadioList dto = new AmdtoRadioList();
				// コード値
				dto.setId(actMst.getGeneralCd1());
				// 表示
				dto.setName(actMst.getGeneralNm1());

				// デフォルト区分
				if(GeneralFlg.ON.equals(actMst.getDefaultFlg())) {
					// 初期値
					if (m_Aceum11Form.getSelectedActLockRadio() == null) {
						m_Aceum11Form.setSelectedActLockRadio(actMst.getGeneralCd1());
					}
				}
				// リストに設定
				actList.add(dto);
			}
			// Beanに設定
			m_Aceum11DispBean.setRadioActLockList(actList);
			m_Aceum11Dto.setRadioActLockList(actList);
		}

		// 店舗グループ初期時のみ空データ設定
		if(m_Aceum11Form.getShopGrpList() == null) {

			List<AceumShopGrpDto> emptyList = new ArrayList<>();

			AceumShopGrpDto dto = new AceumShopGrpDto();
			dto.setShopGrpCd("");
			dto.setShopGrpNm("");
			emptyList.add(dto);

			// 空データを設定
			m_Aceum11Form.setShopGrpList(emptyList);
		}

	}
	/*************************************************************************************
	 * チェックボタン押下処理実行
	 * <p>
	 * チェックボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String idCheck() throws AmallException, Exception {

		// ユーザーID(前半)
		String userIdHead = m_Aceum11Form.getInputedUserIdHead();

		if (m_Aceum11Form.getM_systemKind() == SystemType.CUSTOMER) {
			// 顧客OLの場合は5桁を取得
			userIdHead = getFirstUserId();
		}

		// ユーザーID(後半)
		String userIdBack = m_Aceum11Form.getInputedUserIdBack();

		// 権限ロールコード
		String roleCd = m_Aceum11Form.getSelectedRoleCd();

		// 入力チェック(エラー表示なし)
		if (!inputCheckUserId(userIdHead, userIdBack, roleCd, false)) {
			m_Aceum11Form.setUserIdCheckResult(DISP_NG);
			setStyle(m_Aceum11DispBean, ITEM_ID_USER_CHECK_LABEL, DISP_NG_STYLE);
		} else {
			m_Aceum11Form.setUserIdCheckResult(DISP_OK);
			setStyle(m_Aceum11DispBean, ITEM_ID_USER_CHECK_LABEL, DISP_OK_STYLE);
		}




		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * ログインユーザーから前半ユーザーID取得
	 * <p>
	 * ログインユーザーの前半5桁を取得する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String getFirstUserId() {

		// ログインユーザーID取得
		String loginUserId = m_Aceum11DispBean.getH_loginId();

		if(loginUserId != null && loginUserId.length() > 5) {
			loginUserId.substring(0, 5);
		}

		return loginUserId;
	}
	/*************************************************************************************
	 * 店舗グループ追加ボタン押下処理実行
	 * <p>
	 * 店舗グループ追加ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String addShopGrp() throws AmallException {

		List<AceumShopGrpDto> grplist = m_Aceum11Form.getShopGrpList();
		AceumShopGrpDto grpdto = new AceumShopGrpDto();
		grpdto.setShopGrpCd("");
		grpdto.setShopGrpNm("");
		grplist.add(grpdto);
		 m_Aceum11Form.setShopGrpList(grplist);

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 登録ボタン押下処理実行
	 * <p>
	 * 登録ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException, Exception {

		// 入力値チェック
		if (!inputCheck()) {
			return FORWARD_DISP;
		}

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 削除ボタン押下処理実行
	 * <p>
	 * 削除ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String delete() throws AmallException {

		return FORWARD_RETURN_DEL;
	}
	/*************************************************************************************
	 * 戻るボタン押下処理実行
	 * <p>
	 * 戻るボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String back() throws AmallException {

		return FORWARD_BACK;
	}
	/*************************************************************************************
	 * 入力値チェック
	 * <p>
	 * 入力値チェックを実施する
	 * </p>
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheck() throws AmallException, Exception {

		// 返却フラグ
		boolean ret = true;

		// 権限ロールコード
		String roleCd = m_Aceum11Form.getSelectedRoleCd();
		// 入力値チェック(権限)
		if (AmallUtilities.isEmpty(roleCd)) {
			// 入力値が存在しない場合
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_ROLE, m_Aceum11DispBean));
			setError(m_Aceum11DispBean, ITEM_ID_ROLE);

			ret = false;

		} else {
			// 存在する場合
			// 顧客コード
			String cstCd = m_Aceum11Form.getInputedCstCd();
			// 店舗グループ
			List<AceumShopGrpDto> list = m_Aceum11Form.getShopGrpList();
			// 店舗コード
			String shopCd = m_Aceum11Form.getInputedCstCd();

			switch (roleCd) {
				case AuthRole.ASS_MNGR:
				case AuthRole.ASS_CNTL:
				case AuthRole.ASS_CMPY:
				case AuthRole.ASS_SALE:
					// ASS社員の場合
					break;
				case AuthRole.CST_MNGR:
				case AuthRole.CST_OFFC:
					// お客様の場合

					// 顧客コードチェック
					if(!cstCdCheck(cstCd)) {
						ret = false;
					}
					// TODO 顧客グループチェック
					// 顧客コードが顧客グループに含まれていること

					break;
				case AuthRole.CST_AREA:
					// 顧客コードチェック
					if(!cstCdCheck(cstCd)) {
						ret = false;
					}

					// 店舗グループコードチェック
					boolean shopGrpChkFlg = false;
					for (AceumShopGrpDto shopGrpDto : list) {
						if (shopGrpDto.getShopGrpCd() != null || shopGrpDto.getShopGrpCd().length() > 0) {
							// TODO 店舗グループチェック
							// 顧客コードに属する店舗グループであること

							// 店舗グループに値がある場合
							shopGrpChkFlg = true;
						}
					}

					if(!shopGrpChkFlg) {
						// 店舗グループに値がない場合
						// 店舗コードチェック
						if(!shopCdCheck(cstCd,shopCd, "または"  + getItemDispName(ITEM_ID_SHOP_GRP_CD, m_Aceum11DispBean))) {
							ret = false;
						}
					} else {
						// 店舗グループに値がある場合
						if (!AmallUtilities.isEmpty(cstCd)) {
							// TODO 店舗コードには値は設定できない
							setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
									getItemDispName(ITEM_ID_SHOP_CD, m_Aceum11DispBean), String.valueOf(InputNum.SHOP_CD));
							setError(m_Aceum11DispBean, ITEM_ID_SHOP_CD);
						}
					}


					break;
				case AuthRole.CST_SHOP:
				case AuthRole.CST_CLRK:
					// 顧客コードチェック
					if(!cstCdCheck(cstCd)) {
						ret = false;
					}

					// 店舗コードチェック
					if(!shopCdCheck(cstCd,shopCd, "")) {
						ret = false;
					}
					break;
				default:
					break;
			}

		}


		// == ユーザー情報エリア ==
		// ユーザーIDチェック
		if (m_Aceum11Dto.getDispMode() == MODE_NEW) {
			// 新規モードのみ
			// ユーザーID(前半)
			String userIdHead = m_Aceum11Form.getInputedUserIdHead();

			if (m_Aceum11Form.getM_systemKind() == SystemType.CUSTOMER) {
				// 顧客OLの場合はログインユーザーから5桁を取得
				userIdHead = getFirstUserId();
			}

			// ユーザーID(後半)
			String userIdBack = m_Aceum11Form.getInputedUserIdBack();

			if(!inputCheckUserId(userIdHead, userIdBack, roleCd, true)) {
				ret = false;
			}

		}

		// 自由記載エリアチェック
		// ユーザー名
		String userName = m_Aceum11Form.getInputedUserNm();
		// コメント
		String userCmt = m_Aceum11Form.getInputedCmt();

		if(!inputCheckFree(userName, userCmt)) {
			ret = false;
		}


		// == パスワード情報エリア ==
		// パスワードチェック
		// パスワード
		String pass = m_Aceum11Form.getPassword();
		// 再パスワード
		String rePass = m_Aceum11Form.getRePassword();

		if(!inputCheckPass(pass, rePass)) {
			ret = false;
		}


		// パスワード(期間)チェック
		// 有効期限なしフラグがONの場合はチェックなし
		if(!m_Aceum11Form.isCheckPwdExpFlg()) {
			// 有効期限
			String expDate = m_Aceum11Form.getInputedPasswordExp();
			// 有効期間
			String valid = m_Aceum11Form.getInputedPasswordValid();

			if(!inputCheckPassPeriod(expDate, valid)) {
				ret = false;
			}
		}

		// == その他 ==
		// パスワードロック ラジオボタンチェック
		String pLock = m_Aceum11Form.getSelectedPwdLockRadio();
		if(AmallUtilities.isEmpty(pLock)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_PASS_LOCK, m_Aceum11DispBean));
			ret = false;
		}

		// パスワードロック ラジオボタンチェック
		String actLock = m_Aceum11Form.getSelectedPwdLockRadio();
		if(AmallUtilities.isEmpty(actLock)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_ACT_LOCK, m_Aceum11DispBean));
			ret = false;
		}

		return ret;
	}
	/**********************************************************************************************
	 * 顧客コードチェック
	 *
	 * 顧客コードのチェックを行う
	 *
	 * @param cstCd 顧客コード
	 * @return boolean true:正常 false:異常
	 *********************************************************************************************/
	private boolean cstCdCheck(String cstCd) throws AmallException, Exception {

		// 返却フラグ
		boolean ret = true;

		// 顧客コードチェック(必須)
		boolean uniqChkFlg = true;
		if (!AmallUtilities.isEmpty(cstCd)) {
			if (!AmallUtilities.isHalfWidthCharacterKind(cstCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CST_CD, m_Aceum11DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Aceum11DispBean, ITEM_ID_CST_CD);

				ret = false;
				uniqChkFlg = false;
			} else if (AmallUtilities.getLengthAsHalf(cstCd) != InputNum.CST_CD) {
				// 10桁以外の数字が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CST_CD, m_Aceum11DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Aceum11DispBean, ITEM_ID_CST_CD);

				ret = false;
				uniqChkFlg = false;
			}
		} else {
			// 入力値が存在しない場合
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_CST_CD, m_Aceum11DispBean));
			setError(m_Aceum11DispBean, ITEM_ID_CST_CD);

			ret = false;
			uniqChkFlg = false;
		}

		if(uniqChkFlg) {
			// ユニークチェック
			if (!chkUniqCst(cstCd)) {
				// 特定できない場合
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_CAN_NOT_IDENTIFY_DATA,
						getItemDispName(ITEM_ID_CST_CD, m_Aceum11DispBean), getItemDispName(ITEM_ID_CST_SEARCH, m_Aceum11DispBean));
				setError(m_Aceum11DispBean, ITEM_ID_CST_CD);
				ret = false;
			}
		}

		return ret;
	}
	/**********************************************************************************************
	 * 店舗コードチェック
	 *
	 * 店舗コードのチェックを行う
	 *
	 * @param cstCd 顧客コード
	 * @param shopCd 店舗コード
	 * @param addMsg 追加メッセージ
	 * @return boolean true:正常 false:異常
	 *********************************************************************************************/
	private boolean shopCdCheck(String cstCd, String shopCd, String addMsg) throws AmallException, Exception {

		// 返却フラグ
		boolean ret = true;

		// 顧客コードチェック(必須)
		boolean uniqChkFlg = true;
		if (!AmallUtilities.isEmpty(shopCd)) {
			if (!AmallUtilities.isHalfWidthCharacterKind(shopCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
						getItemDispName(ITEM_ID_SHOP_CD, m_Aceum11DispBean), String.valueOf(InputNum.SHOP_CD));
				setError(m_Aceum11DispBean, ITEM_ID_SHOP_CD);

				ret = false;
				uniqChkFlg = false;
			} else if (AmallUtilities.getLengthAsHalf(shopCd) > InputNum.SHOP_CD) {
				// 10桁より多い数字が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
						getItemDispName(ITEM_ID_SHOP_CD, m_Aceum11DispBean), String.valueOf(InputNum.SHOP_CD));
				setError(m_Aceum11DispBean, ITEM_ID_SHOP_CD);

				ret = false;
				uniqChkFlg = false;
			}
		} else {
			// 入力値が存在しない場合
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_SHOP_CD, m_Aceum11DispBean) + addMsg);
			setError(m_Aceum11DispBean, ITEM_ID_SHOP_CD);

			ret = false;
			uniqChkFlg = false;
		}

		if(uniqChkFlg) {
			// ユニークチェック
			if (!chkUniqShop(cstCd, shopCd)) {
				// 特定できない場合
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_CAN_NOT_IDENTIFY_DATA,
						getItemDispName(ITEM_ID_SHOP_CD, m_Aceum11DispBean), getItemDispName(ITEM_ID_SHOP_SEARCH, m_Aceum11DispBean));
				setError(m_Aceum11DispBean, ITEM_ID_SHOP_CD);
				ret = false;
			}
		}

		return ret;
	}
	/*************************************************************************************
	 * 入力値チェック(ユーザーID)
	 * <p>
	 * ユーザーIDの入力値チェックを実施する
	 * </p>
	 * @param  userIdhead	ユーザーID(前半)
	 * @param  userIdback	ユーザーID(後半)
	 * @param  roleCd	権限ロールコード
	 * @param  msgFlg	メッセージフラグ true:表示する false:表示しない
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheckUserId(String userIdhead, String userIdback, String roleCd, boolean msgFlg) throws AmallException, Exception {

		// 返却フラグ
		boolean retFlg = true;

		// 入力値チェック(ユーザーID前半)
		if (!AmallUtilities.isEmpty(userIdhead)) {
			// 入力値が存在する場合
			switch (roleCd) {
				case AuthRole.ASS_MNGR:
				case AuthRole.ASS_CNTL:
				case AuthRole.ASS_CMPY:
				case AuthRole.ASS_SALE:
					// ASS社員の場合
					if (!AmallUtilities.isHalfWidthCharacterKind(userIdhead, AmallUtilities.H_NUM)) {
						if (msgFlg) {
							// 半角数字以外が設定されている
							setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_NUM,
									getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean) + MSG_HEAD, String.valueOf(InputNum.USER_ID / 2));
							setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
						}
						retFlg = false;
					} else if (AmallUtilities.getLengthAsHalf(userIdhead) != (InputNum.USER_ID / 2)) {
						// 5文字以外が設定されている
						if (msgFlg) {
							setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_NUM,
									getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean) + MSG_HEAD, String.valueOf(InputNum.USER_ID / 2));
							setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
						}
						retFlg = false;
					}
					break;
				case AuthRole.CST_MNGR:
				case AuthRole.CST_OFFC:
				case AuthRole.CST_AREA:
				case AuthRole.CST_SHOP:
				case AuthRole.CST_CLRK:
					// お客様の場合
					if (!AmallUtilities.isHalfWidthCharacterKind(userIdhead, AmallUtilities.H_ALP)) {
						if (msgFlg) {
							// 半角英字以外が設定されている
							setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_ALP,
									getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean) + MSG_HEAD, String.valueOf(InputNum.USER_ID / 2));
							setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
						}
						retFlg = false;
					} else if (AmallUtilities.getLengthAsHalf(userIdhead) != (InputNum.USER_ID / 2)) {
						// 5文字以外が設定されている
						if (msgFlg) {
							setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_ALP,
									getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean) + MSG_HEAD, String.valueOf(InputNum.USER_ID / 2));
							setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
						}
						retFlg = false;
					}
					break;
				default:
					// 指定がないとき
					if (!AmallUtilities.isHalfWidthCharacterKind(userIdhead, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
						if (msgFlg) {
							// 半角英数字以外が設定されている
							setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
									getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean) + MSG_HEAD, String.valueOf(InputNum.USER_ID / 2));
							setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
						}
						retFlg = false;
					} else if (AmallUtilities.getLengthAsHalf(userIdhead) != (InputNum.USER_ID / 2)) {
						if (msgFlg) {
							setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
									getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean) + MSG_HEAD, String.valueOf(InputNum.USER_ID / 2));
							setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
						}
						retFlg = false;
					}
					break;
			}

			// 大文字使用不可チェック
			if (!userIdhead.equals(userIdhead.toLowerCase())) {
				// 全て小文字変換した場合の文字列が一致しないため大文字が含まれている
				if (msgFlg) {
					setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_BIG_CHAR_NOT,
							getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean));
					setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
				}
				retFlg = false;
			}
			// 同一文字使用チェック
			if (!idCharContinueChk(userIdhead)) {
				// 同一文字が5回使用されている
				if (msgFlg) {
					setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_CONTINUE_CHAR,
							getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean));
					setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
				}
				retFlg = false;
			}
		} else {
			// 入力値が存在しない場合
			if (msgFlg) {
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean));
				setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
			}
			retFlg = false;
		}

		// 入力値チェック(ユーザーID後半)
		if (!AmallUtilities.isEmpty(userIdback)) {
			// 入力値が存在する場合
			if (!AmallUtilities.isHalfWidthCharacterKind(userIdback, AmallUtilities.H_NUM)) {
				if (msgFlg) {
					// 半角数字以外が設定されている
					setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_NUM,
							getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean) + MSG_BACK, String.valueOf(InputNum.USER_ID / 2));
					setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
				}
				retFlg = false;
			} else 	if (AmallUtilities.getLengthAsHalf(userIdback) != (InputNum.USER_ID / 2)) {
				// 5文字以外数字が設定されている
				if (msgFlg) {
					setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_NUM,
							getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean) + MSG_BACK, String.valueOf(InputNum.USER_ID / 2));
					setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
				}
				retFlg = false;
			}
		} else {
			// 入力値が存在しない場合
			if (msgFlg) {
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_USER_ID, m_Aceum11DispBean));
				setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
			}
			retFlg = false;
		}

		if(retFlg) {
			String userId = userIdhead + userIdback;

			// IDチェック
			boolean existFlg = false;
			// システム種別関係なく両方のテーブルを検索する
			existFlg = chkSystemUserMst(userId, SystemType.CUSTOMER);
			if (!existFlg) {
				existFlg = chkSystemUserMst(userId, SystemType.BUSINESS);
			}

			if (existFlg) {
				// 存在する場合使用不可
				if (msgFlg) {
					setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_ALREADY_USE_CHECK);
					setError(m_Aceum11DispBean, ITEM_ID_USER_ID);
				}
				retFlg = false;
			}
		}

		// TODO 特殊チェック
		if(retFlg) {
			String userId = userIdhead + userIdback;

			// システムが業務支援で企業管理者以外を作成する場合
			if (m_Aceum11Form.getM_systemKind() == SystemType.BUSINESS) {
				if (AuthRole.CST_OFFC.equals(roleCd) || AuthRole.CST_AREA.equals(roleCd)
						|| AuthRole.CST_SHOP.equals(roleCd) || AuthRole.CST_CLRK.equals(roleCd)) {



				}

			}

		}
		// 処理終了
		return retFlg;

	}
	/**********************************************************************************************
	 * 5文字連続チェック
	 *
	 * 同じ文字が5つ以上使用されていないかチェックを行う
	 *
	 * @param inputPwd 入力されたID
	 * @return boolean true:正常 false:異常
	 *********************************************************************************************/
	private boolean idCharContinueChk(String input) {

		// 正規表現を設定(同じ文字が5回)
		Pattern p = Pattern.compile("(.)\\1\\1\\1\\1");
        Matcher m = p.matcher(input);

        // 存在したらtrueのため反転して返却
        return !m.find();
	}
	/*************************************************************************************
	 * 入力値チェック(自由入力)
	 * <p>
	 * 自由入力の入力値チェックを実施する
	 * </p>
	 * @param  userNm	ユーザー名
	 * @param  cmt	コメント
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheckFree(String userNm, String cmt) throws AmallException {

		// 返却フラグ
		boolean retFlg = true;


		// 入力値チェック(ユーザー名)
		if (!AmallUtilities.isEmpty(userNm)) {
			// 入力値が存在する場合
			if (AmallUtilities.getLengthAsHalf(userNm) > (InputNum.USER_NM * 2)) {
				// 60文字より多い数字が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_STR_WTN,
						getItemDispName(ITEM_ID_USER_NM, m_Aceum11DispBean), String.valueOf(InputNum.USER_NM));
				setError(m_Aceum11DispBean, ITEM_ID_USER_NM);

				retFlg = false;
			}
		}

		// 入力値チェック(コメント)
		if (!AmallUtilities.isEmpty(cmt)) {
			// 入力値が存在する場合
			if (AmallUtilities.getLengthAsHalf(cmt) > (InputNum.USER_CMT * 2)) {
				// 60文字より多い数字が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_STR_WTN,
						getItemDispName(ITEM_ID_CMT, m_Aceum11DispBean), String.valueOf(InputNum.USER_CMT));
				setError(m_Aceum11DispBean, ITEM_ID_CMT);

				retFlg = false;
			}
		}

		// 処理終了
		return retFlg;

	}
	/*************************************************************************************
	 * 入力値チェック(パスワード)
	 * <p>
	 * パスワードの入力値チェックを実施する
	 * </p>
	 * @param  pwd		パスワード
	 * @param  rePwd	再パスワード
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheckPass(String pwd, String rePwd) throws AmallException {

		// 返却フラグ
		boolean retFlg = true;

		// 入力なし
		if (AmallUtilities.isEmpty(pwd) && AmallUtilities.isEmpty(rePwd)){
			// チェックなし
			return true;
		}

		// 必須入力チェック
		// Password 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(pwd)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_PASS, m_Aceum11DispBean));
			setError(m_Aceum11DispBean, ITEM_ID_PASS);
			setError(m_Aceum11DispBean, ITEM_ID_RE_PASS);
			retFlg = false;
		}

		// 再Password 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(rePwd)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_RE_PASS, m_Aceum11DispBean));
			setError(m_Aceum11DispBean, ITEM_ID_PASS);
			setError(m_Aceum11DispBean, ITEM_ID_RE_PASS);
			retFlg = false;
		}

		// パスワード・再パスワードの一致
		if (retFlg == true && !pwd.equals(rePwd)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_PASSWORD_NOT_SAME);
			setError(m_Aceum11DispBean, ITEM_ID_PASS);
			setError(m_Aceum11DispBean, ITEM_ID_RE_PASS);
			retFlg = false;
		}

		// パスワードの内容チェック
		if(retFlg) {
			// ログイン情報の取得
			AmdtoLoginInfo loginInfo = getLoginInfoDTO();

			// ログイン情報存在チェック
			if(loginInfo == null) {
				// 例外を投げる
				AmallException e = new AmallException();
				e.addException(this.m_ClassName, "inputCheckPass()", AmallMessageConst.MSG_SYS_DTO_MNG_DATA_GET_ERROR,
						"m_loginInfo");
				throw e;
			}

			List<String> msglist = AmallPasswordControl.passwordValidateCheck(pwd, loginInfo, m_DbAccess);
			if (msglist.size() > 0) {
				// メッセージを設定
				m_Aceum11DispBean.setMessage(msglist);
				m_Aceum11DispBean.setMessageType(MsgCode.ERROR);
				// 欄を赤く
				setError(m_Aceum11DispBean, ITEM_ID_PASS);
				setError(m_Aceum11DispBean, ITEM_ID_RE_PASS);
				retFlg = false;

			}
		}

		// 処理終了
		return retFlg;

	}

	/*************************************************************************************
	 * 入力値チェック(パスワード期間)
	 * <p>
	 * パスワード(期間)の入力値チェックを実施する
	 * </p>
	 * @param  expDate	有効期限日(YYYY/MM/DD形式)
	 * @param  valdMonth	有効期間(月数)
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheckPassPeriod(String expDate, String valdMonth) throws AmallException, Exception {

		// 返却フラグ
		boolean retFlg = true;


		// 必須入力チェック
		if (AmallUtilities.isEmpty(expDate)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_PASSEXP, m_Aceum11DispBean));
			setError(m_Aceum11DispBean, ITEM_ID_PASSEXP);
			retFlg = false;
		} else {

			// 日付妥当性チェック
			if (expDate.length() != 10) {
				if (expDate.length() == 8) {
					// 「/」が含まれていない日付の場合挿入
					expDate = AmallUtilities.changeFormat(expDate);
				} else {
					setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_DATE_ERROR);
					setError(m_Aceum11DispBean, ITEM_ID_PASSEXP);
					retFlg = false;
				}
			}
			if(retFlg) {
				if (!AmallUtilities.checkExistDate(expDate)) {
					// 正しい日付か
					setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_NOT_EXIST_DATE,	getItemDispName(ITEM_ID_PASSEXP, m_Aceum11DispBean));
					setError(m_Aceum11DispBean, ITEM_ID_PASSEXP);
					retFlg = false;
				}
			}
		}

		// 必須入力チェック
		if (AmallUtilities.isEmpty(valdMonth)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_PASSVALID, m_Aceum11DispBean));
			setError(m_Aceum11DispBean, ITEM_ID_PASSVALID);
			retFlg = false;
		} else {
			if (!AmallUtilities.isHalfWidthCharacterKind(valdMonth, AmallUtilities.H_NUM)) {
				// 半角数字以外が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_NUM_WTN,
						getItemDispName(ITEM_ID_PASSVALID, m_Aceum11DispBean), String.valueOf(InputNum.PASS_VALID));
				setError(m_Aceum11DispBean, ITEM_ID_PASSVALID);

				retFlg = false;
			} else if (AmallUtilities.getLengthAsHalf(valdMonth) > InputNum.PASS_VALID) {
				// 3桁以上の数字が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_NUM_WTN,
						getItemDispName(ITEM_ID_PASSVALID, m_Aceum11DispBean), String.valueOf(InputNum.PASS_VALID));
				setError(m_Aceum11DispBean, ITEM_ID_PASSVALID);

				retFlg = false;
			}
		}

		// 正常終了
		return retFlg;

	}

	/*************************************************************************************
	 * ユーザーマスタ(DB)取得
	 * <p>
	 * ユーザーマスタ(DB)からデータを取得する。
	 * 取得したデータはフォームに設定する
	 * </p>
	 * @param  userCd ユーザーコード
	 * @param  systemKind システム種別
	 * @param  systemDt 業務日付
	 * @return なし
	 ************************************************************************************/
	private void getUserMst(String userCd, int systemKind, String systemDt) throws AmallException, Exception {

		String methodName = "getUserMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	nucm.USER_ID");
			sql.append(",	nucm.USER_NM");
			sql.append(",	nucm.ROLE_GRP_CD");
			sql.append(",	nucm.CST_GRP_CD");
			sql.append(",	A.CST_GRP_NM");
			sql.append(",	nucm.CST_CD");
			sql.append(",	ncm.CST_NM");
			sql.append(",	CASE");
			sql.append("		WHEN nscm.COMPANY_SHOP_CD IS NOT NULL THEN TRIM(nscm.COMPANY_SHOP_CD)");
			sql.append("		ELSE nucm.SHOP_CD");
			sql.append("	END AS SHOP_CD");
			sql.append(",	CASE");
			sql.append("		WHEN nscm.COMPANY_SHOP_NM IS NOT NULL THEN nscm.COMPANY_SHOP_NM");
			sql.append("		ELSE nsm.SHOP_NM");
			sql.append("	END AS SHOP_NM");
			sql.append(",	nucm.CMT");
			sql.append(",	TO_CHAR(nucm.USER_UPD_DT,'YYYY/MM/DD HH24:MI:SS') AS USER_UPD_DT");
			sql.append(",	nucm.PASSWORD_EXP_DATE");
			sql.append(",	nucm.PASSWORD_EXP_FLG");
			sql.append(",	nucm.PASSWORD_VALID_LIMIT");
			sql.append(",	TO_CHAR(nucm.PASSWORD_MODIFIED_DATE,'YYYY/MM/DD HH24:MI:SS') AS PASSWORD_MODIFIED_DATE");
			sql.append(",	nucm.PASSWORD_LOCK");
			sql.append(",	nucm.ACCOUNT_LOCK");
			sql.append(",	nucm.EXCLUSIVE_KEY");
			sql.append("  FROM");
			// システム種別によってテーブルを設定する
			if (systemKind == SystemType.BUSINESS) {
				// 業務支援の場合
				sql.append("	N_USER_EMP_M nucm");
			} else {
				// 顧客OLの場合
				sql.append("	N_USER_CST_M nucm");
			}
			sql.append("	LEFT JOIN");
			sql.append("		(");
			sql.append("			SELECT");
			sql.append("				ncgm.CST_GRP_CD");
			sql.append(",				ncgm.CST_GRP_NM");
			sql.append("			  FROM");
			sql.append("				N_CST_GRP_M ncgm");
			sql.append("			 WHERE");
			sql.append("				ncgm.DEL_FLG = ?");
			sql.append("				AND ? BETWEEN ncgm.EFST_DY AND ncgm.EFED_DY");
			sql.append("			GROUP BY");
			sql.append("				ncgm.CST_GRP_CD");
			sql.append(",				ncgm.CST_GRP_NM");
			sql.append("		) A");
			sql.append("	ON");
			sql.append("		nucm.CST_GRP_CD = A.CST_GRP_CD");
			sql.append("	LEFT JOIN");
			sql.append("		N_CST_M ncm");
			sql.append("	ON");
			sql.append("		nucm.CST_CD = ncm.CST_CD");
			sql.append("		AND ncm.DEL_FLG = ?");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_M nsm");
			sql.append("	ON");
			sql.append("		nucm.CST_CD = nsm.CST_CD");
			sql.append("		AND nucm.SHOP_CD = nsm.SHOP_CD");
			sql.append("		AND nsm.DEL_FLG = ?");
			sql.append("		AND ? BETWEEN nsm.EFST_DY AND nsm.EFED_DY");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_CNV_M nscm");
			sql.append("	ON");
			sql.append("		nucm.CST_CD = nscm.CST_CD");
			sql.append("		AND nucm.SHOP_CD = nscm.SHOP_CD");
			sql.append("		AND nscm.DEL_FLG = ?");
			sql.append("		AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
			sql.append(" WHERE");
			sql.append("	nucm.USER_ID = ?");
			sql.append("	AND nucm.DEL_FLG = ?");

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, systemDt);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, systemDt);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, systemDt);
			// ユーザー
			m_DbAccess.setString(++setCnt, userCd);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				// ユーザーID
				m_Aceum11Form.setDispUserId(m_DbAccess.getString(rs, "USER_ID"));
				// ユーザー名
				m_Aceum11Form.setInputedUserNm(m_DbAccess.getString(rs, "USER_NM"));

				// 権限
				String roleCd = m_DbAccess.getString(rs, "ROLE_GRP_CD");
				m_Aceum11Form.setSelectedRoleCd(roleCd);

				switch (roleCd) {
					case AuthRole.ASS_MNGR:
					case AuthRole.ASS_CNTL:
					case AuthRole.ASS_CMPY:
					case AuthRole.ASS_SALE:
						break;
					case AuthRole.CST_MNGR:
					case AuthRole.CST_OFFC:
						// 顧客グループ
						m_Aceum11Form.setInputedCstGrpCd(m_DbAccess.getString(rs, "CST_GRP_CD"));
						// 顧客グループ名
						m_Aceum11Form.setDispCstGrpNm(m_DbAccess.getString(rs, "CST_GRP_NM"));
						// 顧客コード
						m_Aceum11Form.setInputedCstCd(m_DbAccess.getString(rs, "CST_CD"));
						// 顧客コード名
						m_Aceum11Form.setDispCstNm(m_DbAccess.getString(rs, "CST_NM"));
						break;
					case AuthRole.CST_AREA:
					case AuthRole.CST_SHOP:
					case AuthRole.CST_CLRK:
						// 顧客コード
						m_Aceum11Form.setInputedCstCd(m_DbAccess.getString(rs, "CST_CD"));
						// 顧客コード名
						m_Aceum11Form.setDispCstNm(m_DbAccess.getString(rs, "CST_NM"));
						// 店舗コード
						m_Aceum11Form.setInputedShopCd(m_DbAccess.getString(rs, "SHOP_CD"));
						// 店舗名
						m_Aceum11Form.setDispShopNm(m_DbAccess.getString(rs, "SHOP_NM"));
						break;
					default:
						break;
				}
				// コメント
				m_Aceum11Form.setInputedCmt(m_DbAccess.getString(rs, "CMT"));
				// 更新日時
				m_Aceum11Form.setUserUpdateDate(m_DbAccess.getString(rs, "USER_UPD_DT"));
				// パスワード有効期限
				m_Aceum11Form.setInputedPasswordExp(AmallUtilities.changeFormat(m_DbAccess.getString(rs, "PASSWORD_EXP_DATE")));

				// パスワード有効期限フラグ
				String expFlg = m_DbAccess.getString(rs, "PASSWORD_EXP_FLG");
				if (LoginFlg.VALID_LIMIT_OFF.equals(expFlg)) {
					m_Aceum11Form.setCheckPwdExpFlg(true);
				} else {
					m_Aceum11Form.setCheckPwdExpFlg(false);
				}

				// パスワード有効期間
				int nValid = rs.getInt("PASSWORD_VALID_LIMIT");
				if (nValid > 0) {
					m_Aceum11Form.setInputedPasswordValid(String.valueOf(nValid));
				}

				// パスワードロック
				m_Aceum11Form.setSelectedPwdLockRadio(m_DbAccess.getString(rs, "PASSWORD_LOCK"));
				// パスワード更新日時
				m_Aceum11Form.setPwdUpdateDate(m_DbAccess.getString(rs, "PASSWORD_MODIFIED_DATE"));
				// アカウントロック
				m_Aceum11Form.setSelectedActLockRadio(m_DbAccess.getString(rs, "ACCOUNT_LOCK"));

				// 排他キー
				m_Aceum11Dto.setExclusiveKey(rs.getLong("EXCLUSIVE_KEY"));

			}

			return;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_USER_XXX_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 店舗グループ管理マスタ(DB)取得
	 * <p>
	 * 店舗グループ管理マスタ(DB)からデータを取得する。
	 * 取得したデータはフォームに設定する
	 * </p>
	 * @param  userCd ユーザーコード
	 * @param  systemDt 業務日付
	 * @return なし
	 ************************************************************************************/
	private void getShopGrpMngMst(String userCd, String systemDt) throws AmallException, Exception {

		String methodName = "getShopGrpMngMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		List<AceumShopGrpDto> list = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	nsgmm.SHOP_GRP_CD");
			sql.append(",	nsgm.SHOP_GRP_NM");
			sql.append("  FROM");
			sql.append("	N_SHOP_GRP_MNG_M nsgmm");
			sql.append("	LEFT JOIN");
			sql.append("		(");
			sql.append("			SELECT");
			sql.append("				SHOP_GRP_CD");
			sql.append(",				SHOP_GRP_NM");
			sql.append("			  FROM");
			sql.append("				N_SHOP_GRP_M");
			sql.append("			 WHERE");
			sql.append("				DEL_FLG = ?");
			sql.append("				AND ? BETWEEN EFST_DY AND EFED_DY");
			sql.append("		) nsgm");
			sql.append("	ON");
			sql.append("		nsgmm.SHOP_GRP_CD = nsgm.SHOP_GRP_CD");
			sql.append(" WHERE");
			sql.append("	nsgmm.USER_ID = ?");
			sql.append("	AND nsgmm.DEL_FLG = ?");
			sql.append(" ORDER BY");
			sql.append("	nsgmm.SHOP_GRP_CD");

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, systemDt);
			// ユーザー
			m_DbAccess.setString(++setCnt, userCd);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				// DTO生成
				AceumShopGrpDto dto = new AceumShopGrpDto();
				// 店舗グループコード
				dto.setShopGrpCd(m_DbAccess.getString(rs, "SHOP_GRP_CD"));
				// 店舗グループ名
				dto.setShopGrpNm(m_DbAccess.getString(rs, "SHOP_GRP_NM"));

				// リストに追加
				list.add(dto);
			}

			// リストが存在する場合
			if (list.size() > 0) {
				// 店舗グループに追加
				m_Aceum11Form.setShopGrpList(list);
			}

			return;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_USER_XXX_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 顧客マスタ(DB)ユニークチェック
	 * <p>
	 * 顧客マスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できる場合はActionFormに値を設定し，
	 * 特定できない場合はfalseで返却する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @return boolean true:正常 false:異常
	 ************************************************************************************/
	private boolean chkUniqCst(String cstCd) throws AmallException, Exception {

		String methodName = "chkUniqCst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用チェックリスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	CST_NM");
			sql.append("  FROM");
			sql.append("	N_CST_M");
			sql.append(" WHERE");
			sql.append("	DEL_FLG = ?");
			sql.append("	AND CST_CD = ?");
			// 顧客範囲設定
			// 全顧客判定
			if (!m_Aceum11DispBean.isCustomerCdAllFlg()) {
				// 全顧客ではない場合
				sql.append("	AND CST_CD IN (");
				for (String appCustomer : m_Aceum11DispBean.getCustomerCdList()) {
					sql.append("'").append(appCustomer).append("',");
				}
				sql.append("'')");
			}

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				// 店舗名
				String name = m_DbAccess.getString(rs, "CST_NM");

				// リストに追加
				retList.add(name);
			}

			// 結果チェック
			if(retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}

			// 値を設定
			m_Aceum11Form.setDispCstNm(retList.get(0));

			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_CST_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}

	/*************************************************************************************
	 * 店舗マスタ(DB)ユニークチェック
	 * <p>
	 * 店舗マスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できる場合はActionFormに値を設定し，
	 * 特定できない場合はfalseで返却する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @return boolean true:正常 false:異常
	 ************************************************************************************/
	private boolean chkUniqShop(String cstCd, String shopCd) throws AmallException, Exception {

		String methodName = "chkUniqShop()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用チェックリスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	ncm.CST_CD");
			sql.append(",	ncm.CST_NM");
			sql.append(",	nsm.SHOP_NM");
			sql.append(",	TRIM(nscm.COMPANY_SHOP_NM) AS COMPANY_SHOP_NM");
			sql.append("  FROM");
			sql.append("  	N_SHOP_M nsm");
			sql.append("	LEFT JOIN");
			sql.append("		N_CST_M ncm");
			sql.append("	  ON");
			sql.append("		nsm.CST_CD = ncm.CST_CD");
			sql.append("		AND ncm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_CNV_M nscm");
			sql.append("	  ON");
			sql.append("		nsm.CST_CD = nscm.CST_CD");
			sql.append("		AND nsm.SHOP_CD = nscm.SHOP_CD");
			sql.append("		AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
			sql.append("		AND nscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append(" WHERE");
			sql.append("	nsm.DEL_FLG = ?");
			sql.append("	AND ? BETWEEN nsm.EFST_DY AND nsm.EFED_DY");
			sql.append("	AND nsm.CST_CD = ?");
			sql.append("	AND (");
			sql.append("			nsm.SHOP_CD = ?");
			sql.append("			OR");
			sql.append("			TRIM(nscm.COMPANY_SHOP_CD) = ?");
			sql.append("		)");
			// 店舗範囲設定
			// 全店舗判定
			if (!m_Aceum11DispBean.isShopCdAllFlg()) {
				// 全顧客・全店舗ではない場合
				sql.append("	AND (");
				boolean first = true;
				for (Entry<String, List<String>> entry : m_Aceum11DispBean.getShopCdListMap().entrySet()) {

					String appCstCd = entry.getKey();
					for (String appShop : entry.getValue()) {
						if (first) {
							sql.append("		");
							first = false;
						} else {
							sql.append("		OR");
						}
						sql.append("		(");
						sql.append("			nsm.CST_CD = '").append(appCstCd).append("'");
						sql.append("			AND");
						sql.append("			nsm.SHOP_CD = '").append(appShop).append("'");
						sql.append("		)");
					}
				}
				sql.append("	)");
			}


			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 有効期限
			m_DbAccess.setString(++setCnt, m_Aceum11DispBean.getServiceDate());
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, m_Aceum11DispBean.getServiceDate());
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);
			// 店舗コード
			m_DbAccess.setString(++setCnt, shopCd);
			// 店舗コード
			m_DbAccess.setString(++setCnt, shopCd);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			String cstCdData = "";
			String cstNmData = "";
			while (rs.next()) {

				// 店舗名
				String name = m_DbAccess.getString(rs, "SHOP_NM");
				// 店舗名(企業)
				String comapany = m_DbAccess.getString(rs, "COMPANY_SHOP_NM");

				// 企業店舗コード判定
				if (AmallUtilities.isEmpty(comapany)) {
					// リストに追加
					retList.add(name);
				} else {
					// 企業店舗コードがある場合は企業店舗を優先
					// リストに追加
					retList.add(comapany);
				}

				// 顧客コード
				cstCdData = m_DbAccess.getString(rs, "CST_CD");
				// 顧客名
				cstNmData = m_DbAccess.getString(rs, "CST_NM");

			}

			// 結果チェック
			if(retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}

			// 値を設定
			m_Aceum11Form.setDispShopNm(retList.get(0));
			m_Aceum11Form.setInputedCstCd(cstCdData);
			m_Aceum11Form.setDispCstNm(cstNmData);

			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_SHOP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
}