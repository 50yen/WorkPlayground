/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AceumItemDispDto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * AceumItemDispDtoクラス<br>
 *****************************************************************************************/
public class AceumItemDispDto extends AmclsDtoBase {

	/** メンバ変数 */
	/** 削除チェックボックス */
	private boolean delChkFlg = false;
	/** ユーザーID */
	private String userId = null;
	/** ユーザー名 */
	private String userNm = null;
	/** 顧客CD */
	private String cstCd = null;
	/** 顧客名 */
	private String cstNm = null;
	/** 店舗CD */
	private String shopCd = null;
	/** 店舗名 */
	private String shopNm = null;
	/** 権限 */
	private String role = null;
	/** ステータス */
	private String status = null;
	/** 行スタイル */
	private String trStyle = null;
	/** 排他キー */
	private Long exclusiveKey = null;
	/** システム種別 */
	private int systemKind = 0;


	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AceumItemDispDto() {
		clear();
	}

	/*************************************************************************************
	 * クリア
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		delChkFlg = false;
		userId = null;
		userNm = null;
		cstCd = null;
		cstNm = null;
		shopCd = null;
		shopNm = null;
		role = null;
		status = null;
		systemKind = 0;

	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public boolean isDelChkFlg() {
		return delChkFlg;
	}

	public void setDelChkFlg(boolean delChkFlg) {
		this.delChkFlg = delChkFlg;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

	public String getCstCd() {
		return cstCd;
	}

	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}

	public String getCstNm() {
		return cstNm;
	}

	public void setCstNm(String cstNm) {
		this.cstNm = cstNm;
	}

	public String getShopCd() {
		return shopCd;
	}

	public void setShopCd(String shopCd) {
		this.shopCd = shopCd;
	}

	public String getShopNm() {
		return shopNm;
	}

	public void setShopNm(String shopNm) {
		this.shopNm = shopNm;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTrStyle() {
		return trStyle;
	}

	public void setTrStyle(String trStyle) {
		this.trStyle = trStyle;
	}

	public Long getExclusiveKey() {
		return exclusiveKey;
	}

	public void setExclusiveKey(Long exclusiveKey) {
		this.exclusiveKey = exclusiveKey;
	}

	public int getSystemKind() {
		return systemKind;
	}

	public void setSystemKind(int systemKind) {
		this.systemKind = systemKind;
	}


}
