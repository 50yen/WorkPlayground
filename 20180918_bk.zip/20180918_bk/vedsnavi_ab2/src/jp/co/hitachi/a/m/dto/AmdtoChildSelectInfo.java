/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoChildSelectInfo.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * 子画面表示情報 <br>
 *****************************************************************************************/
public class AmdtoChildSelectInfo extends AmclsDtoBase {

	/** メンバ変数 */
	/** 顧客コード or 顧客グループコード */
	private String cstCd = null;
	/** 顧客名 or 顧客グループ名 */
	private String cstNm = null;
	/** 店舗コード */
	private String shopCd = null;
	/** 店舗コード(表示用) */
	private String shopDispCd = null;
	/** 店舗名 or 店舗グループ名 */
	private String shopNm = null;
	/** 店舗枝番コード */
	private String shopBrnCd = null;
	/** 店舗枝番コード(表示用) */
	private String shopBrnDispCd = null;
	/** 店舗枝番名 */
	private String shopBrnNm = null;
	/** ユーザーID */
	private String userCd = null;
	/** ユーザー名 */
	private String userNm = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmdtoChildSelectInfo() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		cstCd = null;
		cstNm = null;
		shopCd = null;
		shopNm = null;
		shopBrnCd = null;
		shopBrnNm = null;
		userCd = null;
		userNm = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getCstCd() {
		return cstCd;
	}

	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}

	public String getCstNm() {
		return cstNm;
	}

	public void setCstNm(String cstNm) {
		this.cstNm = cstNm;
	}

	public String getShopCd() {
		return shopCd;
	}

	public void setShopCd(String shopCd) {
		this.shopCd = shopCd;
	}

	public String getShopDispCd() {
		return shopDispCd;
	}

	public void setShopDispCd(String shopDispCd) {
		this.shopDispCd = shopDispCd;
	}

	public String getShopNm() {
		return shopNm;
	}

	public void setShopNm(String shopNm) {
		this.shopNm = shopNm;
	}

	public String getShopBrnCd() {
		return shopBrnCd;
	}

	public void setShopBrnCd(String shopBrnCd) {
		this.shopBrnCd = shopBrnCd;
	}

	public String getShopBrnDispCd() {
		return shopBrnDispCd;
	}

	public void setShopBrnDispCd(String shopBrnDispCd) {
		this.shopBrnDispCd = shopBrnDispCd;
	}

	public String getShopBrnNm() {
		return shopBrnNm;
	}

	public void setShopBrnNm(String shopBrnNm) {
		this.shopBrnNm = shopBrnNm;
	}

	public String getUserCd() {
		return userCd;
	}

	public void setUserCd(String userCd) {
		this.userCd = userCd;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}

}
