/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abinf01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.inf.action;

import jp.co.hitachi.a.b.inf.bean.Abinf01DispBean;
import jp.co.hitachi.a.b.inf.business.Abinf01Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Abinf01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Abinf01DispBean abinf01DispBean;

	/** 告知 */
	private String noticeData = null;
	/** 告知ID */
	private Long infoId = null;
	/** 排他キー */
	private Long exclusiveKey = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAbinf01DispBean((Abinf01DispBean)request.getAttribute("Abinf01DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Abinf01Business dao = new Abinf01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Abinf01DispBean getAbinf01DispBean() {
		return abinf01DispBean;
	}

	public void setAbinf01DispBean(Abinf01DispBean abinf01DispBean) {
		this.abinf01DispBean = abinf01DispBean;
	}

	public String getNoticeData() {
		return noticeData;
	}

	public void setNoticeData(String noticeData) {
		this.noticeData = noticeData;
	}

	public Long getInfoId() {
		return infoId;
	}

	public void setInfoId(Long infoId) {
		this.infoId = infoId;
	}

	public Long getExclusiveKey() {
		return exclusiveKey;
	}

	public void setExclusiveKey(Long exclusiveKey) {
		this.exclusiveKey = exclusiveKey;
	}
}
