/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallPasswordControl.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

import jp.co.hitachi.a.m.all.AmallConst.LoginFlg;
import jp.co.hitachi.a.m.all.AmallConst.SystemType;
import jp.co.hitachi.a.m.dto.AmdtoLoginInfo;

/*****************************************************************************************
 * パスワード制御クラス<br>
 *****************************************************************************************/
public class AmallPasswordControl {

	/** メンバ変数 */
	/** パスワード下限値 */
	private static final int PASSWORD_MIN_LENGTH = 8;
	/** パスワード上限値 */
	private static final int PASSWORD_MAX_LENGTH = 64;
	/**
	 * パスワード変換
	 */
	/** アルゴリズム設定 */
	private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
	/** ストレッチング回数 */
	private static final int ITERATION_COUNT = 10000;
	/** 生成される鍵の長さ */
	private static final int KEY_LENGTH = 256;

	/**********************************************************************************************
	 * パスワード変換処理
	 *
	 * 平文のパスワードとソルトから暗号化したパスワードを生成し、返却する
	 *
	 * @param password 平文のパスワード
	 * @param salt ソルト
	 * @return String 暗号化したパスワード
	 *********************************************************************************************/
	public static String getSafetyPassword(String password, String salt) {

		char[] passCharAry = password.toCharArray();
		byte[] hashedSalt = getHashedSalt(salt);

		PBEKeySpec keySpec = new PBEKeySpec(passCharAry, hashedSalt, ITERATION_COUNT, KEY_LENGTH);

		SecretKeyFactory skf;
		try {
			skf = SecretKeyFactory.getInstance(ALGORITHM);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}

		SecretKey secretKey;
		try {
			secretKey = skf.generateSecret(keySpec);
		} catch (InvalidKeySpecException e) {
			throw new RuntimeException(e);
		}
		byte[] passByteAry = secretKey.getEncoded();

		// 生成されたバイト配列を16進数の文字列に変換
		StringBuilder sb = new StringBuilder(64);
		for (byte b : passByteAry) {
			sb.append(String.format("%02x", b & 0xff));
		}
		return sb.toString();
	}

	/**********************************************************************************************
	 * ソルトハッシュ化処理
	 *
	 * ソルトをハッシュ化して返却
	 * ※ハッシュアルゴリズムはSHA-256を使用
	 *
	 * @param salt ソルト
	 * @return ハッシュ化されたバイト配列のソルト
	 *********************************************************************************************/
	private static byte[] getHashedSalt(String salt) {
		MessageDigest messageDigest;
		try {
			messageDigest = MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException(e);
		}
		messageDigest.update(salt.getBytes());
		return messageDigest.digest();
	}

	/**********************************************************************************************
	 * パスワードの一致チェック
	 *
	 * パスワードが一致しているかチェックする
	 *
	 * @param inputPwd 入力されたパスワード
	 * @param dbPwd DBに格納されているパスワード(暗号化済み)
	 * @param salt ソルト
	 * @return boolean true:一致 false:不一致
	 *********************************************************************************************/
	public static boolean isSafetyPasswordMatch(String inputPwd, String dbPwd, String salt) {

		// 引数チェック
		if (inputPwd == null || inputPwd.length() == 0) {
			return false;
		}
		if (dbPwd == null || dbPwd.length() == 0) {
			return false;
		}
		if (salt == null || salt.length() == 0) {
			return false;
		}

		// 入力したパスワードを暗号化
		String safetyInputPwd = getSafetyPassword(inputPwd, salt);

		if (dbPwd.equals(safetyInputPwd)) {
			// 一致した場合
			return true;
		} else {
			// 一致しない場合
			return false;
		}

	}
	/**********************************************************************************************
	 * パスワード妥当性チェック
	 *
	 * パスワードとして正しいものかチェックを行う
	 *
	 * @param inputPwd 入力されたパスワード
	 * @param loginInfo ログイン情報
	 * @param db DBアクセサインスタンス
	 * @return List<String> 0件 :正常 1件以上:判定したエラーメッセージ null：異常
	 *********************************************************************************************/
	public static List<String> passwordValidateCheck(String inputPwd, AmdtoLoginInfo loginInfo, AmallDbAccess db) throws AmallException {
		String methodName = "passwordValidateCheck()";

		try {
			// 引数チェック
			if (inputPwd == null || inputPwd.length() == 0 || loginInfo == null || db == null) {
				return null;
			}

			// 返却エラーメッセージリスト
			List<String> retList = new ArrayList<>();

			// ユーザー名と同一不可
			if(!userNameMatchChk(inputPwd, loginInfo)) {
				retList.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_NOT_SAME_PASSWORD));
			}

			// 過去パスワードの再使用
			if(!reusePastPasswordChk(inputPwd, loginInfo)) {
				retList.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_PASSWORD_OLD_NOT_SAME));
			}

			// ワーストパスワードチェック
			if(!worstPasswordChk(inputPwd, db)) {
				retList.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_PASSWORD_DISABLE));
			}
			// 入力桁数 64文字以下
			// 文字列長を取得
			int pwdLength = inputPwd.length();
			// 64文字より多い
			if (pwdLength > PASSWORD_MAX_LENGTH) {
				retList.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN, "新パスワード", String.valueOf(PASSWORD_MAX_LENGTH)));
			}
			// アルファベット・数字かつ3種類＋8文字以上
			if (!passwordCharChk(inputPwd)) {
				retList.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_PASSWORD_COMBI));
			}
			// 文字連続チェック
			if (!passwordCharContinueChk(inputPwd)) {
				retList.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_PASSWORD_SERIAL));
			}
			return retList;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException("", methodName, e);
			throw ee;
		}

	}
	/**********************************************************************************************
	 * ユーザー名と同一チェック
	 *
	 * パスワードがユーザー名ではないかチェックを行う
	 *
	 * @param inputPwd 入力されたパスワード
	 * @param loginInfo ログイン情報
	 * @return boolean true:正常 false::異常
	 *********************************************************************************************/
	private static boolean userNameMatchChk(String inputPwd, AmdtoLoginInfo loginInfo) {

		// ユーザーIDを取得
		String userId = loginInfo.getM_User_Cd();

		// 一致しているかチェック
		if (inputPwd.equals(userId)) {
			// 一致したらエラー
			return false;
		}

		return true;
	}
	/**********************************************************************************************
	 * 過去パスワードの再使用チェック
	 *
	 * パスワードが過去に使用されたものではないかチェックを行う
	 *
	 * @param inputPwd 入力されたパスワード
	 * @param loginInfo ログイン情報
	 * @return boolean true:正常 false::異常
	 *********************************************************************************************/
	private static boolean reusePastPasswordChk(String inputPwd, AmdtoLoginInfo loginInfo) {

		// ユーザーIDを取得
		String userId = loginInfo.getM_User_Cd();

		// 今回パスワードと一致チェック
		if(loginInfo.getM_OldPassword() != null) {
			if (isSafetyPasswordMatch(inputPwd, loginInfo.getM_Password(), userId)) {
				// 一致した場合
				return false;
			}
		}

		// 前回パスワードと一致チェック
		if(loginInfo.getM_OldPassword() != null) {
			if (isSafetyPasswordMatch(inputPwd, loginInfo.getM_OldPassword(), userId)) {
				// 一致した場合
				return false;
			}
		}
		// 前々回パスワードと一致チェック
		if(loginInfo.getM_LastPassword() != null) {
			if (isSafetyPasswordMatch(inputPwd, loginInfo.getM_LastPassword(), userId)) {
				// 一致した場合
				return false;
			}
		}


		return true;
	}
	/**********************************************************************************************
	 * ワーストパスワードの使用チェック
	 *
	 * パスワードがパスワード禁止文字列ではないかチェックを行う
	 *
	 * @param inputPwd 入力されたパスワード
	 * @param loginInfo DBアクセサインスタンス
	 * @return boolean true:正常 false::異常
	 *********************************************************************************************/
	private static boolean worstPasswordChk(String inputPwd, AmallDbAccess db) throws AmallException ,Exception{
		String methodName = "worstPasswordChk()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		try {
			// SQL文生成
			sql.append("SELECT");
			sql.append("	*");
			sql.append("  FROM");
			sql.append("	N_WORST_PWD_M");
			sql.append(" WHERE");
			sql.append("	DEL_FLG =  ?");
			sql.append("	AND WST_PASSWORD =  ?");

			db.createPreparedStatement(sql.toString());
			// 条件設定
			db.setString(1, AmallConst.DEFAULT_DEL_FLG);
			db.setString(2, inputPwd);
			// SQL実行
			rs = db.executeQuery();

			// 結果取得
			while (rs.next()) {
				// レコードが存在した場合
				return false;
			}

			return true;
		} catch (AmallException e) {
			e.addException("", methodName, AmallMessageConst.MSG_SYS_DTO_MNG_DATA_GET_ERROR, "N_WORST_PWD_M");
			throw e;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException("", methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
			sql.delete(0, sql.length());
			sql = null;
		}

	}

	/**********************************************************************************************
	 * アルファベット・数字かつ3種類＋8文字以上
	 *
	 * パスワードが正しい文字種かチェックを行う
	 *
	 * @param inputPwd 入力されたパスワード
	 * @return boolean true:正常 false::異常
	 *********************************************************************************************/
	private static boolean passwordCharChk(String inputPwd) {
		// 文字列長を取得
		int pwdLength = inputPwd.length();

		// 8文字以下
		if (pwdLength < PASSWORD_MIN_LENGTH) {
			return false;
		}

		// 半角英数値混在チェック
		if (AmallUtilities.contain(inputPwd, AmallUtilities.H_ALP)
				&& AmallUtilities.contain(inputPwd, AmallUtilities.H_NUM)) {
			// 半角英字と半角数字が共に含まれている
			// 英大文字・英小文字チェック
			if (inputPwd.equals(inputPwd.toLowerCase())) {
				// 全て小文字変換した場合の文字列が一致であるため大文字が含まれていない
				return false;
			}
		} else {
			// どちらかしか(またはどちらも)含まれていない場合
			return false;
		}


		return true;
	}
	/**********************************************************************************************
	 * パスワード文字連続チェック
	 *
	 * パスワードに同じ文字が3つ以上使用されていないかチェックを行う
	 *
	 * @param inputPwd 入力されたパスワード
	 * @return boolean true:正常 false::異常
	 *********************************************************************************************/
	private static boolean passwordCharContinueChk(String inputPwd) {

		// 正規表現を設定(同じ文字が3回)
		Pattern p = Pattern.compile("(.)\\1\\1");
        Matcher m = p.matcher(inputPwd);

        // 存在したらtrueのため反転して返却
        return !m.find();
	}


	/*************************************************************************************
	 * パスワード更新
	 * <p>
	 * ユーザーマスタDBを更新する
	 * </p>
	 * @param inputPwd 入力パスワード
	 * @param preFlg 仮パスワード設定 true:仮パスワードに設定 false:通常のパスワード変更
	 * @param loginInfo ログイン情報DTO
	 * @param db	DBアクセサインスタンス
	 * @param systemKind	システム種別
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	public static boolean updatePasswordData(String inputPwd, boolean preFlg, AmdtoLoginInfo loginInfo, AmallDbAccess db, int systemkind) throws AmallException {

		String className = AmallPasswordControl.class.getName();
		String methodName = "updatePasswordData()";
		StringBuffer sql = new StringBuffer();

		try {

			// システム種別に応じてテーブルを変える
			String tableName = "";
			if (systemkind == SystemType.CUSTOMER) {
				tableName  = SystemType.CUSTOMER_USER_TABLE_NM;
			} else {
				tableName  = SystemType.BUSINESS_USER_TABLE_NM;
			}

			// パスワードを暗号化
			String safetyInputPwd = getSafetyPassword(inputPwd, loginInfo.getM_User_Cd());

			// 仮パスワード設定を判定する
			String prePwdFlg = "";
			if(preFlg) {
				// 仮パスワードON
				prePwdFlg = LoginFlg.PRE_PASS;
			} else {
				// 仮パスワードO
				prePwdFlg = LoginFlg.PRE_PASS_OFF;
			}

			// パスワード有効期限フラグを判定する
			Long expMonth = 0L;
			if(!LoginFlg.VALID_LIMIT_OFF.equals(loginInfo.getM_Password_Exp_Flg())) {
				// 有効期限がある場合
				// 有効期間を取得
				expMonth = loginInfo.getM_Password_Valid_Limit();
			}

			// SQL生成
			sql.append("UPDATE");
			sql.append("	").append(tableName);
			sql.append("   SET");
			// パスワード
			sql.append("	PASSWORD = ?");
			// 前回パスワード
			sql.append(",	PASSWORD_OLD = ?");
			// 前々回パスワード
			sql.append(",	PASSWORD_LAST = ?");
			// 仮パスワードフラグ
			sql.append(",	PASSWORD_PRE_FLG = ?");
			// パスワード変更日時
			sql.append(",	PASSWORD_MODIFIED_DATE =  SYSDATE");


			// パスワード有効期限フラグを判定する
			if(!LoginFlg.VALID_LIMIT_OFF.equals(loginInfo.getM_Password_Exp_Flg())) {
				// 有効期限がある場合
				// パスワード有効期限の更新
				sql.append(",	PASSWORD_EXP_DATE = ADD_MONTHS(SYSDATE, ").append(expMonth.toString()).append(")");
			}

			// 共通部分
			sql.append(",	UPD_PGM_ID =  ?");
			sql.append(",	UPD_USER_ID =  ?");
			sql.append(",	UPD_DT =  SYSDATE");
			sql.append(",	EXCLUSIVE_KEY =  EXCLUSIVE_KEY + 1");

			// 条件指定
			sql.append(" WHERE");
			sql.append("	USER_ID =  ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND EXCLUSIVE_KEY = ?");

			// WHERE句のパラメタ設定
			db.createPreparedStatement(sql.toString());
			// パスワード
			db.setString(1, safetyInputPwd);
			// 前回パスワード
			db.setString(2, loginInfo.getM_Password());
			// 前々回パスワード
			db.setString(3, loginInfo.getM_OldPassword());
			// 仮パスワードフラグ
			db.setString(4, prePwdFlg);


			// 更新プログラムID
			db.setString(5, className);
			// 更新ユーザーID
			db.setString(6, loginInfo.getM_User_Cd());
			// ユーザーID
			db.setString(7, loginInfo.getM_User_Cd());
			// 削除フラグ
			db.setString(8, AmallConst.DEFAULT_DEL_FLG);
			// 排他キー
			db.setLong(9, loginInfo.getM_Exclusive_Key());

			// SQL文実行
			int ret = db.executeUpdateSql();

			// 排他チェック
			if(ret == 0) {
				// 更新対象無し(楽観排他)
				db.rollback();
				return false;
			}

			// 更新結果判定
			if (ret != 1) {
				db.rollback();
				AmallException ee = new AmallException();
				ee.addException(className, methodName, AmallMessageConst.MSG_SYS_DB_UPDATE_ERROR, "");
				throw ee;
			}
			// コミット処理
			db.commit();
			return true;

		} catch (AmallException e) {
			db.rollback();
			e.addException(className, methodName, AmallMessageConst.MSG_SYS_DB_UPDATE_ERROR, "");
			throw e;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(className, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}
}
