/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Accme11DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cme.bean;

import jp.co.hitachi.a.m.cls.AmclsBeanBase;

/*****************************************************************************************
 * Accme11DispBeanクラス<br>
 *****************************************************************************************/
public class Accme11DispBean extends AmclsBeanBase {

	/** メンバ変数 */
	/** 更新日時 */
	private String updateDate = null;

	/** 前ページフラグ */
	private String prevPageFlg = null;
	/** 次ページフラグ */
	private String nextPageFlg = null;
	/** リストフラグ */
	private String listFlg = null;
	/** 登録フラグ */
	private String registFlg = null;
	/** 戻るボタンフラグ */
	private String returnFlg = null;

	/** 自動計算合計金額 */
	private int autoSpccmt = 0;
	/** 自動計算合計金額(表示用) */
	private String dispAutoSpccmt = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Accme11DispBean() {
		super();
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		super.clear();
		updateDate = null;
		prevPageFlg = null;
		nextPageFlg = null;
		listFlg = null;
		registFlg = null;
		returnFlg = null;
		autoSpccmt = 0;
		dispAutoSpccmt = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getPrevPageFlg() {
		return prevPageFlg;
	}

	public void setPrevPageFlg(String prevPageFlg) {
		this.prevPageFlg = prevPageFlg;
	}

	public String getNextPageFlg() {
		return nextPageFlg;
	}

	public void setNextPageFlg(String nextPageFlg) {
		this.nextPageFlg = nextPageFlg;
	}

	public String getListFlg() {
		return listFlg;
	}

	public void setListFlg(String listFlg) {
		this.listFlg = listFlg;
	}

	public String getRegistFlg() {
		return registFlg;
	}

	public void setRegistFlg(String registFlg) {
		this.registFlg = registFlg;
	}

	public String getReturnFlg() {
		return returnFlg;
	}

	public void setReturnFlg(String returnFlg) {
		this.returnFlg = returnFlg;
	}

	public int getAutoSpccmt() {
		return autoSpccmt;
	}

	public void setAutoSpccmt(int autoSpccmt) {
		this.autoSpccmt = autoSpccmt;
	}

	public String getDispAutoSpccmt() {
		return dispAutoSpccmt;
	}

	public void setDispAutoSpccmt(String dispAutoSpccmt) {
		this.dispAutoSpccmt = dispAutoSpccmt;
	}

}
