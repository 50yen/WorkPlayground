/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aceum11Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.dto;

import java.util.List;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;
import jp.co.hitachi.a.m.dto.AmdtoDropDownList;
import jp.co.hitachi.a.m.dto.AmdtoRadioList;

/*****************************************************************************************
 * Aceum11Dtoクラス<br>
 *****************************************************************************************/
public class Aceum11Dto extends AmclsDtoBase{

	/** メンバ変数 */
	/** ユーザーID */
	private String userId = null;
	/** システム種別 */
	private int systemKind = 0;
	/** 表示モード */
	private int dispMode = 0;

	/** 権限ロールプルダウンリスト */
	private List<AmdtoDropDownList> roleDropDownList = null;

	/** パスワードロックラジオボタンリスト */
	private List<AmdtoRadioList> radioPwdLockList = null;

	/** アカウントロックラジオボタンリスト */
	private List<AmdtoRadioList> radioActLockList = null;

	/** 排他キー */
	private Long exclusiveKey = null;


	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public Aceum11Dto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		userId = null;
		systemKind = 0;
		dispMode = 0;
		roleDropDownList = null;
		radioPwdLockList = null;
		radioActLockList = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getSystemKind() {
		return systemKind;
	}
	public void setSystemKind(int systemKind) {
		this.systemKind = systemKind;
	}
	public int getDispMode() {
		return dispMode;
	}
	public void setDispMode(int dispMode) {
		this.dispMode = dispMode;
	}
	public synchronized List<AmdtoDropDownList> getRoleDropDownList() {
		return roleDropDownList;
	}
	public synchronized void setRoleDropDownList(List<AmdtoDropDownList> roleDropDownList) {
		this.roleDropDownList = roleDropDownList;
	}
	public synchronized List<AmdtoRadioList> getRadioPwdLockList() {
		return radioPwdLockList;
	}
	public synchronized void setRadioPwdLockList(List<AmdtoRadioList> radioPwdLockList) {
		this.radioPwdLockList = radioPwdLockList;
	}
	public synchronized List<AmdtoRadioList> getRadioActLockList() {
		return radioActLockList;
	}
	public synchronized void setRadioActLockList(List<AmdtoRadioList> radioActLockList) {
		this.radioActLockList = radioActLockList;
	}
	public synchronized Long getExclusiveKey() {
		return exclusiveKey;
	}
	public synchronized void setExclusiveKey(Long exclusiveKey) {
		this.exclusiveKey = exclusiveKey;
	}

}
