/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech31DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.21 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.bean;

import java.util.List;

import jp.co.hitachi.a.c.ech.dto.AcechItemDispDto;
import jp.co.hitachi.a.m.cls.AmclsBeanBase;

/*****************************************************************************************
 * Acech31DispBeanクラス<br>
 *****************************************************************************************/
public class Acech31DispBean extends AmclsBeanBase {

	/** メンバ変数 */
	/** 回収日 */
	private String cld = null;
	/** 顧客名 */
	private String customerNm = null;
	/** 店舗名 */
	private String shopNm = null;

	/** 現ページ */
	private int displayNum = 0;
	/** 前ページフラグ */
	private String prevPageFlg = null;
	/** 次ページフラグ */
	private String nextPageFlg = null;

	/** 一覧表示 */
	private List<AcechItemDispDto> itemDispList = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Acech31DispBean() {
		clear();
	}

	/*************************************************************************************
	 * クリア
	 * <p>
	 * クリア処理
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		super.clear();
		cld = null;
		customerNm = null;
		shopNm = null;
		displayNum = 0;
		prevPageFlg = null;
		nextPageFlg = null;
		itemDispList = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getCld() {
		return cld;
	}

	public void setCld(String cld) {
		this.cld = cld;
	}

	public String getCustomerNm() {
		return customerNm;
	}

	public void setCustomerNm(String cutomerNm) {
		this.customerNm = cutomerNm;
	}

	public String getShopNm() {
		return shopNm;
	}

	public void setShopNm(String shopNm) {
		this.shopNm = shopNm;
	}

	public int getDisplayNum() {
		return displayNum;
	}

	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}

	public String getPrevPageFlg() {
		return prevPageFlg;
	}

	public void setPrevPageFlg(String prevPageFlg) {
		this.prevPageFlg = prevPageFlg;
	}

	public String getNextPageFlg() {
		return nextPageFlg;
	}

	public void setNextPageFlg(String nextPageFlg) {
		this.nextPageFlg = nextPageFlg;
	}

	public List<AcechItemDispDto> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<AcechItemDispDto> itiran) {
		this.itemDispList = itiran;
	}

}
