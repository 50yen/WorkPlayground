/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech31Business.java
 *
 * ----------------------------------------------------
 * 2018.08.21 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.business;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.ech.action.Acech31Action;
import jp.co.hitachi.a.c.ech.bean.Acech31DispBean;
import jp.co.hitachi.a.c.ech.dto.Acech31Dto;
import jp.co.hitachi.a.c.ech.dto.AcechItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.Encode;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallPage;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;
import jp.co.hitachi.a.m.dto.AmdtoPagingSql;

/*****************************************************************************************
 * Acech31Businessクラス<br>
 *****************************************************************************************/
public class Acech31Business extends AcechBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Acech31DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** ダウンロード処理 */
	public static final String FORWARD_DOWNLOAD = "DOWNLOAD";
	/** 前頁 */
	private static final String FORWARD_PAGEPREV = "PAGEPREV";
	/** 先頭頁処理 */
	private static final String FORWARD_PAGEFIRST = "PAGEFIRST";
	/** 次頁 */
	private static final String FORWARD_PAGENEXT = "PAGENEXT";
	/** 最終頁 */
	private static final String FORWARD_PAGELAST = "PAGELAST";
	/** 件数変更 */
	private static final String FORWARD_DISPRESULTS = "DISPRESULTS";
	/** 詳細遷移 */
	private static final String FORWARD_DETAIL = "DETAIL";
	/** 戻るボタン押下 */
	private static final String FORWARD_RETURNPAGE = "RETURNPAGE";
	/** カレンダー表示（Acech01）に戻る */
	private static final String FORWARD_RETURNCAL = "RETURNCAL";
	/** 回収日別店舗一覧（Acech11）に戻る */
	private static final String FORWARD_RETURNREGI = "RETURNREGI";
	/** 「戻る」にてページ再表示 */
	public static final String FORWARD_REDISP = "REDISP";

	/**
	 * 画面項目ID
	 */
	/** 画面名 */
	public static final String ITEM_ID_SCREEN_NAME = "ScreenName";
	/** 回収日 */
	public static final String ITEM_ID_CLD = "cld";
	/** 顧客名 */
	public static final String ITEM_ID_CST_CD = "cstCd";
	/** 店舗名 */
	public static final String ITEM_ID_SHOP_CD = "shopCd";

	/** メンバ変数 */
	/** アクションフォーム */
	private Acech31Action m_Acech31Form = null;
	/** 表示用画面Bean */
	private Acech31DispBean m_Acech31DispBean = null;
	/** ページング処理用 */
	private AmallPage m_Page = null;
	/** SQL作成用 */
	private AmdtoPagingSql m_Page_Sql = null;
	/** 画面DTO */
	Acech31Dto m_Acech31Dto;
	/** 画面DTO */
	AcechItemDispDto acechInfoDto;
	/** DTOキー名 */
	private String DTO_ACECH31 = "DTO_ACECH31";
	/** 遷移先画面キー */
	public static final String ACECH_INFO_KEY = "AcechInfo";

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Acech31Business(
			Acech31Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Acech31Business.class.getName();
		m_Acech31Form = form;
		m_Acech31DispBean = new Acech31DispBean();
		m_Page = new AmallPage();
		m_Page_Sql = new AmdtoPagingSql();
		m_Acech31Dto = new Acech31Dto();
		setErrString(gid, m_Acech31Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}
			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Acech31DispBean);

			/* 内部記憶情報の生成 */
			m_Acech31Dto = (Acech31Dto) getSpecifiedDTO(m_Gid, DTO_ACECH31);
			if (m_Acech31Dto == null) {
				m_Acech31Dto = new Acech31Dto();
				putSpecifiedDTO(m_Gid, DTO_ACECH31, m_Acech31Dto);
			}
			// 遷移元情報取得
			acechInfoDto = (AcechItemDispDto) getSpecifiedDTO(ACECH_INFO_KEY);
			if (acechInfoDto != null) {
				m_Acech31Dto.setCld(acechInfoDto.getCld());
				m_Acech31Dto.setCstCd(acechInfoDto.getCstCd());
				m_Acech31Dto.setShopCd(acechInfoDto.getShopCd());
				// DTO削除
				delSpecifiedDTO(ACECH_INFO_KEY);
			}

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Acech31Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_PAGEFIRST.equals(m_Event)) {
				// "<<"ボタン押下の場合
				forwardStr = pageFirst();
			} else if (FORWARD_PAGEPREV.equals(m_Event)) {
				// "<"ボタン押下の場合
				forwardStr = pagePrev();
			} else if (FORWARD_PAGENEXT.equals(m_Event)) {
				// ">"ボタン押下の場合
				forwardStr = pageNext();
			} else if (FORWARD_PAGELAST.equals(m_Event)) {
				// ">>"ボタン押下の場合
				forwardStr = pageLast();
			} else if (FORWARD_DISPRESULTS.equals(m_Event)) {
				// 表示件数変更の場合
				forwardStr = changeDispRslts();
			} else if (FORWARD_DOWNLOAD.equals(m_Event)) {
				// ダウンロード処理の場合
				forwardStr = download();
			} else if (FORWARD_DETAIL.equals(m_Event)) {
				// 詳細ボタン押下処理の場合
				forwardStr = details();
			} else if (m_Event.equals(FORWARD_RETURNPAGE)) {
				// 戻るボタン押下処理の場合
				forwardStr = returnPage();
			} else if (FORWARD_REDISP.equals(m_Event)) {
				// 戻るボタンでページに戻ってきた場合
				forwardStr = redisp();
			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Acech31DispBean);

			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 * @throws Exception
	 ************************************************************************************/
	private String disp() throws AmallException, Exception {

		// 遷移元情報が存在しない場合
		if (acechInfoDto == null) {
			// エラーメッセージセット
			setMessageInfo(m_Acech31DispBean, AmallMessageConst.MSG_ERR_SPEC_NOT_COMBI,
					getItemDispName(ITEM_ID_CST_CD, m_Acech31DispBean),
					getItemDispName(ITEM_ID_SHOP_CD, m_Acech31DispBean));
			return FORWARD_DISP;
		}
		// キャプションセット
		infoCreate();
		// 一覧表示データ
		search();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ダウンロード処理
	 * <p>
	 * ダウンロード処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String download() throws AmallException {

		// ファイルデータ作成
		List<String> data = new ArrayList<>();

		// 出力ファイル検索
		search();

		// データセット
		if (m_Acech31DispBean.getItemDispList() != null) {
			for (AcechItemDispDto list : m_Acech31DispBean.getItemDispList()) {
				data.add(
						list.getShopSbno() + AmallConst.CSV_SEP +
								list.getMcdSchNm() + AmallConst.CSV_SEP +
								list.getSld() + AmallConst.CSV_SEP +
								list.getSpccDfemt() + AmallConst.CSV_SEP +
								list.getSpccmTotal() + AmallConst.CSV_SEP +
								list.getSrmTotal());
			}
		}

		// ファイルデータ出力
		AmdtoGeneralMst dlFileDto = AmallUtilities.getGeneralMstDataRecord(m_DbAccess, GeneralMstKey.CSV_DOWNLOAD_FILE,
				m_Gid, null, m_Acech31DispBean.getServiceDate());
		m_Acech31Form.setDownloadFileData(data, dlFileDto.getGeneralNm1(), Encode.SHIFT_JIS);

		return FORWARD_DOWNLOAD;
	}

	/*************************************************************************************
	 * "<"ボタン押下処理実行
	 * <p>
	 * "<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	public String pagePrev() throws AmallException, Exception {

		// キャプションセット
		infoCreate();

		// 検索処理を呼ぶ
		search();
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * "<<"ボタン押下処理実行
	 * <p>
	 * "<<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	public String pageFirst() throws AmallException, Exception {

		// キャプションセット
		infoCreate();

		// 検索処理を呼ぶ
		search();
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ">"ボタン押下処理実行
	 * <p>
	 * ">"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	public String pageNext() throws AmallException, Exception {

		// キャプションセット
		infoCreate();

		// 検索処理を呼ぶ
		search();
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ">>"ボタン押下処理実行
	 * <p>
	 * ">>"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	public String pageLast() throws AmallException, Exception {

		// キャプションセット
		infoCreate();

		// 検索処理を呼ぶ
		search();
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 表示件数変更処理実行
	 * <p>
	 * 表示件数変更処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	public String changeDispRslts() throws AmallException, Exception {

		// キャプションセット
		infoCreate();

		// 検索処理を呼ぶ
		search();
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 詳細ボタン押下処理
	 * <p>
	 * 詳細ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	public String details() throws AmallException {

		// 取得枝番をdtoにセット
		AcechItemDispDto dto = new AcechItemDispDto();
		dto.setCld(m_Acech31Dto.getCld());
		dto.setCstCd(m_Acech31Dto.getCstCd());
		dto.setCstNm(m_Acech31Dto.getCstNm());
		dto.setShopCd(m_Acech31Dto.getShopCd());
		dto.setShopNm(m_Acech31Dto.getShopNm());
		dto.setShopSbnosp(m_Acech31Form.getShopSbno());
		dto.setShopSbno(m_Acech31Form.getDispShopSbno());
		putSpecifiedDTO(ACECH_INFO_KEY, dto);

		return FORWARD_DETAIL;
	}

	/*************************************************************************************
	 * 戻るボタン押下処理実行
	 * <p>
	 * 戻る変更押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String returnPage() throws AmallException {

		// 画面DTOを削除
		delSpecifiedDTO(m_Gid);

		// TODO 権限
		if(!m_Acech31DispBean.isCustomerCdAllFlg() && m_Acech31DispBean.getShopCdListMap().size() == 1) {
			return FORWARD_RETURNCAL;

		}
		return FORWARD_RETURNREGI;
	}

	/*************************************************************************************
	 * 再表示処理
	 * <p>
	 * 「戻る」ボタンで戻ってきた場合の再表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String redisp() throws AmallException, Exception {

		// キャプションセット
		infoCreate();

		// 検索処理
		search();

		return FORWARD_DISP;

	}

	/*************************************************************************************
	 * キャプションエリア検索処理実行
	 * <p>
	 * キャプションエリア検索処理を実行する
	 * </p>
	 * @param  なし
	 * @return なし
	 ************************************************************************************/
	public void infoCreate() throws AmallException, Exception {
		// methodName
		String methodName = "infoCreate()";

		// 結果
		ResultSet rs = null;
		// システム日付取得
		String systemDt = m_Acech31DispBean.getServiceDate();

		try {

			// 初期表示ではない場合DTOの値をセット・返却
			if (!(FORWARD_DISP.equals(m_Event))) {
				m_Acech31DispBean.setCld(AmallUtilities.changeFormat(m_Acech31Dto.getCld()));
				m_Acech31DispBean.setCustomerNm(m_Acech31Dto.getCstNm());
				m_Acech31DispBean.setShopNm(m_Acech31Dto.getShopNm());

				return;
			}

			// 検索条件
			String cstCd = acechInfoDto.getCstCd();
			String shopCd = acechInfoDto.getShopCd();
			String cld = acechInfoDto.getCld();
			// SQL作成
			StringBuffer sql = new StringBuffer();
			List<String> bindParam = new ArrayList<String>();
			sql.append("SELECT");
			sql.append(" ncm.CST_CD AS CST_CD");
			sql.append(", ncm.CST_NM AS CST_NM");
			sql.append(", nsm.SHOP_CD AS SHOP_CD");
			sql.append(", nsm.SHOP_NM AS SHOP_NM");
			sql.append(", nscm.COMPANY_SHOP_CD AS COMPANY_SHOP_CD");
			sql.append(", nscm.COMPANY_SHOP_NM AS COMPANY_SHOP_NM");

			sql.append(" FROM");
			sql.append("  N_CST_M ncm");
			sql.append(" LEFT JOIN");
			sql.append("  N_SHOP_M nsm");
			sql.append("  ON ncm.CST_CD = nsm.CST_CD");
			sql.append("  AND nsm.EFST_DY <= ?");
			bindParam.add(systemDt);
			sql.append("  AND ? <= nsm.EFED_DY");
			bindParam.add(systemDt);
			sql.append(" AND nsm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" LEFT JOIN");
			sql.append("  N_SHOP_CNV_M nscm");
			sql.append("  ON nsm.CST_CD = nscm.CST_CD");
			sql.append("  AND nsm.SHOP_CD = nscm.SHOP_CD");
			sql.append("  AND nscm.EFST_DY <= ?");
			bindParam.add(systemDt);
			sql.append("  AND ? <= nscm.EFED_DY");
			bindParam.add(systemDt);
			sql.append("  AND nscm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" WHERE");
			sql.append("  ncm.CST_CD = ?");
			bindParam.add(cstCd);
			sql.append(" AND");
			sql.append("  nsm.SHOP_CD = ?");
			bindParam.add(shopCd);
			sql.append(" AND ncm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < bindParam.size(); i++) {
				m_DbAccess.setString(i + 1, bindParam.get(i));
			}

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 実行結果チェック
			while (rs.next()) {
				// データセット
				String str = m_DbAccess.getString(rs, "CST_NM");
				m_Acech31DispBean.setCustomerNm(str);

				if (!AmallUtilities.isEmpty(m_DbAccess.getString(rs, "COMPANY_SHOP_CD"))) {
					m_Acech31DispBean.setShopNm(m_DbAccess.getString(rs, "COMPANY_SHOP_NM"));
				} else {
					m_Acech31DispBean.setShopNm(m_DbAccess.getString(rs, "SHOP_NM"));
				}
			}
			m_Acech31DispBean.setCld(AmallUtilities.changeFormat(cld));

			// DTOにセット
			m_Acech31Dto.setCstNm(m_Acech31DispBean.getCustomerNm());
			m_Acech31Dto.setShopNm(m_Acech31DispBean.getShopNm());
			m_Acech31Dto.setCstCd(cstCd);
			m_Acech31Dto.setShopCd(shopCd);
			m_Acech31Dto.setCld(cld);

			/* StringBuffer 開放  */
			sql.delete(0, sql.length());
			sql = null;

			/* List<String> 開放  */
			bindParam.clear();
			bindParam = null;

		} catch (AmallException ame) {
			m_DbAccess.rollback();
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					getItemDispName(ITEM_ID_SCREEN_NAME, m_Acech31DispBean));
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	/*************************************************************************************
	 * 検索処理実行
	 * <p>
	 * 検索処理を実行する
	 * </p>
	 * @param  なし
	 * @return なし
	 ************************************************************************************/
	public void search() throws AmallException {
		// methodName
		String methodName = "search()";
		// 明細部用LIST
		List<AcechItemDispDto> detailList = new ArrayList<>();

		// システム日付取得
		String systemDt = m_Acech31DispBean.getServiceDate();

		// 検索条件
		String cstCd = m_Acech31Dto.getCstCd();
		String shopCd = m_Acech31Dto.getShopCd();
		String cld = m_Acech31Dto.getCld();

		try {

			// SQL作成
			makeSearchSql(cstCd, shopCd, cld, systemDt);

			// select句
			String sqlSelect = m_Page_Sql.getSqlSelect();
			// from where 句
			String sqlCondition = m_Page_Sql.getSqlConditinon();
			// order 句
			String sqlOrder = m_Page_Sql.getSqlOrder();
			// param 句
			String[] sqlParam = m_Page_Sql.getSqlParam();
			// 表示件数
			int pageDispCnt = m_Page_Sql.getPageDispCnt();
			// ページ番号
			int pageNo = m_Acech31Form.getDisplayNum();

			List<Map<String, String>> pageData;
			if (m_Event.equals(FORWARD_DISP)) { // 初期検索状態
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEFIRST)) { // "<<"ボタン押下時
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEPREV)) { // "<"ボタン押下時
				pageData = m_Page.getPrevPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGENEXT)) { // ">"ボタン押下時
				pageData = m_Page.getNextPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGELAST)) { // ">>"ボタン押下時
				pageData = m_Page.getLastPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else { // 表示件数プル変更時、その他
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			}

			/* 表示頁NOのセット */
			m_Acech31DispBean.setDisplayNum(m_Page.getNowPage());
			/* ページ遷移ボタンセット */
			if (!m_Page.isPrevPageExist()) {
				m_Acech31DispBean.setPrevPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Acech31DispBean.setPrevPageFlg(AmallConst.GeneralFlg.OFF);
			}
			if (!m_Page.isNextPageExist()) {
				m_Acech31DispBean.setNextPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Acech31DispBean.setNextPageFlg(AmallConst.GeneralFlg.OFF);
			}

			// 件数セット
			m_Acech31DispBean.setDispCountDefault(String.valueOf(pageDispCnt));

			// ページ情報がない場合
			if (pageData == null) {
				// エラーメッセージをセット
				setMessageInfo(m_Acech31DispBean, AmallMessageConst.MSG_ERR_SELECT_CON_NO_DATA,
						getItemDispName(ITEM_ID_CLD, m_Acech31DispBean));
				return;

			}

			/** 明細部リスト作成 **/
			if (m_Event.equals(FORWARD_DOWNLOAD)) { // DL用リスト作成
				detailList = makeDetailDlList(m_Page.getNowPage(), pageData);
			} else {
				detailList = makeDetailList(m_Page.getNowPage(), pageData);
			}

			/* 表示Beanに一覧データをセット */
			m_Acech31DispBean.setItemDispList(detailList);

		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					getItemDispName(ITEM_ID_SCREEN_NAME, m_Acech31DispBean));
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * SQL作成
	 * <p>
	 * SQLを作成する
	 * </p>
	 * @param cstCd 顧客CD
	 * @param shopCd 店舗CD
	 * @param cld 回収日
	 * @param systemDt システム日付
	 * @return SQL
	 ************************************************************************************/
	protected void makeSearchSql(String cstCd, String shopCd, String cld, String systemDt)
			throws AmallException, Exception {
		String methodName = "makeSearchSql()";
		StringBuffer sql = new StringBuffer();
		String[] sqlParam = { cstCd, shopCd, cld };

		try {
			// 1ページの表示件数
			// 初期表示はデフォルト値を設定する
			if (m_Event.equals(FORWARD_DISP) || m_Event.equals(FORWARD_REDISP)) {
				m_Page_Sql.setPageDispCnt(Integer.parseInt(m_Acech31DispBean.getDispCountDefault()));
			} else {
				m_Page_Sql.setPageDispCnt(m_Acech31Form.getDispResults());
			}

			// SQL SELECT
			sql.delete(0, sql.length());
			sql.append("SELECT");
			sql.append(" ncd.SHOP_SBNO AS SHOP_SBNO");
			sql.append(", nssm.SHOP_SB_NM AS SHOP_SB_NM");
			sql.append(", NVL(nsscm.COMPANY_SHOP_SB_CD,null) AS COMPANY_SHOP_SB_CD");
			sql.append(", NVL(nsscm.COMPANY_SHOP_SB_NM,'') AS COMPANY_SHOP_SB_NM");
			sql.append(", ncd.CLMY_SLD AS CLMY_SLD");
			sql.append(", ncd.SPCC_DFEMT AS SPCC_DFEMT");
			sql.append(", ncd.SRMT AS SRMT");
			sql.append(", ncd.SPCCMT AS SPCCMT");
			String sqlSelect = sql.toString();
			// SQL FROM & WHERE
			sql.delete(0, sql.length());
			sql.append("FROM");
			sql.append(" N_CLMY_DAT ncd");
			sql.append(" LEFT JOIN");
			sql.append(" 	N_SHOP_SB_M nssm");
			sql.append(" 	ON ncd.CST_CD = nssm.CST_CD");
			sql.append(" 	AND ncd.SHOP_CD = nssm.SHOP_CD");
			sql.append(" 	AND ncd.SHOP_SBNO = nssm.SHOP_SBNO");
			sql.append(" 	AND nssm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" 	AND nssm.EFST_DY <= " + systemDt);
			sql.append(" 	AND " + systemDt + " <= nssm.EFED_DY");
			sql.append(" LEFT JOIN");
			sql.append(" 	N_SHOP_SB_CNV_M nsscm");
			sql.append(" 	ON nssm.CST_CD = nsscm.CST_CD");
			sql.append(" 	AND nssm.SHOP_CD = nsscm.SHOP_CD");
			sql.append(" 	AND nssm.SHOP_SBNO = nsscm.SHOP_SBNO");
			sql.append(" 	AND nsscm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" 	AND nsscm.EFST_DY <= " + systemDt);
			sql.append(" 	AND " + systemDt + " <= nsscm.EFED_DY");
			sql.append(" WHERE");
			sql.append(" ncd.CST_CD = ?");
			sql.append(" AND ncd.SHOP_CD = ?");
			sql.append(" AND ncd.CLD = ?");
			sql.append(" AND ncd.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			String sqlCondition = sql.toString();
			// SQL ORDER
			sql.delete(0, sql.length());
			sql.append(" ORDER BY ncd.SHOP_SBNO");
			String sqlOrder = sql.toString();

			// セット処理
			m_Page_Sql.setSqlSelect(sqlSelect);
			m_Page_Sql.setSqlConditinon(sqlCondition);
			m_Page_Sql.setSqlOrder(sqlOrder);
			m_Page_Sql.setSqlParam(sqlParam);

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 明細リスト作成処理
	 * <p>
	 * 明細リスト作成処理を実行する
	 * </p>
	 * @param  	pageSize	頁数
	 * @param	pageData	頁データ
	 * @return 明細ArrayList
	 ************************************************************************************/
	public List<AcechItemDispDto> makeDetailList(int pageSize, List<Map<String, String>> pageData)
			throws AmallException {
		List<AcechItemDispDto> retList = new ArrayList<>();
		String methodName = "makeDetailList()";
		try {
			// ページ情報をリストに追加
			for (Map<String, String> map : pageData) {
				AcechItemDispDto listdto = new AcechItemDispDto();
				// 企業店舗枝番がある場合は企業店舗枝番を優先
				if (!AmallUtilities.isEmpty(map.get("COMPANY_SHOP_SB_CD"))
						|| !AmallUtilities.isEmpty(map.get("COMPANY_SHOP_SB_NM"))) {
					// 企業店舗枝番
					listdto.setShopSbno(map.get("COMPANY_SHOP_SB_CD"));
					// 企業店舗枝番名称
					listdto.setMcdSchNm(map.get("COMPANY_SHOP_SB_NM"));

				} else {
					// 店舗枝番
					listdto.setShopSbno(AmallUtilities.changeFormatSbNo(map.get("SHOP_SBNO")));
					// 店舗枝番名称
					listdto.setMcdSchNm(map.get("SHOP_SB_NM"));
				}
				// 遷移用店舗枝番
				listdto.setShopSbnosp(map.get("SHOP_SBNO"));

				// 売上日
				listdto.setSld(AmallUtilities.changeFormat(map.get("CLMY_SLD")));
				// 差額
				if (Integer.parseInt(map.get("SPCC_DFEMT")) != 0) {
					// 差額がマイナスの場合フラグをオン
					listdto.setDefFlg(AmallConst.GeneralFlg.ON);
				}
				listdto.setSpccDfemt(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, Integer.parseInt(map.get("SPCC_DFEMT")))
								+ AmallConst.DEFAULT_MONEY_JA);
				// 金種票登録合計
				listdto.setSrmTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, Integer.parseInt(map.get("SRMT")))
								+ AmallConst.DEFAULT_MONEY_JA);
				// 精査金額計
				listdto.setSpccmTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, Integer.parseInt(map.get("SPCCMT")))
								+ AmallConst.DEFAULT_MONEY_JA);
				// 返却リストに追加
				retList.add(listdto);
			}

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

		return retList;
	}

	/*************************************************************************************
	 * DL用明細リスト作成処理
	 * <p>
	 * DL用明細リスト作成処理を実行する
	 * </p>
	 * @param  	pageSize	頁数
	 * @param	pageData	頁データ
	 * @return DL用明細ArrayList
	 ************************************************************************************/
	public List<AcechItemDispDto> makeDetailDlList(int pageSize, List<Map<String, String>> pageData)
			throws AmallException {
		List<AcechItemDispDto> retList = new ArrayList<>();
		String methodName = "makeDetailList()";
		try {
			// ページ情報をリストに追加
			for (Map<String, String> map : pageData) {
				AcechItemDispDto listdto = new AcechItemDispDto();
				// 企業店舗枝番がある場合は企業店舗枝番を優先
				if (!AmallUtilities.isEmpty(map.get("COMPANY_SHOP_SB_CD"))
						|| !AmallUtilities.isEmpty(map.get("COMPANY_SHOP_SB_NM"))) {
					// 企業店舗枝番
					listdto.setShopSbno(map.get("COMPANY_SHOP_SB_CD"));
					// 企業店舗枝番名称
					listdto.setMcdSchNm(map.get("COMPANY_SHOP_SB_NM"));
				} else {
					// 店舗枝番
					listdto.setShopSbno(AmallUtilities.changeFormatSbNo(map.get("SHOP_SBNO")));
					// 店舗枝番名称
					listdto.setMcdSchNm(map.get("SHOP_SB_NM"));
				}

				// 売上日
				listdto.setSld(AmallUtilities.changeFormat(map.get("CLMY_SLD")));
				// 差額
				listdto.setSpccDfemt(map.get("SPCC_DFEMT"));
				// 金種票登録合計
				listdto.setSrmTotal(map.get("SRMT"));
				// 精査金額計
				listdto.setSpccmTotal(map.get("SPCCMT"));
				// 返却リストに追加
				retList.add(listdto);
			}

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

		return retList;
	}

}