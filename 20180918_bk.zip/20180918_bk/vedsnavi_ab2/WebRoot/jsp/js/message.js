/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) message.js
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
/****************************************************************
 * @name メッセージエリア点滅処理
 *
 * @description
 * メッセージエリアの点滅処理を行う
 * OnLoadに設定
 *
 * @param formName サブミット対象Form名
 * @param action サブミットアクション名
 * @return なし
 ****************************************************************/
// エリア点滅回数管理
var msgBlnkkCnt = 0;
function messageAreaBlink() {

	// 表示位置をTOPに戻す。
    var h = $('html, body');
    h.scrollTop(0).scrollLeft(0);

    // 一定間隔での起動
    var id = setInterval(function(){
    	// 点滅処理
    	$(".alertblink").fadeOut(500,function(){
    		$(this).fadeIn(500)
    	});

    	// 繰り返し回数のチェック
    	if(msgBlnkkCnt > 0) {
    		// 点滅処理の完了
    		clearInterval(id);
    	}
    	msgBlnkkCnt++;
    },1000);
}
/****************************************************************
 * @name 共通OnLoad処理
 *
 * @description
 * 共通で設定するOnLoad処理を以下に記載する
 *
 * @param なし
 * @return なし
 ****************************************************************/
$(function () {
	// メッセージエリア点滅処理
	messageAreaBlink();
});
