/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) acsgm01.js
 *
 * ----------------------------------------------------
 * 2018.08.21 新規作成
 * ----------------------------------------------------
 */

/****************************************************************
 * @name 編集ボタン押下時
 *
 * @description
 * 画面遷移処理を実行する。
 *
 * @param beanName
 * @param shopGrpCd
 * @param action
 * @return なし
 * @author Hitachi Document
 ****************************************************************/
function clickEdit(beanName, shopGrpCd, action){
	selectLine(beanName, shopGrpCd, action);
}

/****************************************************************
 * @name コピーボタン押下時
 *
 * @description
 * コピー確認ダイアログを表示し、画面遷移処理を実行する。
 *
 * @param beanName
 * @param shopGrpCd
 * @param action
 * @return なし
 * @author Hitachi Document
 ****************************************************************/
function clickCopy(beanName, shopGrpCd, action){
	if(window.confirm(MESSAGE['Mapi018'])){
		selectLine(beanName, shopGrpCd, action);
	}
}

/****************************************************************
 * @name 画面遷移
 *
 * @description
 * 対象店舗グループコードをhiddenに設定し、画面遷移を行う
 *
 * @param beanName
 * @param cstGrpCd
 * @param action
 * @return なし
 * @author Hitachi Document
 ****************************************************************/
function selectLine(beanName, shopGrpCd, action)
{
	document.forms[beanName].shopGrpCdHid.value = shopGrpCd;
	amallSubmit(beanName, action);
}