/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) common.js
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
/****************************************************************
 * @name サイドバーメニュー
 *
 * @description
 * サイドバーメニューをマウスオーバーで表示非表示を切り替える
 * OnLoadに設定
 *
 * @param なし
 * @return なし
 * @author Hitachi Document
 ****************************************************************/
function amallSideMenu() {
	$(".menu").hover(function(){
		$(this).stop().animate({'width':'200px'}, 'fast', 'linear', function(){
			$(this).css('overflow', 'visible');
		});
	}, function(){
		$(this).css('overflow', 'hidden');
		$(this).stop().animate({'width':'60px'}, 'fast');
	});

	$(".menu li").hover(function(){
		$(this).find(">.submenu").show();
	}, function(){
		$(this).find(">.submenu").hide();
	});

	$(".accordion .ac-content label").click(function(){
		$(this).toggleClass('open');
		$(this).next().slideToggle("fast")
	}).next().hide();
}
/****************************************************************
 * @name ページ離脱防止処理
 *
 * @description
 * 通常の移動以外の処理の場合にアラートを表示する
 * onLoadに設定
 *
 * @param なし
 * @return なし
 ****************************************************************/
//フォームの入力欄が更新されたかどうかを表すフラグです。
var isChanged = false;
//サブミット処理の場合の処理を表すフラグです。
var isSubmit = false;
// 移動時のメッセージ
var moveMsg = 'Mapw004';
function onBeforeunloadHandler() {
	$(window).bind("beforeunload", function(e) {
		if (isSubmit == false) {
			var errMsg = MESSAGE[moveMsg];
			// Chrome
			e.returnValue = errMsg;

			// IE
			return errMsg;
		}
	});
};
/****************************************************************
 * @name 画面更新検知
 *
 * @description
 * 画面項目が変更された場合に正規サブミット処理以外を警告出力する
 * 必要な場合のみonLoadに設定
 *
 * @param msgId メッセージID(ない場合はデフォルト)
 * @return なし
 ****************************************************************/
function discoverChangeForm(msgId){
	$("form input, form select, form textarea").change(function() {
		// 入力内容が更新されている場合は、isChangedフラグをtrueにします。
		isChanged = true;
		// 表示メッセージを変更
		if(msgId === undefined){
			msgId = 'Mapw002';
		}
		moveMsg = msgId;
	});
}
/****************************************************************
 * @name サブミット処理
 *
 * @description
 * サブミット処理を行う。
 * 二重送信を抑止する機能があり，
 * JSPの再構築までは再度ボタンは押せない。
 * 正規サブミットフラグがundefinedの場合は
 * isChangedフラグをチェックして修正がある場合に値を設定する
 * (修正がない場合通常はtrue)
 *
 * @param formName サブミット対象Form名
 * @param action サブミットアクション名
 * @param flg 正規サブミットチェックフラグ
 * @return なし
 ****************************************************************/
function amallSubmit(formName, action, flg) {

	// 正規サブミットチェック
	if(flg === undefined){
		// 登録系のサブミットでない場合
		if(isChanged == true){
			// 修正が発生している場合はサブミット違反(=false)
			isSubmit == false;
		} else {
			// 修正が発生していなければ問題なし
			isSubmit = true;
		}
	} else {
		// 正規サブミットが設定されている場合はその値を設定
		isSubmit = flg;
	}

	// 二重送信抑止
	$.LoadingOverlay("show",{
		background  : "rgba(0, 0, 0, 0.4)",
		imageResizeFactor : 0.8,
		imageColor : "#ffffff",
	});

	if(isSubmit == false){
		// 確認ダイアログでキャンセルの可能性があるため消去処理を入れる
		setTimeout(function(){
			$.LoadingOverlay("hide");
		}, 7000);
	}

	// サブミット処理
	window.document.forms[formName].target = "_self";
	window.document.forms[formName].action = action;
	window.document.forms[formName].submit();



}
/****************************************************************
 * @name サブミット処理(二重送信チェックなし)
 *
 * @description
 * サブミット処理を行う。
 * 二重送信を抑止する機能はない
 * CSVダウンロードなどの自画面遷移時のみ使用する
 *
 * @param formName サブミット対象Form名
 * @param action サブミットアクション名
 * @return なし
 ****************************************************************/
function amallSubmitWithoutDupcheck(formName, action) {

	// 正規サブミットフラグをON
	isSubmit = true;

	// サブミット処理
	window.document.forms[formName].target = "_self";
	window.document.forms[formName].action = action;
	window.document.forms[formName].submit();

	// 別スレッドで正規サブミットフラグをOFFに戻す。
	setTimeout(function(){
		isSubmit = false;
	},1);
}
/****************************************************************
 * @name 登録確認
 *
 * @description
 * 登録確認ダイアログを表示した後「OK」の場合のみ
 * 二重送信を抑止するサブミット処理を呼び出す，
 *
 * @param formName サブミット対象Form名
 * @param action サブミットアクション名
 * @param msg 表示するメッセージID(デフォルト値あり省略可)
 * @return なし
 ****************************************************************/
function amallSubmitWithRegistDialog(formName, action, msgId) {

	var msg ="";
	// ダイアログメッセージを取得
	if(msgId === undefined){
		msg = MESSAGE['Mapi011'];
	} else {
		msg = MESSAGE[msgId];
	}
	// ダイアログ表示
	if(window.confirm(msg)){
		// OKの時
		amallSubmit(formName, action, true)
	}
}
/****************************************************************
 * @name マニュアル起動(ウィンドウオープン)
 *
 * @description
 * マニュアル(PDF)起動を実行する
 * パスが存在する場合のみ別タブに開く
 *
 * @param path 対象PDFパス
 * @return なし
 ****************************************************************/
function manualOpen(path) {

	// パスの存在チェック
	if(path !== undefined){
		if(path.length > 0){
			// 別タブオープン
			window.open(path,'pdf');
		}
	}
}
/****************************************************************
 * @name パスワードエリアコピペ抑止
 *
 * @description
 * パスワードエリアのみコピペ(カット含む)を抑止する
 * onLoadに設定
 *
 * @param なし
 * @return なし
 ****************************************************************/
function cancelCopyPastPass() {
	$(document).on('copy cut paste','input[type=password]',function(){
		return false;
	});
}
/****************************************************************
 * @name 初期フォーカス設定処理
 *
 * @description
 * 画面上のフォーム内の最初の入力可能項目にフォーカスをあてる
 * onLoadに設定
 *
 * @param なし
 * @return なし
 ****************************************************************/
var firstElm = "form input:enabled:visible:not([readonly]),textarea:enabled:visible:not([readonly]),select:enabled:visible";
$firstElm = $(firstElm);

function setFirstFocus() {
	// 画面が読み込まれる前に動かないように遅延処理
	setTimeout(function(){
        $(firstElm).filter(":first").focus();
	}, 200);
}

/****************************************************************
 * @name Enterキー押下処理
 *
 * @description
 * Enterキー押下時にTabと同等の動きにする。
 * 以下の内容に対応
 * ・Enter : 次のフォーカス対象に遷移(targetElm)に定義したもの
 * 			 自フォーカスにtabindexが設定されている場合はその値よりも大きいtabindexに遷移
 * 			 最大値の場合は、tabindexの最小値に遷移
 * ・Shift+Enter：逆順の次のフォーカスに移動
 * ・aおよびbuttonの場合は onclickイベントを優先する
 * onLoadに設定
 *
 * @param なし
 * @return なし
 ****************************************************************/
//移動先の対象
var targetElm = "input[type=text],input[type=password],input[type=submit],select,input[type=button],input[type=checkbox],textarea,a,button";
$targetElm = $( targetElm );

function enterTabBind() {

	// Enterが押されたときに動作する対象
	var elements = "input[type=text],input[type=password],select,input[type=checkbox]";

	// キー押下のイベントリスナー
	$(elements).keypress(function(e) {
		// キーコード取得
		var c = e.which ? e.which : e.keyCode; // クロスブラウザ対応

		// キーコード13(=Enter)のとき
		if (c == 13) {
			// 現在のタブインデックス番号を取得
			var curentTabIdx = $(this).attr("tabindex");
			// 現在のタブインデックス番号が存在する
			if (typeof(curentTabIdx) != "undefined") {
				// タブインデックスのリストを作成
				var tabIdxAllCnt = $("[tabindex]").length; // 全体のタブインデックス数
				var tabIdxAllObj = $("[tabindex]"); // 全体のタブインデックスを持つオブジェクトの配列
				var tabIdxLst = []; // タブインデックスの番号リスト
				for (listCnt = 0; listCnt < tabIdxAllCnt; listCnt++) {
					// タブインデックス番号のリストを生成
					tabIdxLst.push(tabIdxAllObj[listCnt].tabIndex);
				}
				// ソートを行う
				tabIdxLst.sort(function(a, b) {
					if (a < b) return -1;
					if (a > b) return 1;
					return 0;
				});
				// 現在のタブインデックス番号が全体の何番目か算出
				var currentPos = tabIdxLst.indexOf(curentTabIdx - 0);
				// 次のインデックス番号の位置を特定
				var nextPos = currentPos;
				var pos = e.shiftKey ? -1 : 1;
				// 最大と最初は位置探索しない
				do {
					// 次のタブインデックス番号の取得
					var nextTabIdx = tabIdxLst[currentPos + pos];
					if (nextTabIdx === undefined) {
						// 位置が最初または最後の場合
						break;
					} else {
						// 止まってはいけいない属性 readonly
						if ($("[tabindex=" + nextTabIdx + "]").attr("readonly") == "readonly") {
							if (e.shiftKey) {
								pos--; // １つ前
							} else {
								pos++; // 次へ
							}
						}
						// 止まってはいけいない属性 disabled
						else if ($("[tabindex=" + nextTabIdx + "]").prop("disabled") == true) {
							if (e.shiftKey) {
								pos--; // １つ前
							} else {
								pos++; // 次へ
							}
						}// 止まってはいけいない属性 表示なし
						else if ($("[tabindex=" + nextTabIdx + "]").is(':hidden') == true) {
							if (e.shiftKey) {
								pos--; // １つ前
							} else {
								pos++; // 次へ
							}
						}
						else {
							// 次のタブインデックス番号の位置を決定し、フォーカス移動
							$("[tabindex=" + nextTabIdx + "]").focus();
							e.preventDefault();
							return;
						}
					}
				} while (currentPos + pos > 0 && currentPos + pos <= tabIdxAllCnt);
				// タブインデックスの移動先が存在しない場合
				var index = $(targetElm).index(this); // indexは0～
				var cNext = "";
				var nLength = $(targetElm).length;
				for (i = index; i < nLength; i++) {
					cNext = e.shiftKey ? ":lt(" + index + "):last" : ":gt(" + index + "):first";
					// 止まってはいけいない属性 readonly
					if ($(targetElm).filter(cNext).attr("readonly") == "readonly") {
						if (e.shiftKey) {
							index--; // １つ前
						} else {
							index++; // 次へ
						}
					}
					// 止まってはいけいない属性 disabled
					else if ($(targetElm).filter(cNext).prop("disabled") == true) {
						if (e.shiftKey) {
							index--; // １つ前
						} else {
							index++; // 次へ
						}
					}
					// 止まってはいけいない属性 表示なし
					else if ($(targetElm).filter(cNext).is(':hidden') == true) {
						if (e.shiftKey) {
							index--; // １つ前
						} else {
							index++; // 次へ
						}
					}
					// 止まってはいけいない属性 tabindex あり
					else if ($(targetElm).filter(cNext).attr("tabindex") !== undefined) {
						if (e.shiftKey) {
							index--; // １つ前
						} else {
							index++; // 次へ
						}
					} else {
						break;
					}
				}
				if (index == nLength - 1) {
					if (!e.shiftKey) {
						// 最後の項目なら、最初に移動。
						for (i = 0; i < nLength; i++) {
							cNext = ":eq(" + (i) + ")";
							// 最初の要素もチェック
							if ($(targetElm).filter(cNext).attr("readonly") == "readonly" ||
									$(targetElm).filter(cNext).prop("disabled") == true ||
									$(targetElm).filter(cNext).attr("tabindex") !== undefined) {
								// 最初の要素から1つ後に
							} else {
								// 問題なければ移動
								break;
							}
						}
					}
				}
				if (index == 0) {
					if (e.shiftKey) {
						// 最初の項目なら、最後に移動。
						for (i = 1; i < nLength; i++) {
							cNext = ":eq(" + (nLength - i) + ")";
							// 最後の要素もチェック
							if ($(targetElm).filter(cNext).attr("readonly") == "readonly" ||
									$(targetElm).filter(cNext).prop("disabled") == true ||
									$(targetElm).filter(cNext).attr("tabindex") !== undefined) {
								// 最後の要素から1つ前に
							} else {
								// 問題なければ移動
								break;
							}
						}
					}
				}
				$(targetElm).filter(cNext).focus();
				e.preventDefault;
			} else {
				var index = $(targetElm).index(this); // indexは0～
				var cNext = "";
				var nLength = $(targetElm).length;
				for (i = index; i < nLength; i++) {
					cNext = e.shiftKey ? ":lt(" + index + "):last" : ":gt(" + index + "):first";
					// 止まってはいけいない属性 readonly
					if ($(targetElm).filter(cNext).attr("readonly") == "readonly") {
						if (e.shiftKey) {
							index--; // １つ前
						} else {
							index++; // 次へ
						}
					}
					// 止まってはいけいない属性 disabled
					else if ($(targetElm).filter(cNext).prop("disabled") == true) {
						if (e.shiftKey) {
							index--; // １つ前
						} else {
							index++; // 次へ
						}
					}
					// 止まってはいけいない属性 表示なし
					else if ($(targetElm).filter(cNext).is(':hidden') == true) {
						if (e.shiftKey) {
							index--; // １つ前
						} else {
							index++; // 次へ
						}
					}
					else {
						break;
					}
				}
				if (index == nLength - 1) {
					if (!e.shiftKey) {
						// 最後の項目なら、最初に移動。
						for (i = 0; i < nLength; i++) {
							cNext = ":eq(" + (i) + ")";
							// 最初の要素もチェック
							if ($(targetElm).filter(cNext).attr("readonly") == "readonly" ||
									$(targetElm).filter(cNext).prop("disabled") == true) {
								// 最初の要素から1つ後に
							} else {
								// 問題なければ移動
								break;
							}
						}
					}
				}
				if (index == 0) {
					if (e.shiftKey) {
						// 最初の項目なら、最後に移動。
						for (i = 1; 1 < nLength; i++) {
							cNext = ":eq(" + (nLength - i) + ")";
							// 最後の要素もチェック
							if ($(targetElm).filter(cNext).attr("readonly") == "readonly" ||
									$(targetElm).filter(cNext).prop("disabled") == true) {
								// 最後の要素から1つ前に
							} else {
								// 問題なければ移動
								break;
							}
						}
					}
				}
				$(targetElm).filter(cNext).focus();
				e.preventDefault() //規定の動作をキャンセルするため、こちらのメソッドを呼ぶ。
			}
		}
	});
}
/****************************************************************
* @name 子画面起動ボタン押下処理
*
* @description
* 子画面起動を実行するボタンイベントを監視する
* 押下後に共通のモーダル画面起動処理を実施する
* OnLoadに設定
*
* @param なし
* @return なし
****************************************************************/
function setChidlBtnEvent() {

	// IDのSearchChildBtnの後方一致イベント監視
	$('[id$=SearchChildBtn]').on('click', function() {

		// ダイアログの幅指定(980pxより小さい場合のみ)
		var dialogWidth = $(window).width() * 0.95;
		if (dialogWidth > 980) {
			dialogWidth = 980;
		}

		// ダイアログの高さを指定(ブラウザの90%の高さ)
		var dialogHeight = $(window).height() * 0.85;

		// 呼び出し元の画面IDを取得
		var callGid = $('#callScreenId').val();


		// iframeのsrc要素にパラメータを付加したURLを設定
		// モーダルダミーに飛ぶ
		var srcStr = "jsp/ac/modaldummy.jsp";

		// 押されたボタンに応じて遷移先・値の取得先を変更
		var btnId = $(this).attr("id");

		// 'SearchChildBtn'より前の部分を取得
		var prefix = btnId.replace( 'SearchChildBtn', '' );

		// メイン取得先ID
		var searchDataId = prefix + 'Search';
		// メイン検索データ
		var dataParam = "";
		if($('#' + searchDataId).length != 0) {
			dataParam = encodeURIComponent($('#' + searchDataId).val());
		}

		// メイン名称設定先ID
		var reciveDataId = prefix + 'SearchNm';

		// 検索タイプ
		var typeParam = "";
		if (prefix.indexOf('customerGrp') != -1) {
			typeParam = "customerGrp";
		} else if (prefix.indexOf('customer') != -1) {
			typeParam = "customer";
		} else if (prefix.indexOf('shopGrp') != -1) {
			typeParam = "shopGrp";
		} else if (prefix.indexOf('shopBranch') != -1) {
			typeParam = "shopBranch";
		} else if (prefix.indexOf('user') != -1) {
			typeParam = "user";
		} else if (prefix.indexOf('shop') != -1) {
			typeParam = "shop";
		}

		// タイプのさらに前の一覧番号を取得(ある場合のみ)
		var prefixNumber = prefix.replace(typeParam , '' );


		// 検索タイプに応じたデータを設定する
		var cstCdId = prefixNumber + "customerSearch";
		var cstNmId = prefixNumber + "customerSearchNm";
		var shopCdId = prefixNumber + "shopSearch";
		var shopNmId = prefixNumber + "shopSearchNm";
		var addParam ="";
		switch (typeParam) {
		case 'customer':
			// 顧客検索
			// サブデータなし
			break;
		case 'customerGrp':
			// 顧客グループ検索
			// サブデータなし
			break;
		case 'shop':
			// 店舗検索
			// 顧客
			// IDの存在チェック
			if($('#' + cstCdId).length != 0 && $('#' + cstNmId).length != 0){
				var data = encodeURIComponent($('#' + cstCdId).val());
				addParam = addParam + "&cstcdid=" + cstCdId + "&cstnmid=" + cstNmId + '&cstdata=' + data;
			}
			break;
		case 'shopGrp':
			// 店舗グループ検索
			// サブデータなし
			break;
		case 'user':
			// ユーザー検索
			// IDの存在チェック
			if($('#' + cstCdId).length != 0 && $('#' + cstNmId).length != 0){
				var data = encodeURIComponent($('#' + cstCdId).val());
				addParam = addParam + "&cstcdid=" + cstCdId + "&cstnmid=" + cstNmId + '&cstdata=' + data;
			}
			if($('#' + shopCdId).length != 0 && $('#' + shopNmId).length != 0){
				var data = encodeURIComponent($('#' + shopCdId).val());
				addParam = addParam + "&shopcdid=" + shopCdId + "&shopnmid=" + shopNmId + '&shopdata=' + data;
			}
			break;
		case 'shopBranch':
			// 店舗枝番検索
			// IDの存在チェック
			if($('#' + cstCdId).length != 0 && $('#' + cstNmId).length != 0){
				var data = encodeURIComponent($('#' + cstCdId).val());
				addParam = addParam + "&cstcdid=" + cstCdId + "&cstnmid=" + cstNmId + '&cstdata=' + data;
			}
			if($('#' + shopCdId).length != 0 && $('#' + shopNmId).length != 0){
				var data = encodeURIComponent($('#' + shopCdId).val());
				addParam = addParam + "&shopcdid=" + shopCdId + "&shopnmid=" + shopNmId + '&shopdata=' + data;
			}
			break;
		default:
			break;
		}

		// GET パラメータの文字列を作成する
		srcStr = srcStr + "?type=" + typeParam + "&data=" + dataParam + "&sndid=" + searchDataId + "&rcvid=" + reciveDataId + "&callgid=" + callGid + addParam;



		// ダイアログ表示
		$("#dialog-iframe").dialog({
			modal : true,
			width : dialogWidth,
			height : dialogHeight,
			closeOnEscape : true,
			hide : null,
			position : {
				my : "center",
				at : "center",
				of : window
			},
			resizable : false,
			show : null,
			open : function() {
				$('<iframe />').attr({
					src : srcStr,
					id : 'iframe_contents',
					width: "100%",
					height : "100%",
					scrolling: "no",
				}).appendTo('#dialog-iframe');
			},
			close : function() {
				$("#iframe_contents").remove();
			}
		});
	});
}

/****************************************************************
 * @name ModalDummy OnLoad処理
 *
 * @description
 * ModalDummy OnLoad処理を以下に記載する
 * ダミーからアクションへの遷移
 *
 * @param flg 正規サブミットチェックフラグ
 * @return なし
 ****************************************************************/
function modalDummy() {

	// 親画面からの値をhiddenにセット
	var param = paramWrite();

	// 種別値取得
	var sendType = param['type'];

	// 引数をセット
	// 種別
	$('#type').val(sendType);
	// 検索値
	$('#data').val(param['data']);
	// 取得先ID
	$('#sndid').val(param['sndid']);
	// 返却先ID
	$('#rcvid').val(param['rcvid']);
	// 呼び出し元画面ID
	$('#callgid').val(param['callgid']);
	// 顧客コード
	$('#cstcdid').val(param['cstcdid']);
	// 顧客名
	$('#cstnmid').val(param['cstnmid']);
	// 顧客データ
	$('#cstdata').val(param['cstdata']);
	// 店舗コード
	$('#shopcdid').val(param['shopcdid']);
	// 店舗名
	$('#shopnmid').val(param['shopnmid']);
	// 店舗データ
	$('#shopdata').val(param['shopdata']);

	// サブミット先設定(相対パス)
	var submitPath = "../../";

	switch (sendType) {
	case 'customer':
		// 顧客検索
		submitPath = submitPath + 'accsi01' + 'DISP';
		break;
	case 'customerGrp':
		// 顧客グループ検索
		submitPath = submitPath + 'accsi02' + 'DISP';
		break;
	case 'shop':
		// 店舗検索
		submitPath = submitPath + 'acssi01' + 'DISP';
		break;
	case 'shopGrp':
		// 店舗グループ検索
		submitPath = submitPath + 'acssi02' + 'DISP';
		break;
	case 'user':
		// ユーザー検索
		submitPath = submitPath + 'acsts01' + 'DISP';
		break;
	case 'shopBranch':
		// 店舗枝番検索
		submitPath = submitPath + 'acsbi01' + 'DISP';
		break;
	default:
		break;
	}

	// サブミット処理
	amallSubmitWithoutDupcheck(0,submitPath);
}

/****************************************************************
 * @name 引数処理
 *
 * @description
 * 引数処理を以下に記載する
 *
 * @param なし
 * @return pram
 ****************************************************************/
function paramWrite() {
	// 返却用配列
	var vars = [];

	// URLのクエリ文字列を取得
	var url = window.location.search;
	// 引数がない時は処理しない
	if (!url) {
		return vars;
	}

	// ?を取り除くため、1から始める。複数のクエリ文字列に対応するため、&で区切る
	var hash  = url.slice(1).split('&');
	var max = hash.length;
	for (var i = 0; i < max; i++) {
		// keyと値に分割
		var array = hash[i].split('=');
		// 末尾にクエリ文字列のkeyを挿入
		vars.push(array[0]);
		// 先ほど確保したkeyに、値を代入
		vars[array[0]] = decodeURIComponent(array[1]);
	}
	return vars;
}


/****************************************************************
 * @name ダイアログクローズ処理
 *
 * @description
 * ダイアログを閉じる処理とともに、選択値を親画面に返却する
 * 設定値がない場合はそのままダイアログを閉じる
 * (トークンは設定を行う)
 *
 * @param cd コード値
 * @param name 名称
 * @param cstCd 顧客コード値
 * @param cstNm 顧客名称
 * @param shopCd 店舗コード値
 * @param shopNm 店舗名称
 * @return なし
 ****************************************************************/
function closeDialog(cd, name, cstCd, cstNm, shopCd, shopNm) {

	if(cd !== undefined && name !== undefined){
		// コード値の親画面IDを取得
		var parentCdId = $('#sndid').val();
		// 名称の親画面IDを取得
		var parentNmId = $('#rcvid').val();

		if(name.length == 0){
			name ="&nbsp;"
		}

		// 親画面に値を渡す
		// ID存在チェック
		if($("#" + parentCdId, parent.document).length != 0){
			// コード値
			$("#" + parentCdId, parent.document).val(cd);
		}
		// 名称設定エリアがhiddenの場合
		if($("input:hidden#" + parentNmId, parent.document).length != 0){
			// 名称
			$("#" + parentNmId, parent.document).val(name);
			// 親画面のonChangeイベントを発火
			parent.$("#" + parentNmId).trigger('change');

		} else if($("#" + parentNmId, parent.document).length != 0){
			// 名称
			$("#" + parentNmId, parent.document).html(name);
		}


	}
	if(cstCd !== undefined && cstNm !== undefined){
		// コード値の親画面IDを取得
		var parentCdId = $('#cstcdid').val();
		// 名称の親画面IDを取得
		var parentNmId = $('#cstnmid').val();

		if(cstNm.length == 0){
			cstNm ="&nbsp;"
		}

		// 親画面に値を渡す
		// ID存在チェック
		if($("#" + parentCdId, parent.document).length != 0){
			// コード値
			$("#" + parentCdId, parent.document).val(cstCd);
		}
		// 名称設定エリアがhiddenの場合
		if($("input:hidden#" + parentNmId, parent.document).length != 0){
			// 名称
			$("#" + parentNmId, parent.document).val(cstNm);
			// 親画面のonChangeイベントを発火
			parent.$("#" + parentNmId).trigger('change');

		} else if($("#" + parentNmId, parent.document).length != 0){
			// 名称
			$("#" + parentNmId, parent.document).html(cstNm);
		}

	}
	if(shopCd !== undefined && shopNm !== undefined){
		// コード値の親画面IDを取得
		var parentCdId = $('#shopcdid').val();
		// 名称の親画面IDを取得
		var parentNmId = $('#shopnmid').val();

		if(shopNm.length == 0){
			shopNm ="&nbsp;"
		}

		// 親画面に値を渡す
		// ID存在チェック
		if($("#" + parentCdId, parent.document).length != 0){
			// コード値
			$("#" + parentCdId, parent.document).val(shopCd);
		}
		// 名称設定エリアがhiddenの場合
		if($("input:hidden#" + parentNmId, parent.document).length != 0){
			// 名称
			$("#" + parentNmId, parent.document).val(shopNm);
			// 親画面のonChangeイベントを発火
			parent.$("#" + parentNmId).trigger('change');

		} else if($("#" + parentNmId, parent.document).length != 0){
			// 名称
			$("#" + parentNmId, parent.document).html(shopNm);
		}

	}
	// トークンを親画面に設定
	$("[name=token]", parent.document).val($("[name=token]").val());

	// モーダルクローズ
	parent.$('#dialog-iframe').dialog('close');

}
/****************************************************************
* @name 各種検索エリアの結果欄初期化処理
*
* @description
* 各種子画面検索エリアに値がある場合に入力欄が変更された場合は
* 結果欄を初期化する。(IDは後方一致の決めうち)
* OnLoadに設定
*
* @param なし
* @return なし
****************************************************************/
function initSerachResultArea() {

	// IDのcustomerSearchの後方一致イベント監視
	$('[id$=customerSearch]').on('change', function() {
		// 変更エリアに応じて初期化先を変更
		var inputId = $(this).attr("id");

		// 'Search'より前の部分を取得
		var prefix = inputId.replace( 'Search', '' );

		// 名称設定先ID
		var resultId = prefix + 'SearchNm';

		// 内容初期化
		$('#' + resultId).html('&nbsp;');
	});

	// IDのshopSearchの後方一致イベント監視
	$('[id$=shopSearch]').on('change', function() {
		// 変更エリアに応じて初期化先を変更
		var inputId = $(this).attr("id");

		// 'Search'より前の部分を取得
		var prefix = inputId.replace( 'Search', '' );

		// 名称設定先ID
		var resultId = prefix + 'SearchNm';

		// 内容初期化
		$('#' + resultId).html('&nbsp;');
	});

	// IDのuserSearchの後方一致イベント監視
	$('[id$=userSearch]').on('change', function() {
		// 変更エリアに応じて初期化先を変更
		var inputId = $(this).attr("id");

		// 'Search'より前の部分を取得
		var prefix = inputId.replace( 'Search', '' );

		// 名称設定先ID
		var resultId = prefix + 'SearchNm';

		// 内容初期化
		$('#' + resultId).html('&nbsp;');
	});

	// IDのshopBranchSearchの後方一致イベント監視
	$('[id$=shopBranchSearch]').on('change', function() {
		// 変更エリアに応じて初期化先を変更
		var inputId = $(this).attr("id");

		// 'Search'より前の部分を取得
		var prefix = inputId.replace( 'Search', '' );

		// 名称設定先ID
		var resultId = prefix + 'SearchNm';

		// 内容初期化
		$('#' + resultId).html('&nbsp;');
	});
}

/****************************************************************
 * @name 共通OnLoad処理
 *
 * @description
 * 共通で設定するOnLoad処理を以下に記載する
 *
 * @param なし
 * @return なし
 ****************************************************************/
$(function () {
	// オートコンプリート機能OFF
	$('form').attr('autocomplete', 'off');
	// Enterキー押下時Tab処理
	enterTabBind();
	// パスワードコピペ抑止
	cancelCopyPastPass();
	// サイドバーメニュー設定
	amallSideMenu();
	// ブラウザバック&ページ更新抑止
	onBeforeunloadHandler();
	// 初期フォーカス処理
	setFirstFocus();
	// 子画面読み込み処理
	setChidlBtnEvent();
	// 各種検索結果欄初期化処理
	initSerachResultArea();
});

