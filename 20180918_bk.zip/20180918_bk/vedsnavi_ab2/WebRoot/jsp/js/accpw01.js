/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) accpw01.js
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
/****************************************************************
 * @name 自動TOP移動処理
 *
 * @description
 * 自動でTOP画面へ遷移する
 * OnLoadに設定
 *
 * @param formName サブミット対象Form名
 * @param action サブミットアクション名
 * @return なし
 ****************************************************************/
function autoMoveProc() {

	// 対象のエリアが0秒でない時のみ起動する
	var setSecData = $('#autoTopMoveSecId').val();
	var nSec = Number(setSecData);

	if(setSecData !== undefined && Number(setSecData) > 0){

		setTimeout(function(){
			amallSubmit('Accpw01Form','accpw01REGISTLOGIN');
		},nSec);

	}

	// 対象のエリアが0秒でない時のみ起動する
	var setSecLogOutData = $('#autoLogOutMoveSecId').val();

	var nSecLog = Number(setSecLogOutData);

	if(setSecLogOutData !== undefined && Number(setSecLogOutData) > 0){

		setTimeout(function(){
			amallSubmit(0,'actop01LOGOUT');
		},nSecLog);

	}


}
/****************************************************************
 * @name OnLoad処理
 *
 * @description
 * OnLoad処理を以下に記載する
 *
 * @param なし
 * @return なし
 ****************************************************************/
$(function () {
	// 自動移動処理
	autoMoveProc();
});
