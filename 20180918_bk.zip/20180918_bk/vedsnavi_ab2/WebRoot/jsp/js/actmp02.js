/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) actmp02.js
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
$(function() {
	// ファイルダイアログ処理監視
	$('#fileOpen').change(function() {

		// s:fileタグのデータ
		var fileRef = $(this).get(0);

		// ファイルリストを取得
		for(i = 0; i < fileRef.files.length; i++){
			// File オブジェクトからファイル名を取得する
			$('#fileDisp').val(fileRef.files[i].name);
		}
	});
});