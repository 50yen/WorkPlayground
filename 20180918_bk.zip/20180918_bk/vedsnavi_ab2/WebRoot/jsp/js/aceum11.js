/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) aceum11.js
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
/****************************************************************
 * @name 権限プルダウン切り替え時処理
 *
 * @description
 * 権限プルダウンを切り替えた時、入力欄を切り替える
 * OnLoadに設定
 *
 * @return なし
 ****************************************************************/
function roleDropDownChange(){

	// 初期化
	$('[id$=SearchChildBtn]').prop('disabled', true);
	$('[id$=SearchChildBtn_Del]').prop('disabled', true);
	$('#shopGrpAddBtn').prop('disabled', true);
	$('[id$=Search]').prop('disabled', true);
	$('[id$=Search]').addClass('disable');

	//選択されたカテゴリのvalueを取得し変数に入れる
	var val = $('.cls').val();
	// 切り替え処理
	roleChangeData(val);


	//分類のselect要素が変更になるとイベントが発生
	$('.cls').change(function() {
		// 初期化
		$('[id$=SearchChildBtn]').prop('disabled', true);
		$('[id$=SearchChildBtn_Del]').prop('disabled', true);
		$('#shopGrpAddBtn').prop('disabled', true);
		$('[id$=Search]').prop('disabled', true);
		$('[id$=Search]').addClass('disable');
		$('[id$=Search]').val("");
		$('[id$=SearchNm]').val("");
		$('[id$=SearchNm]').html("&nbsp;");
		$('[id$=SearchNmDiv]').html("&nbsp;");
		$('[id$=GrpSearchNm]').trigger('change');

		//選択されたカテゴリのvalueを取得し変数に入れる
		var val = $(this).val();
		// 切り替え処理
		roleChangeData(val);

	});
}
/****************************************************************
 * @name 権限プルダウン切り替え内容
 *
 * @description
 * 権限プルダウンを切り替えた時、の対象データ
 *
 * @param val 権限コード
 * @return なし
 ****************************************************************/
function roleChangeData(val) {

	switch (val) {
	case '0001':
	case '0002':
	case '0003':
	case '0004':
		break;
	case '0005':
	case '0006':
		// 企業管理者
		// 企業本部担当
		$("#customerGrpSearch").prop('disabled', false);
		$("#customerGrpSearch").removeClass('disable');
		$("#customerGrpSearchChildBtn").prop('disabled', false);
		$("#customerGrpSearchChildBtn_Del").prop('disabled', false);

		$("#customerSearch").prop('disabled', false);
		$("#customerSearch").removeClass('disable');
		$("#customerSearchChildBtn").prop('disabled', false);
		break;
	case '0007':
		// エリア担当
		$('[id$=shopGrpSearch]').prop('disabled', false);
		$('[id$=shopGrpSearch]').removeClass('disable');
		$('[id$=shopGrpSearchChildBtn]').prop('disabled', false);
		$('[id$=shopGrpSearchChildBtn_Del]').prop('disabled', false);
		$('#shopGrpAddBtn').prop('disabled', false);
		$("#shopSearch").prop('disabled', false);
		$("#shopSearch").removeClass('disable');
		$("#shopSearchChildBtn").prop('disabled', false);

		$("#customerSearch").prop('disabled', false);
		$("#customerSearch").removeClass('disable');
		$("#customerSearchChildBtn").prop('disabled', false);
		break;
	case '0008':
	case '0009':
		// 店長
		// 担当者
		$("#shopSearch").prop('disabled', false);
		$("#shopSearch").removeClass('disable');
		$("#shopSearchChildBtn").prop('disabled', false);

		$("#customerSearch").prop('disabled', false);
		$("#customerSearch").removeClass('disable');
		$("#customerSearchChildBtn").prop('disabled', false);
		break;
	default:
		break;
	}
}
/****************************************************************
 * @name チェックボックス切り替え時処理
 *
 * @description
 * チェックボックスを切り替えた時、日付ピッカーおよび入力欄を切り替える
 * OnLoadに設定
 *
 * @return なし
 ****************************************************************/
function checkChangeEvent(){
	// 初期設定
	checkChangeProc();

	// 権限のselect要素が変更になるとイベントが発生
	$('#passwordExpCheck').change(function() {
		// 切り替え処理
		checkChangeProc();

	});
}
/****************************************************************
 * @name チェックボックス切り替え内容
 *
 * @description
 * チェックボックス切り替えた時、の対象データ
 *
 * @return なし
 ****************************************************************/
function checkChangeProc() {

	if ($("#passwordExpCheck").prop("checked") == true) {
		//チェックON時
		$("#datepicker").datepicker( "option", "disabled", true );
		$("#datepicker").addClass('disable');
		$('#datepicker').val("");

		$('#inputedPasswordValidId').prop('disabled', true);
		$('#inputedPasswordValidId').addClass('disable');
		$('#inputedPasswordValidId').val("");

	} else {
		//チェックOFF時
		$( "#datepicker" ).datepicker( "option", "disabled", false );
		$("#datepicker").removeClass('disable');


		$('#inputedPasswordValidId').prop('disabled', false);
		$('#inputedPasswordValidId').removeClass('disable');

	}
}
/****************************************************************
 * @name グループ名変更後起動処理
 *
 * @description
 * グループ名が変更後に起動する処理
 * OnLoadに設定
 *
 * @return なし
 ****************************************************************/
function grpNameChangeEvent(){

	// 初期設定
	$('[id$=GrpSearchNm]').each(function(index, elem){
		var orgId = $(elem).attr("id");
		grpNameChangeData(orgId);
	});

	// グループ名のhidden要素のOnChangeイベントを監視
	$('[id$=GrpSearchNm]').change(function() {

		// 変更のあったIDに応じて遷移先・値の取得先を変更
		var orgId = $(this).attr("id");
		grpNameChangeData(orgId);

	});
}
/****************************************************************
 * @name グループ名変更後起動処理内容
 *
 * @description
 * グループ名が変更後に起動する処理の内容
 * OnLoadに設定
 *
 * @param orgId 対象ID
 * @return なし
 ****************************************************************/
function grpNameChangeData(orgId){

	// 'GrpSearchNm'より前の部分を取得
	var prefix = orgId.replace( 'SearchNm', '' );

	// 設定先ID
	var targetId = prefix + 'SearchNmDiv';

	// 設定値
	var setData = $('#' + orgId).val();
	$('#'+ targetId).html(setData);

	// 設定値が存在する場合
	if(setData.length > 0){
		// 削除ボタン表示
		$('#' + prefix + 'SearchChildBtn').addClass('displaynone');
		$('#' + prefix + 'SearchChildBtn_Del').removeClass('displaynone');
	} else {
		// 通常ボタン表示
		$('#' + prefix + 'SearchChildBtn_Del').addClass('displaynone');
		$('#' + prefix + 'SearchChildBtn').removeClass('displaynone');
	}
}
/****************************************************************
 * @name 削除ボタン押下処理
 *
 * @description
 * 削除ボタン押下後に起動する処理
 * OnLoadに設定
 *
 * @return なし
 ****************************************************************/
function deleteBtnEvent(){

	// グループ名のhidden要素のOnChangeイベントを監視
	$('[id$=SearchChildBtn_Del]').on('click',function() {

		// 変更のあったIDに応じて遷移先・値の取得先を変更
		var orgId = $(this).attr("id");

		// 'GrpSearchNm'より前の部分を取得
		var prefix = orgId.replace( 'SearchChildBtn_Del', '' );

		// 設定先ID
		var hiddenId = prefix + 'Search';
		var hiddenNm = prefix + 'SearchNm';
		var dispId = prefix + 'SearchNmDiv';

		// 設定値
		$('#' + hiddenId).val("");
		$('#' + hiddenNm).val("");
		$('#'+ dispId).html("&nbsp;");

		// 通常ボタン表示
		$('#' + prefix + 'SearchChildBtn_Del').addClass('displaynone');
		$('#' + prefix + 'SearchChildBtn').removeClass('displaynone');

	});
}

/****************************************************************
 * @name OnLoad処理
 *
 * @description
 * OnLoad処理を以下に記載する
 *
 * @param なし
 * @return なし
 ****************************************************************/
$(function () {

	// 権限プルダウンの監視処理
	roleDropDownChange();

	// グループ名の変更監視
	grpNameChangeEvent();

	// 削除ボタンの押下処理監視
	deleteBtnEvent();

	// 有効期限チェックボックス監視
	checkChangeEvent();

	// 画面項目変更検知
	discoverChangeForm();

});
