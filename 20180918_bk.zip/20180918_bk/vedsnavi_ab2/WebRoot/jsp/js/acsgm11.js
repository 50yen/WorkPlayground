/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) acsgm11.js
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
/****************************************************************
 * @name 店舗名変更後起動処理
 *
 * @description
 * 店舗名が変更後に起動する処理
 * OnLoadに設定
 *
 * @return なし
 ****************************************************************/
function nameChangeEvent(){

	// 初期設定
	$('[id$=SearchNm]').each(function(index, elem){
		var orgId = $(elem).attr("id");
		nameChangeData(orgId);
	});

	// グループ名のhidden要素のOnChangeイベントを監視
	$('[id$=SearchNm]').change(function() {

		// 変更のあったIDに応じて遷移先・値の取得先を変更
		var orgId = $(this).attr("id");
		nameChangeData(orgId);

	});
}
/****************************************************************
 * @name 店舗名変更後起動処理内容
 *
 * @description
 * 店舗名が変更後に起動する処理の内容
 * OnLoadに設定
 *
 * @param orgId 対象ID
 * @return なし
 ****************************************************************/
function nameChangeData(orgId){

	// 'SearchNm'より前の部分を取得
	var prefix = orgId.replace( 'SearchNm', '' );

	// 取得元ID
	var srcId = prefix + 'Search';
	// 設定先ID
	var targetId = prefix + 'SearchDiv';
	// 設定値
	var setDataId = $('#' + srcId).val();

	// 値の設定
	$('#'+ targetId).html(setDataId);

	// 取得元Name
	var srcNm = prefix + 'SearchNm';
	// 設定先Name
	var targetNm = prefix + 'SearchNmDiv';
	// 設定値
	var setDataNm = $('#' + srcNm).val();

	// 値の設定
	$('#'+ targetNm).html(setDataNm);

	// ボタン存在チェック
	if ($('#' + prefix + 'SearchChildBtn').length > 0){
		// 設定値が存在する場合
		if(setDataId.length > 0){
			// 削除ボタン表示
			$('#' + prefix + 'SearchChildBtn').addClass('displaynone');
			$('#' + prefix + 'SearchChildBtn_Del').removeClass('displaynone');
		} else {
			// 通常ボタン表示
			$('#' + prefix + 'SearchChildBtn_Del').addClass('displaynone');
			$('#' + prefix + 'SearchChildBtn').removeClass('displaynone');
		}
	}

}
/****************************************************************
 * @name 削除ボタン押下処理
 *
 * @description
 * 削除ボタン押下後に起動する処理
 * OnLoadに設定
 *
 * @return なし
 ****************************************************************/
function deleteBtnEvent(){

	// hidden要素のOnChangeイベントを監視
	$('[id$=shopSearchChildBtn_Del]').on('click',function() {

		// 変更のあったIDに応じて遷移先・値の取得先を変更
		var orgId = $(this).attr("id");

		// 'SearchNm'より前の部分を取得
		var prefix = orgId.replace( 'SearchChildBtn_Del', '' );
		// 'shopSearchNm'より前の部分を取得
		var prefixNumber = orgId.replace( 'shopSearchChildBtn_Del', '' );

		// 設定先セレクタ生成
		var hiddenId = "[id^='" + prefixNumber + "'][id$='Search']";
		var hiddenNm = "[id^='" + prefixNumber + "'][id$='SearchNm']";
		var dispId = "[id^='" + prefixNumber + "'][id$='SearchDiv']";
		var dispNm = "[id^='" + prefixNumber + "'][id$='SearchNmDiv']";

		// 設定値
		$(hiddenId).val("");
		$(hiddenNm).val("");
		$(dispId).html("&nbsp;");
		$(dispNm).html("&nbsp;");

		// 通常ボタン表示
		$('#' + prefix + 'SearchChildBtn_Del').addClass('displaynone');
		$('#' + prefix + 'SearchChildBtn').removeClass('displaynone');

	});
}

/****************************************************************
 * @name OnLoad処理
 *
 * @description
 * OnLoad処理を以下に記載する
 *
 * @param なし
 * @return なし
 ****************************************************************/
$(function () {

	// 店舗名の変更監視
	nameChangeEvent();

	// 削除ボタンの押下処理監視
	deleteBtnEvent();

	// 画面項目変更検知
	discoverChangeForm();

});
