/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aceum01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.action;

import java.util.List;

import jp.co.hitachi.a.c.eum.bean.Aceum01DispBean;
import jp.co.hitachi.a.c.eum.business.Aceum01Business;
import jp.co.hitachi.a.c.eum.dto.AceumItemDispDto;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Aceum01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Aceum01DispBean aceum01DispBean;

	/**
	 * 入力項目
	 */
	/** 顧客コード */
	private String inputCustomerCd = null;
	/** 店舗コード */
	private String inputShopCd = null;
	/** ユーザーID */
	private String inputUserId = null;
	/** 権限ロールプルダウン選択値 */
	private String selectedRoleCd = null;
	/** パスワードロック */
	private boolean passLockFlg = false;
	/** アカウントロック */
	private boolean actLockFlg = false;

	/** プルダウンリスト選択値 */
	private int dispResults = 0;
	/** ページ番号 */
	private int displayNum = 0;

	/** 顧客名称 */
	private String dispCstNm = null;
	/** 店舗名称 */
	private String dispShopNm = null;
	/** ユーザー名称 */
	private String dispUserNm = null;

	/** 選択ユーザーID */
	private String transUserId = null;

	/** 選択システム種別 */
	private String transSystemKind = null;

	/** 一覧表示 */
	private List<AceumItemDispDto> itemDispList = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAceum01DispBean((Aceum01DispBean)request.getAttribute("Aceum01DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Aceum01Business dao = new Aceum01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Aceum01DispBean getAceum01DispBean() {
		return aceum01DispBean;
	}

	public void setAceum01DispBean(Aceum01DispBean aceum01DispBean) {
		this.aceum01DispBean = aceum01DispBean;
	}

	public String getInputCustomerCd() {
		return inputCustomerCd;
	}

	public void setInputCustomerCd(String inputCustomerCd) {
		this.inputCustomerCd = inputCustomerCd;
	}

	public String getInputShopCd() {
		return inputShopCd;
	}

	public void setInputShopCd(String inputShopCd) {
		this.inputShopCd = inputShopCd;
	}

	public String getInputUserId() {
		return inputUserId;
	}

	public void setInputUserId(String inputUserId) {
		this.inputUserId = inputUserId;
	}

	public String getSelectedRoleCd() {
		return selectedRoleCd;
	}

	public void setSelectedRoleCd(String selectedRoleCd) {
		this.selectedRoleCd = selectedRoleCd;
	}

	public boolean isPassLockFlg() {
		return passLockFlg;
	}

	public void setPassLockFlg(boolean passLockFlg) {
		this.passLockFlg = passLockFlg;
	}

	public boolean isActLockFlg() {
		return actLockFlg;
	}

	public void setActLockFlg(boolean actLockFlg) {
		this.actLockFlg = actLockFlg;
	}

	public int getDispResults() {
		return dispResults;
	}

	public void setDispResults(int dispResults) {
		this.dispResults = dispResults;
	}

	public int getDisplayNum() {
		return displayNum;
	}

	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}

	public String getDispCstNm() {
		return dispCstNm;
	}

	public void setDispCstNm(String dispCstNm) {
		this.dispCstNm = dispCstNm;
	}

	public String getDispShopNm() {
		return dispShopNm;
	}

	public void setDispShopNm(String dispShopNm) {
		this.dispShopNm = dispShopNm;
	}

	public String getDispUserNm() {
		return dispUserNm;
	}

	public void setDispUserNm(String dispUserNm) {
		this.dispUserNm = dispUserNm;
	}

	public String getTransUserId() {
		return transUserId;
	}

	public void setTransUserId(String transUserId) {
		this.transUserId = transUserId;
	}

	public String getTransSystemKind() {
		return transSystemKind;
	}

	public void setTransSystemKind(String transSystemKind) {
		this.transSystemKind = transSystemKind;
	}

	public List<AceumItemDispDto> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<AceumItemDispDto> itemDispList) {
		this.itemDispList = itemDispList;
	}


}
