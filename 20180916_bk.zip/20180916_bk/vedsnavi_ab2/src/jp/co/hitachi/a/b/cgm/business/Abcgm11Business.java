/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abcgm11DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.cgm.business;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.b.cgm.action.Abcgm11Action;
import jp.co.hitachi.a.b.cgm.bean.Abcgm11DispBean;
import jp.co.hitachi.a.b.cgm.dto.Abcgm11Dto;
import jp.co.hitachi.a.b.cgm.dto.AbcgmCstGrpDto;
import jp.co.hitachi.a.b.cgm.dto.AbcgmItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;

/*****************************************************************************************
 * Abcgm11Businessクラス<br>
 *****************************************************************************************/
public class Abcgm11Business extends AbcgmBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Abcgm11DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	private static final String FORWARD_DISP = "DISP";
	/** 顧客追加 */
	private static final String FORWARD_ADD = "ADD";
	/** 削除 */
	private static final String FORWARD_DELETE = "DELETE";
	/** 登録 */
	private static final String FORWARD_REGIST = "REGIST";
	/** 戻る */
	private static final String FORWARD_RETURN = "RETURNPAGE";
	/** 戻る(削除処理完了時) */
	private static final String FORWARD_RETURN_DEL = "DELRETURN";
	/** DTOキー名 */
	private static final String DTO_ABCGM11 = "DTO_ABCGM11";
	/**
	 * 画面項目ID
	 */
	/** お客様グループ名 */
	private static final String ITEM_ID_CST_GRP_NAME = "customerGroupNm";


	/** メンバ変数 */
	/** アクションフォーム */
	private Abcgm11Action m_Abcgm11Form = null;
	/** 表示用画面Bean */
	private Abcgm11DispBean m_Abcgm11DispBean = null;
	/** 画面用DTO */
	private Abcgm11Dto m_Abcgm11Dto = null;


	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Abcgm11Business(
			Abcgm11Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Abcgm11Business.class.getName();
		m_Abcgm11Form = form;
		m_Abcgm11DispBean = new Abcgm11DispBean();
		setErrString(gid, m_Abcgm11Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Abcgm11DispBean);

			/* 内部記憶情報の生成 */
			m_Abcgm11Dto = (Abcgm11Dto) getSpecifiedDTO(m_Gid, DTO_ABCGM11);
			if (m_Abcgm11Dto == null || FORWARD_DISP.equals(m_Event)) {
				deleteSpecifiedDTO(m_Gid);
				m_Abcgm11Dto = new Abcgm11Dto();
				putSpecifiedDTO(m_Gid, DTO_ABCGM11, m_Abcgm11Dto);
			}

			// 遷移元情報取得
			AbcgmItemDispDto transDto = (AbcgmItemDispDto) getSpecifiedDTO(ABCGM_INFO_KEY);
			if (transDto != null) {
				// 遷移元から顧客グループコードを取得
				m_Abcgm11Form.setCstGrpCd(transDto.getCstGrpCd());
				// DTO削除
				delSpecifiedDTO(ABCGM_INFO_KEY);
			}

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Abcgm11Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_ADD.equals(m_Event)) {
				// 顧客追加ボタン押下の場合
				forwardStr = add();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				// 登録ボタン押下の場合
				forwardStr = regist();
			} else if (FORWARD_DELETE.equals(m_Event)) {
				// 削除ボタン押下の場合
				forwardStr = delete();
			} else if (FORWARD_RETURN.equals(m_Event)) {
				// 戻るボタン押下処理の場合
				forwardStr = back();
			} else {
				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Abcgm11DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException, Exception {

		// 遷移元から顧客グループコードを取得していた場合
		String cstGrpCd = m_Abcgm11Form.getCstGrpCd();
		if(!AmallUtilities.isEmpty(cstGrpCd)) {
			// 検索処理を実施
			search(cstGrpCd);

		} else {
			// 初期化
			List<AbcgmCstGrpDto> list = new ArrayList<>();
			// 1行目を追加
			AbcgmCstGrpDto dto = new AbcgmCstGrpDto();
			list.add(dto);
			m_Abcgm11Form.setItemDispList(list);
		}


		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 検索処理
	 * <p>
	 * 顧客グループコードを元に検索処理を実行する
	 * </p>
	 * @param  cstGrpCd 顧客グループコード
	 * @return ActionForward名称
	 ************************************************************************************/
	private void search(String cstGrpCd) throws AmallException, Exception {

		List<AbcgmCstGrpDto> dataList = getCstGrpMst(cstGrpCd, m_Abcgm11DispBean.getServiceDate());
		if (dataList ==  null ||  dataList.size() == 0) {
			// データが存在しない場合
			setMessageInfo(m_Abcgm11DispBean, AmallMessageConst.MSG_ERR_SELECT_CON_NO_DATA,
					getItemDispName(ITEM_ID_CST_GRP_NAME, m_Abcgm11DispBean));
			return;
		}

		// 1件目のデータをヘッダに設定
		// 顧客グループコード
		m_Abcgm11Form.setCstGrpCd(dataList.get(0).getCstGrpCd());
		// 顧客グループ名
		m_Abcgm11Form.setCstGrpNm(dataList.get(0).getCstGrpNm());
		// 更新日時
		m_Abcgm11Form.setUpdateDateDisp(dataList.get(0).getUpDate());
		// 更新者
		m_Abcgm11Form.setUpdateUserDisp(dataList.get(0).getUpDateUser());

		// 表示リスト
		m_Abcgm11Form.setItemDispList(dataList);

		return;
	}
	/*************************************************************************************
	 * 顧客追加ボタン押下処理実行
	 * <p>
	 * 顧客追加ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String add() throws AmallException {

		// リストを取得
		List<AbcgmCstGrpDto> list = m_Abcgm11Form.getItemDispList();
		if (list == null) {
			// nullの場合生成
			list = new ArrayList<>();
		}
		// 空行を追加
		AbcgmCstGrpDto dto = new AbcgmCstGrpDto();
		list.add(dto);
		m_Abcgm11Form.setItemDispList(list);


		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 削除ボタン押下処理実行
	 * <p>
	 * 削除ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String delete() throws AmallException, Exception  {

		// 排他チェックを行う
		if(!exclutionCheck()) {
			return FORWARD_DISP;
		}

		// 顧客グループコードを取得
		String cstGrpCd = m_Abcgm11Form.getCstGrpCd();
		// 削除処理を呼ぶ
		if(!deleteCstGrpMst(cstGrpCd, m_Abcgm11DispBean.getServiceDate())) {
			return FORWARD_DISP;
		}
		// コミット処理
		m_DbAccess.commit();
		// 前のページに戻る(削除正常：メッセージは遷移先で設定)
		return FORWARD_RETURN_DEL;
	}

	/*************************************************************************************
	 * 登録処理
	 * <p>
	 * 登録処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException, Exception {

		// 入力チェックを行う
		if(!inputCheck()) {
			return FORWARD_DISP;
		}

		// 顧客グループコードを取得
		String cstGrpCd = m_Abcgm11Form.getCstGrpCd();

		// 顧客グループ名を取得
		String cstGrpNm = m_Abcgm11Form.getCstGrpNm();

		// 登録対象を取得
		List<AbcgmCstGrpDto> list = m_Abcgm11Form.getItemDispList();

		if(!AmallUtilities.isEmpty(cstGrpCd)) {
			// 更新
			// 排他チェックを行う
			if(!exclutionCheck()) {
				return FORWARD_DISP;
			}
			// 削除処理を呼ぶ
			if(!deleteCstGrpMst(cstGrpCd, m_Abcgm11DispBean.getServiceDate())) {
				return FORWARD_DISP;
			}


			for (AbcgmCstGrpDto cstGrpDto : list) {
				// 登録処理を呼ぶ
				if(!insertCstGrpMst(cstGrpCd, cstGrpDto.getCstCd(), cstGrpNm)) {
					return FORWARD_DISP;
				}
			}
		} else {
			// 新規
			// お客様グループコード自動採番処理
			Long nextVal = AmallUtilities.getSequenceNextval("S_CST_GRP_CD", m_DbAccess);

			//nullチェック
			if(nextVal == null || nextVal.longValue() == 0) {
				setMessageInfo(m_Abcgm11DispBean, AmallMessageConst.MSG_ERR_DB_ACCESS);
				return FORWARD_DISP;
			}

			//0埋めされた顧客グループコードを取得
			cstGrpCd = String.format(AmallConst.CST_GRP_CD_FORMAT, nextVal);

			for (AbcgmCstGrpDto cstGrpDto : list) {
				// 登録処理を呼ぶ
				if(!insertCstGrpMst(cstGrpCd, cstGrpDto.getCstCd(), cstGrpNm)) {
					return FORWARD_DISP;
				}
			}
		}
		// 正常終了メッセージ
		// コミット処理
		m_DbAccess.commit();
		// 正常完了処理メッセージ
		setMessageInfo(m_Abcgm11DispBean, AmallMessageConst.MSG_INF_NML_REGIST_END);

		// 再検索処理
		search(cstGrpCd);

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 戻る処理
	 * <p>
	 * 登録処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String back() throws AmallException {

		// 内部保存値の削除
		deleteSpecifiedDTO(m_Gid);
		return FORWARD_RETURN;
	}
	/*************************************************************************************
	 * 入力値チェック
	 * <p>
	 * 入力値チェックを実施する
	 * </p>
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheck() throws  AmallException {
		// 返却フラグ
		boolean ret = true;

		// 顧客グループ名
		String cstGrpNm = m_Abcgm11Form.getCstGrpNm();

		// 入力値チェック(顧客グループ名)
		if (!AmallUtilities.isEmpty(cstGrpNm)) {
			// 入力値が存在する場合
			if (AmallUtilities.getLengthAsHalf(cstGrpNm) > (InputNum.CST_GRP_NM * 2)) {
				// 60文字以上が設定されている
				setMessageInfo(m_Abcgm11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_STR_WTN,
						getItemDispName(ITEM_ID_CST_GRP_NAME, m_Abcgm11DispBean), String.valueOf(InputNum.CST_GRP_NM));
				setError(m_Abcgm11DispBean, ITEM_ID_CST_GRP_NAME);

				ret = false;
			}
		} else {
			// 入力がない場合
			setMessageInfo(m_Abcgm11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
					getItemDispName(ITEM_ID_CST_GRP_NAME, m_Abcgm11DispBean));
			setError(m_Abcgm11DispBean, ITEM_ID_CST_GRP_NAME);
			ret = false;
		}

		// リストを取得
		List<AbcgmCstGrpDto> list = m_Abcgm11Form.getItemDispList();
		// 整理後リストを生成
		List<AbcgmCstGrpDto> afterList = new ArrayList<>();;
		// 設定数を取得
		for (AbcgmCstGrpDto cstGrpDto : list) {
			if (!AmallUtilities.isEmpty(cstGrpDto.getCstCd())) {
				// 顧客コードが存在する場合
				afterList.add(cstGrpDto);
			}
		}

		// リスト件数チェック
		if(afterList.size() == 0) {
			// 登録内容がない場合
			setMessageInfo(m_Abcgm11DispBean, AmallMessageConst.MSG_ERR_REGIST_NOTHING_DATA);
			ret = false;
		} else {
			// 重複チェック
			for (AbcgmCstGrpDto orgDto : afterList) {

				int count = 0;
				for (AbcgmCstGrpDto compareDto : afterList) {

					// 同一顧客コードの数をカウント
					if (compareDto.getCstCd().equals(orgDto.getCstCd())) {
						count++;
					}
				}
				// 2件以上ある場合
				if(count >= 2) {
					setMessageInfo(m_Abcgm11DispBean, AmallMessageConst.MSG_ERR_REGIST_DUPLICATION_DATA);
					ret = false;
					break;
				}
			}
		}

		// 正常の場合 整理後リストを設定
		if(ret) {
			m_Abcgm11Form.setItemDispList(afterList);
		}

		return ret;
	}
	/*************************************************************************************
	 * 排他チェック
	 * <p>
	 * 排他チェックを実施する
	 * </p>
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean exclutionCheck() throws  AmallException , Exception {
		// 返却フラグ
		boolean ret = true;


		// 内部保存値からリストを取得する
		List<AbcgmCstGrpDto> list = m_Abcgm11Dto.getItemSavedList();

		for (AbcgmCstGrpDto cstGrpDto : list) {
			if (!existsCstGrpMst(cstGrpDto.getCstGrpCd(), cstGrpDto.getCstCd(), cstGrpDto.getCreateDate(), m_Abcgm11DispBean.getServiceDate())) {
				ret = false;
				break;
			}
		}

		return ret;
	}
	/*************************************************************************************
	 * 顧客グループマスタ(DB)取得
	 * <p>
	 * 顧客グループマスタ(DB)からデータを取得する
	 * 遷移元からの検索条件と合致する一覧を取得する、取得されるデータは内部保存値にも保存する
	 * </p>
	 * @param  cstGrpCd 顧客グループコード
	 * @param  systemDt 業務日付
	 * @return List<AbcgmCstGrpDto> データリスト
	 ************************************************************************************/
	private List<AbcgmCstGrpDto> getCstGrpMst(String cstGrpCd, String systemDt) throws AmallException, Exception {

		String methodName = "getCstGrpMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<AbcgmCstGrpDto> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	ncgm.CST_GRP_CD");
			sql.append(",	ncgm.CST_GRP_NM");
			sql.append(",	ncgm.CST_CD");
			sql.append(",   ncm.CST_NM");
			sql.append(",   TO_CHAR(ncgm.UPD_DT,'YYYY/MM/DD HH:MI:SS') AS UPD_DT");
			sql.append(",   ncgm.UPD_USER_ID || ' ' || nuem.USER_NM AS UPD_USER");
			sql.append(",	ncgm.CR_DT");
			sql.append("  FROM");
			sql.append("	N_CST_GRP_M ncgm");
			sql.append("	INNER JOIN");
			sql.append("		N_CST_M ncm");
			sql.append("	ON");
			sql.append("		ncgm.CST_CD = ncm.CST_CD");
			sql.append("		AND ncm.DEL_FLG = ?");
			sql.append("	LEFT JOIN");
			sql.append("		N_USER_EMP_M nuem");
			sql.append("	ON");
			sql.append("		ncgm.UPD_USER_ID = nuem.USER_ID");
			sql.append("		AND nuem.DEL_FLG = ?");
			sql.append(" WHERE");
			sql.append("	ncgm.CST_GRP_CD = ?");
			sql.append("	AND ncgm.DEL_FLG = ?");
			sql.append("	AND ? BETWEEN ncgm.EFST_DY AND ncgm.EFED_DY");
			sql.append(" ORDER BY");
			sql.append("	ncgm.CST_GRP_CD");
			sql.append(",	ncgm.CST_CD");

			m_DbAccess.createPreparedStatement(sql.toString());

			// 条件設定
			int setCnt = 0;
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 顧客グループコード
			m_DbAccess.setString(++setCnt, cstGrpCd);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, systemDt);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				// DTOを生成
				AbcgmCstGrpDto dto = new AbcgmCstGrpDto();
				// 顧客グループコード
				dto.setCstGrpCd(m_DbAccess.getString(rs, "CST_GRP_CD"));
				// 顧客グループ名
				dto.setCstGrpNm(m_DbAccess.getString(rs, "CST_GRP_NM"));
				// 顧客コード
				dto.setCstCd(m_DbAccess.getString(rs, "CST_CD"));
				// 顧客名
				dto.setCstNm(m_DbAccess.getString(rs, "CST_NM"));
				// 更新日時
				dto.setUpDate(m_DbAccess.getString(rs, "UPD_DT"));
				// 更新者
				dto.setUpDateUser(m_DbAccess.getString(rs, "UPD_USER"));
				// 登録日時
				dto.setCreateDate(rs.getDate("CR_DT"));

				// リストに追加
				retList.add(dto);
			}

			// 内部保存情報に保存
			m_Abcgm11Dto.setItemSavedList(retList);

			return retList;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_CST_GRP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 顧客グループマスタ(DB)存在チェック
	 * <p>
	 * 顧客グループマスタ(DB)からデータの存在を確認する
	 * 登録日時を比較するため排他チェックの代替とする
	 * </p>
	 * @param  cstGrpCd 顧客グループコード
	 * @param  cstCd 顧客コード
	 * @param  crDt 登録日時
	 * @param  systemDt システム日付
	 * @return boolean true : 存在する false : 存在しない
	 ************************************************************************************/
	private boolean existsCstGrpMst(String cstGrpCd, String cstCd, Date crDt, String systemDt) throws AmallException, Exception {

		String methodName = "existsCstGrpMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	COUNT(*)");
			sql.append("  FROM");
			sql.append("	N_CST_GRP_M");
			sql.append(" WHERE");
			sql.append("	CST_GRP_CD = ?");
			sql.append("	AND CST_CD = ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND ? BETWEEN EFST_DY AND EFED_DY");
			sql.append("	AND CR_DT = ?");

			m_DbAccess.createPreparedStatement(sql.toString());

			// 条件設定
			int setCnt = 0;
			// 顧客グループコード
			m_DbAccess.setString(++setCnt, cstGrpCd);
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, systemDt);
			// 登録日時
			m_DbAccess.setDate(++setCnt, crDt);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			int count = 0;
			while (rs.next()) {
				count = rs.getInt(1);
			}

			// 結果を確認
			if (count > 0) {
				return true;
			} else {
				// 楽観排他

				// エラー情報を設定
				setMessageInfo(m_Abcgm11DispBean, AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST);

				// アクセスログ情報の作成
				AmallExceptionInfo amei = new AmallExceptionInfo();
				amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_ACS_OPT_ERROR, "N_CST_GRP_M"));
				setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

				return false;
			}
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_CST_GRP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 顧客グループマスタ(DB)登録
	 * <p>
	 * 顧客グループマスタ(DB)にレコードを登録する
	 * </p>
	 * @param cstGrpCd 顧客グループコード
	 * @param cstCd 顧客コード
	 * @param cstGrpNm 顧客グループ名
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	public boolean insertCstGrpMst(String cstGrpCd, String cstCd, String cstGrpNm) throws AmallException {

		String methodName = "insertCstGrpMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// SQL生成
			sql.append("INSERT INTO");
			sql.append("	N_CST_GRP_M (");
			sql.append("		CST_GRP_CD");
			sql.append(",		CST_CD");
			sql.append(",		EFST_DY");
			sql.append(",		EFED_DY");
			sql.append(",		CST_GRP_NM");
			sql.append(",		EXCLUSIVE_KEY");
			sql.append(",		DEL_FLG");
			sql.append(",		CR_PGM_ID");
			sql.append(",		CR_USER_ID");
			sql.append(",		CR_DT");
			sql.append(",		UPD_PGM_ID");
			sql.append(",		UPD_USER_ID");
			sql.append(",		UPD_DT");
			sql.append("	) VALUES (");
			sql.append("		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			// 共通部分
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append("	)");

			// 登録値のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;

			// 顧客グループコード
			m_DbAccess.setString(++setCnt, cstGrpCd);
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);
			// 有効開始日
			m_DbAccess.setString(++setCnt, AmallConst.EFST_DY_DEFAULT);
			// 有効終了日
			m_DbAccess.setString(++setCnt, AmallConst.EFED_DY_DEFAULT);
			// 顧客グループ名
			m_DbAccess.setString(++setCnt, cstGrpNm);


			// 排他キー
			m_DbAccess.setLong(++setCnt, 0);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 登録プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 登録ユーザーID
			m_DbAccess.setString(++setCnt, m_Abcgm11DispBean.getH_loginId());
			// 更新プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 更新ユーザーID
			m_DbAccess.setString(++setCnt, m_Abcgm11DispBean.getH_loginId());

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 更新結果判定
			if (ret <= 0) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_CST_GRP_M");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_CST_GRP_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}
	/*************************************************************************************
	 * 顧客グループマスタ(DB)削除
	 * <p>
	 * 顧客グループマスタ(DB)を削除する
	 * </p>
	 * @param cstGrpCd 顧客グループコード
	 * @param  systemDt システム日付
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	public boolean deleteCstGrpMst(String cstGrpCd, String systemDt) throws AmallException {

		String methodName = "deleteCstGrpeMst()";
		StringBuffer sql = new StringBuffer();

		try {
			// SQL生成
			sql.append("DELETE FROM");
			sql.append("	N_CST_GRP_M");
			// 条件指定
			sql.append(" WHERE");
			sql.append("	CST_GRP_CD = ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND ? BETWEEN EFST_DY AND EFED_DY");


			// パラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;

			// WHERE句のパラメタ設定
			// 顧客グループコード
			m_DbAccess.setString(++setCnt, cstGrpCd);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// システム日付
			m_DbAccess.setString(++setCnt, systemDt);

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 排他チェック
			if(ret == 0) {
				// 更新対象無し(楽観排他)
				m_DbAccess.rollback();

				// エラー情報を設定
				setMessageInfo(m_Abcgm11DispBean, AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST);

				// アクセスログ情報の作成
				AmallExceptionInfo amei = new AmallExceptionInfo();
				amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_ACS_OPT_ERROR, "N_CST_GRP_M"));
				setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

				return false;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_CST_GRP_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}
}