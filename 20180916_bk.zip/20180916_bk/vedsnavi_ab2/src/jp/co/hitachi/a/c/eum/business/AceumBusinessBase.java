/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AcechBusinessBase.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.business;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.eum.dto.AceumItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.SystemType;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.cls.AmclsBusinessPcBase;
import jp.co.hitachi.a.m.dto.AmdtoDropDownList;

/*****************************************************************************************
 * AcechBusinessBaseクラス<br>
 *****************************************************************************************/
public abstract class AceumBusinessBase extends AmclsBusinessPcBase {


	/** メンバ定数 */
	/** 遷移先画面キー */
	protected static final String ACEUM_INFO_KEY = "AceumInfo";

	/** メンバ変数 */
	/** 遷移画面DTO */
	protected AceumItemDispDto aceumInfoDto;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  mapping
	 * @param  form
	 * @param  request
	 * @param  response
	 * @param  context
	 * @param  gid
	 * @param  event
	 * @return 無し
	 ************************************************************************************/
	public AceumBusinessBase(HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);
	}
	/*************************************************************************************
	 * 権限ロール一覧取得処理
	 * <p>
	 * 権限ロールの一覧を取得する
	 * プルダウンリストとして扱えるようにAmdtoDropDownList形式で返却
	 * システム種別に応じて取得範囲を指定する
	 * </p>
	 * @param  systemKind システム種別
	 * @return AmdtoDropDownListのリスト
	 ************************************************************************************/
	protected List<AmdtoDropDownList> getAuthRoleList(int systemKind) throws AmallException, Exception {


		String methodName = "getAuthRoleList()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<AmdtoDropDownList> retList = new ArrayList<>();

		// 空の選択を設定
		AmdtoDropDownList empty  = new AmdtoDropDownList();
		retList.add(empty);

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	ROLE_GRP_CD");
			sql.append(",	ROLE_GRP_NM");
			sql.append("  FROM");
			sql.append("  	N_ROLE_GRP_M");
			sql.append(" WHERE");
			sql.append("	DEL_FLG =  ?");
			if(SystemType.CUSTOMER == systemKind) {
				// 顧客OLの場合
				sql.append("	AND ROLE_GRP_TYPE =  ?");
			}
			sql.append(" ORDER BY");
			sql.append("	ROLE_GRP_CD");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			if(SystemType.CUSTOMER == systemKind) {
				// 顧客OLの場合
				m_DbAccess.setString(++setCnt, String.valueOf(SystemType.CUSTOMER));
			}

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				AmdtoDropDownList dto = new AmdtoDropDownList();
				// コード値
				dto.setId(m_DbAccess.getString(rs, "ROLE_GRP_CD"));
				// 名称
				dto.setName(m_DbAccess.getString(rs, "ROLE_GRP_NM"));
				// リストに追加
				retList.add(dto);
			}
			return retList;
		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * ユーザーマスタ(DB)テーブル判定
	 * <p>
	 * ユーザーマスタ(DB)のどのテーブルに存在するかチェックする
	 *
	 * </p>
	 * @param userId ユーザーID
	 * @param systemKind システム種別
	 * @return boolean true: 存在する false:存在しない
	 ************************************************************************************/
	protected boolean chkSystemUserMst(String userId, int systemKind)  throws AmallException, Exception {

		ResultSet rs = null;
		String methodName = "chkSystemUserMst()";
		StringBuffer sql = new StringBuffer();

		try {
			// システム種別チェック
			sql.delete(0, sql.length());
			sql.append("SELECT");
			sql.append("	COUNT(*)");
			sql.append(" FROM");

			// システム種別によってテーブルを切り替える
			if (systemKind == SystemType.BUSINESS) {
				// 業務支援の場合
				sql.append("	N_USER_EMP_M");
			} else {
				sql.append("	N_USER_CST_M");
			}
			sql.append(" WHERE");
			sql.append("	DEL_FLG = ?");
			sql.append("	AND USER_ID = ?");
			// パラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());

			// 条件設定
			int setCnt = 0;
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			//
			m_DbAccess.setString(++setCnt, userId);
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 取得結果判定
			int lineMaxCount = 0;
			if (rs.next()) {
				// データ存在
				lineMaxCount = rs.getInt(1);
			} else {
				lineMaxCount = 0;
			}
			if (lineMaxCount <= 0) {
				return false;
			}
			return true;
		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}


	}
	/*************************************************************************************
	 * ユーザーマスタ(DB)削除
	 * <p>
	 * ユーザーマスタ(DBを削除する
	 *
	 * </p>
	 * @param userId ユーザーID
	 * @param exKey 排他キー
	 * @param  systemKind システム種別
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	protected boolean deleteUserMst(String userId, Long exKey, int systemKind) throws AmallException, Exception {

		String methodName = "deleteUserMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// == 削除処理 ==
			// SQL生成
			sql.delete(0, sql.length());
			sql.append("DELETE FROM");
			// システム種別によってテーブルを切り替える
			if (systemKind == SystemType.BUSINESS) {
				// 業務支援の場合
				sql.append("	N_USER_EMP_M");
			} else {
				sql.append("	N_USER_CST_M");
			}// 条件指定
			sql.append(" WHERE");
			sql.append("	USER_ID = ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND EXCLUSIVE_KEY = ?");


			// パラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;
			// WHERE句のパラメタ設定
			// 画面個別権限ID
			m_DbAccess.setString(++setCnt, userId);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 排他キー
			m_DbAccess.setLong(++setCnt, exKey);

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 排他チェック
			if(ret == 0) {
				// 更新対象無し(楽観排他)
				m_DbAccess.rollback();

				return false;
			}

			// 更新結果判定
			if (ret != 1) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_USER_XXX_M");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_USER_XXX_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		}
	}
}
