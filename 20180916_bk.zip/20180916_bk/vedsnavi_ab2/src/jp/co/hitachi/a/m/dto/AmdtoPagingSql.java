/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoPagingSql.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * AmdtoPagingSql Dtoクラス<br>
 *****************************************************************************************/
public class AmdtoPagingSql extends AmclsDtoBase {

	/** メンバ変数 */
	// SQL SELECT 文
	String sqlSelect = null;
	// SQL FROM WHERE  文
	String sqlConditinon = null;
	// SQL ORDER 文
	String sqlOrder = null;
	// SQL PARAM 文
	String[] sqlParam = null;
	// SQL 表示件数 文
	int pageDispCnt = 0;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmdtoPagingSql() {
		clear();
	}

	/*************************************************************************************
	 * クリア
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		sqlSelect = null;
		sqlConditinon = null;
		sqlOrder = null;
		sqlParam = null;
		pageDispCnt = 0;
	}

	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getSqlSelect() {
		return sqlSelect;
	}

	public void setSqlSelect(String sqlSelect) {
		this.sqlSelect = sqlSelect;
	}

	public String getSqlConditinon() {
		return sqlConditinon;
	}

	public void setSqlConditinon(String sqlConditinon) {
		this.sqlConditinon = sqlConditinon;
	}

	public String getSqlOrder() {
		return sqlOrder;
	}

	public void setSqlOrder(String sqlOrder) {
		this.sqlOrder = sqlOrder;
	}

	public String[] getSqlParam() {
		return sqlParam;
	}

	public void setSqlParam(String[] sqlParam) {
		this.sqlParam = sqlParam;
	}

	public int getPageDispCnt() {
		return pageDispCnt;
	}

	public void setPageDispCnt(int pageDispCnt) {
		this.pageDispCnt = pageDispCnt;
	}
}
