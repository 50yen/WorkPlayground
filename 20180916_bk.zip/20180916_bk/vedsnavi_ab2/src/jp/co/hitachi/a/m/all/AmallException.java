/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallException.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.hitachi.a.m.all.AmallConst.LogType;

/*****************************************************************************************
 * 例外管理クラス<br>
 *****************************************************************************************/
public final class AmallException extends Exception {

	/** メンバ変数 */
	/** セッションID */
	private String m_SessionID = null;
	/** 発生時刻 */
	private Date m_GTime = null;
	/** ログインID */
	private String m_LoginID = null;
	/** 区分 */
	private String m_Kind = null;
	/** 業務情報 */
	private String m_BusinessName = null;
	/** ログ情報ヘッダ */
	private String m_LogInfoHeader = null;
	/** ログ情報 */
	private List<AmallExceptionInfo> m_AmallExceptionInfoList = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmallException() {
		m_GTime = null;
		m_LoginID = "";
		m_Kind = "";
		m_BusinessName = "";
		m_LogInfoHeader = "";
		this.m_AmallExceptionInfoList = new ArrayList<AmallExceptionInfo>();
	}

	/*************************************************************************************
	 * 例外情報クリア
	 * <p>
	 * 例外情報のクリア処理を行う
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		m_GTime = null;
		m_LoginID = "";
		m_Kind = "";
		m_BusinessName = "";
		m_LogInfoHeader = "";
		for (int i = 0; i < this.m_AmallExceptionInfoList.size(); i++) {
			AmallExceptionInfo e = (AmallExceptionInfo) this.m_AmallExceptionInfoList.get(i);
			e.clear();
		}
		this.m_AmallExceptionInfoList.clear();
	}

	/*************************************************************************************
	 * 例外情報追加
	 * <p>
	 * 例外情報を追加する
	 * </p>
	 * @param className  例外が発生したクラス名称
	 * @param methodName 例外が発生したメソッド名称
	 * @param eMassage   例外メッセージ内容
	 * @return 無し
	 ************************************************************************************/
	public void addExceptionMsg(String className, String methodName, String eMassage) {
		if (isSameClassMethod(className, methodName)) {
			return;
		}
		AmallExceptionInfo e = new AmallExceptionInfo();
		e.setException(AmallException.class.getName());
		e.setClassName(className);
		e.setMethodName(methodName);
		e.setMessageID("");
		e.setMessage(eMassage);
		e.setMassageKind(LogType.ERROR);
		this.m_AmallExceptionInfoList.add(e);
		return;
	}

	/*************************************************************************************
	 * 例外情報追加
	 * <p>
	 * 例外情報を追加する
	 * </p>
	 * @param className  例外が発生したクラス名称
	 * @param methodName 例外が発生したメソッド名称
	 * @param massageID  eMassage.csvに対応するメッセージＩＤ
	 * @return 無し
	 ************************************************************************************/
	public void addException(String className, String methodName, String massageID) {
		if (isSameClassMethod(className, methodName)) {
			return;
		}
		AmallExceptionInfo e = new AmallExceptionInfo();
		e.setException(AmallException.class.getName());
		e.setClassName(className);
		e.setMethodName(methodName);
		try {
			String eMassage = AmallMessage.getMessage(massageID);
			e.setMessageID(massageID);
			e.setMessage(eMassage);
			e.setMassageKind(AmallMessage.getMessageCategory(massageID));
		} catch (Exception ee) {
			e.setMessageID(massageID);
			e.setMessage("");
			e.setMassageKind(LogType.ERROR);
		}
		this.m_AmallExceptionInfoList.add(e);
		return;
	}

	/*************************************************************************************
	 * 例外情報追加
	 * <p>
	 * 例外情報を追加する
	 * </p>
	 * @param className  例外が発生したクラス名称
	 * @param methodName 例外が発生したメソッド名称
	 * @param massageID  メッセージＩＤ
	 * @param var        可変引数
	 * @return 無し
	 ************************************************************************************/
	public void addException(String className,
			String methodName,
			String massageID,
			String ... var) {
		if (isSameClassMethod(className, methodName)) {
			return;
		}
		AmallExceptionInfo e = new AmallExceptionInfo();
		e.setException(AmallException.class.getName());
		e.setClassName(className);
		e.setMethodName(methodName);
		try {
			String eMassage = AmallMessage.getMessage(massageID, var);
			e.setMessageID(massageID);
			e.setMessage(eMassage);
			e.setMassageKind(AmallMessage.getMessageCategory(massageID));
		} catch (Exception ee) {
			e.setMessageID(massageID);
			e.setMessage("");
			e.setMassageKind(LogType.ERROR);
		}
		this.m_AmallExceptionInfoList.add(e);
		return;
	}

	/*************************************************************************************
	 * 例外情報追加
	 * <p>
	 * 例外情報を追加する
	 * </p>
	 * @param className   例外が発生したクラス名称
	 * @param methodName  例外が発生したメソッド名称
	 * @param massageKind 例外種別
	 * @param ee          Exception
	 * @return 無し
	 ************************************************************************************/
	public void addException(String className, String methodName, String massageKind, Exception ee) {
		AmallExceptionInfo e = new AmallExceptionInfo();
		e.setException(ee.getClass().getName());
		e.setClassName(className);
		e.setMethodName(methodName);
		e.setMessageID("");
		e.setMessage(ee.getMessage());
		e.setMassageKind(massageKind);
		this.m_AmallExceptionInfoList.add(e);
	}

	/*************************************************************************************
	 * 例外情報追加
	 * <p>
	 * 例外情報を追加する
	 * </p>
	 * @param className   例外が発生したクラス名称
	 * @param methodName  例外が発生したメソッド名称
	 * @param ee          Exception
	 * @return 無し
	 ************************************************************************************/
	public void addException(String className, String methodName, Exception ee) {
		AmallExceptionInfo e = new AmallExceptionInfo();
		e.setException(ee.getClass().getName());
		e.setClassName(className);
		e.setMethodName(methodName);
		e.setMessageID("");
		e.setMessage(ee.getMessage());
		e.setMassageKind(LogType.ERROR);
		this.m_AmallExceptionInfoList.add(e);
	}

	/*************************************************************************************
	 * 例外情報取得
	 * <p>
	 * 例外リストから指定した位置の例外情報を取得する
	 * </p>
	 * @param pos 指定位置
	 * @return 例外情報
	 ************************************************************************************/
	public AmallExceptionInfo getException(int pos) {
		if (this.m_AmallExceptionInfoList == null && pos < 0) {
			return null;
		}
		if (this.m_AmallExceptionInfoList.size() <= 0) {
			return null;
		}
		if (this.m_AmallExceptionInfoList.size() >= pos && m_AmallExceptionInfoList.size() <= pos) {
		} else {
			return null;
		}
		return (AmallExceptionInfo) m_AmallExceptionInfoList.get(pos);

	}

	/*************************************************************************************
	 * 例外メッセージ種別判定
	 * <p>
	 * 例外メッセージ種別が警告か否かを判定する
	 * </p>
	 * @param  e 例外情報
	 * @return YES/NO
	 *          true  : YES
	 *          false : NO
	 ************************************************************************************/
	public boolean isWarning(AmallExceptionInfo e) {
		if (e.getMassageKind().equals(LogType.WARNING)) {
			return true;
		} else {
			return false;
		}
	}

	/*************************************************************************************
	 * 例外メッセージ種別判定
	 * <p>
	 * 例外メッセージ種別がエラーか否かを判定する
	 * </p>
	 * @param  e 例外情報
	 * @return YES/NO
	 *          true  : YES
	 *          false : NO
	 ************************************************************************************/
	public boolean isError(AmallExceptionInfo e) {
		if (e.getMassageKind().equals(LogType.ERROR)) {
			return true;
		} else {
			return false;
		}
	}

	/*************************************************************************************
	 * 同クラス、メソッド存在判定
	 * <p>
	 * 同クラス、メソッドが、エラー情報リストに存在するか否か
	 * </p>
	 * @param  classNm  クラス名
	 * @param  methodNm メソッド名
	 * @return YES/NO
	 *          true  : 有
	 *          false : 無
	 ************************************************************************************/
	private boolean isSameClassMethod(String classNm, String methodNm) {
		for (int i = 0; i < this.m_AmallExceptionInfoList.size(); i++) {
			AmallExceptionInfo e = (AmallExceptionInfo) this.m_AmallExceptionInfoList.get(i);
			if (classNm.equals(e.getClassName()) && methodNm.equals(e.getMethodName())) {
				return true;
			}
		}
		return false;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * m_BusinessNameのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return 業務名称
	 ************************************************************************************/
	public String getM_BusinessName() {
		return m_BusinessName;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * m_BusinessNameのSetterメソッド
	 * </p>
	 * @param  業務名称
	 * @return 無し
	 ************************************************************************************/
	public void setM_BusinessName(String businessName) {
		m_BusinessName = businessName;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * m_GTimeのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return 発生日時
	 ************************************************************************************/
	public Date getM_GTime() {
		return m_GTime;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * m_GTimeのSetterメソッド
	 * </p>
	 * @param  発生日時
	 * @return 無し
	 ************************************************************************************/
	public void setM_GTime(Date time) {
		m_GTime = time;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * m_KindのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return 区分
	 ************************************************************************************/
	public String getM_Kind() {
		return m_Kind;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * m_KindのSetterメソッド
	 * </p>
	 * @param  区分
	 * @return 無し
	 ************************************************************************************/
	public void setM_Kind(String kind) {
		m_Kind = kind;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * m_LogInfoHeaderのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return ログ情報ヘッダ
	 ************************************************************************************/
	public String getM_LogInfoHeader() {
		return m_LogInfoHeader;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * m_LogInfoHeaderのSetterメソッド
	 * </p>
	 * @param  ログ情報ヘッダ
	 * @return 無し
	 ************************************************************************************/
	public void setM_LogInfoHeader(String logInfoHeader) {
		m_LogInfoHeader = logInfoHeader;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * m_LoginIDのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return ログインID
	 ************************************************************************************/
	public String getM_LoginID() {
		return m_LoginID;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * m_LoginIDのSetterメソッド
	 * </p>
	 * @param  ログインID
	 * @return 無し
	 ************************************************************************************/
	public void setM_LoginID(String loginID) {
		m_LoginID = loginID;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * m_SessionIDのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return セッションID
	 ************************************************************************************/
	public String getM_SessionID() {
		return m_SessionID;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * m_SessionIDのSetterメソッド
	 * </p>
	 * @param  セッションID
	 * @return 無し
	 ************************************************************************************/
	public void setM_SessionID(String sessionID) {
		m_SessionID = sessionID;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * m_AmallExceptionInfoListのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return m_AmallExceptionInfoList
	 ************************************************************************************/
	public List<AmallExceptionInfo> getM_AmallExceptionInfoList() {
		return m_AmallExceptionInfoList;
	}
}