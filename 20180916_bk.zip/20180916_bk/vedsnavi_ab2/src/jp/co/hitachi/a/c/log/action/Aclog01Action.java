/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aclog01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.log.action;

import jp.co.hitachi.a.c.log.bean.Aclog01DispBean;
import jp.co.hitachi.a.c.log.business.Aclog01Business;
import jp.co.hitachi.a.m.all.AmallConst.SystemName;
import jp.co.hitachi.a.m.all.AmallConst.SystemType;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallSystemErrLog;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Aclog01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Aclog01DispBean aclog01DispBean;
	/** ログインID */
	private String loginID = null;
	/** パスワード */
	private String password = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		String forwardName = FORWARD_GLOBALERROR;
		try {
			// セッション再作成
			reCreateSession(request);
			// セッション(DTO管理データ)作成
			createSession(request);
			// システム種別設定
			setM_systemKind(request, SystemType.CUSTOMER); // 顧客OLをセット
			// トークン生成
			createToken(request);
			// クッキー生成
			createCookie(request, response);

			// ビジネス層の実行処理呼び出し処理
			forwardName = callexecute();

			// 実行結果をリクエストに設定
			setAclog01DispBean((Aclog01DispBean) request.getAttribute("Aclog01DispBean"));

			// システム名を設定
			aclog01DispBean.setH_systemName(SystemName.CUSTOMER);

		} catch (AmallException e) {
			AmallSystemErrLog.createSystemErrLog(getM_systemKind(request), e, request);
		}

		return forwardName;
	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Aclog01Business dao = new Aclog01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行(ログイン画面のみ共通情報の取得不要)
		return dao.execute();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////


	public Aclog01DispBean getAclog01DispBean() {
		return aclog01DispBean;
	}

	public void setAclog01DispBean(Aclog01DispBean aclog01DispBean) {
		this.aclog01DispBean = aclog01DispBean;
	}

	public String getLoginID() {
		return loginID;
	}

	public void setLoginID(String loginID) {
		this.loginID = AmallUtilities.convEmpty(loginID);;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = AmallUtilities.convEmpty(password);;
	}


}
