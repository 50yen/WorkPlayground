/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallConst.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

/*****************************************************************************************
 * 共通定数クラス<br>
 *****************************************************************************************/
public class AmallConst {

	/**
	 * システム名称定義
	 */
	public static class SystemName {
		/** 顧客OL */
		public static final String CUSTOMER = "VEDS NAVI";
		/** 業務支援 */
		public static final String BUSINESS = "VEDS NAVI";
	}

	/**
	 * システム種別定義
	 */
	public static class SystemType {
		/** 顧客OL コード値 */
		public static final int CUSTOMER = 1;
		/** 顧客OL 名称 */
		public static final String CUSTOMER_NM = "顧客ＯＬ";
		/** 顧客OL ユーザーマスタテーブル名 */
		public static final String CUSTOMER_USER_TABLE_NM = "N_USER_CST_M";

		/** 業務支援 コード値 */
		public static final int BUSINESS = 2;
		/** 業務支援 名称 */
		public static final String BUSINESS_NM = "業務支援";
		/** 業務支援 ユーザーマスタテーブル名 */
		public static final String BUSINESS_USER_TABLE_NM = "N_USER_EMP_M";
	}

	/**
	 * セッション・リクエストパラメタ取得キーワード
	 */
	public static class ParamKey {
		/** トランザクション キーワード */
		public static final String TRANS_TOKEN = "TRANS_TOKEN_OWD";
		/** クッキー キーワード */
		public static final String ASS_COOKIE_ID = "ASS_COOKIE_ID_OWD";
		/** システム種別 キーワード */
		public static final String SYSTEM_KIND = "SYSTEM_KIND_OWD";
		/** 楽観的排他 キーワード */
		public static final String OPTIMISTIC_EXCLU_INFO = "OPTIMISTIC_EXCLU_INFO_OWD";

		/** DTO 取得キー */
		public final static String DTO = "DTO_OWD";
		/** 画面DTO 取得キー */
		public final static String DTO_SCREEN = "DTO_SCREEN_OWD";
		/** ログイン情報DTO 取得キー */
		public final static String DTO_LOGININFO = "DTO_LOGININFO_OWD";
		/** 共通情報DTO 取得キー */
		public final static String DTO_COMMONINFO = "DTO_COMMONINFO_OWD";
		/** 画面遷移履歴DTO 取得キー */
		public final static String DTO_TRANSHISTORY = "DTO_TRANSHISTORY_OWD";
		/** アクセス権限DTO 取得キー */
		public final static String DTO_ACCESS_AUTH = "DTO_ACCESS_AUTH_OWD";

		/** 画面ID リクエストパラメタ */
		public final static String GID = "gid";
		/** 画面イベント リクエストパラメタ */
		public final static String EVENT = "event";

	}
	/**
	 * 項目権限マップパラメタ取得キーワード
	 */
	public static class ItemMapKey {
		/** 名称 */
		public final static String NAME = "name";
		/** 表示 */
		public final static String DISP = "disp";
		/** 編集 */
		public final static String ENABLE = "enable";
		/** 画像パス */
		public final static String IMG = "img";
		/** 画面名称 */
		public final static String SCREEN_NAME = "ScreenName";
		/** 画面名称付加情報 */
		public final static String SCREEN_NAME_ADD = "ScreenNameAddData";

	}

	/**
	 * メッセージ種別定義
	 */
	public static class MsgCode {
		/** メッセージ種別(正常) */
		public static final int NORMAL = 0;
		/** メッセージ種別(エラー) */
		public static final int ERROR = 1;
		/** メッセージ種別(警告) */
		public static final int WARNING = 2;
		/** メッセージ種別(情報) */
		public static final int INFO = 9;
	}

	/**
	 * メッセージレベル定義
	 */
	public static class MsgLvl {
		/** メッセージレベル(正常) */
		public static final String NORMAL = "0";
		/** メッセージレベル(業務系) */
		public static final String ERROR = "1";
		/** メッセージレベル(例外) */
		public static final String EXCEPTION = "2";
		/** メッセージレベル(APLトレース) */
		public static final String APLTRACE = "9";
	}

	/**
	 * エラーログ種別定義
	 */
	public static class LogType {
		/** メッセージ種別(エラー) */
		public static final String ERROR = "ERROR";
		/** メッセージ種別(警告) */
		public static final String WARNING = "WARNING";
		/** メッセージ種別(警告) */
		public static final String WARN = "WARN";
		/** メッセージ種別(情報) */
		public static final String INFO = "INFO";
	}

	/**
	 * ログテーブル定義
	 */
	public static class LogTable {
		/** ログテーブル定義 アクセスログ */
		public static final String CUSTOMER = "AACSLHT";
		/** ログテーブル定義 社員ログ */
		public static final String BUSINESS = "ASTFLHT";
	}

	/**
	 * ログ 出力有無
	 */
	public static class LogDbOut {
		/** ログ出力有無 ON */
		public static final String ON = "1";
		/** ログ出力有無 OFF */
		public static final String OFF = "0";
	}

	/**
	 * ログ アペンダー名称定義
	 */
	public static class LoggerName {
		/** ログ アペンダー名称定義 顧客OL */
		public static final String CUSTOMER = "AccessLog_assvedsnavi.Logging";
		/** ログ アペンダー名称定義 業務支援 */
		public static final String BUSINESS = "AccessLog_assvedsnavi.Logging";
	}

	/**
	 * 共通FOWARD定義
	 */
	public static class FowardCom {
		/** 共通FOWARD定義 ログイン画面 */
		public static final String LOGIN = "TOLOGIN";
		/** 共通FOWARD定義 ログイン画面(業務支援) */
		public static final String LOGIN_BUSINESS = "TOBLOGIN";
	}

	/**
	 *  共通スタイルシート定義
	 */
	public static class CssStyleCom {
		/** 正常時の背景色(CSS名) */
		public final static String NORMAL = "";
		/** 異常時の背景色(CSS名) */
		public final static String ERROR = "error";
		/** 警告時の背景色(CSS名) */
		public final static String WARNING = "";

		/** カレンダーの祝日(CSS名) */
		public final static String HOLIDAY = "day holiday";
		/** カレンダーの平日(CSS名) */
		public final static String WEEKDAY = "day";

		/** 一覧の注意表示(ピンク)(CSS名) */
		public final static String CAUTION = "caution";

	}

	/**
	 * 日付フォーマット定義
	 */
	public static class DateFormatCom {
		/** 日時フォーマット */
		public final static String YYYYMMDD24HMISS = "yyyy/MM/dd HH:mm:ss";
	}
	/**
	 * 文字コード定義
	 */
	public static class Encode {
		/** シフトJIS */
		public final static String SHIFT_JIS = "Shift_JIS";
		/** UTF-8 */
		public final static String UTF8 = "UTF-8";
	}

	/**
	 * ログイン関連 フラグ
	 */
	public static class LoginFlg {
		/** ロックアウトフラグ */
		public static final String LOCK_OUT = "1";
		/** ロックアウトOFFフラグ */
		public static final String LOCK_OUT_OFF = "0";
		/** 仮パスワードフラグ */
		public static final String PRE_PASS = "1";
		/** 仮パスワードOFFフラグ */
		public static final String PRE_PASS_OFF = "0";
		/** 有効期限なしフラグ */
		public static final String VALID_LIMIT_OFF = "1";
		/** アカウントロック表示 */
		public static final String ACCOUNT_LOCK_OUT_NM = "使用停止";
		/** パスワードロック表示 */
		public static final String PASSWORD_LOCK_OUT_NM = "ロック";
	}

	/**
	 * 画面権限関連
	 */
	public static class ScrExp {
		/** 分類タイプ：顧客 */
		public static final String EXP_TYPE_CUSTOMER = "30";
		/** 分類タイプ：店舗 */
		public static final String EXP_TYPE_SHOP = "20";
		/** 分類タイプ：ユーザー */
		public static final String EXP_TYPE_USER = "10";
		/** 表示可否：非表示 */
		public static final String DISPLAY_OFF = "0";
		/** 表示可否：表示 */
		public static final String DISPLAY_ON = "1";
		/** 表示可否：未設定 */
		public static final String DISPLAY_UNDEFF = "2";
		/** 編集可否：非表示 */
		public static final String EDIT_OFF = "0";
		/** 編集可否：表示 */
		public static final String EDIT_ON = "1";
		/** 表示パターン：表示なし */
		public static final String DISP_TYPE_OFF = "3";
	}


	/**
	 * フラグ全般 有無
	 */
	public static class GeneralFlg {
		/** フラグ ON */
		public static final String ON = "1";
		/** フラグ OFF */
		public static final String OFF = "0";
	}

	/**
	 * 汎用マスタ取得用キーワード
	 */
	public static class GeneralMstKey {
		/** 業務日付 */
		public static final String GYOMU_DATE = "GYOMU_DATE";
		/** アクセスログ有無 */
		public static final String ACCESS_LOG_OUTPUT_FLG = "ACCESS_LOG_OUTPUT_FLG";
		/** 表示件数プルダウンリスト */
		public static final String DISPLAY_LIST_COUNT = "DISPLAY_LIST_COUNT";
		/** 表示権限プルダウンリスト */
		public static final String DISP_AUTH_LIST = "DISP_AUTH_LIST";
		/** 編集権限プルダウンリスト */
		public static final String EDIT_AUTH_LIST = "EDIT_AUTH_LIST";
		/** 個別表示権限プルダウンリスト */
		public static final String IND_DISP_AUTH_LIST = "IND_DISP_AUTH_LIST";
		/** 個別権限分類優先度 */
		public static final String IND_AUTH_PRIORITY = "IND_AUTH_PRIORITY";
		/** 項目タイプ */
		public static final String ITEM_TYPE = "ITEM_TYPE";
		/** ログイン失敗回数上限 */
		public static final String LOGIN_ERR_COUNT_MAX = "LOGIN_ERR_COUNT_MAX";
		/** パスワードロック復帰時間 */
		public static final String PASWORD_LOCK_RETURN = "PASWORD_LOCK_RETURN";
		/** 回収金カレンダー表示範囲 */
		public static final String CALENDER_RANGE = "CALENDER_RANGE";
		/** JS用メッセージ定義 */
		public static final String JAVASCRIPT_MSG_CONST = "JAVASCRIPT_MSG_CONST";
		/** CSVファイル用定義 */
		public static final String CSV_DOWNLOAD_FILE = "CSV_DOWNLOAD_FILE";
		/** パスワード変更後自動遷移 */
		public static final String PASSWORD_CNG_AUTO_MOVE = "PASSWORD_CNG_AUTO_MOVE";
		/** 金種リスト取得 */
		public static final String MONEY_TYPE = "MONEY_TYPE";
		/** 画面権限制限対象関連画面 */
		public static final String RELATED_SCREEN = "RELATED_SCREEN";
		/** ブラウザ判定用文字列 */
		public static final String BROWSER_CHECK_KEY = "BROWSER_CHECK_KEY";
		/** CSVヘッダー項目用定義 */
		public static final String CSV_HEADER_COLUMN = "CSV_HEADER_COLUMN";
		/** パスワードロックラジオボタン選択値 */
		public static final String PASSWORD_LOCK_RADIO = "PASSWORD_LOCK_RADIO";
		/** アカウントロックラジオボタン選択値 */
		public static final String ACCOUNT_LOCK_RADIO = "ACCOUNT_LOCK_RADIO";
		/** 金種票入力締め日用定義 */
		public static final String ENT_FIN_DY = "ENT_FIN_DY";
		/** 顧客OLユーザー管理特殊権限ロール */
		public static final String  ROLE_CST_USER_DEL = "ROLE_CST_USER_DEL";


	}

	/**
	 * 入力欄用桁数チェック数値
	 */
	public static class InputNum {
		/** 顧客コード */
		public static final int CST_CD = 10;
		/** 顧客名(文字数) */
		public static final int CST_NM = 60;
		/** 顧客グループ名(文字数) */
		public static final int CST_GRP_NM = 60;
		/** 店舗コード */
		public static final int SHOP_CD = 10;
		/** 店舗名(文字数) */
		public static final int SHOP_NM = 60;
		/** 店舗枝番コード */
		public static final int SHOP_BRANCH_CD = 14;
		/** 店舗枝番名(文字数) */
		public static final int SHOP_BRANCH_NM = 60;
		/** 店舗グループ名(文字数) */
		public static final int SHOP_GRP_NM = 60;
		/** ユーザーID */
		public static final int USER_ID = 10;
		/** ユーザー名(文字数) */
		public static final int USER_NM = 60;
		/** パスワード有効期間(99か月まで=2桁) */
		public static final int PASS_VALID = 2;
		/** コメント(文字数) */
		public static final int USER_CMT = 60;
	}

	/**
	 * 確定状況ステータス
	 */
	public static class confirmCls {
		/** 修正可能 */
		public static final String NO_CONFIRM = "修正可能";
		/** 確定済 */
		public static final String CONFIRMED = "確定済";

	}

	/**
	 * 入力状態ステータス
	 */
	public static class statusCls {
		/** 未入力('00') */
		public static final String NO_ENTERED_NUM = "00";
		/** 入力済('01') */
		public static final String ENTERED_NUM = "01";
		/** 修正済('02') */
		public static final String MODIFIED_NUM = "02";
		/** 送信済('03') */
		public static final String SENT_NUM = "03";
		/** 未入力 */
		public static final String NO_ENTERED = "未入力";
		/** 入力済 */
		public static final String ENTERED = "入力済";
		/** 修正済 */
		public static final String MODIFIED = "修正済";
		/** 送信済 */
		public static final String SENT = "送信済";
	}

	/**
	 * 固定文字列定義
	 */
	/** 半角スラッシュ */
	public static final String CS_HF_SLASH = "/";
	/** 全角スラッシュ */
	public static final String CS_FL_SLASH = "／";
	/** 通過文字列マイナス値(黒三角) */
	public static final String CS_MINUS_CURRENCY = "▲";
	/** マスタ登録なしデータ */
	public static final String CS_NOT_FOUND_MASTER = "マスタ未登録";
	/** 改行コード */
	public static final String LINE_SEPARATOR = System.getProperty("line.separator");
	/** CSVセパレータ */
	public static final String CSV_SEP = ",";
	/** ログイン表示名称末尾 */
	public static final String USER_NAME_SUFFIX = "様";
	/** ユーザーIDエリア名称 */
	public static final String USER_ID_AREA_NAME = "ユーザーID";
	/** パスワードエリア名称 */
	public static final String PASSWORD_AREA_NAME = "パスワード";
	/** 削除フラグ初期値(削除されていない) */
	public static final String DEFAULT_DEL_FLG = "0";
	/** 金額への"枚"付与 */
	public static final String DEFAULT_MONEY_AMOUNT_JA = "枚";
	/** 金額への"円"付与 */
	public static final String DEFAULT_MONEY_JA = "円";
	/** 顧客グループコード：全顧客 */
	public static final String CUSTOMER_GRP_CD_ALL = "9999999999";
	/** 店舗グループコード：全店舗 */
	public static final String SHOP_GRP_CD_ALL = "9999999999";
	/** 3桁区切りフォーマット文字列 */
	public static final String THREE_SEPARATOR_FORMAT = "%,d";
	/** 日付フォーマット文字（年） */
	public static final String DATE_FORMAT_YEAR = "年";
	/** 日付フォーマット文字（月） */
	public static final String DATE_FORMAT_MONTH = "月";
	/** like句用％ */
	public static final String SQL_LIKE_PER = "%";
	/** 有効開始年月(固定 Ph1) */
	public static final String EFST_DY_DEFAULT = "20000101";
	/** 有効終了年月(固定 Ph1) */
	public static final String EFED_DY_DEFAULT = "29991231";
	/** 社員表示 */
	public static final String EMP_NAME = "社員";
	/** 店舗グループ有表示 */
	public static final String SHOP_GRP_EXISTS = "複数店舗";
	/** 顧客グループコードフォーマット */
	public static final String CST_GRP_CD_FORMAT = "%010d";
	/** 店舗グループコードフォーマット */
	public static final String SHOP_GRP_CD_FORMAT = "%010d";
}
