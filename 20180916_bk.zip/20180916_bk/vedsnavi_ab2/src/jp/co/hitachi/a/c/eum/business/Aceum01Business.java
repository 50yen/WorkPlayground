/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aceum01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.business;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.eum.action.Aceum01Action;
import jp.co.hitachi.a.c.eum.bean.Aceum01DispBean;
import jp.co.hitachi.a.c.eum.dto.Aceum01Dto;
import jp.co.hitachi.a.c.eum.dto.AceumItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.CssStyleCom;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallConst.LoginFlg;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallConst.SystemType;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallPage;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoLoginInfo;
import jp.co.hitachi.a.m.dto.AmdtoPagingSql;

/*****************************************************************************************
 * Aceum01Businessクラス<br>
 *****************************************************************************************/
public class Aceum01Business extends AceumBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Aceum01DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	private static final String FORWARD_DISP = "DISP";
	/** 顧客検索 */
	private static final String FORWARD_SEARCH = "SEARCH";
	/** 前頁 */
	private static final String FORWARD_PAGEPREV = "PAGEPREV";
	/** 先頭頁処理 */
	private static final String FORWARD_PAGEFIRST = "PAGEFIRST";
	/** 次頁 */
	private static final String FORWARD_PAGENEXT = "PAGENEXT";
	/** 最終頁 */
	private static final String FORWARD_PAGELAST = "PAGELAST";
	/** 件数変更 */
	private static final String FORWARD_DISPRESULTS = "DISPRESULTS";
	/** 詳細 */
	private static final String FORWARD_DETAIL = "DETAIL";
	/** 変更 */
	private static final String FORWARD_DETAILCHANGE = "DETAILCHANGE";
	/** 新規登録 */
	private static final String FORWARD_DETAILNEW = "DETAILNEW";
	/** 削除 */
	private static final String FORWARD_DELETE = "DELETE";
	/** 遷移元画面戻るボタン押下による再表示 */
	private static final String FORWARD_RETURNPAGE = "REDISP";

	/**
	 * 画面項目ID
	 */
	/** 顧客コード */
	private static final String ITEM_ID_CST_CD = "customerSearchNm";
	/** 店舗コード */
	private static final String ITEM_ID_SHOP_CD = "shopSearchNm";
	/** ユーザーID */
	private static final String ITEM_ID_USER_CD = "userSearchNm";
	/** 削除カラム  */
	private static final String ITEM_ID_DELETE_COLUMN = "deleteObject";

	/** DTOキー名 */
	private static final String DTO_KEY = "DTO_ACEUM01";


	/** メンバ変数 */
	/** アクションフォーム */
	private Aceum01Action m_Aceum01Form = null;
	/** 表示用画面Bean */
	private Aceum01DispBean m_Aceum01DispBean = null;
	/** ページング処理用 */
	private AmallPage m_Page = null;
	/** SQL作成用 */
	private AmdtoPagingSql m_Page_Sql = null;
	/** 画面DTO */
	private Aceum01Dto m_Aceum01Dto;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Aceum01Business(
			Aceum01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Aceum01Business.class.getName();
		m_Aceum01Form = form;
		m_Aceum01DispBean = new Aceum01DispBean();
		m_Aceum01Dto = new Aceum01Dto();
		m_Page = new AmallPage();
		m_Page_Sql = new AmdtoPagingSql();
		setErrString(gid, m_Aceum01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Aceum01DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Aceum01Form.getM_systemKind());
			m_DbAccess.initDB();

			/* 内部記憶情報の生成 */
			m_Aceum01Dto = (Aceum01Dto) getSpecifiedDTO(m_Gid, DTO_KEY);
			if (m_Aceum01Dto == null || FORWARD_DISP.equals(m_Event)) {
				m_Aceum01Dto = new Aceum01Dto();
				putSpecifiedDTO(m_Gid, DTO_KEY, m_Aceum01Dto);
			}

			// 共通処理
			getDropDownListData();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_SEARCH.equals(m_Event)) {
				// 検索ボタン押下の場合
				forwardStr = search();
			} else if (FORWARD_PAGEFIRST.equals(m_Event)) {
				// "<<"ボタン押下の場合
				forwardStr = pageFirst();
			} else if (FORWARD_PAGEPREV.equals(m_Event)) {
				// "<"ボタン押下の場合
				forwardStr = pagePrev();
			} else if (FORWARD_PAGENEXT.equals(m_Event)) {
				// ">"ボタン押下の場合
				forwardStr = pageNext();
			} else if (FORWARD_PAGELAST.equals(m_Event)) {
				// ">>"ボタン押下の場合
				forwardStr = pageLast();
			} else if (FORWARD_DISPRESULTS.equals(m_Event)) {
				// 表示件数変更の場合
				forwardStr = changeDispRslts();
			} else if (FORWARD_DETAILCHANGE.equals(m_Event)) {
				// 変更ボタン押下処理の場合
				forwardStr = detailChange();
			} else if (FORWARD_DETAILNEW.equals(m_Event)) {
				// 新規作成ボタン押下処理の場合
				forwardStr = detailNew();
			} else if (FORWARD_DELETE.equals(m_Event)) {
				// 削除ボタン押下処理の場合
				forwardStr = delete();
			} else if (FORWARD_RETURNPAGE.equals(m_Event)) {
				// 戻るボタン押下で表示処理の場合
				forwardStr = redisp();
			} else {
				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {

			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Aceum01DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * 入力値が存在する場合は初期検索を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * プルダウンリスト取得処理
	 * <p>
	 * 画面に表示するプルダウンリストの値を取得する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private void getDropDownListData() throws AmallException, Exception {

		// 権限一覧を取得する
		m_Aceum01DispBean.setRoleDropDownList(getAuthRoleList(m_Aceum01Form.getM_systemKind()));

	}
	/*************************************************************************************
	 * 検索ボタン押下処理実行
	 * <p>
	 * 検索ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String search() throws AmallException, Exception {
		// 検索結果の初期化
		m_Aceum01Form.setItemDispList(new ArrayList<>());

		// 顧客コード取得
		String cstCd = m_Aceum01Form.getInputCustomerCd();

		// 店舗コード取得
		String shopCd = m_Aceum01Form.getInputShopCd();

		// ユーザーID取得
		String userId = m_Aceum01Form.getInputUserId();

		// 入力値チェック
		if (!inputCheck(cstCd, shopCd, userId )) {
			// 入力なし・エラーの場合
			return FORWARD_DISP;
		}

		// 検索条件を保存する
		m_Aceum01Dto.setSavedCustomerCd(cstCd);
		m_Aceum01Dto.setSavedShopCd(shopCd);
		m_Aceum01Dto.setSavedUserId(userId);
		m_Aceum01Dto.setSavedRoleCd(m_Aceum01Form.getSelectedRoleCd());
		m_Aceum01Dto.setSavedPassLockFlg(m_Aceum01Form.isPassLockFlg());
		m_Aceum01Dto.setSavedActLockFlg(m_Aceum01Form.isActLockFlg());

		// 検索処理を呼ぶ
		return searchProc();
	}

	/*************************************************************************************
	 * 入力値チェック
	 * <p>
	 * 入力値チェックを実施する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @param  userId ユーザーID
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheck(String cstCd, String shopCd, String userId) throws AmallException, Exception {

		// 返却フラグ
		boolean ret = true;

		// 入力値チェック(顧客コード)
		if (!AmallUtilities.isEmpty(cstCd)) {
			// 入力値が存在する場合
			if (!AmallUtilities.isHalfWidthCharacterKind(cstCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CST_CD, m_Aceum01DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Aceum01DispBean, ITEM_ID_CST_CD);

				ret = false;
			} else if (AmallUtilities.getLengthAsHalf(cstCd) != InputNum.CST_CD) {
				// 10桁より多い数字が設定されている
				setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CST_CD, m_Aceum01DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Aceum01DispBean, ITEM_ID_CST_CD);

				ret = false;
			}
			if(ret) {
				// 名称取得
				chkUniqCst(cstCd);
			}
		}

		// 入力値チェック(店舗コード)
		if (!AmallUtilities.isEmpty(shopCd)) {
			// 入力値が存在する場合
			// 顧客コード必須チェック

			// 入力値チェック(顧客コード)
			if (!AmallUtilities.isEmpty(cstCd)) {
				// 入力値が存在する場合
				if (!AmallUtilities.isHalfWidthCharacterKind(cstCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
					// 半角英数以外が設定されている
					setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
							getItemDispName(ITEM_ID_CST_CD, m_Aceum01DispBean), String.valueOf(InputNum.CST_CD));
					setError(m_Aceum01DispBean, ITEM_ID_CST_CD);

					ret = false;
				} else if (AmallUtilities.getLengthAsHalf(cstCd) != InputNum.CST_CD) {
					// 10桁以外の数字が設定されている
					setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
							getItemDispName(ITEM_ID_CST_CD, m_Aceum01DispBean), String.valueOf(InputNum.CST_CD));
					setError(m_Aceum01DispBean, ITEM_ID_CST_CD);

					ret = false;
				}
			} else {
				// 入力がない場合
				setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
						getItemDispName(ITEM_ID_CST_CD, m_Aceum01DispBean));
				setError(m_Aceum01DispBean, ITEM_ID_CST_CD);

				ret = false;
			}


			if (!AmallUtilities.isHalfWidthCharacterKind(shopCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
						getItemDispName(ITEM_ID_SHOP_CD, m_Aceum01DispBean), String.valueOf(InputNum.SHOP_CD));
				setError(m_Aceum01DispBean, ITEM_ID_SHOP_CD);

				ret = false;
			} else if (AmallUtilities.getLengthAsHalf(shopCd) > InputNum.SHOP_CD) {
				// 10桁より多い数字が設定されている
				setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
						getItemDispName(ITEM_ID_SHOP_CD, m_Aceum01DispBean), String.valueOf(InputNum.SHOP_CD));
				setError(m_Aceum01DispBean, ITEM_ID_SHOP_CD);

				ret = false;
			}
			if(ret) {
				// 名称取得
				chkUniqShop(cstCd, shopCd);
			}
		}


		// 入力値チェック(ユーザーID)
		if (!AmallUtilities.isEmpty(userId)) {
			// 入力値が存在する場合
			if (!AmallUtilities.isHalfWidthCharacterKind(userId, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_USER_CD, m_Aceum01DispBean), String.valueOf(InputNum.USER_ID));
				setError(m_Aceum01DispBean, ITEM_ID_USER_CD);

				ret = false;
			} else if (AmallUtilities.getLengthAsHalf(userId) != InputNum.USER_ID) {
				// 10桁以外の英数字が設定されている
				setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_USER_CD, m_Aceum01DispBean), String.valueOf(InputNum.USER_ID));
				setError(m_Aceum01DispBean, ITEM_ID_USER_CD);

				ret = false;
			}
			if(ret) {
				// 名称取得
				chkUniqUser(userId);
			}
		}


		return ret;
	}
	/*************************************************************************************
	 * 顧客マスタ(DB)ユニークチェック
	 * <p>
	 * 顧客マスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できる場合はActionFormに値を設定し，
	 * 特定できない場合はfalseで返却する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @return boolean true:正常 false:異常
	 ************************************************************************************/
	private boolean chkUniqCst(String cstCd) throws AmallException, Exception {

		String methodName = "chkUniqCst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用チェックリスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	CST_NM");
			sql.append("  FROM");
			sql.append("	N_CST_M");
			sql.append(" WHERE");
			sql.append("	DEL_FLG = ?");
			sql.append("	AND CST_CD = ?");
			// 顧客範囲設定
			// 全顧客判定
			if (!m_Aceum01DispBean.isCustomerCdAllFlg()) {
				// 全顧客ではない場合
				sql.append("	AND CST_CD IN (");
				for (String appCustomer : m_Aceum01DispBean.getCustomerCdList()) {
					sql.append("'").append(appCustomer).append("',");
				}
				sql.append("'')");
			}

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				// 店舗名
				String name = m_DbAccess.getString(rs, "CST_NM");

				// リストに追加
				retList.add(name);
			}

			// 結果チェック
			if(retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}

			// 値を設定
			m_Aceum01Form.setDispCstNm(retList.get(0));
			m_Aceum01Dto.setSavedCustomerNm(retList.get(0));

			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_CST_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}

	/*************************************************************************************
	 * 店舗マスタ(DB)ユニークチェック
	 * <p>
	 * 店舗マスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できる場合はActionFormに値を設定し，
	 * 特定できない場合はfalseで返却する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @return boolean true:正常 false:異常
	 ************************************************************************************/
	private boolean chkUniqShop(String cstCd, String shopCd) throws AmallException, Exception {

		String methodName = "chkUniqShop()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用チェックリスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	ncm.CST_CD");
			sql.append(",	ncm.CST_NM");
			sql.append(",	nsm.SHOP_NM");
			sql.append(",	TRIM(nscm.COMPANY_SHOP_NM) AS COMPANY_SHOP_NM");
			sql.append("  FROM");
			sql.append("  	N_SHOP_M nsm");
			sql.append("	LEFT JOIN");
			sql.append("		N_CST_M ncm");
			sql.append("	  ON");
			sql.append("		nsm.CST_CD = ncm.CST_CD");
			sql.append("		AND ncm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_CNV_M nscm");
			sql.append("	  ON");
			sql.append("		nsm.CST_CD = nscm.CST_CD");
			sql.append("		AND nsm.SHOP_CD = nscm.SHOP_CD");
			sql.append("		AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
			sql.append("		AND nscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append(" WHERE");
			sql.append("	nsm.DEL_FLG = ?");
			sql.append("	AND ? BETWEEN nsm.EFST_DY AND nsm.EFED_DY");
			sql.append("	AND nsm.CST_CD = ?");
			sql.append("	AND (");
			sql.append("			nsm.SHOP_CD = ?");
			sql.append("			OR");
			sql.append("			TRIM(nscm.COMPANY_SHOP_CD) = ?");
			sql.append("		)");
			// 店舗範囲設定
			// 全店舗判定
			if (!m_Aceum01DispBean.isShopCdAllFlg()) {
				// 全顧客・全店舗ではない場合
				sql.append("	AND (");
				boolean first = true;
				for (Entry<String, List<String>> entry : m_Aceum01DispBean.getShopCdListMap().entrySet()) {

					String appCstCd = entry.getKey();
					for (String appShop : entry.getValue()) {
						if (first) {
							sql.append("		");
							first = false;
						} else {
							sql.append("		OR");
						}
						sql.append("		(");
						sql.append("			nsm.CST_CD = '").append(appCstCd).append("'");
						sql.append("			AND");
						sql.append("			nsm.SHOP_CD = '").append(appShop).append("'");
						sql.append("		)");
					}
				}
				sql.append("	)");
			}


			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 有効期限
			m_DbAccess.setString(++setCnt, m_Aceum01DispBean.getServiceDate());
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, m_Aceum01DispBean.getServiceDate());
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);
			// 店舗コード
			m_DbAccess.setString(++setCnt, shopCd);
			// 店舗コード
			m_DbAccess.setString(++setCnt, shopCd);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			String cstNmData = "";
			while (rs.next()) {

				// 店舗名
				String name = m_DbAccess.getString(rs, "SHOP_NM");
				// 店舗名(企業)
				String comapany = m_DbAccess.getString(rs, "COMPANY_SHOP_NM");

				// 企業店舗コード判定
				if (AmallUtilities.isEmpty(comapany)) {
					// リストに追加
					retList.add(name);
				} else {
					// 企業店舗コードがある場合は企業店舗を優先
					// リストに追加
					retList.add(comapany);
				}

				// 顧客名
				cstNmData = m_DbAccess.getString(rs, "CST_NM");

			}

			// 結果チェック
			if(retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}

			// 値を設定
			m_Aceum01Form.setDispShopNm(retList.get(0));
			m_Aceum01Dto.setSavedShopNm(retList.get(0));
			m_Aceum01Form.setDispCstNm(cstNmData);
			m_Aceum01Dto.setSavedCustomerNm(cstNmData);


			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_SHOP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}

	/*************************************************************************************
	 * ユーザーマスタ(DB)ユニークチェック
	 * <p>
	 * ユーザーマスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できない場合はnullで返却する
	 * </p>
	 * @param  userCd ユーザーコード
	 * @return String ユーザー名(異常時はnull)
	 ************************************************************************************/
	private boolean chkUniqUser(String userCd) throws AmallException, Exception {

		String methodName = "chkUniqUser()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用チェックリスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	nucm.USER_NM");
			sql.append("  FROM");
			sql.append("	(");
			sql.append("		SELECT");
			sql.append("			USER_ID");
			sql.append(",			USER_NM");
			sql.append(",			DEL_FLG");
			sql.append("		 FROM");
			sql.append("			N_USER_CST_M");

			// システム種別によってテーブルを追加する
			if (m_Aceum01Form.getM_systemKind() == SystemType.BUSINESS) {
				// 業務支援の場合
				sql.append("		UNION ALL");
				sql.append("		SELECT");
				sql.append("			USER_ID");
				sql.append(",			USER_NM");
				sql.append(",			DEL_FLG");
				sql.append("		 FROM");
				sql.append("			N_USER_EMP_M");
			}
			sql.append("	) nucm");
			sql.append(" WHERE");
			sql.append("	nucm.USER_ID = ?");
			sql.append("	AND nucm.DEL_FLG = ?");

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;

			// ユーザー
			m_DbAccess.setString(++setCnt, userCd);

			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				String name = m_DbAccess.getString(rs, "USER_NM");
				// リストに追加
				retList.add(name);
			}

			// 結果チェック
			if(retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}
			// 値を設定
			m_Aceum01Form.setDispUserNm(retList.get(0));
			m_Aceum01Dto.setSavedUserNm(retList.get(0));

			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_USER_CST_M,N_USER_EMP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * "<"ボタン押下処理実行
	 * <p>
	 * "<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pagePrev() throws AmallException {

		// 保存している条件を入力欄に設定する
		// 顧客コード取得
		m_Aceum01Form.setInputCustomerCd(m_Aceum01Dto.getSavedCustomerCd());

		// 店舗コード取得
		m_Aceum01Form.setInputShopCd(m_Aceum01Dto.getSavedShopCd());

		// ユーザーID取得
		m_Aceum01Form.setInputUserId(m_Aceum01Dto.getSavedUserId());

		// 権限ロールコード取得
		m_Aceum01Form.setSelectedRoleCd(m_Aceum01Dto.getSavedRoleCd());

		// パスコードロックフラグ取得
		m_Aceum01Form.setPassLockFlg(m_Aceum01Dto.isSavedPassLockFlg());

		// アカウントロックフラグ取得
		m_Aceum01Form.setActLockFlg(m_Aceum01Dto.isSavedActLockFlg());

		// 検索処理を呼ぶ
		return searchProc();
	}

	/*************************************************************************************
	 * "<<"ボタン押下処理実行
	 * <p>
	 * "<<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageFirst() throws AmallException {


		// 保存している条件を入力欄に設定する
		// 顧客コード取得
		m_Aceum01Form.setInputCustomerCd(m_Aceum01Dto.getSavedCustomerCd());

		// 店舗コード取得
		m_Aceum01Form.setInputShopCd(m_Aceum01Dto.getSavedShopCd());

		// ユーザーID取得
		m_Aceum01Form.setInputUserId(m_Aceum01Dto.getSavedUserId());

		// 権限ロールコード取得
		m_Aceum01Form.setSelectedRoleCd(m_Aceum01Dto.getSavedRoleCd());

		// パスコードロックフラグ取得
		m_Aceum01Form.setPassLockFlg(m_Aceum01Dto.isSavedPassLockFlg());

		// アカウントロックフラグ取得
		m_Aceum01Form.setActLockFlg(m_Aceum01Dto.isSavedActLockFlg());

		// 検索処理を呼ぶ
		return searchProc();
	}

	/*************************************************************************************
	 * ">"ボタン押下処理実行
	 * <p>
	 * ">"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageNext() throws AmallException {


		// 保存している条件を入力欄に設定する
		// 顧客コード取得
		m_Aceum01Form.setInputCustomerCd(m_Aceum01Dto.getSavedCustomerCd());

		// 店舗コード取得
		m_Aceum01Form.setInputShopCd(m_Aceum01Dto.getSavedShopCd());

		// ユーザーID取得
		m_Aceum01Form.setInputUserId(m_Aceum01Dto.getSavedUserId());

		// 権限ロールコード取得
		m_Aceum01Form.setSelectedRoleCd(m_Aceum01Dto.getSavedRoleCd());

		// パスコードロックフラグ取得
		m_Aceum01Form.setPassLockFlg(m_Aceum01Dto.isSavedPassLockFlg());

		// アカウントロックフラグ取得
		m_Aceum01Form.setActLockFlg(m_Aceum01Dto.isSavedActLockFlg());

		// 検索処理を呼ぶ
		return searchProc();
	}

	/*************************************************************************************
	 * ">>"ボタン押下処理実行
	 * <p>
	 * ">>"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageLast() throws AmallException {


		// 保存している条件を入力欄に設定する
		// 顧客コード取得
		m_Aceum01Form.setInputCustomerCd(m_Aceum01Dto.getSavedCustomerCd());

		// 店舗コード取得
		m_Aceum01Form.setInputShopCd(m_Aceum01Dto.getSavedShopCd());

		// ユーザーID取得
		m_Aceum01Form.setInputUserId(m_Aceum01Dto.getSavedUserId());

		// 権限ロールコード取得
		m_Aceum01Form.setSelectedRoleCd(m_Aceum01Dto.getSavedRoleCd());

		// パスコードロックフラグ取得
		m_Aceum01Form.setPassLockFlg(m_Aceum01Dto.isSavedPassLockFlg());

		// アカウントロックフラグ取得
		m_Aceum01Form.setActLockFlg(m_Aceum01Dto.isSavedActLockFlg());

		// 検索処理を呼ぶ
		return searchProc();
	}

	/*************************************************************************************
	 * 表示件数変更処理実行
	 * <p>
	 * 表示件数変更処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String changeDispRslts() throws AmallException {

		// 保存している条件を入力欄に設定する
		// 顧客コード取得
		m_Aceum01Form.setInputCustomerCd(m_Aceum01Dto.getSavedCustomerCd());

		// 店舗コード取得
		m_Aceum01Form.setInputShopCd(m_Aceum01Dto.getSavedShopCd());

		// ユーザーID取得
		m_Aceum01Form.setInputUserId(m_Aceum01Dto.getSavedUserId());

		// 権限ロールコード取得
		m_Aceum01Form.setSelectedRoleCd(m_Aceum01Dto.getSavedRoleCd());

		// パスコードロックフラグ取得
		m_Aceum01Form.setPassLockFlg(m_Aceum01Dto.isSavedPassLockFlg());

		// アカウントロックフラグ取得
		m_Aceum01Form.setActLockFlg(m_Aceum01Dto.isSavedActLockFlg());

		// 検索処理を呼ぶ
		return searchProc();
	}
	/*************************************************************************************
	 * 変更ボタン押下処理
	 * <p>
	 * 変更ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String detailChange() throws AmallException, Exception {

		// 選択行のキー値を取得
		String selectUserID = m_Aceum01Form.getTransUserId();
		if (AmallUtilities.isEmpty(selectUserID)) {
			return FORWARD_DISP;

		}
		// 選択行の対象テーブルを取得
		String strSystemKind = m_Aceum01Form.getTransSystemKind();
		if (AmallUtilities.isEmpty(strSystemKind)) {
			return FORWARD_DISP;

		}
		// 数値変換
		int selectSystemKind = Integer.valueOf(strSystemKind);


		// 選択列をdtoにセット
		AceumItemDispDto dto = new AceumItemDispDto();
		dto.setUserId(selectUserID);
		dto.setSystemKind(selectSystemKind);


		// セッションに保管
		putSpecifiedDTO(ACEUM_INFO_KEY, dto);

		return FORWARD_DETAIL;
	}
	/*************************************************************************************
	 * 新規作成ボタン押下処理
	 * <p>
	 * 新規作成ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String detailNew() throws AmallException {

		// 選択列をdtoにセット(空)
		AceumItemDispDto dto = new AceumItemDispDto();
		// システム種別を判定
		if (m_Aceum01Form.getM_systemKind() == SystemType.CUSTOMER) {
			// 顧客OLの場合はユーザーマスタ顧客のみ
			dto.setSystemKind(SystemType.CUSTOMER);
		}
		// セッションに保管
		putSpecifiedDTO(ACEUM_INFO_KEY, dto);

		return FORWARD_DETAIL;
	}
	/*************************************************************************************
	 * 削除ボタン押下処理
	 * <p>
	 * 削除ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String delete() throws AmallException,Exception {

		// 処理判定フラグ
		boolean registFlg = true;
		boolean procFlg = false;

		// 一覧情報を取得
		List<AceumItemDispDto> list = m_Aceum01Form.getItemDispList();

		// 対象列を取得し、削除処理を実行
		for (AceumItemDispDto itemDispDto : list) {

			if (itemDispDto.isDelChkFlg()) {
				// 削除フラグが存在した場合
				procFlg = true;

				// 対象テーブルはシステム種別より判定
				registFlg = deleteUserMst(itemDispDto.getUserId(), itemDispDto.getExclusiveKey(), itemDispDto.getSystemKind());

				if(!registFlg) {
					// 排他エラーの場合
					break;
				}

			}

		}
		// DB処理正常判定
		if (registFlg && procFlg) {
			// コミット処理
			m_DbAccess.commit();
			// 正常完了処理メッセージ
			setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_INF_DEL_NML_END);
		} else if(registFlg) {
			// 処理対象無しメッセージ
			setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_ERR_NOT_SELECT_COLUMN, getItemDispName(ITEM_ID_DELETE_COLUMN, m_Aceum01DispBean));
		} else {
			// 排他エラーの場合
			// エラー情報を設定
			setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST);

			// アクセスログ情報の作成
			AmallExceptionInfo amei = new AmallExceptionInfo();
			amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_ACS_OPT_ERROR, "N_USER_XXX_M"));
			setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);
		}

		// 再検索処理
		// 顧客コード取得
		m_Aceum01Form.setInputCustomerCd(m_Aceum01Dto.getSavedCustomerCd());
		// 店舗コード取得
		m_Aceum01Form.setInputShopCd(m_Aceum01Dto.getSavedShopCd());
		// ユーザーID取得
		m_Aceum01Form.setInputUserId(m_Aceum01Dto.getSavedUserId());
		// 権限ロールコード取得
		m_Aceum01Form.setSelectedRoleCd(m_Aceum01Dto.getSavedRoleCd());
		// パスコードロックフラグ取得
		m_Aceum01Form.setPassLockFlg(m_Aceum01Dto.isSavedPassLockFlg());
		// アカウントロックフラグ取得
		m_Aceum01Form.setActLockFlg(m_Aceum01Dto.isSavedActLockFlg());

		// 再検索処理
		search();

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 再表示処理
	 * <p>
	 * 「戻る」ボタンで戻ってきた場合の再表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String redisp() throws AmallException,Exception {

		// 顧客コード取得
		m_Aceum01Form.setInputCustomerCd(m_Aceum01Dto.getSavedCustomerCd());

		// 店舗コード取得
		m_Aceum01Form.setInputShopCd(m_Aceum01Dto.getSavedShopCd());

		// ユーザーID取得
		m_Aceum01Form.setInputUserId(m_Aceum01Dto.getSavedUserId());

		// 権限ロールコード取得
		m_Aceum01Form.setSelectedRoleCd(m_Aceum01Dto.getSavedRoleCd());

		// パスコードロックフラグ取得
		m_Aceum01Form.setPassLockFlg(m_Aceum01Dto.isSavedPassLockFlg());

		// アカウントロックフラグ取得
		m_Aceum01Form.setActLockFlg(m_Aceum01Dto.isSavedActLockFlg());

		// 再検索処理
		search();

		return FORWARD_DISP;

	}
	/*************************************************************************************
	 * 検索処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String searchProc() throws AmallException {
		// methodName
		String methodName = "search()";
		// 明細部用LIST
		List<AceumItemDispDto> detailList = new ArrayList<>();

		// システム日付取得
		String systemDt = m_Aceum01DispBean.getServiceDate();

		// 検索条件
		// 顧客コード取得
		String cstCd = m_Aceum01Form.getInputCustomerCd();

		// 店舗コード取得
		String shopCd = m_Aceum01Form.getInputShopCd();

		// ユーザーID取得
		String userId = m_Aceum01Form.getInputUserId();

		// 権限ロールコード取得
		String roleCd = m_Aceum01Form.getSelectedRoleCd();

		// パスコードロックフラグ取得
		boolean passLockFlg = m_Aceum01Form.isPassLockFlg();

		// アカウントロックフラグ取得
		boolean actLockFlg = m_Aceum01Form.isActLockFlg();

		try {

			// ユーザーコードリストの作成
			List<String> list = getUserListData(cstCd, shopCd, systemDt);
			// SQL作成
			makeSearchSql(userId, list,  roleCd,  passLockFlg, actLockFlg, systemDt);

			// select句
			String sqlSelect = m_Page_Sql.getSqlSelect();
			// from where 句
			String sqlCondition = m_Page_Sql.getSqlConditinon();
			// order 句
			String sqlOrder = m_Page_Sql.getSqlOrder();
			// param 句
			String[] sqlParam = m_Page_Sql.getSqlParam();
			// 表示件数
			int pageDispCnt = m_Page_Sql.getPageDispCnt();
			// ページ番号
			int pageNo = m_Aceum01Dto.getDisplayNum();

			List<Map<String, String>> pageData;
			if (m_Event.equals(FORWARD_DISP)) {
				// 初期検索状態
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEFIRST)) {
				// "<<"ボタン押下時
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEPREV)) {
				// "<"ボタン押下時
				pageData = m_Page.getPrevPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGENEXT)) {
				// ">"ボタン押下時
				pageData = m_Page.getNextPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGELAST)) {
				// ">>"ボタン押下時
				pageData = m_Page.getLastPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else {
				// 検索ボタン押下時、その他
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam,	pageDispCnt);
			}
			// 表示頁NOのセット
			m_Aceum01Dto.setDisplayNum(m_Page.getNowPage());
			m_Aceum01DispBean.setDisplayNum(m_Page.getNowPage());
			// ページ遷移ボタンセット
			if (!m_Page.isPrevPageExist()) {
				m_Aceum01DispBean.setPrevPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Aceum01DispBean.setPrevPageFlg(AmallConst.GeneralFlg.OFF);
			}
			if (!m_Page.isNextPageExist()) {
				m_Aceum01DispBean.setNextPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Aceum01DispBean.setNextPageFlg(AmallConst.GeneralFlg.OFF);
			}

			// 件数セット
			m_Aceum01Dto.setDisplayCount(pageDispCnt);
			m_Aceum01DispBean.setDispCountDefault(String.valueOf(pageDispCnt));

			// ページ情報がない場合
			if (pageData == null) {
				// エラーメッセージをセット
				setMessageInfo(m_Aceum01DispBean, AmallMessageConst.MSG_INF_SEARCH_CON_NO_DATA);
				return FORWARD_DISP;

			}

			/** 明細部リスト作成 **/
			detailList = makeDetailList(m_Page.getNowPage(), pageData);

			// ActionForm一覧データをセット
			m_Aceum01Form.setItemDispList(detailList);

			return FORWARD_DISP;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "Page Proc");
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		}
	}
	/*************************************************************************************
	 * ユーザーリスト作成
	 * <p>
	 * 対象ユーザーのリストを作成する
	 * 条件に応じたユーザーリスト取得処理を行う
	 * 条件の違うリスト取得方式をマージさせる処理を行う。
	 * </p>
	 * @param cstCd 顧客コード
	 * @param shopCd 店舗コード
	 * @param systemDt システム日付
	 * @return SQL
	 ************************************************************************************/
	private List<String> getUserListData(String cstCd, String shopCd, String systemDt) throws AmallException, Exception {

		// 返却リスト
		List<String> retList = new ArrayList<>();
		// 取得リスト
		List<String> getList = new ArrayList<>();

		// == 通常取得処理 ==
		getList = getUserNoConSpec(cstCd, shopCd, systemDt);

		// マージ処理
		for (String data : getList) {
			if (!retList.contains(data)) {
				// 含まれていない場合追加
				retList.add(data);
			}
		}

		// == 条件別取得処理を記載 ==

		return retList;

	}
	/*************************************************************************************
	 * 通常取得処理取得
	 * <p>
	 * 対象ユーザーのリストを作成する
	 * 条件：なし
	 * </p>
	 * @param cstCd 顧客コード
	 * @param shopCd 店舗コード
	 * @param systemDt システム日付
	 * @return List<String> ユーザーリスト
	 ************************************************************************************/
	private List<String> getUserNoConSpec(String cstCd, String shopCd, String systemDt) throws AmallException, Exception {

		String methodName = "getUserNoConSpec()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<String> retList = new ArrayList<>();

		// パラメタ用リスト
		List<String> paramList = new ArrayList<>();

		// ログイン情報取得
		AmdtoLoginInfo loginInfo = getLoginInfoDTO();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	nucm.USER_ID");
			sql.append("  FROM");
			sql.append("	(");
			sql.append("		SELECT");
			sql.append("			USER_ID");
			sql.append(",			USER_NM");
			sql.append(",			CST_GRP_CD");
			sql.append(",			CST_CD");
			sql.append(",			SHOP_CD");
			sql.append(",			DEL_FLG");
			sql.append("		 FROM");
			sql.append("			N_USER_CST_M");

			// システム種別によってテーブルを追加する
			if (m_Aceum01Form.getM_systemKind() == SystemType.BUSINESS) {
				// 業務支援の場合
				sql.append("		UNION ALL");
				sql.append("		SELECT");
				sql.append("			USER_ID");
				sql.append(",			USER_NM");
				sql.append(",			CST_GRP_CD");
				sql.append(",			CST_CD");
				sql.append(",			SHOP_CD");
				sql.append(",			DEL_FLG");
				sql.append("		 FROM");
				sql.append("			N_USER_EMP_M");
			}
			sql.append("	) nucm");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_CNV_M nscm");
			sql.append("	  ON");
			sql.append("		nucm.CST_CD = nscm.CST_CD");
			sql.append("		AND nucm.SHOP_CD = nscm.SHOP_CD");
			// 有効期間
			sql.append("		AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
			paramList.add(systemDt);
			sql.append("		AND nscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append(" WHERE");
			sql.append("	nucm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			// 検索条件が指定されていないかつ全顧客フラグの場合
			if (AmallUtilities.isEmpty(cstCd) && AmallUtilities.isEmpty(shopCd) &&
					m_Aceum01DispBean.isCustomerCdAllFlg()) {
				// 条件指定なし
			} else {
				sql.append("	AND (");
				sql.append("			(");
				sql.append("				1=1");
				// 顧客コードの指定がある場合
				if (!AmallUtilities.isEmpty(cstCd)) {
					sql.append("				AND");
					sql.append("				nucm.CST_CD = ?");
					paramList.add(cstCd);
				}
				// 顧客範囲設定
				// 全顧客判定
				if (!m_Aceum01DispBean.isCustomerCdAllFlg()) {
					// 全顧客ではない場合
					sql.append("				AND");
					sql.append("				nucm.CST_CD IN (");
					for (String appCustomer : m_Aceum01DispBean.getCustomerCdList()) {
						sql.append("'").append(appCustomer).append("',");
					}
					sql.append("'')");
				}
				sql.append("			)");
				// 顧客グループ指定あり
				if(!AmallUtilities.isEmpty(loginInfo.getM_Customer_Grp_Cd())) {
					sql.append("		OR (");
					// 全顧客フラグ
					if (!m_Aceum01DispBean.isCustomerCdAllFlg()) {
						// 全顧客ではない場合
						sql.append("			nucm.CST_GRP_CD = ?");
						paramList.add(loginInfo.getM_Customer_Grp_Cd());
						sql.append("			AND");
					}
					sql.append("				nucm.CST_GRP_CD IN (");
					sql.append("										SELECT");
					sql.append("											ncgm.CST_GRP_CD");
					sql.append("										  FROM");
					sql.append("											N_CST_GRP_M ncgm");
					sql.append("										 WHERE");
					sql.append("											EXISTS (");
					sql.append("													SELECT");
					sql.append("														exncm.CST_CD");
					sql.append("													  FROM");
					sql.append("														n_cst_m exncm");
					sql.append("													 WHERE");
					sql.append("														ncgm.CST_CD = exncm.CST_CD");
					// 顧客コードの指定がある場合
					if (!AmallUtilities.isEmpty(cstCd)) {
						sql.append("														AND");
						sql.append("														exncm.CST_CD = ?");
						paramList.add(cstCd);
					}
					// 顧客範囲設定
					// 全顧客判定
					if (!m_Aceum01DispBean.isCustomerCdAllFlg()) {
						// 全顧客ではない場合
						sql.append("														AND");
						sql.append("														exncm.CST_CD IN (");
						for (String appCustomer : m_Aceum01DispBean.getCustomerCdList()) {
							sql.append("'").append(appCustomer).append("',");
						}
						sql.append("'')");
					}
					sql.append("											)");
					sql.append("											AND ncgm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
					sql.append("							 			GROUP BY");
					sql.append("											ncgm.CST_GRP_CD");
					sql.append("				)");
					sql.append("		)");
				}
				sql.append("	)");
				sql.append("	AND (");
				sql.append("			(");
				sql.append("				1=1");
				if (!AmallUtilities.isEmpty(shopCd)) {
					// 店舗コードが存在する場合(お客様店舗コードも検索対象)
					sql.append("				AND (");
					sql.append("					nucm.SHOP_CD = ?");
					sql.append("					OR");
					sql.append("					TRIM(nscm.COMPANY_SHOP_CD) = ?");
					sql.append("				)");
					paramList.add(shopCd);
					paramList.add(shopCd);
				}
				// 店舗範囲設定
				// 全店舗判定
				if (!m_Aceum01DispBean.isShopCdAllFlg()) {
					// 全顧客・全店舗ではない場合
					sql.append("				AND (");
					boolean first = true;
					for (Entry<String, List<String>> entry : m_Aceum01DispBean.getShopCdListMap().entrySet()) {

						String appCstCd = entry.getKey();
						for (String appShop : entry.getValue()) {
							if(first) {
								sql.append("			");
								first = false;
							} else {
								sql.append("			OR");
							}
							sql.append("				(");
							sql.append("					nucm.CST_CD = '").append(appCstCd).append("'");
							sql.append("					AND");
							sql.append("					nucm.SHOP_CD = '").append(appShop).append("'");
							sql.append("				)");
						}
					}
					sql.append("				)");
				}
				sql.append("			)");
				sql.append("			OR (");
				sql.append("				nucm.USER_ID IN (");
				sql.append("									SELECT");
				sql.append("										nsgmm.USER_ID");
				sql.append("									  FROM");
				sql.append("										N_SHOP_GRP_MNG_M nsgmm");
				sql.append("									 WHERE");
				sql.append("										nsgmm.SHOP_GRP_CD IN (");
				sql.append("																SELECT");
				sql.append("																	nsgm.SHOP_GRP_CD");
				sql.append("									  							  FROM");
				sql.append("																	N_SHOP_GRP_M nsgm");
				sql.append("																 WHERE");
				sql.append("																	EXISTS (");
				sql.append("																			SELECT");
				sql.append("																				exnsm.SHOP_CD");
				sql.append("																			  FROM");
				sql.append("																				n_shop_m exnsm");
				sql.append("																				LEFT JOIN");
				sql.append("																					N_SHOP_CNV_M exnscm");
				sql.append("	 																			  ON");
				sql.append("																					exnsm.CST_CD = exnscm.CST_CD");
				sql.append("																					AND exnsm.SHOP_CD = exnscm.SHOP_CD");
				// 有効期間
				sql.append("																					AND ? BETWEEN exnscm.EFST_DY AND exnscm.EFED_DY");
				paramList.add(systemDt);
				sql.append("																					AND exnscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
				sql.append("												 							 WHERE");
				sql.append("																				nsgm.CST_CD = exnsm.CST_CD");
				sql.append("																				AND");
				sql.append("																				nsgm.SHOP_CD = exnsm.SHOP_CD");
				// 有効期間
				sql.append("																				AND ? BETWEEN exnsm.EFST_DY AND exnsm.EFED_DY");
				sql.append("																				AND exnsm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
				paramList.add(systemDt);
				// 店舗コードが存在する場合(お客様店舗コードも検索対象)
				if (!AmallUtilities.isEmpty(shopCd)) {
					sql.append("																				AND (");
					sql.append("																						exnsm.SHOP_CD = ?");
					sql.append("																						OR");
					sql.append("																						TRIM(exnscm.COMPANY_SHOP_CD) = ?");
					sql.append("																				)");
					paramList.add(shopCd);
					paramList.add(shopCd);
				}
				// 店舗範囲設定
				// 全店舗判定
				if (!m_Aceum01DispBean.isShopCdAllFlg()) {
					// 全顧客・全店舗ではない場合
					sql.append("																				AND (");
					boolean first = true;
					for (Entry<String, List<String>> entry : m_Aceum01DispBean.getShopCdListMap().entrySet()) {

						String appCstCd = entry.getKey();
						for (String appShop : entry.getValue()) {
							if(first) {
								sql.append("																		");
								first = false;
							} else {
								sql.append("																		OR");
							}
							sql.append("																			(");
							sql.append("																				exnsm.CST_CD = '").append(appCstCd).append("'");
							sql.append("																				AND");
							sql.append("																				exnsm.SHOP_CD = '").append(appShop).append("'");
							sql.append("																			)");
						}
					}
					sql.append("																				)");
				}
				sql.append("																	)");
				sql.append("																	AND nsgm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
				sql.append("							 									 GROUP BY");
				sql.append("																	nsgm.SHOP_GRP_CD");
				sql.append("										)");
				sql.append("										AND nsgmm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
				sql.append("									 GROUP BY");
				sql.append("										nsgmm.USER_ID");
				sql.append("				)");
				sql.append("			)");
				sql.append("	)");
			}
			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < paramList.size(); i++) {
				m_DbAccess.setString(i + 1, paramList.get(i));
			}

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				// ユーザーID
				String userId = m_DbAccess.getString(rs, "USER_ID");

				// リストに追加
				retList.add(userId);

			}
			return retList;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_USER_XXX_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	/*************************************************************************************
	 * SQL作成
	 * <p>
	 * SQLを作成する
	 * </p>
	 * @param userId ユーザーCD
	 * @param userList ユーザーリスト
	 * @param roleCd 権限ロールコード
	 * @param passFlg パスワードロックフラグ
	 * @param actFlg アカウントロックフラグ
	 * @param systemDt システム日付
	 * @return SQL
	 ************************************************************************************/
	private void makeSearchSql(String userId, List<String> userList, String roleCd, boolean passFlg, boolean actFlg,  String systemDt)
			throws AmallException, Exception {

		String methodName = "makeSearchSql()";

		StringBuffer sql = new StringBuffer();
		List<String> list = new ArrayList<>();

		try {
			// 1ページの表示件数
			// 初期表示はデフォルト値を設定する
			if (m_Event.equals(FORWARD_DISP)) {

				m_Page_Sql.setPageDispCnt(Integer.parseInt(m_Aceum01DispBean.getDispCountDefault()));

			} else if (m_Event.equals(FORWARD_SEARCH)) {
				// 検索ボタン押下時に表示検索がないときはデフォルト値とする
				int dispCnt = m_Aceum01Form.getDispResults();
				if (dispCnt == 0) {
					m_Page_Sql.setPageDispCnt(Integer.parseInt(m_Aceum01DispBean.getDispCountDefault()));
				} else {
					m_Page_Sql.setPageDispCnt(dispCnt);
				}
			} else if (m_Event.equals(FORWARD_RETURNPAGE)) {
				// 戻る処理はDTOから件数を取得する
				m_Page_Sql.setPageDispCnt(m_Aceum01Dto.getDisplayCount());

			} else {
				m_Page_Sql.setPageDispCnt(m_Aceum01Form.getDispResults());
			}

			// SQL SELECT
			sql.delete(0, sql.length());

			sql.append("SELECT");
			sql.append("	CASE");
			sql.append("		WHEN nucm.CST_GRP_CD = '").append(AmallConst.CUSTOMER_GRP_CD_ALL).append("' THEN ''");
			sql.append("		ELSE nucm.CST_CD");
			sql.append("	END AS CST_CD");
			sql.append(",	CASE");
			sql.append("		WHEN nucm.CST_GRP_CD = '").append(AmallConst.CUSTOMER_GRP_CD_ALL).append("' THEN '").append(AmallConst.EMP_NAME).append("'");
			sql.append("		ELSE ncm.CST_NM");
			sql.append("	END AS CST_NM");
			sql.append(",	CASE");
			sql.append("		WHEN nucm.CST_GRP_CD = '").append(AmallConst.CUSTOMER_GRP_CD_ALL).append("' THEN ''");
			sql.append("		ELSE nucm.SHOP_CD");
			sql.append("	END AS SHOP_CD");
			sql.append(",	CASE");
			sql.append("		WHEN nucm.CST_GRP_CD = '").append(AmallConst.CUSTOMER_GRP_CD_ALL).append("' THEN '-'");
			sql.append("		WHEN EXISTS(");
			sql.append("					SELECT");
			sql.append("						 *");
			sql.append("					  FROM");
			sql.append("						N_SHOP_GRP_MNG_M nsgmm");
			sql.append("					 WHERE");
			sql.append("						nsgmm.USER_ID = nucm.USER_ID");
			sql.append("					) THEN '").append(AmallConst.SHOP_GRP_EXISTS).append("'");
			sql.append("		ELSE nsm.SHOP_NM");
			sql.append("	END AS SHOP_NM");
			sql.append(",	TRIM(nscm.COMPANY_SHOP_CD) AS COMPANY_SHOP_CD");
			sql.append(",	TRIM(nscm.COMPANY_SHOP_NM) AS COMPANY_SHOP_NM");
			sql.append(",	nucm.USER_ID");
			sql.append(",	nucm.USER_NM");
			sql.append(",	nrgm.ROLE_GRP_NM");
			sql.append(",	nucm.ACCOUNT_LOCK");
			sql.append(",	nucm.EXCLUSIVE_KEY");
			sql.append(",	nucm.SYSTEM_KIND");
			sql.append(",	CASE");
			sql.append("		WHEN nucm.ACCOUNT_LOCK = '").append(LoginFlg.LOCK_OUT).append("' THEN '").append(LoginFlg.ACCOUNT_LOCK_OUT_NM).append("'");
			sql.append("		WHEN nucm.PASSWORD_LOCK = '").append(LoginFlg.LOCK_OUT).append("' THEN '").append(LoginFlg.PASSWORD_LOCK_OUT_NM).append("'");
			sql.append("		ELSE ''");
			sql.append("	END AS STATUS");

			String sqlSelect = sql.toString();


			// SQL FROM & WHERE
			sql.delete(0, sql.length());
			sql.append("  FROM");
			sql.append("	(");
			sql.append("		SELECT");
			sql.append("			USER_ID");
			sql.append(",			USER_NM");
			sql.append(",			CST_GRP_CD");
			sql.append(",			ROLE_GRP_CD");
			sql.append(",			ACCOUNT_LOCK");
			sql.append(",			PASSWORD_LOCK");
			sql.append(",			EXCLUSIVE_KEY");
			sql.append(",			CST_CD");
			sql.append(",			SHOP_CD");
			sql.append(",			DEL_FLG");
			sql.append(",			").append(SystemType.CUSTOMER).append(" AS SYSTEM_KIND");
			sql.append("		 FROM");
			sql.append("			N_USER_CST_M");

			// システム種別によってテーブルを追加する
			if (m_Aceum01Form.getM_systemKind() == SystemType.BUSINESS) {
				// 業務支援の場合
				sql.append("		UNION ALL");
				sql.append("		SELECT");
				sql.append("			USER_ID");
				sql.append(",			USER_NM");
				sql.append(",			CST_GRP_CD");
				sql.append(",			ROLE_GRP_CD");
				sql.append(",			ACCOUNT_LOCK");
				sql.append(",			PASSWORD_LOCK");
				sql.append(",			EXCLUSIVE_KEY");
				sql.append(",			CST_CD");
				sql.append(",			SHOP_CD");
				sql.append(",			DEL_FLG");
				sql.append(",			").append(SystemType.BUSINESS).append(" AS SYSTEM_KIND");
				sql.append("		 FROM");
				sql.append("			N_USER_EMP_M");
			}
			sql.append("	) nucm");

			sql.append("	LEFT JOIN");
			sql.append("		N_CST_M ncm");
			sql.append("	  ON");
			sql.append("		nucm.CST_CD = ncm.CST_CD");
			sql.append("		AND ncm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_M nsm");
			sql.append("	  ON");
			sql.append("		nucm.CST_CD = nsm.CST_CD");
			sql.append("		AND nucm.SHOP_CD = nsm.SHOP_CD");
			// 有効期間
			sql.append("		AND ? BETWEEN nsm.EFST_DY AND nsm.EFED_DY");
			list.add(systemDt);
			sql.append("		AND nsm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_CNV_M nscm");
			sql.append("	  ON");
			sql.append("		nucm.CST_CD = nscm.CST_CD");
			sql.append("		AND nucm.SHOP_CD = nscm.SHOP_CD");
			// 有効期間
			sql.append("		AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
			list.add(systemDt);
			sql.append("		AND nscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_ROLE_GRP_M nrgm");
			sql.append("	  ON");
			sql.append("		nucm.ROLE_GRP_CD = nrgm.ROLE_GRP_CD");
			sql.append("		AND nrgm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");

			sql.append(" WHERE");
			sql.append("	1 = 1");

			// ユーザーID
			if(!AmallUtilities.isEmpty(userId)) {
				// ユーザーIDが存在する場合
				sql.append("	AND nucm.USER_ID = ?");
				list.add(userId);
			}
			// 権限
			if(!AmallUtilities.isEmpty(roleCd)) {
				// 権限が存在する場合
				sql.append("	AND nucm.ROLE_GRP_CD = ?");
				list.add(roleCd);
			}
			// パスワードロック
			if(passFlg) {
				// パスワードロックされているユーザーのみ表示
				sql.append("	AND nucm.PASSWORD_LOCK = '").append(LoginFlg.LOCK_OUT).append("'");
			}

			// アカウントロック
			if(!actFlg) {
				// アカウントロックされているユーザーも表示(通常は表示しない)
				sql.append("	AND nucm.ACCOUNT_LOCK = '").append(LoginFlg.LOCK_OUT_OFF).append("'");
			}

			// 削除フラグ
			sql.append("	AND nucm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");

			// 対象ユーザーIDリストが存在する場合
			if (userList.size() > 0) {
				sql.append("	AND nucm.USER_ID IN (");
				for (String trgtUser : userList) {
					sql.append("'").append(trgtUser).append("',");
				}
				sql.append("'')");
			}

			String sqlCondition = sql.toString();


			// SQL ORDER
			sql.delete(0, sql.length());
			sql.append("  ORDER BY");
			sql.append("	ncm.CST_CD");
			sql.append(",	nsm.SHOP_CD");
			sql.append(",	nucm.USER_ID");
			String sqlOrder = sql.toString();


			// 配列変換
			String[] sqlParam = list.toArray(new String[list.size()]);


			// セット処理
			m_Page_Sql.setSqlSelect(sqlSelect);
			m_Page_Sql.setSqlConditinon(sqlCondition);
			m_Page_Sql.setSqlOrder(sqlOrder);
			m_Page_Sql.setSqlParam(sqlParam);

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}
	/*************************************************************************************
	 * 明細リスト作成処理
	 * <p>
	 * 明細リスト作成処理を実行する
	 * </p>
	 * @param  pageSize	頁数
	 * @param	pageData	頁データ
	 * @return 明細ArrayList
	 ************************************************************************************/
	private List<AceumItemDispDto> makeDetailList(int pageSize, List<Map<String, String>> pageData)
			throws AmallException {

		String methodName = "makeDetailList()";

		// 返却リスト
		List<AceumItemDispDto> retList = new ArrayList<>();

		try {
			// ページ情報をリストに追加
			for (Map<String, String> map : pageData) {

				AceumItemDispDto listdto = new AceumItemDispDto();

				// 顧客コード
				listdto.setCstCd(map.get("CST_CD"));
				// 顧客名
				listdto.setCstNm(map.get("CST_NM"));

				// 企業店舗コード判定
				if (AmallUtilities.isEmpty(map.get("COMPANY_SHOP_CD"))) {
					// 店舗コード
					listdto.setShopCd(map.get("SHOP_CD"));
				} else {
					// 企業店舗コードがある場合は企業店舗を優先
					// 企業店舗コード
					listdto.setShopCd(map.get("COMPANY_SHOP_CD"));
				}
				// 企業店舗名判定
				if (AmallUtilities.isEmpty(map.get("COMPANY_SHOP_NM"))) {
					// 店舗コード
					listdto.setShopNm(map.get("SHOP_NM"));
				} else {
					// 企業店舗名がある場合は企業店舗を優先
					// 企業店舗名
					listdto.setShopNm(map.get("COMPANY_SHOP_NM"));
				}
				// ユーザーID
				listdto.setUserId(map.get("USER_ID"));
				// ユーザー名
				listdto.setUserNm(map.get("USER_NM"));
				// 権限ロール
				listdto.setRole(map.get("ROLE_GRP_NM"));
				// ステータス
				listdto.setStatus(map.get("STATUS"));
				// 行スタイル指定
				if (LoginFlg.LOCK_OUT.equals(map.get("ACCOUNT_LOCK"))) {
					listdto.setTrStyle(CssStyleCom.CAUTION);
				}
				// 排他キー
				Long key = Long.valueOf(map.get("EXCLUSIVE_KEY"));
				listdto.setExclusiveKey(key);

				// システム種別
				int kind = Integer.valueOf(map.get("SYSTEM_KIND"));
				listdto.setSystemKind(kind);

				// 返却リストに追加
				retList.add(listdto);
			}

			return retList;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

	}
}