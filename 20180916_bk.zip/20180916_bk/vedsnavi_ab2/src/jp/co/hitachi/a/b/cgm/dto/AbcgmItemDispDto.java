/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abcgm02Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.cgm.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * AbcgmItemDispDtoクラス<br>
 *****************************************************************************************/
public class AbcgmItemDispDto extends AmclsDtoBase{

	/** メンバ変数 */
	/** お客様グループコード */
	private String cstGrpCd = null;
	/** お客様グループ名 */
	private String cstGrpNm = null;
	/** お客様件数 */
	private Long cstCount = null;
	/** 顧客CD */
	private String cstCd = null;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public AbcgmItemDispDto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		cstGrpCd = null;
		cstGrpNm = null;
		cstCount = null;
		cstCd = null;
	}
	public String getCstGrpCd() {
		return cstGrpCd;
	}
	public void setCstGrpCd(String cstGrpCd) {
		this.cstGrpCd = cstGrpCd;
	}
	public String getCstGrpNm() {
		return cstGrpNm;
	}
	public void setCstGrpNm(String cstGrpNm) {
		this.cstGrpNm = cstGrpNm;
	}
	public Long getCstCount() {
		return cstCount;
	}
	public void setCstCount(Long cstCount) {
		this.cstCount = cstCount;
	}
	public String getCstCd() {
		return cstCd;
	}
	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}


}
