/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abiam01Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.dto;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Abiam01Dtoクラス<br>
 *****************************************************************************************/
public class Abiam01Dto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 更新対象データマップ */
	private Map<String, List<AbiamScreenAuthDto>> updateDataMap = null;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public Abiam01Dto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		updateDataMap = new ConcurrentHashMap<>();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Map<String, List<AbiamScreenAuthDto>> getUpdateDataMap() {
		return updateDataMap;
	}
	public void setUpdateDataMap(Map<String, List<AbiamScreenAuthDto>> updateDataMap) {
		this.updateDataMap = updateDataMap;
	}
}
