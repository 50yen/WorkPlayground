/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acssi02DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ssi.bean;

import java.util.ArrayList;
import java.util.List;

import jp.co.hitachi.a.m.cls.AmclsBeanBase;
import jp.co.hitachi.a.m.dto.AmdtoChildSelectInfo;

/*****************************************************************************************
 * Acssi02DispBeanクラス<br>
 *****************************************************************************************/
public class Acssi02DispBean extends AmclsBeanBase {

	/** メンバ変数 */
	/** 現ページ */
	private int displayNum = 0;
	/** 前ページフラグ */
	private String prevPageFlg = null;
	/** 次ページフラグ */
	private String nextPageFlg = null;

	/** 一覧表示 */
	private List<AmdtoChildSelectInfo> itemDispList = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Acssi02DispBean() {
		super();
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		super.clear();
		displayNum = 0;
		prevPageFlg = null;
		nextPageFlg = null;
		itemDispList = new ArrayList<>();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public int getDisplayNum() {
		return displayNum;
	}

	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}

	public String getPrevPageFlg() {
		return prevPageFlg;
	}

	public void setPrevPageFlg(String prevPageFlg) {
		this.prevPageFlg = prevPageFlg;
	}

	public String getNextPageFlg() {
		return nextPageFlg;
	}

	public void setNextPageFlg(String nextPageFlg) {
		this.nextPageFlg = nextPageFlg;
	}

	public List<AmdtoChildSelectInfo> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<AmdtoChildSelectInfo> itemDispList) {
		this.itemDispList = itemDispList;
	}

}
