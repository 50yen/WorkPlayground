/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abiam01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.action;

import java.util.List;

import jp.co.hitachi.a.b.iam.bean.Abiam01DispBean;
import jp.co.hitachi.a.b.iam.business.Abiam01Business;
import jp.co.hitachi.a.b.iam.dto.AbiamScreenAuthDto;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Abiam01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Abiam01DispBean abiam01DispBean;

	/** カテゴリプルダウン選択値 */
	private String selectedCategoryCd = null;
	/** メニュープルダウン選択値 */
	private String selectedMenuCd = null;
	/** 画面名プルダウン選択値 */
	private String selectedScreenCd = null;

	/** カテゴリプルダウン選択値(検索ボタン押下保存値) */
	private String savedCategoryCd = null;
	/** メニューロールプルダウン選択値(検索ボタン押下保存値) */
	private String savedMenuCd = null;
	/** 画面名プルダウン選択値(検索ボタン押下保存値) */
	private String savedScreenCd = null;

	/** 一覧表示用データ */
	private List<AbiamScreenAuthDto> screenDispList = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAbiam01DispBean((Abiam01DispBean)request.getAttribute("Abiam01DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Abiam01Business dao = new Abiam01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Abiam01DispBean getAbiam01DispBean() {
		return abiam01DispBean;
	}

	public void setAbiam01DispBean(Abiam01DispBean abiam01DispBean) {
		this.abiam01DispBean = abiam01DispBean;
	}

	public String getSelectedCategoryCd() {
		return selectedCategoryCd;
	}

	public void setSelectedCategoryCd(String selectedCategoryCd) {
		this.selectedCategoryCd = selectedCategoryCd;
	}

	public String getSelectedMenuCd() {
		return selectedMenuCd;
	}

	public void setSelectedMenuCd(String selectedMenuCd) {
		this.selectedMenuCd = selectedMenuCd;
	}

	public String getSelectedScreenCd() {
		return selectedScreenCd;
	}

	public void setSelectedScreenCd(String selectedScreenCd) {
		this.selectedScreenCd = selectedScreenCd;
	}

	public String getSavedCategoryCd() {
		return savedCategoryCd;
	}

	public void setSavedCategoryCd(String savedCategoryCd) {
		this.savedCategoryCd = savedCategoryCd;
	}

	public String getSavedMenuCd() {
		return savedMenuCd;
	}

	public void setSavedMenuCd(String savedMenuCd) {
		this.savedMenuCd = savedMenuCd;
	}

	public String getSavedScreenCd() {
		return savedScreenCd;
	}

	public void setSavedScreenCd(String savedScreenCd) {
		this.savedScreenCd = savedScreenCd;
	}

	public List<AbiamScreenAuthDto> getScreenDispList() {
		return screenDispList;
	}

	public void setScreenDispList(List<AbiamScreenAuthDto> screenDispList) {
		this.screenDispList = screenDispList;
	}


}
