/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abcgm01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.cgm.business;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.b.cgm.action.Abcgm01Action;
import jp.co.hitachi.a.b.cgm.bean.Abcgm01DispBean;
import jp.co.hitachi.a.b.cgm.dto.Abcgm01Dto;
import jp.co.hitachi.a.b.cgm.dto.AbcgmItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallPage;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoPagingSql;

/*****************************************************************************************
 * Abcgm01Businessクラス<br>
 *****************************************************************************************/
public class Abcgm01Business extends AbcgmBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Abcgm01DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	private static final String FORWARD_DISP = "DISP";
	/** 画面遷移 */
	private static final String FORWARD_DETAIL = "DETAIL";
	/** 検索 */
	private static final String FORWARD_SEARCH = "SEARCH";
	/** 登録 */
	private static final String FORWARD_REGIST = "REGIST";
	/** 先頭頁処理 */
	private static final String FORWARD_PAGEFIRST = "PAGEFIRST";
	/** 前頁 */
	private static final String FORWARD_PAGEPREV = "PAGEPREV";
	/** 次頁 */
	private static final String FORWARD_PAGENEXT = "PAGENEXT";
	/** 最終頁 */
	private static final String FORWARD_PAGELAST = "PAGELAST";
	/** 件数変更 */
	private static final String FORWARD_DISPRESULTS = "DISPRESULTS";
	/** 編集ボタン */
	private static final String FORWARD_EDIT = "EDIT";
	/** コピーボタン */
	private static final String FORWARD_COPY = "COPY";
	/** 戻る処理 */
	private static final String FORWARD_REDISP = "REDISP";
	/** 戻る(削除完了時)処理 */
	private static final String FORWARD_DELDISP = "DELDISP";
	/** 画面DTOキー */
	private static final String DTO_Abcgm01 = "DTO_ABCGM01";

	/**
	 * 画面項目ID
	 */
	//  画面のフォームのIDを設定する(エラー状態時のキー値用)
	/** お客様コード */
	private static final String ITEM_ID_CUSTOMERSEARCH = "customerSearchNm";

	/** お客様グループコード */
	private static final String ITEM_ID_CUSTOMERGROUPCD = "customerGroupCd";


	/** メンバ変数 */
	// フォームとBeanの変数をメンバ変数で定義 フォームから画面上の入力値が取得可能
	/** アクションフォーム */
	private Abcgm01Action m_Abcgm01Form = null;
	/** 表示用画面Bean */
	private Abcgm01DispBean m_Abcgm01DispBean = null;
	/** ページング処理用 */
	private AmallPage m_Page = null;
	/** SQL作成用 */
	private AmdtoPagingSql m_Page_Sql = null;
	/** 画面DTO */
	private Abcgm01Dto m_Abcgm01Dto = null;



	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Abcgm01Business(
			Abcgm01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Abcgm01Business.class.getName();
		m_Abcgm01Form = form;
		m_Abcgm01DispBean = new Abcgm01DispBean();
		m_Page = new AmallPage();
		m_Page_Sql = new AmdtoPagingSql();
		m_Abcgm01Dto = new Abcgm01Dto();
		setErrString(gid, m_Abcgm01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Abcgm01DispBean);

			/* 内部記憶情報の生成 */
			m_Abcgm01Dto = (Abcgm01Dto) getSpecifiedDTO(m_Gid, DTO_Abcgm01);
			if (m_Abcgm01Dto == null || FORWARD_DISP.equals(m_Event)) {
				deleteSpecifiedDTO(m_Gid);
				m_Abcgm01Dto = new Abcgm01Dto();
				putSpecifiedDTO(m_Gid, DTO_Abcgm01, m_Abcgm01Dto);
			}

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Abcgm01Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_SEARCH.equals(m_Event)) {
				// 検索ボタン押下の場合
				forwardStr = search();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				// 登録ボタン押下の場合
				forwardStr = regist();
			} else if (FORWARD_PAGEFIRST.equals(m_Event)) {
				// "<<"ボタン押下の場合
				forwardStr = pageFirst();
			} else if (FORWARD_PAGEPREV.equals(m_Event)) {
				// "<"ボタン押下の場合
				forwardStr = pagePrev();
			} else if (FORWARD_PAGENEXT.equals(m_Event)) {
				// ">"ボタン押下の場合
				forwardStr = pageNext();
			} else if (FORWARD_PAGELAST.equals(m_Event)) {
				// ">>"ボタン押下の場合
				forwardStr = pageLast();
			} else if (FORWARD_DISPRESULTS.equals(m_Event)) {
				// 表示件数変更の場合
				forwardStr = changeDispRslts();
			} else if (FORWARD_EDIT.equals(m_Event)) {
				// 編集ボタン押下処理の場合
				forwardStr = edit();
			}else if (FORWARD_COPY.equals(m_Event)) {
				// コピーボタン押下処理の場合
				forwardStr = copy();
			} else if (FORWARD_REDISP.equals(m_Event)) {
				// 戻るボタン押下処理の場合
				forwardStr = redisp(false);
			} else if (FORWARD_DELDISP.equals(m_Event)) {
				// 戻るボタン押下処理の場合
				forwardStr = redisp(true);
			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Abcgm01DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 検索ボタン押下処理実行
	 * <p>
	 * 検索ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String search() throws AmallException, Exception {

		// 入力値チェック
		if (!inputCheck()) {
			// エラーの場合
			return FORWARD_DISP;
		}

		// 検索処理を呼ぶ
		searchProc();
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * "<"ボタン押下処理実行
	 * <p>
	 * "<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pagePrev() throws AmallException {

		// 検索処理を呼ぶ
		searchProc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * "<<"ボタン押下処理実行
	 * <p>
	 * "<<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageFirst() throws AmallException {

		// 検索処理を呼ぶ
		searchProc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ">"ボタン押下処理実行
	 * <p>
	 * ">"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageNext() throws AmallException {

		// 検索処理を呼ぶ
		searchProc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ">>"ボタン押下処理実行
	 * <p>
	 * ">>"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageLast() throws AmallException {

		// 検索処理を呼ぶ
		searchProc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 表示件数変更処理実行
	 * <p>
	 * 表示件数変更処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String changeDispRslts() throws AmallException {

		// 検索処理を呼ぶ
		searchProc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 登録処理
	 * <p>
	 * 登録処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException {

		AbcgmItemDispDto dto = new AbcgmItemDispDto();
		putSpecifiedDTO(ABCGM_INFO_KEY, dto);

		return FORWARD_DETAIL;
	}
	/*************************************************************************************
	 * 編集ボタン押下処理
	 * <p>
	 * 編集ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String edit() throws AmallException {

		//編集対象顧客グループコードチェック
		if(AmallUtilities.isEmpty(m_Abcgm01Form.getCstGrpCdHid())) {
			// エラーメッセージセット
			setMessageInfo(m_Abcgm01DispBean, AmallMessageConst.MSG_ERR_SELECT_CON_NO_DATA,
					getItemDispName(ITEM_ID_CUSTOMERGROUPCD, m_Abcgm01DispBean));
			// 検索処理を呼ぶ
			searchProc();
			return FORWARD_DISP;
		}
		// 顧客グループコードをdtoにセット
		AbcgmItemDispDto dto = new AbcgmItemDispDto();
		dto.setCstGrpCd(m_Abcgm01Form.getCstGrpCdHid());
		putSpecifiedDTO(ABCGM_INFO_KEY, dto);

		return FORWARD_DETAIL;
	}

	/*************************************************************************************
	 * コピーボタン押下処理
	 * <p>
	 * コピーボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String copy() throws AmallException {

		boolean ret = false;

		//コピー対象顧客グループコードチェック
		if(AmallUtilities.isEmpty(m_Abcgm01Form.getCstGrpCdHid())) {
			setMessageInfo(m_Abcgm01DispBean, AmallMessageConst.MSG_ERR_FAIL_COPY);
			// 検索処理を呼ぶ
			searchProc();
			return FORWARD_DISP;
		}

		//コピー処理を呼ぶ
		ret = copyProc();

		// DB処理正常判定
		if (ret) {
			// コミット処理
			m_DbAccess.commit();

			// 顧客グループコードをdtoにセット
			AbcgmItemDispDto dto = new AbcgmItemDispDto();
			dto.setCstGrpCd(m_Abcgm01Form.getCstGrpCdHid());
			putSpecifiedDTO(ABCGM_INFO_KEY, dto);

			return FORWARD_DETAIL;
		}else {
			// 検索処理を呼ぶ
			searchProc();
			return FORWARD_DISP;
		}
	}
	/*************************************************************************************
	 * 再表示処理
	 * <p>
	 * 「戻る」または「削除」ボタンで戻ってきた場合の再表示処理を行う
	 * </p>
	 * @param  flg true: メッセージあり false:メッセージ無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String redisp(boolean flg) throws AmallException {

		// 検索ボタン未押下チェック(検索押下後は空文字に変化する)
		if (m_Abcgm01Dto.getCstCd() != null) {

			m_Abcgm01Form.setCstCd(m_Abcgm01Dto.getCstCd());
			m_Abcgm01Form.setDisplayNum(m_Abcgm01Dto.getDisplayNum());
			m_Abcgm01Form.setDispResults(m_Abcgm01Dto.getDispResults());
			// 検索処理
			searchProc();
		}

		if(flg) {
			// 削除完了メッセージをセット
			setMessageInfo(m_Abcgm01DispBean, AmallMessageConst.MSG_INF_DEL_NML_END);
		}

		return FORWARD_DISP;

	}

	/*************************************************************************************
	 * 検索処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private void searchProc() throws AmallException {
		// methodName
		String methodName = "searchProc()";
		// 明細部用LIST
		List<AbcgmItemDispDto> detailList = new ArrayList<>();

		//検索値
		String searchCst = null;
		if ( m_Event.equals(FORWARD_SEARCH)) {
			searchCst = m_Abcgm01Form.getCstCd();
			m_Abcgm01Dto.setCstCd(searchCst);
		}else {
			searchCst = m_Abcgm01Dto.getCstCd();
			m_Abcgm01Form.setCstCd(searchCst);
		}

		try {
			makeSearchSql(searchCst);

			// select句
			String sqlSelect = m_Page_Sql.getSqlSelect();
			// from where 句
			String sqlCondition = m_Page_Sql.getSqlConditinon();
			// order 句
			String sqlOrder = m_Page_Sql.getSqlOrder();
			// param 句
			String[] sqlParam = m_Page_Sql.getSqlParam();
			// 表示件数
			int pageDispCnt = m_Page_Sql.getPageDispCnt();
			// ページ番号
			int pageNo = m_Abcgm01Form.getDisplayNum();

			List<Map<String, String>> pageData;
			if (m_Event.equals(FORWARD_DISP) || m_Event.equals(FORWARD_SEARCH)) { // 初期検索状態
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEFIRST)) { // "<<"ボタン押下時
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEPREV)) { // "<"ボタン押下時
				pageData = m_Page.getPrevPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGENEXT)) { // ">"ボタン押下時
				pageData = m_Page.getNextPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGELAST)) { // ">>"ボタン押下時
				pageData = m_Page.getLastPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else { // 表示件数プル変更時、その他
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			}

			/* 表示頁NOのセット */
			m_Abcgm01DispBean.setDisplayNum(m_Page.getNowPage());
			/* ページ遷移ボタンセット */
			if (!m_Page.isPrevPageExist()) {
				m_Abcgm01DispBean.setPrevPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Abcgm01DispBean.setPrevPageFlg(AmallConst.GeneralFlg.OFF);
			}
			if (!m_Page.isNextPageExist()) {
				m_Abcgm01DispBean.setNextPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Abcgm01DispBean.setNextPageFlg(AmallConst.GeneralFlg.OFF);
			}

			// 件数セット
			m_Abcgm01DispBean.setDispCountDefault(String.valueOf(pageDispCnt));

			// ページ情報がない場合
			if (pageData == null) {
				// エラーメッセージをセット
				setMessageInfo(m_Abcgm01DispBean, AmallMessageConst.MSG_ERR_SELECT_CON_NO_DATA,
						getItemDispName(ITEM_ID_CUSTOMERSEARCH, m_Abcgm01DispBean));
				return;

			}

			detailList = makeDetailList(m_Page.getNowPage(), pageData);

			/* 表示Beanに一覧データをセット */
			m_Abcgm01DispBean.setItemDispList(detailList);

			//検索欄名称設定処理
			if (!AmallUtilities.isEmpty(searchCst)) {
				//お客様コードが設定されている場合
				chkUniqCstNm(searchCst);
			}

			//dtoに退避
			m_Abcgm01Dto.setDisplayNum(m_Page.getNowPage());
			m_Abcgm01Dto.setDispResults(pageDispCnt);

		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					getItemDispName(ITEM_ID_CUSTOMERSEARCH, m_Abcgm01DispBean));
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		}

	}
	/*************************************************************************************
	 * 明細リスト作成処理
	 * <p>
	 * 明細リスト作成処理を実行する
	 * </p>
	 * @param  pageSize	頁数
	 * @param	pageData	頁データ
	 * @return 明細ArrayList
	 ************************************************************************************/
	private List<AbcgmItemDispDto> makeDetailList(int pageSize, List<Map<String, String>> pageData)
			throws AmallException {
		String methodName = "makeDetailList()";

		// 返却リスト
		List<AbcgmItemDispDto> retList = new ArrayList<>();

		try {
			// ページ情報をリストに追加
			for (Map<String, String> map : pageData) {
				AbcgmItemDispDto listdto = new AbcgmItemDispDto();
				//お客様グループコード
				listdto.setCstGrpCd(map.get("CST_GRP_CD"));
				//お客様グループ名
				listdto.setCstGrpNm(map.get("CST_GRP_NM"));
				//登録お客様件数
				listdto.setCstCount(Long.parseLong(map.get("CNT")));

				// 返却リストに追加
				retList.add(listdto);
			}

			return retList;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

	}

	/*************************************************************************************
	 * 入力値チェック
	 * <p>
	 * 入力値チェックを実施する
	 * </p>
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheck() throws  AmallException, Exception {
		// 返却フラグ
		boolean ret = true;

		String cstCd = m_Abcgm01Form.getCstCd();

		// 入力値チェック(顧客コード)
		if (!AmallUtilities.isEmpty(cstCd)) {
			// 入力値が存在する場合
			if (!AmallUtilities.isHalfWidthCharacterKind(cstCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Abcgm01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CUSTOMERSEARCH, m_Abcgm01DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Abcgm01DispBean, ITEM_ID_CUSTOMERSEARCH);

				ret = false;
			} else if (AmallUtilities.getLengthAsHalf(cstCd) != InputNum.CST_CD) {
				// 10桁以外が設定されている
				setMessageInfo(m_Abcgm01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CUSTOMERSEARCH, m_Abcgm01DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Abcgm01DispBean, ITEM_ID_CUSTOMERSEARCH);

				ret = false;
			}
			if(ret) {
				// 名称取得
				chkUniqCstNm(cstCd);
			}
		}

		return ret;
	}

	/*************************************************************************************
	 * SQL作成
	 * <p>
	 * SQLを作成する
	 * </p>
	 * @param cstCd 顧客CD
	 * @return SQL
	 ************************************************************************************/
	private void makeSearchSql(String CstCd) throws AmallException, Exception {
		String methodName = "makeSearchSql()";
		StringBuffer sql = new StringBuffer();

		String[] sqlParam = null;

		String systemDt = m_Abcgm01DispBean.getServiceDate();

		try {
			// 1ページの表示件数
			// 初期表示はデフォルト値を設定する
			if (m_Event.equals(FORWARD_SEARCH)) {
				int dispCnt = m_Abcgm01Form.getDispResults();
				if (dispCnt == 0) {
					m_Page_Sql.setPageDispCnt(Integer.parseInt(m_Abcgm01DispBean.getDispCountDefault()));
				}else {
					m_Page_Sql.setPageDispCnt(dispCnt);
				}
			} else {
				m_Page_Sql.setPageDispCnt(m_Abcgm01Form.getDispResults());
			}

			// SQL SELECT
			//ページ処理のため副問い合わせ
			sql.delete(0, sql.length());
			sql.append(" SELECT ");
			sql.append("    sub.CST_GRP_CD as CST_GRP_CD ");
			sql.append("  , sub.CST_GRP_NM as CST_GRP_NM ");
			sql.append("  , sub.CNT as CNT ");
			String sqlSelect = sql.toString();

			// SQL FROM & WHERE
			sql.delete(0, sql.length());
			sql.append(" FROM ( ");

			sql.append("  SELECT ");
			sql.append("    ncgm.CST_GRP_CD as CST_GRP_CD");
			sql.append("   ,ncgm.CST_GRP_NM as CST_GRP_NM");
			sql.append("   ,COUNT (ncgm.CST_CD) as CNT ");
			sql.append("  FROM N_CST_GRP_M ncgm  ");
			sql.append("  WHERE ncgm.CST_GRP_CD in ");
			sql.append("   ( select ");
			sql.append("      distinct CST_GRP_CD ");
			sql.append("     from N_CST_GRP_M  ");
			sql.append("     where 1 = 1 ");
			if (!AmallUtilities.isEmpty(CstCd)) {
				//顧客コード設定ありの場合
				sql.append(" and CST_CD = ? ");
				//退避した値をパラメータとして設定
				sqlParam = new String[1];
				sqlParam[0] = CstCd;
			}
			sql.append("      and DEL_FLG = ").append(AmallConst.DEFAULT_DEL_FLG);
			sql.append("      and EFST_DY <= '").append(systemDt).append("' ");
			sql.append("      and EFED_DY >= '").append(systemDt).append("' ");
			sql.append("   ) ");
			sql.append("   AND ncgm.DEL_FLG = ").append(AmallConst.DEFAULT_DEL_FLG);
			sql.append("   AND ncgm.EFST_DY <= '").append(systemDt).append("' ");
			sql.append("   AND ncgm.EFED_DY >= '").append(systemDt).append("' ");
			sql.append("  GROUP BY ncgm.CST_GRP_CD, ncgm.CST_GRP_NM ");
			sql.append(" ) sub");
			String sqlCondition = sql.toString();

			// SQL ORDER
			sql.delete(0, sql.length());
			sql.append(" ORDER BY sub.CST_GRP_CD ");
			String sqlOrder = sql.toString();

			// セット処理
			m_Page_Sql.setSqlSelect(sqlSelect);
			m_Page_Sql.setSqlConditinon(sqlCondition);
			m_Page_Sql.setSqlOrder(sqlOrder);
			m_Page_Sql.setSqlParam(sqlParam);

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 顧客マスタ(DB)ユニーク設定
	 * <p>
	 * 顧客マスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できる場合はActionFormに値を設定し，
	 * 特定できない場合はfalseで返却する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @return boolean true:正常 false:異常
	 ************************************************************************************/
	private boolean chkUniqCstNm(String cstCd) throws AmallException, Exception {

		String methodName = "chkUniqCstNm()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用チェックリスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	CST_NM");
			sql.append("  FROM");
			sql.append("	N_CST_M");
			sql.append(" WHERE");
			sql.append("	DEL_FLG = ?");
			sql.append("	AND CST_CD = ?");

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				// 店舗名
				String name = m_DbAccess.getString(rs, "CST_NM");

				// リストに追加
				retList.add(name);
			}

			// 結果チェック
			if(retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}

			// 値を設定
			m_Abcgm01Form.setCstNm(retList.get(0));

			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_CST_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * コピー処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private boolean copyProc() throws AmallException {

		String methodName = "copyProc()";

		StringBuffer sql = new StringBuffer();

		List<String> bindParam = new ArrayList<String>();

		try {
			// お客様グループコード自動採番処理
			Long nextVal = AmallUtilities.getSequenceNextval("S_CST_GRP_CD", m_DbAccess);

			//nullチェック
			if(nextVal == null || nextVal.longValue() == 0) {
				setMessageInfo(m_Abcgm01DispBean, AmallMessageConst.MSG_ERR_DB_ACCESS);
				return false;
			}

			//0埋めされた顧客グループコードを取得
			String nextCstGrpCd = String.format(AmallConst.CST_GRP_CD_FORMAT, nextVal);

			//システム日付を取得
			String systemDt = m_Abcgm01DispBean.getServiceDate();

			//INSERT SELECT用SQLの生成
			sql = new StringBuffer();
			sql.append(" Insert into N_CST_GRP_M ( ");
			sql.append("     CST_GRP_CD ");
			sql.append("   , CST_CD ");
			sql.append("   , EFST_DY ");
			sql.append("   , EFED_DY ");
			sql.append("   , CST_GRP_NM ");
			sql.append("   , VARCHAR_YOBI_01 ");
			sql.append("   , VARCHAR_YOBI_02 ");
			sql.append("   , VARCHAR_YOBI_03 ");
			sql.append("   , VARCHAR_YOBI_04 ");
			sql.append("   , VARCHAR_YOBI_05 ");
			sql.append("   , VARCHAR_YOBI_06 ");
			sql.append("   , VARCHAR_YOBI_07 ");
			sql.append("   , VARCHAR_YOBI_08 ");
			sql.append("   , VARCHAR_YOBI_09 ");
			sql.append("   , VARCHAR_YOBI_10 ");
			sql.append("   , EXCLUSIVE_KEY ");
			sql.append("   , DEL_FLG ");
			sql.append("   , CR_PGM_ID ");
			sql.append("   , CR_USER_ID ");
			sql.append("   , CR_DT ");
			sql.append("   , UPD_PGM_ID ");
			sql.append("   , UPD_USER_ID ");
			sql.append("   , UPD_DT) ");
			sql.append(" SELECT ");
			bindParam.add(nextCstGrpCd);
			sql.append("  ? as CST_GRP_CD ");
			sql.append("  , ncgm.CST_CD as CST_CD ");
			sql.append("  , ncgm.EFST_DY as EFST_DY ");
			sql.append("  , ncgm.EFED_DY as EFED_DY ");
			sql.append("  , ncgm.CST_GRP_NM as CST_GRP_NM ");
			sql.append("  , ncgm.VARCHAR_YOBI_01 as VARCHAR_YOBI_01 ");
			sql.append("  , ncgm.VARCHAR_YOBI_02 as VARCHAR_YOBI_02 ");
			sql.append("  , ncgm.VARCHAR_YOBI_03 as VARCHAR_YOBI_03 ");
			sql.append("  , ncgm.VARCHAR_YOBI_04 as VARCHAR_YOBI_04 ");
			sql.append("  , ncgm.VARCHAR_YOBI_05 as VARCHAR_YOBI_05 ");
			sql.append("  , ncgm.VARCHAR_YOBI_06 as VARCHAR_YOBI_06 ");
			sql.append("  , ncgm.VARCHAR_YOBI_07 as VARCHAR_YOBI_07 ");
			sql.append("  , ncgm.VARCHAR_YOBI_08 as VARCHAR_YOBI_08 ");
			sql.append("  , ncgm.VARCHAR_YOBI_09 as VARCHAR_YOBI_09 ");
			sql.append("  , ncgm.VARCHAR_YOBI_10 as VARCHAR_YOBI_10 ");
			sql.append("  , 0 as EXCLUSIVE_KEY ");
			sql.append("  , ").append(AmallConst.DEFAULT_DEL_FLG).append(" as DEL_FLG ");
			sql.append("  , '").append(m_ClassName).append("' as CR_PGM_ID ");
			sql.append("  , '").append(m_Abcgm01DispBean.getH_loginId()).append("' as CR_USER_ID ");
			sql.append("  , SYSDATE as CR_DT ");
			sql.append("  , '").append(m_ClassName).append("' as UPD_PGM_ID ");
			sql.append("  , '").append(m_Abcgm01DispBean.getH_loginId()).append("' as UPD_USER_ID ");
			sql.append("  , SYSDATE as UPD_DT ");
			sql.append(" FROM N_CST_GRP_M ncgm ");
			bindParam.add(m_Abcgm01Form.getCstGrpCdHid());
			sql.append(" WHERE ncgm.CST_GRP_CD = ? ");
			sql.append("  AND ncgm.DEL_FLG = ").append(AmallConst.DEFAULT_DEL_FLG);
			sql.append("  AND ncgm.EFST_DY <= '").append(systemDt).append("' ");
			sql.append("  AND ncgm.EFED_DY >= '").append(systemDt).append("' ");

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < bindParam.size(); i++) {
				m_DbAccess.setString(i + 1, bindParam.get(i));
			}

			// SQL実行
			int ret = m_DbAccess.executeUpdateSql();

			// 更新結果判定
			if (ret <= 0) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_CST_GRP_M");
				throw ee;
			}

			//Hiddenに値を追加
			m_Abcgm01Form.setCstGrpCdHid(nextCstGrpCd);

			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_CST_GRP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

}