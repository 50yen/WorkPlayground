/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abiam02DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.business;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.b.iam.action.Abiam02Action;
import jp.co.hitachi.a.b.iam.bean.Abiam02DispBean;
import jp.co.hitachi.a.b.iam.dto.AbiamItemAuthDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.GeneralFlg;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallConst.ScrExp;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;

/*****************************************************************************************
 * Abiam02Businessクラス<br>
 *****************************************************************************************/
public class Abiam02Business extends AbiamBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Abiam02DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 検索 */
	public static final String FORWARD_SEARCH = "SEARCH";
	/** 登録 */
	public static final String FORWARD_REGIST = "REGIST";

	/**
	 * 画面項目ID
	 */
	/** 画面名プルダウン */
	public static final String ITEM_ID_SCREEN_DD = "screenDropDown";
	/** 権限ロールプルダウン */
	public static final String ITEM_ID_ROLE_DD = "roleDropDown";
	/** 一覧表示可否プルダウン */
	public static final String ITEM_ID_DISP_DD = "itemDropDown";
	/** 一覧編集可否プルダウン */
	public static final String ITEM_ID_EDIT_DD = "itemEditDropDown";

	/** メンバ変数 */
	/** アクションフォーム */
	private Abiam02Action m_Abiam02Form = null;
	/** 表示用画面Bean */
	private Abiam02DispBean m_Abiam02DispBean = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Abiam02Business(
			Abiam02Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Abiam02Business.class.getName();
		m_Abiam02Form = form;
		m_Abiam02DispBean = new Abiam02DispBean();
		setErrString(gid, m_Abiam02Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Abiam02DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Abiam02Form.getM_systemKind());
			m_DbAccess.initDB();

			// 共通処理
			getDropDownListData();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_SEARCH.equals(m_Event)) {
				// 検索処理の場合

				// 検索結果を初期化
				List<AbiamItemAuthDto> emptylist = new ArrayList<>();
				m_Abiam02Form.setItemDispList(emptylist);

				// 検索実行
				forwardStr = search();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				forwardStr = regist();
			} else {
				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Abiam02DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 検索処理
	 * <p>
	 * 検索処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String search() throws AmallException, Exception {

		// 画面コード取得
		String screenCd = m_Abiam02Form.getSelectedScreenCd();
		// 権限コード取得
		String roleCd = m_Abiam02Form.getSelectedRoleCd();


		// 入力チェック
		boolean chkFlg = true;
		// 画面コード 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(screenCd)) {
			setMessageInfo(m_Abiam02DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_SCREEN_DD, m_Abiam02DispBean));
			setError(m_Abiam02DispBean, ITEM_ID_SCREEN_DD);
			chkFlg = false;
		}
		// 権限コード 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(roleCd)) {
			setMessageInfo(m_Abiam02DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_ROLE_DD, m_Abiam02DispBean));
			setError(m_Abiam02DispBean, ITEM_ID_ROLE_DD);
			chkFlg = false;
		}
		// 入力チェック判定
		if (!chkFlg) {
			return FORWARD_DISP;
		}

		// 画面一覧検索
		List<AbiamItemAuthDto> itemDispList = getItemRoleMst(roleCd, screenCd);

		// 結果チェック
		if (itemDispList.size() == 0) {
			// 0件だった場合
			setMessageInfo(m_Abiam02DispBean, AmallMessageConst.MSG_INF_SEARCH_CON_NO_DATA);
			return FORWARD_DISP;
		}

		for (AbiamItemAuthDto authDto : itemDispList) {

			// 項目タイプを取得
			String typeCd = authDto.getItemTypeCd();
			if (typeCd != null && typeCd.length() > 0) {
				// 項目タイプから汎用マスタを取得
				AmdtoGeneralMst generalMst = AmallUtilities.getGeneralMstDataRecord(m_DbAccess, GeneralMstKey.ITEM_TYPE, typeCd, null, m_Abiam02DispBean.getServiceDate());

				// 取得データより項目タイプ名を設定
				authDto.setItemType(generalMst.getGeneralNm1());

				// 取得データより編集必須フラグを取得
				authDto.setEnableReqFlg(generalMst.getChar1());
			}

		}
		// 一覧表示データセット
		m_Abiam02Form.setItemDispList(itemDispList);
		// 検索ボタン押下時検索条件保存
		m_Abiam02Form.setSavedScreenCd(screenCd);
		m_Abiam02Form.setSavedRoleCd(roleCd);


		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 登録処理
	 * <p>
	 * 登録処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException, Exception {

		// == 検索条件・更新データ取得 ==
		// 画面コード取得
		String screenCd = m_Abiam02Form.getSavedScreenCd();
		// 権限コード取得
		String roleCd = m_Abiam02Form.getSavedRoleCd();

		// 入力データ取得
		List<AbiamItemAuthDto> dataList = m_Abiam02Form.getItemDispList();

		// == 入力チェック ==
		boolean chkFlg = true;
		// 取得データ分繰り返す

		for (int index = 0;index < dataList.size(); index++) {

			AbiamItemAuthDto authDto = dataList.get(index);

			// 表示可否取得
			String dispCd = authDto.getDispCd();

			// 表示可否は必須
			if(dispCd == null || dispCd.length() == 0) {
				setMessageInfo(m_Abiam02DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, authDto.getItemDispName() + "の" + getItemDispName(ITEM_ID_DISP_DD, m_Abiam02DispBean));
				setError(m_Abiam02DispBean, ITEM_ID_DISP_DD + index);
				chkFlg = false;
				continue;
			}

			// 編集可否取得
			String enableCd = authDto.getDispCd();

			// 編集必須フラグONかつ表示可否が「表示」の時に編集可否が指定なし
			if (GeneralFlg.ON.equals(authDto.getEnableReqFlg()) && ScrExp.DISPLAY_ON.equals(dispCd)) {
				if (enableCd == null || enableCd.length() == 0) {
					setMessageInfo(m_Abiam02DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, authDto.getItemDispName() + "の" + getItemDispName(ITEM_ID_EDIT_DD, m_Abiam02DispBean));
					setError(m_Abiam02DispBean, ITEM_ID_EDIT_DD + index);
					chkFlg = false;
					continue;
				}
			}
		}
		// 入力チェック判定
		if (!chkFlg) {
			// 入力チェックエラー有
			return FORWARD_DISP;
		}


		// == 登録処理 ==
		boolean registFlg = true;
		for (AbiamItemAuthDto authDto : dataList) {

			// 処理分岐

			// 排他キーチェック
			Long versionkey = authDto.getExclusiveKey();

			if (versionkey != null) {
				// 排他キーが存在する場合はUpdate処理
				boolean ret = updateItemRoleMst(authDto, screenCd, roleCd);
				// 処理結果チェック
				if(!ret) {
					// 処理中断
					registFlg = false;
					break;
				}
			} else {
				// 存在しない場合はInsert処理
				boolean ret = insertItemRoleMst(authDto, screenCd, roleCd);
				// 処理結果チェック
				if(!ret) {
					// 処理中断
					registFlg = false;
					break;
				}
			}

		}
		// DB処理正常判定
		if (registFlg) {
			// コミット処理
			m_DbAccess.commit();
			// 正常完了処理メッセージ
			setMessageInfo(m_Abiam02DispBean, AmallMessageConst.MSG_INF_NML_REGIST_END_RELOGIN);

			// 再検索処理
			m_Abiam02Form.setSelectedScreenCd(screenCd);
			m_Abiam02Form.setSelectedRoleCd(roleCd);

			search();
		}


		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * プルダウンリスト取得処理
	 * <p>
	 * 画面に表示するプルダウンリストの値を取得する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private void getDropDownListData() throws AmallException, Exception {

		// 画面一覧を取得する
		m_Abiam02DispBean.setScreenDropDownList(getScreenList());

		// 権限一覧を取得する
		m_Abiam02DispBean.setRoleDropDownList(getAuthRoleList());

		// 表示可否一覧を取得する
		m_Abiam02DispBean.setDispDropDownList(getDispProprietyList(m_Abiam02DispBean.getServiceDate()));

		// 編集可否一覧を取得する
		m_Abiam02DispBean.setEditDropDownList(getEditProprietyList(m_Abiam02DispBean.getServiceDate()));

	}

	/*************************************************************************************
	 * 項目権限マスタ(DB)取得
	 * <p>
	 * 項目権限マスタ(DB)からデータを取得する
	 * </p>
	 * @param  roleGrpCd 権限グループコード
	 * @param  screenCd 画面コード
	 * @return List<AbiamItemAuthDto> 表示項目リスト
	 ************************************************************************************/
	private List<AbiamItemAuthDto> getItemRoleMst(String roleGrpCd, String screenCd) throws AmallException, Exception {

		String methodName = "getItemRoleMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<AbiamItemAuthDto> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	A.ITEM_CD");
			sql.append(",	A.ITEM_DESCRIPTION");
			sql.append(",	A.ITEM_TYPE");
			sql.append(",	CASE");
			sql.append("		WHEN B.SCREEN_CD IS NULL");
			sql.append("		 AND B.ITEM_CD IS NULL");
			sql.append("		THEN A.VISIBLE");
			sql.append("		ELSE B.VISIBLE");
			sql.append("	 END AS VISIBLE");
			sql.append(",	CASE");
			sql.append("		WHEN B.SCREEN_CD IS NULL");
			sql.append("		 AND B.ITEM_CD IS NULL");
			sql.append("		THEN A.EDITABLE");
			sql.append("		ELSE B.EDITABLE");
			sql.append("	 END AS EDITABLE");
			sql.append(",    B.EXCLUSIVE_KEY");
			sql.append("  FROM");
			sql.append("  	N_ITEM_M A");
			sql.append("  	LEFT JOIN");
			sql.append("  		N_ITEM_ROLE_M B");
			sql.append("  		ON");
			sql.append("  			A.SCREEN_CD = B.SCREEN_CD");
			sql.append("  		AND A.ITEM_CD = B.ITEM_CD");
			sql.append("		AND B.ROLE_GRP_CD =  ?");
			sql.append("  		AND B.DEL_FLG = ?");
			sql.append(" WHERE");
			sql.append("	A.DEL_FLG =  ?");
			sql.append("	AND A.SCREEN_CD =  ?");
			sql.append(" ORDER BY");
			sql.append("	A.VIEW_ORDER");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 権限コード
			m_DbAccess.setString(++setCnt, roleGrpCd);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 画面コード
			m_DbAccess.setString(++setCnt, screenCd);
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				AbiamItemAuthDto dto = new AbiamItemAuthDto();
				// 項目ID
				dto.setItemId(m_DbAccess.getString(rs, "ITEM_CD"));
				// 項目説明
				dto.setItemDispName(m_DbAccess.getString(rs, "ITEM_DESCRIPTION"));
				// 項目タイプコード
				dto.setItemTypeCd(m_DbAccess.getString(rs, "ITEM_TYPE"));
				// 表示可否
				dto.setDispCd(m_DbAccess.getString(rs, "VISIBLE"));
				// 編集可否
				dto.setEnableCd(m_DbAccess.getString(rs, "EDITABLE"));
				// 排他キー
				Long key = rs.getLong("EXCLUSIVE_KEY");
				if (rs.wasNull()) {
					dto.setExclusiveKey(null);
				} else {
					dto.setExclusiveKey(key);
				}
				// リストに追加
				retList.add(dto);
			}
			return retList;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_ITEM_M, N_ITEM_ROLE_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 項目権限マスタ(DB)更新
	 * <p>
	 * 項目権限マスタ(DBを更新する
	 * </p>
	 * @param authDto 入力データ
	 * @param screenCd 画面コード
	 * @param roleCd 権限コード
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	private boolean updateItemRoleMst(AbiamItemAuthDto authDto, String screenCd, String roleCd) throws AmallException {

		String methodName = "updateItemRoleMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// 編集可否の判定
			String enabaleFlg = authDto.getEnableCd();
			if (GeneralFlg.OFF.equals(authDto.getEnableReqFlg())) {
				// 編集必要フラグがOFFの場合
				enabaleFlg = null;
			}

			// SQL生成
			sql.append("UPDATE");
			sql.append("	N_ITEM_ROLE_M");
			sql.append("   SET");
			// 表示可否
			sql.append("	VISIBLE = ?");
			// 編集可否
			sql.append(",	EDITABLE = ?");
			// 共通部分
			sql.append(",	UPD_PGM_ID =  ?");
			sql.append(",	UPD_USER_ID =  ?");
			sql.append(",	UPD_DT =  SYSDATE");
			sql.append(",	EXCLUSIVE_KEY =  EXCLUSIVE_KEY + 1");

			// 条件指定
			sql.append(" WHERE");
			sql.append("	ROLE_GRP_CD =  ?");
			sql.append("	AND SCREEN_CD = ?");
			sql.append("	AND ITEM_CD = ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND EXCLUSIVE_KEY = ?");


			// 更新値のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;
			// 表示可否
			m_DbAccess.setString(++setCnt, authDto.getDispCd());
			// 編集可否
			m_DbAccess.setString(++setCnt, enabaleFlg);
			// 更新プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 更新ユーザーID
			m_DbAccess.setString(++setCnt, m_Abiam02DispBean.getH_loginId());


			// WHERE句のパラメタ設定
			// 権限グループコード
			m_DbAccess.setString(++setCnt, roleCd);
			// 画面コード
			m_DbAccess.setString(++setCnt, screenCd);
			// 項目コード
			m_DbAccess.setString(++setCnt, authDto.getItemId());
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 排他キー
			m_DbAccess.setLong(++setCnt, authDto.getExclusiveKey());

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 排他チェック
			if(ret == 0) {
				// 更新対象無し(楽観排他)
				m_DbAccess.rollback();

				// エラー情報を設定
				setMessageInfo(m_Abiam02DispBean, AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST);

				// アクセスログ情報の作成
				AmallExceptionInfo amei = new AmallExceptionInfo();
				amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_ACS_OPT_ERROR, "N_ITEM_ROLE_M"));
				setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

				return false;
			}

			// 更新結果判定
			if (ret != 1) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_ITEM_ROLE_M");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_ITEM_ROLE_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}
	/*************************************************************************************
	 * 項目権限マスタ(DB)登録
	 * <p>
	 * 項目権限マスタ(DB)にレコードを登録する
	 * </p>
	 * @param authDto 入力データ
	 * @param screenCd 画面コード
	 * @param roleCd 権限コード
	 * @return true:正常 false:更新エラー
	 ************************************************************************************/
	private boolean insertItemRoleMst(AbiamItemAuthDto authDto, String screenCd, String roleCd) throws AmallException {

		String methodName = "insertItemRoleMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// 編集可否の判定
			String enabaleFlg = authDto.getEnableCd();
			if (GeneralFlg.OFF.equals(authDto.getEnableReqFlg())) {
				// 編集必要フラグがOFFの場合
				enabaleFlg = null;
			}


			// SQL生成
			sql.append("INSERT INTO");
			sql.append("	N_ITEM_ROLE_M (");
			sql.append("   		ROLE_GRP_CD");
			sql.append(",  		SCREEN_CD");
			sql.append(",  		ITEM_CD");
			sql.append(",  		VISIBLE");
			sql.append(",  		EDITABLE");
			sql.append(",  		EXCLUSIVE_KEY");
			sql.append(",  		DEL_FLG");
			sql.append(",  		CR_PGM_ID");
			sql.append(",  		CR_USER_ID");
			sql.append(",  		CR_DT");
			sql.append(",  		UPD_PGM_ID");
			sql.append(",  		UPD_USER_ID");
			sql.append(",  		UPD_DT");
			sql.append("	) VALUES (");
			sql.append("		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			// 共通部分
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append("	)");

			// 登録値のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;
			// 権限グループコード
			m_DbAccess.setString(++setCnt, roleCd);
			// 画面コード
			m_DbAccess.setString(++setCnt, screenCd);
			// 項目コード
			m_DbAccess.setString(++setCnt, authDto.getItemId());
			// 表示可否
			m_DbAccess.setString(++setCnt, authDto.getDispCd());
			// 編集可否
			m_DbAccess.setString(++setCnt, enabaleFlg);
			// 排他キー
			m_DbAccess.setLong(++setCnt, 0);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 登録プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 登録ユーザーID
			m_DbAccess.setString(++setCnt, m_Abiam02DispBean.getH_loginId());
			// 更新プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 更新ユーザーID
			m_DbAccess.setString(++setCnt, m_Abiam02DispBean.getH_loginId());

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 更新結果判定
			if (ret <= 0) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_ITEM_ROLE_M");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_ITEM_ROLE_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}
}