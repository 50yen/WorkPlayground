/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.bean;

import java.util.ArrayList;
import java.util.List;

import jp.co.hitachi.a.m.cls.AmclsBeanBase;
import jp.co.hitachi.a.m.dto.AmdtoCalender;

/*****************************************************************************************
 * Acech01DispBeanクラス<br>
 *****************************************************************************************/
public class Acech01DispBean extends AmclsBeanBase {

	/** メンバ変数 */

	/** カレンダーデータ */
	List<List<AmdtoCalender>> calDataList = new ArrayList<>();

	/** 前ページフラグ */
	private String prevPageFlg = null;
	/** 次ページフラグ */
	private String nextPageFlg = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Acech01DispBean() {
		super();
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		super.clear();
		calDataList = new ArrayList<>();
		prevPageFlg = null;
		nextPageFlg = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public List<List<AmdtoCalender>> getCalDataList() {
		return calDataList;
	}

	public void setCalDataList(List<List<AmdtoCalender>> calDataList) {
		this.calDataList = calDataList;
	}

	public String getPrevPageFlg() {
		return prevPageFlg;
	}

	public void setPrevPageFlg(String prevPageFlg) {
		this.prevPageFlg = prevPageFlg;
	}

	public String getNextPageFlg() {
		return nextPageFlg;
	}

	public void setNextPageFlg(String nextPageFlg) {
		this.nextPageFlg = nextPageFlg;
	}

}
