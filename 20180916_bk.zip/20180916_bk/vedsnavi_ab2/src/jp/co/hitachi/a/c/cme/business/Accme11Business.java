/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Accme11DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cme.business;

import java.sql.ResultSet;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.cme.action.Accme11Action;
import jp.co.hitachi.a.c.cme.bean.Accme11DispBean;
import jp.co.hitachi.a.c.cme.dto.Accme11Dto;
import jp.co.hitachi.a.c.cme.dto.AccmeItemDispDto;
import jp.co.hitachi.a.c.cme.dto.AccmeItemInsertDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.GeneralFlg;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;

/*****************************************************************************************
 * Accme11Businessクラス<br>
 *****************************************************************************************/
public class Accme11Business extends AccmeBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Accme11DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 画面表示(一覧からの遷移) */
	public static final String FORWARD_DISP_LIST = "DISPLIST";
	/** 前頁 */
	private static final String FORWARD_PAGEPREV = "PREV";
	/** 次頁 */
	private static final String FORWARD_PAGENEXT = "NEXT";
	/** 登録 */
	private static final String FORWARD_REGIST = "REGIST";
	/** 印刷 */
	private static final String FORWARD_PRINT = "PRINT";
	/** 戻るボタン押下 */
	private static final String FORWARD_RETURNPAGE = "RETURNPAGE";
	/**
	 * 画面項目ID
	 */
	/** 画面名 */
	private static final String ITEM_ID_SCREEN_NAME = "ScreenName";
	/** 顧客コード */
	public static final String ITEM_ID_CST_CD = "customerSearchNm";
	/** 店舗CD */
	private static final String ITEM_ID_SHOP_CD = "shopSearchNm";
	/** 店舗枝番コード */
	public static final String ITEM_ID_SHOPSBNO_CD = "shopBranchSearchNm";
	/** 店舗CD */
	private static final String ITEM_ID_SLD = "sld";
	/** 店舗入力 */
	public static final String ITEM_ID_SHOP_BRANCH_SEARCH_IN = "shopBranchSearchChildBtn";
	/** 店舗検索ボタン */
	public static final String ITEM_ID_SHOP_BRANCH_SEARCH = "shopBranchSearchNm";
	/** 金額枚数 */
	public static final String ITEM_ID_MONEY_NUM = "moneyNum";
	/** 合計金額 */
	public static final String ITEM_ID_SPCCMT = "spccmt";

	/** メンバ変数 */
	/** アクションフォーム */
	private Accme11Action m_Accme11Form = null;
	/** 表示用画面Bean */
	private Accme11DispBean m_Accme11DispBean = null;
	/** 画面DTO */
	Accme11Dto m_Accme11Dto;
	/** DTOキー名 */
	private String DTO_ACCME11 = "DTO_ACCME11";

	/** 遷移元情報取得 */
	private List<AccmeItemDispDto> infoList;
	/** 遷移元情報取得 */
	private AccmeItemInsertDto insertDto = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Accme11Business(
			Accme11Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Accme11Business.class.getName();
		m_Accme11Form = form;
		m_Accme11DispBean = new Accme11DispBean();
		insertDto = new AccmeItemInsertDto();
		setErrString(gid, m_Accme11Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}
			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Accme11DispBean);

			/* 内部記憶情報の生成 */
			m_Accme11Dto = (Accme11Dto) getSpecifiedDTO(DTO_ACCME11);
			if (m_Accme11Dto == null || FORWARD_DISP.equals(m_Event)) {
				if (m_Accme11Dto != null) {
					delSpecifiedDTO(DTO_ACCME11);
				}
				m_Accme11Dto = new Accme11Dto();
				putSpecifiedDTO(DTO_ACCME11, m_Accme11Dto);
			}

			// 遷移元情報取得
			infoList = (List<AccmeItemDispDto>) getSpecifiedDTO(ACCME_INFO_KEY);
			if (infoList != null) {
				// 取得リストセット
				m_Accme11Dto.setInfoList(infoList);
				// 取得リスト存在フラグ
				m_Accme11Dto.setListFlg(GeneralFlg.ON);

				// 初期項目
				m_Accme11Dto.setCount(0);
				m_Accme11Form.setCstCd(infoList.get(m_Accme11Dto.getCount()).getCstCd());
				m_Accme11Form.setShopCd(infoList.get(m_Accme11Dto.getCount()).getShopCd());
				m_Accme11Form.setShopSbno(infoList.get(m_Accme11Dto.getCount()).getShopSbno());
				m_Accme11Form.setSld(AmallUtilities.changeFormat(infoList.get(m_Accme11Dto.getCount()).getSld()));
				// DTO削除
				delSpecifiedDTO(ACCME_INFO_KEY);
			}

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Accme11Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_DISP_LIST.equals(m_Event)) {
				// 戻るボタンフラグON
				m_Accme11Dto.setReturnFlg(GeneralFlg.ON);
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_PAGEPREV.equals(m_Event)) {
				// "<"ボタン押下の場合
				forwardStr = pagePrev();
			} else if (FORWARD_PAGENEXT.equals(m_Event)) {
				// ">"ボタン押下の場合
				forwardStr = pageNext();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				// 登録ボタン押下の場合
				forwardStr = regist();
			} else if (FORWARD_PRINT.equals(m_Event)) {
				// 印刷ボタン押下処理の場合
				forwardStr = print();
			} else if (FORWARD_RETURNPAGE.equals(m_Event)) {
				// 戻るボタン押下処理の場合
				forwardStr = returnPage();
			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Accme11DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException, Exception {

		// フォーム値取得
		String cstCd = m_Accme11Form.getCstCd();
		String shopCd = m_Accme11Form.getShopCd();
		String shopSbno = m_Accme11Form.getShopSbno();
		String sld = m_Accme11Form.getSld();
		boolean cstFlg = AmallUtilities.isEmpty(cstCd);
		boolean shopFlg = AmallUtilities.isEmpty(shopCd);
		boolean sbnoFlg = AmallUtilities.isEmpty(shopSbno);
		boolean sldFlg = AmallUtilities.isEmpty(sld);

		if (!cstFlg && !shopFlg && !sbnoFlg && !sldFlg) {
			// 遷移元からリストを取得できた場合
			// 検索
			search();

		} else {
			// 金種テーブル・フラグ設定
			dispCommonproc();

		}

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * "<"ボタン押下処理実行
	 * <p>
	 * "<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pagePrev() throws AmallException, Exception {

		if (m_Accme11Dto.getInfoList() != null) {
			// カウントダウン
			m_Accme11Dto.setCount(m_Accme11Dto.getCount() - 1);
			// formセット
			m_Accme11Form.setCstCd(m_Accme11Dto.getInfoList().get(m_Accme11Dto.getCount()).getCstCd());
			m_Accme11Form.setShopCd(m_Accme11Dto.getInfoList().get(m_Accme11Dto.getCount()).getShopCd());
			m_Accme11Form.setShopSbno(m_Accme11Dto.getInfoList().get(m_Accme11Dto.getCount()).getShopSbno());
			m_Accme11Form.setSld(
					AmallUtilities.changeFormat(m_Accme11Dto.getInfoList().get(m_Accme11Dto.getCount()).getSld()));

			// 検索
			search();

		} else {
			// DTOにリストがない場合エラー
			setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_DB_ACCESS);
			// フォーム初期化
			m_Accme11Form = new Accme11Action();
			// 金種テーブル・フラグ設定
			dispCommonproc();

		}

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ">"ボタン押下処理実行
	 * <p>
	 * ">"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageNext() throws AmallException, Exception {

		if (m_Accme11Dto.getInfoList() != null) {
			// カウントアップ
			m_Accme11Dto.setCount(m_Accme11Dto.getCount() + 1);

			// セット
			m_Accme11Form.setCstCd(m_Accme11Dto.getInfoList().get(m_Accme11Dto.getCount()).getCstCd());
			m_Accme11Form.setShopCd(m_Accme11Dto.getInfoList().get(m_Accme11Dto.getCount()).getShopCd());
			m_Accme11Form.setShopSbno(m_Accme11Dto.getInfoList().get(m_Accme11Dto.getCount()).getShopSbno());
			m_Accme11Form.setSld(
					AmallUtilities.changeFormat(m_Accme11Dto.getInfoList().get(m_Accme11Dto.getCount()).getSld()));

			// 検索
			search();
		} else {
			// DTOにリストがない場合エラー
			setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_DB_ACCESS);
			// フォーム初期化
			m_Accme11Form = new Accme11Action();
			// 金種テーブル・フラグ設定
			dispCommonproc();

		}

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 登録ボタン押下処理実行
	 * <p>
	 * 登録ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException, Exception {

		// 入力条件妥当性チェック
		if (!proprietyCheck()) {
			// 金種テーブル・フラグ設定
			dispCommonproc();
			// 入力チェックエラー有
			return FORWARD_DISP;
		}

		// 入力データ取得
		List<Accme11Dto> dataList = m_Accme11Form.getItemDispList();
		// 枚数リスト
		List<Integer> moneyNumList = new ArrayList<>();
		// 金額リスト
		List<Integer> totalList = new ArrayList<>();

		// == 入力チェック ==
		// 取得データ分繰り返す

		// 金種別枚数・金種別金額
		for (int index = 0; index < dataList.size(); index++) {
			// 枚数
			int moneyNum = 0;
			if (!AmallUtilities.isEmpty(dataList.get(index).getMoneyNum())) {
				// 枚数がnullでない場合
				moneyNum = Integer.parseInt(dataList.get(index).getMoneyNum());
			}
			// 金種別枚数
			moneyNumList.add(moneyNum);
			// 金種別金額
			totalList.add(dataList.get(index).getMoneyTotal());
		}

		// == 登録処理 ==
		// 枝番情報検索
		clmyDatSearch();
		// 排他キー取得
		Long entFlg = m_Accme11Dto.getExclusiveKey();

		boolean registFlg = true;
		if (entFlg != null) {
			// 排他キーが存在する場合はUpdate処理
			boolean ret = updateClmyEntDat(moneyNumList, totalList);
			// 処理結果チェック
			if (!ret) {
				// 処理中断
				registFlg = false;
				// 金種テーブル・フラグ設定
				dispCommonproc();
				// 入力チェックエラー有
				return FORWARD_DISP;
			}
		} else {
			// 新規登録処理
			searchInsertItem();
			boolean ret = insertClmyEntDat(moneyNumList, totalList);
			// 処理結果チェック
			if (!ret) {
				// 処理中断
				registFlg = false;
				// 金種テーブル・フラグ設定
				dispCommonproc();
				// 入力チェックエラー有
				return FORWARD_DISP;
			}
		}

		// DB処理正常判定
		if (registFlg) {
			// コミット処理
			m_DbAccess.commit();
			// 正常完了処理メッセージ
			setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_INF_NML_REGIST_END);
			// 登録フラグオン
			m_Accme11DispBean.setRegistFlg(GeneralFlg.ON);
			// 再検索処理
			search();

		}

		return FORWARD_DISP;

	}

	/*************************************************************************************
	 * 印刷ボタン押下処理実行
	 * <p>
	 * 印刷ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String print() throws AmallException, Exception {

		// TODO 印刷処理

		// 初期画面に戻る

		return disp();
	}

	/*************************************************************************************
	 * 戻るボタン押下処理実行
	 * <p>
	 * 戻るボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String returnPage() throws AmallException, Exception {

		// DTO削除
		delSpecifiedDTO(DTO_ACCME11);

		return FORWARD_RETURNPAGE;
	}

	/*************************************************************************************
	 * ページ遷移フラグセット
	 * <p>
	 * ページ遷移フラグを設定する
	 * </p>
	 * @param  なし
	 * @return なし
	 ************************************************************************************/
	private void pageMoveSet() throws AmallException {
		String methodName = "pageMoveSet()";
		try {
			// ページ遷移フラグ
			if (m_Accme11Dto.getInfoList() != null) {
				if ((m_Accme11Dto.getInfoList().size() - (m_Accme11Dto.getCount() + 1)) > 0) {
					// 次ページフラグ
					m_Accme11DispBean.setNextPageFlg(GeneralFlg.ON);
				}
				if (m_Accme11Dto.getCount() > 0) {
					// 前ページフラグ
					m_Accme11DispBean.setPrevPageFlg(GeneralFlg.ON);
				}
			}

			// 検索エリア非活性化フラグ
			m_Accme11DispBean.setListFlg(m_Accme11Dto.getListFlg());

			// 戻るボタン表示設定
			m_Accme11DispBean.setReturnFlg(m_Accme11Dto.getReturnFlg());

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 初期画面設定(金種・枚数・金額)
	 * <p>
	 * 画面初期項目を設定する
	 * </p>
	 * @param  なし
	 * @return なし
	 ************************************************************************************/
	private void denomiSet() throws AmallException {
		String methodName = "makeDetailList()";
		try {

			// 自動計算用
			int autoTotal = 0;

			// 金種取得（汎用マスタ）
			List<Integer> moneyTypeList = new ArrayList<>();
			List<AmdtoGeneralMst> typeList = AmallUtilities.getGeneralMstDataList(m_DbAccess,
					GeneralMstKey.MONEY_TYPE, null, null, m_Accme11DispBean.getServiceDate());
			for (AmdtoGeneralMst mst : typeList) {
				Number number = NumberFormat.getInstance().parse(mst.getGeneralNm1());
				moneyTypeList.add(number.intValue());
			}
			// 金額が大きいものからソート
			Collections.sort(moneyTypeList, Comparator.reverseOrder());

			// テーブルリストセット処理
			if (m_Accme11Form.getItemDispList() != null) {
				List<Accme11Dto> itemDispList = new ArrayList<>();
				for (Accme11Dto dto : m_Accme11Form.getItemDispList()) {
					// 金種表示用
					dto.setDispDenomi(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dto.getDenomi()));

					// 枚数表示用（登録後）
					if ((GeneralFlg.ON).equals(m_Accme11DispBean.getRegistFlg())) {
						dto.setMoneyNum(dto.getMoneyNum() + AmallConst.DEFAULT_MONEY_AMOUNT_JA);
					}

					// 金額表示用
					dto.setDispMoneyTotal(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dto.getMoneyTotal())
							+ AmallConst.DEFAULT_MONEY_JA);

					// 自動計算用
					autoTotal = autoTotal + dto.getMoneyTotal();
					// リスト追加
					itemDispList.add(dto);
				}
				if ((GeneralFlg.ON).equals(m_Accme11DispBean.getRegistFlg())) {
					int spccmt = Integer.parseInt(m_Accme11Form.getSpccmt());
					m_Accme11Form.setSpccmt(
							String.format(AmallConst.THREE_SEPARATOR_FORMAT, spccmt) + AmallConst.DEFAULT_MONEY_JA);

				}
				m_Accme11Form.setItemDispList(itemDispList);

			} else {
				// リストが存在しない場合
				List<Accme11Dto> itemDispList = new ArrayList<>();
				for (Integer money : moneyTypeList) {
					Accme11Dto dto = new Accme11Dto();
					// 金種
					dto.setDenomi(money);
					// 表示用
					dto.setDispDenomi(String.format(AmallConst.THREE_SEPARATOR_FORMAT, money));

					// 金額初期値
					dto.setDispMoneyTotal("0" + AmallConst.DEFAULT_MONEY_JA);
					dto.setMoneyTotal(0);

					itemDispList.add(dto);
				}
				m_Accme11Form.setItemDispList(itemDispList);
			}

			// 自動計算用代入
			m_Accme11Form.setAutoSpccmt(autoTotal);
			m_Accme11DispBean.setDispAutoSpccmt(
					String.format(AmallConst.THREE_SEPARATOR_FORMAT, autoTotal) + AmallConst.DEFAULT_MONEY_JA);

			return;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 入力項目妥当性チェック
	 * <p>
	 * 入力項目妥当性チェックを実行する
	 * </p>
	 * @return boolean
	 ************************************************************************************/
	private boolean proprietyCheck() throws AmallException {
		String methodName = "proprietyCheck()";
		try {

			// 返却用フラグ
			boolean ret = true;
			// 入力情報
			String cstCd = m_Accme11Form.getCstCd();
			String shopCd = m_Accme11Form.getDispShopCd();
			String shopSbno = m_Accme11Form.getDispShopSbno();
			String sld = m_Accme11Form.getSld();

			// 空白チェック
			if (AmallUtilities.isEmpty(cstCd) || AmallUtilities.isEmpty(shopCd) || AmallUtilities.isEmpty(shopSbno)
					|| AmallUtilities.isEmpty(sld)) {
				if (AmallUtilities.isEmpty(cstCd)) {
					// エラーメッセージ
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
							getItemDispName(ITEM_ID_CST_CD, m_Accme11DispBean));
					setError(m_Accme11DispBean, ITEM_ID_CST_CD);
				}
				if (AmallUtilities.isEmpty(shopCd)) {
					// エラーメッセージ
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
							getItemDispName(ITEM_ID_SHOP_CD, m_Accme11DispBean));
					setError(m_Accme11DispBean, ITEM_ID_SHOP_CD);
				}
				if (AmallUtilities.isEmpty(shopSbno)) {
					// エラーメッセージ
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
							getItemDispName(ITEM_ID_SHOPSBNO_CD, m_Accme11DispBean));
					setError(m_Accme11DispBean, ITEM_ID_SHOPSBNO_CD);
				}
				if (AmallUtilities.isEmpty(sld)) {
					// エラーメッセージ
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
							getItemDispName(ITEM_ID_SLD, m_Accme11DispBean));
					setError(m_Accme11DispBean, ITEM_ID_SLD);
				}
				return false;
			}

			// 入力値チェック(顧客コード)
			if (!AmallUtilities.isEmpty(cstCd)) {
				// 入力値が存在する場合
				if (!AmallUtilities.isHalfWidthCharacterKind(cstCd, AmallUtilities.H_NUM | AmallUtilities.H_ALP)) {
					// 半角英数以外が設定されている
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_CST_CD, m_Accme11DispBean), String.valueOf(InputNum.CST_CD));
					setError(m_Accme11DispBean, ITEM_ID_CST_CD);

					ret = false;
				} else if (AmallUtilities.getLengthAsHalf(cstCd) != InputNum.CST_CD) {
					// 10桁以外の数字が設定されている
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
							getItemDispName(ITEM_ID_CST_CD, m_Accme11DispBean), String.valueOf(InputNum.CST_CD));
					setError(m_Accme11DispBean, ITEM_ID_CST_CD);

					ret = false;
				}
			}

			// 入力値チェック(店舗コード)
			if (!AmallUtilities.isEmpty(shopCd)) {
				// 入力値が存在する場合
				if (!AmallUtilities.isHalfWidthCharacterKind(shopCd, AmallUtilities.H_NUM | AmallUtilities.H_ALP)) {
					// 半角英数字以外が設定されている
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_SHOP_CD, m_Accme11DispBean), String.valueOf(InputNum.SHOP_CD));
					setError(m_Accme11DispBean, ITEM_ID_SHOP_CD);
					ret = false;
				} else if (AmallUtilities.getLengthAsHalf(shopCd) > InputNum.SHOP_CD) {
					// 10桁より多い英数字が設定されている
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_SHOP_CD, m_Accme11DispBean), String.valueOf(InputNum.SHOP_CD));
					setError(m_Accme11DispBean, ITEM_ID_SHOP_CD);

					ret = false;
				}
				if (AmallUtilities.isEmpty(cstCd)) {
					// 顧客が空の場合
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
							getItemDispName(ITEM_ID_CST_CD, m_Accme11DispBean));
					setError(m_Accme11DispBean, ITEM_ID_CST_CD);
					ret = false;
				}
			}

			// 入力値チェック(店舗枝番コード)
			if (!AmallUtilities.isEmpty(shopSbno)) {
				// 入力値が存在する場合
				if (!AmallUtilities.isHalfWidthCharacterKind(shopSbno, AmallUtilities.H_NUM | AmallUtilities.H_ALP)) {
					// 半角英数以外が設定されている
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_SHOPSBNO_CD, m_Accme11DispBean),
							String.valueOf(InputNum.SHOP_BRANCH_CD));
					setError(m_Accme11DispBean, ITEM_ID_SHOPSBNO_CD);

					ret = false;
				} else if (AmallUtilities.getLengthAsHalf(shopSbno) > InputNum.SHOP_BRANCH_CD) {
					// 14桁より多い数字が設定されている
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
							getItemDispName(ITEM_ID_SHOPSBNO_CD, m_Accme11DispBean),
							String.valueOf(InputNum.SHOP_BRANCH_CD));
					setError(m_Accme11DispBean, ITEM_ID_SHOPSBNO_CD);
					ret = false;
				}
				if (AmallUtilities.isEmpty(shopCd)) {
					// 店舗が空の場合
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
							getItemDispName(ITEM_ID_SHOP_CD, m_Accme11DispBean));
					setError(m_Accme11DispBean, ITEM_ID_SHOP_CD);

					if (AmallUtilities.isEmpty(cstCd)) {
						// 顧客も空の場合
						setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
								getItemDispName(ITEM_ID_CST_CD, m_Accme11DispBean));
						setError(m_Accme11DispBean, ITEM_ID_CST_CD);
					}
					ret = false;
				}
			}

			// 日付妥当性チェック
			if (!AmallUtilities.isEmpty(sld)) {
				// 日付入力形式チェック
				if (sld.length() != 10) {
					if (sld.length() == 8) {
						sld = AmallUtilities.changeFormat(sld);
						m_Accme11Form.setSld(sld);
					} else {
						setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_DATE_ERROR, "", "");
						setError(m_Accme11DispBean, ITEM_ID_SLD);
						ret = false;
					}
				}
				if (!AmallUtilities.checkExistDate(sld)) {
					// 正しい日付か
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_NOT_EXIST_DATE,
							getItemDispName(ITEM_ID_SLD, m_Accme11DispBean), "");
					setError(m_Accme11DispBean, ITEM_ID_SLD);
					ret = false;
				}

				// 未来日チェック
				String nowDate = m_Accme11DispBean.getServiceDate();
				String sldDate = AmallUtilities.changeFormat422(sld);
				if (AmallUtilities.diffDate(sldDate, nowDate) < 0) {
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_FUTURE_DATE, "");
					setError(m_Accme11DispBean, ITEM_ID_SLD);
					ret = false;
				}
			}

			// 金種テーブル内妥当性チェック
			if (!inputCheckNum()) {

				ret = false;
			}

			// ユニークチェック
			if (ret) {
				m_Accme11Dto.setSld(AmallUtilities.changeFormat422(sld));
				// ユニークチェック
				if (!chkUniqShopSbno()) {
					// 特定できない場合
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_CAN_NOT_IDENTIFY_DATA,
							getItemDispName(ITEM_ID_SHOPSBNO_CD, m_Accme11DispBean),
							getItemDispName(ITEM_ID_SHOP_BRANCH_SEARCH_IN, m_Accme11DispBean));
					setError(m_Accme11DispBean, ITEM_ID_SHOPSBNO_CD);
					ret = false;
				}
				// 特定した場合はdtoセット（chkUniqShopSbno()で処理）
			}

			return ret;

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

	}

	/*************************************************************************************
	 * 検索処理実行
	 * <p>
	 * 検索処理を実行する
	 * </p>
	 * @param  なし
	 * @return なし
	 ************************************************************************************/
	public boolean inputCheckNum() throws AmallException {
		// methodName
		String methodName = "inputCheckNum()";

		// 返却フラグ
		boolean retFlg = true;
		try {

			// == 検索条件・更新データ取得 ==
			// 今回対象画面データリストを取得

			// 入力データ取得
			List<Accme11Dto> dataList = m_Accme11Form.getItemDispList();

			// == 入力チェック ==
			// 取得データ分繰り返す

			// 金種・枚数・（金種別）金額
			for (int index = 0; index < dataList.size(); index++) {
				// 枚数
				if (!AmallUtilities.isEmpty(dataList.get(index).getMoneyNum())) {
					if (!AmallUtilities.isHalfWidthCharacterKind(dataList.get(index).getMoneyNum(),
							AmallUtilities.H_NUM)) {
						// 入力されているのが半角数字のみかの判断
						setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_NUMBER_ONLY,
								getItemDispName(ITEM_ID_MONEY_NUM, m_Accme11DispBean));
						setError(m_Accme11DispBean, (ITEM_ID_MONEY_NUM + index));
						retFlg = false;
						break;
					}
				}
			}

			// 合計金額

			String total = "0";
			// 数値フラグ
			boolean numFlg = true;
			if (!AmallUtilities.isEmpty(m_Accme11Form.getSpccmt())) {
				// 枚数がnullでない場合
				if (!AmallUtilities.isHalfWidthCharacterKind(m_Accme11Form.getSpccmt(), AmallUtilities.H_NUM)) {
					// 入力されているのが半角数字のみかの判断
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_INPUT_NUMBER_ONLY,
							getItemDispName(ITEM_ID_SPCCMT, m_Accme11DispBean));
					setError(m_Accme11DispBean, ITEM_ID_SPCCMT);
					retFlg = false;
					numFlg = false;
				}
				total = m_Accme11Form.getSpccmt();
			}
			m_Accme11Form.setSpccmt(total);

			// 入力金額と自動金額比較
			if (numFlg) {
				int spccmt = Integer.parseInt(m_Accme11Form.getSpccmt());
				int autoTotal = m_Accme11Form.getAutoSpccmt();
				if (spccmt != autoTotal) {
					setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_COMPARE_SPCCMT_ERROR);
					setError(m_Accme11DispBean, ITEM_ID_SPCCMT);
					retFlg = false;
				}
			}

			return retFlg;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 検索処理実行
	 * <p>
	 * 検索処理を実行する
	 * </p>
	 * @param  なし
	 * @return なし
	 ************************************************************************************/
	public void search() throws AmallException {
		// methodName
		String methodName = "search()";

		try {

			// キャプションデータチェック
			chkUniqShopSbno();

			// 回収金入力レコード検索処理
			clmyDatSearch();

			// 金種テーブル・フラグ設定
			dispCommonproc();

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 金種別テーブル項目・フラグ作成
	 * <p>
	 * 画面共通処理である金種別テーブル項目・フラグ設定を行う
	 * </p>
	 * @param なし
	 * @return なし
	 ************************************************************************************/
	private void dispCommonproc() throws AmallException {

		// methodName
		String methodName = "dispCommonproc()";
		//

		try {
			// 金種テーブル設定
			denomiSet();
			// フラグセット
			pageMoveSet();

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		}

	}

	/*************************************************************************************
	 * 回収金入力データ取得
	 * <p>
	 * 回収金入力データ取得処理を行う
	 * </p>
	 * @param なし
	 * @return
	 ************************************************************************************/
	protected void clmyDatSearch() throws AmallException, Exception {
		String methodName = "clmyDatSearch()";

		// リザルトセット
		ResultSet rs = null;
		// 返却用チェックリスト
		List<AccmeItemDispDto> retList = new ArrayList<>();

		// 検索条件
		String cstCd = m_Accme11Form.getCstCd();
		String shopCd = m_Accme11Form.getShopCd();
		String shopSbno = m_Accme11Form.getShopSbno();
		String sld = AmallUtilities.changeFormat422(m_Accme11Form.getSld());

		try {

			// 画面表示
			// テーブル内金種枚数金額
			List<Integer> moneyTypeList = new ArrayList<>();
			List<AmdtoGeneralMst> typeList = AmallUtilities.getGeneralMstDataList(m_DbAccess,
					GeneralMstKey.MONEY_TYPE, null, null, m_Accme11DispBean.getServiceDate());
			for (AmdtoGeneralMst mst : typeList) {
				Number number = NumberFormat.getInstance().parse(mst.getGeneralNm1());
				moneyTypeList.add(number.intValue());
			}
			// 金額が大きいものからソート
			Collections.sort(moneyTypeList, Comparator.reverseOrder());

			// SQL作成
			StringBuffer sql = new StringBuffer();
			List<String> bindParam = new ArrayList<String>();
			sql.append("SELECT");
			sql.append("    NCED.CST_CD AS CST_CD,");
			sql.append("    NCED.SHOP_CD AS SHOP_CD,");
			sql.append("    NCED.SHOP_SBNO AS SHOP_SBNO,");
			sql.append("    NCED.SLD AS SLD,");
			sql.append("    NCED.EXCLUSIVE_KEY AS EXCLUSIVE_KEY,");
			sql.append("    NCED.UPD_DT AS UPD_DT,");
			sql.append("    NVL(NCED.SPCCMT,0) AS SPCCMT,");
			sql.append("    NVL(NCED.SPCCMT_10000Y_MAI,0) AS SPCCMT_10000Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_5000Y_MAI,0) AS SPCCMT_5000Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_2000Y_MAI,0) AS SPCCMT_2000Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_1000Y_MAI,0) AS SPCCMT_1000Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_500Y_MAI,0) AS SPCCMT_500Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_100Y_MAI,0) AS SPCCMT_100Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_50Y_MAI,0) AS SPCCMT_50Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_10Y_MAI,0) AS SPCCMT_10Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_5Y_MAI,0) AS SPCCMT_5Y_MAI,");
			sql.append("    NVL(NCED.SPCCMT_1Y_MAI,0) AS SPCCMT_1Y_MAI");
			sql.append(" FROM");
			sql.append("   N_CLMY_ENT_DAT NCED");
			sql.append(" WHERE");
			sql.append("    NCED.CST_CD = ?");
			bindParam.add(cstCd);
			sql.append("    AND   NCED.SHOP_CD = ?");
			bindParam.add(shopCd);
			sql.append("    AND   NCED.SHOP_SBNO = ?");
			bindParam.add(shopSbno);
			sql.append("    AND  NCED.SLD = ?");
			bindParam.add(sld);
			sql.append("    AND		NCED.DEL_FLG = ?");
			bindParam.add(AmallConst.DEFAULT_DEL_FLG);

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < bindParam.size(); i++) {
				m_DbAccess.setString(i + 1, bindParam.get(i));
			}

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			// 実行結果チェック

			// 排他キー
			Long exKey = null;
			while (rs.next()) {
				AccmeItemDispDto dto = new AccmeItemDispDto();
				// 更新日時
				if (rs.getDate("UPD_DT") == null) {
					dto.setUpdateDate(null);

				} else {
					String str = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(rs.getDate("UPD_DT"));
					dto.setUpdateDate(str);
				}
				m_Accme11DispBean.setUpdateDate(dto.getUpdateDate());

				// 自動計算金額
				int autoTotal = 0;
				// リストセット処理
				List<Accme11Dto> itemDispList = new ArrayList<>();
				for (Integer money : moneyTypeList) {
					Accme11Dto dispdto = new Accme11Dto();
					// 数値
					dispdto.setDenomi(money);
					// 表示用
					dispdto.setDispDenomi(String.format(AmallConst.THREE_SEPARATOR_FORMAT, money));

					// 枚数
					//	SPCCMT_10000Y_MAI SPCCMT_10000_MAI
					String key = "SPCCMT_" + money + "Y_MAI";
					dispdto.setMoneyNum(rs.getString(key));

					// 金額初期値
					int total = money * (Integer.parseInt(rs.getString(key)));
					dispdto.setDispMoneyTotal(
							String.format(AmallConst.THREE_SEPARATOR_FORMAT, total) + AmallConst.DEFAULT_MONEY_JA);
					dispdto.setMoneyTotal(total);
					// 自動計算用
					autoTotal = autoTotal + total;

					itemDispList.add(dispdto);
				}

				// Formに保存
				// 金種別枚数＆金額
				m_Accme11Form.setItemDispList(itemDispList);
				// 合計金額
				m_Accme11Form.setSpccmt(rs.getString("SPCCMT"));
				// 自動計算用代入
				m_Accme11Form.setAutoSpccmt(autoTotal);
				m_Accme11DispBean.setDispAutoSpccmt(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, autoTotal) + AmallConst.DEFAULT_MONEY_JA);

				// 排他キー
				exKey = rs.getLong("EXCLUSIVE_KEY");
				if (rs.wasNull()) {
					exKey = null;
				}
				retList.add(dto);
			}

			// 排他キーをDTOに保存（結果0件時はnullを代入）
			m_Accme11Dto.setExclusiveKey(exKey);

			/* StringBuffer 開放  */
			sql.delete(0, sql.length());
			sql = null;

			/* List<String> 開放  */
			bindParam.clear();
			bindParam = null;

		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					ITEM_ID_SCREEN_NAME);
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	/*************************************************************************************
	 * キャプションエリアユニークチェック
	 * <p>
	 *顧客・店舗・レジ名検索処理を実行し、ユニークかどうか判定を行う
	 * </p>
	 * @param	なし
	 * @return boolean
	 ************************************************************************************/
	protected boolean chkUniqShopSbno() throws AmallException, Exception {
		// メソッド名
		String methodName = "chkUniqShopSbno()";
		// 結果
		ResultSet rs = null;
		// 返却用チェックリスト
		List<Accme11Action> retList = new ArrayList<>();

		// システム日付
		String systemDt = m_Accme11DispBean.getServiceDate();
		// 顧客CD
		String cstCd = m_Accme11Form.getCstCd();
		String shopCd = m_Accme11Form.getDispShopCd();
		String shopSbno = m_Accme11Form.getDispShopSbno();

		try {

			StringBuffer sql = new StringBuffer();
			List<String> bindParam = new ArrayList<String>();

			// SQL SELECT
			sql.delete(0, sql.length());

			sql.append("SELECT");
			sql.append("	ncm.CST_CD");
			sql.append(",	ncm.CST_NM");
			sql.append(",	nsm.SHOP_CD");
			sql.append(",	nsm.SHOP_NM");
			sql.append(",	TRIM(nscm.COMPANY_SHOP_CD) AS COMPANY_SHOP_CD");
			sql.append(",	TRIM(nscm.COMPANY_SHOP_NM) AS COMPANY_SHOP_NM");
			sql.append(",	nssm.SHOP_SBNO");
			sql.append(",	nssm.SHOP_SB_NM");
			sql.append(",	TRIM(nsscm.COMPANY_SHOP_SB_CD) AS COMPANY_SHOP_SB_CD");
			sql.append(",	TRIM(nsscm.COMPANY_SHOP_SB_NM) AS COMPANY_SHOP_SB_NM");

			// SQL FROM & WHERE
			sql.append("  FROM");
			sql.append("	N_SHOP_SB_M nssm");
			sql.append("	INNER JOIN");
			sql.append("		N_CST_M ncm");
			sql.append("	  ON");
			sql.append("		nssm.CST_CD = ncm.CST_CD");
			sql.append("		AND ncm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	INNER JOIN");
			sql.append("		N_SHOP_M nsm");
			sql.append("	  ON");
			sql.append("		nssm.CST_CD = nsm.CST_CD");
			sql.append("		AND nssm.SHOP_CD = nsm.SHOP_CD");
			// 有効期間
			sql.append("		AND ? BETWEEN nsm.EFST_DY AND nsm.EFED_DY");
			bindParam.add(systemDt);
			sql.append("		AND nsm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_CNV_M nscm");
			sql.append("	  ON");
			sql.append("		nssm.CST_CD = nscm.CST_CD");
			sql.append("		AND nssm.SHOP_CD = nscm.SHOP_CD");
			// 有効期間
			sql.append("		AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
			bindParam.add(systemDt);
			sql.append("		AND nscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_SB_CNV_M nsscm");
			sql.append("	  ON");
			sql.append("		nssm.CST_CD = nsscm.CST_CD");
			sql.append("		AND nssm.SHOP_CD = nsscm.SHOP_CD");
			sql.append("		AND nssm.SHOP_SBNO = nsscm.SHOP_SBNO");
			// 有効期間
			sql.append("		AND ? BETWEEN nsscm.EFST_DY AND nsscm.EFED_DY");
			bindParam.add(systemDt);
			sql.append("		AND nsscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append(" WHERE");
			// 削除フラグ
			sql.append("	 nssm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");

			// 顧客コード
			sql.append("	AND ncm.CST_CD = ?");
			bindParam.add(cstCd);

			// 店舗コード(お客様店舗コード)
			sql.append("	AND (");
			sql.append("		nsm.SHOP_CD = ?");
			sql.append("		OR");
			sql.append("		TRIM(nscm.COMPANY_SHOP_CD) = ?");
			sql.append("	)");
			bindParam.add(shopCd);
			bindParam.add(shopCd);
			// 店舗枝番コード(お客様店舗コード)
			sql.append("	AND (");
			sql.append("		nssm.SHOP_SBNO = ?");
			sql.append("		OR");
			sql.append("		TRIM(nsscm.COMPANY_SHOP_SB_CD) = ?");
			sql.append("	)");
			bindParam.add(shopSbno);
			bindParam.add(shopSbno);

			// 有効期間
			sql.append("	AND ? BETWEEN nssm.EFST_DY AND nssm.EFED_DY");
			bindParam.add(systemDt);

			// 店舗範囲設定
			// 全店舗判定
			if (!m_Accme11DispBean.isShopCdAllFlg()) {
				// 全顧客・全店舗ではない場合
				sql.append("	AND (");
				boolean first = true;
				for (Entry<String, List<String>> entry : m_Accme11DispBean.getShopCdListMap().entrySet()) {

					String appCstCd = entry.getKey();
					for (String appShop : entry.getValue()) {
						if (first) {
							sql.append("		(");
							first = false;
						} else {
							sql.append("		OR (");
						}
						sql.append("			ncm.CST_CD = '").append(appCstCd).append("'");
						sql.append("			AND");
						sql.append("			nsm.SHOP_CD = '").append(appShop).append("'");
						sql.append("		)");
					}
				}
				sql.append("	)");
			}

			// SQL ORDER
			sql.append("  ORDER BY");
			sql.append("	ncm.CST_CD");
			sql.append(",	nsm.SHOP_CD");

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < bindParam.size(); i++) {
				m_DbAccess.setString(i + 1, bindParam.get(i));
			}

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 実行結果チェック
			// 結果取得
			Accme11Action infoAction = new Accme11Action();

			while (rs.next()) {

				// 顧客コード
				infoAction.setCstCd(m_DbAccess.getString(rs, "CST_CD"));
				// 顧客名
				infoAction.setCstNm(m_DbAccess.getString(rs, "CST_NM"));

				// 店舗名
				String shop = m_DbAccess.getString(rs, "SHOP_CD");
				infoAction.setShopCd(shop);
				// 店舗名(企業)
				String comapany = m_DbAccess.getString(rs, "COMPANY_SHOP_CD");

				// 企業店舗コード判定
				if (AmallUtilities.isEmpty(comapany)) {
					// リストに追加
					infoAction.setDispShopCd(shop);
				} else {
					// 企業店舗コードがある場合は企業店舗を優先
					// リストに追加
					infoAction.setDispShopCd(comapany);
				}

				// 店舗名
				shop = m_DbAccess.getString(rs, "SHOP_NM");
				// 店舗名(企業)
				comapany = m_DbAccess.getString(rs, "COMPANY_SHOP_NM");

				// 企業店舗コード判定
				if (AmallUtilities.isEmpty(comapany)) {
					// リストに追加
					infoAction.setShopNm(shop);
				} else {
					// 企業店舗コードがある場合は企業店舗を優先
					// リストに追加
					infoAction.setShopNm(comapany);
				}

				// 店舗枝番
				String sbno = m_DbAccess.getString(rs, "SHOP_SBNO");
				infoAction.setShopSbno(sbno);
				// 店舗枝番(企業)
				comapany = m_DbAccess.getString(rs, "COMPANY_SHOP_SB_CD");

				// 企業店舗枝番判定
				if (AmallUtilities.isEmpty(comapany)) {
					// リストに追加
					infoAction.setDispShopSbno(sbno);
				} else {
					// 企業店舗枝番がある場合は企業店舗を優先
					// リストに追加
					infoAction.setDispShopSbno(comapany);
				}

				// 店舗枝番名
				sbno = m_DbAccess.getString(rs, "SHOP_SB_NM");
				// 店舗枝番名(企業)
				comapany = m_DbAccess.getString(rs, "COMPANY_SHOP_SB_NM");

				// 企業店舗枝番判定
				if (AmallUtilities.isEmpty(comapany)) {
					// リストに追加
					infoAction.setShopSbnm(sbno);
				} else {
					// 企業店舗枝番名がある場合は企業店舗を優先
					// リストに追加
					infoAction.setShopSbnm(comapany);
				}

				retList.add(infoAction);

			}

			// 結果チェック
			if (retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}

			// 値を設定
			m_Accme11Form.setCstCd(infoAction.getCstCd());
			m_Accme11Form.setCstNm(infoAction.getCstNm());
			m_Accme11Form.setShopCd(infoAction.getShopCd());
			m_Accme11Form.setDispShopCd(infoAction.getDispShopCd());
			m_Accme11Form.setShopNm(infoAction.getShopNm());
			m_Accme11Form.setShopSbno(infoAction.getShopSbno());
			m_Accme11Form.setDispShopSbno(infoAction.getDispShopSbno());
			m_Accme11Form.setShopSbnm(infoAction.getShopSbnm());

			// DTOセット
			m_Accme11Dto.setCstCd(infoAction.getCstCd());
			m_Accme11Dto.setShopCd(infoAction.getShopCd());
			m_Accme11Dto.setShopSbno(infoAction.getShopSbno());

			/* StringBuffer 開放  */
			sql.delete(0, sql.length());
			sql = null;

		} catch (AmallException ame) {
			m_DbAccess.rollback();
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					getItemDispName(ITEM_ID_SCREEN_NAME, m_Accme11DispBean));
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

		return true;
	}

	/*************************************************************************************
	 * 回収金集票入力データ(DB)更新
	 * <p>
	 * 回収金集票入力データ(DB)にレコードを更新する
	 * </p>
	 * @param moneyNumList 金額枚数リスト(金額降順)
	 * @param moneyTotalList 金額リスト(金額降順)
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	private boolean updateClmyEntDat(List<Integer> moneyNumList, List<Integer> moneyTotalList) throws AmallException {

		String methodName = "updateScrRoleMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// SQL生成
			sql.append("UPDATE N_CLMY_ENT_DAT");
			sql.append("    SET");
			sql.append("        SPCCMT_10000Y_MAI = ?,");
			sql.append("        SPCCMT_5000Y_MAI = ?,");
			sql.append("        SPCCMT_2000Y_MAI = ?,");
			sql.append("        SPCCMT_1000Y_MAI = ?,");
			sql.append("        SPCCMT_500Y_MAI = ?,");
			sql.append("        SPCCMT_100Y_MAI = ?,");
			sql.append("        SPCCMT_50Y_MAI = ?,");
			sql.append("        SPCCMT_10Y_MAI = ?,");
			sql.append("        SPCCMT_5Y_MAI = ?,");
			sql.append("        SPCCMT_1Y_MAI = ?,");
			sql.append("        SPCCMT_10000Y_AMT = 10000 * ?,");
			sql.append("        SPCCMT_5000Y_AMT = 10000 * ?,");
			sql.append("        SPCCMT_2000Y_AMT = 10000 * ?,");
			sql.append("        SPCCMT_1000Y_AMT = 10000 * ?,");
			sql.append("        SPCCMT_500Y_AMT = 10000 * ?,");
			sql.append("        SPCCMT_100Y_AMT = 10000 * ?,");
			sql.append("        SPCCMT_50Y_AMT = 10000 * ?,");
			sql.append("        SPCCMT_10Y_AMT = 10000 * ?,");
			sql.append("        SPCCMT_5Y_AMT = 10000 * ?,");
			sql.append("        SPCCMT_1Y_AMT = 10000 * ?,");
			sql.append("        SPCCMT = ?,");
			sql.append("        STATUS_CLS = ?,");
			sql.append("        SEND_FLG = ?,");
			sql.append("        UPD_CNT = UPD_CNT + 1,");
			sql.append("        UPD_ENT_USER_ID = ?,");
			sql.append("        UPD_ENT_USER_NM = ?,");
			sql.append("        UPD_ENT_DT = SYSDATE");

			// 共通部分
			sql.append(",	UPD_PGM_ID =  ?");
			sql.append(",	UPD_USER_ID =  ?");
			sql.append(",	UPD_DT =  SYSDATE");
			sql.append(",	EXCLUSIVE_KEY =  EXCLUSIVE_KEY + 1");
			// 条件指定
			sql.append(" WHERE");
			sql.append("    CST_CD = ?");
			sql.append("    AND   SHOP_CD = ?");
			sql.append("    AND   SHOP_SBNO = ?");
			sql.append("    AND   SLD = ?");
			sql.append("    AND   FIN_FLG = ?");

			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND EXCLUSIVE_KEY = ?");

			// 更新値のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;

			// 枚数 10回
			for (int num : moneyNumList) {
				m_DbAccess.setInt(++setCnt, num);
			}

			// 金額 10回
			for (int num : moneyTotalList) {
				m_DbAccess.setInt(++setCnt, num);
			}

			// 合計金額
			m_DbAccess.setString(++setCnt, m_Accme11Form.getSpccmt());

			// ステータスクラス
			m_DbAccess.setString(++setCnt, "02");

			// 送信フラグ
			m_DbAccess.setString(++setCnt, "0");

			// アップデートユーザーID
			m_DbAccess.setString(++setCnt, m_Accme11DispBean.getH_loginId());
			// アップデートユーザー名
			m_DbAccess.setString(++setCnt, m_Accme11DispBean.getH_loginDispName());

			// 更新プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 更新ユーザーID
			m_DbAccess.setString(++setCnt, m_Accme11DispBean.getH_loginId());

			// WHERE句のパラメタ設定
			// 顧客CD
			m_DbAccess.setString(++setCnt, m_Accme11Dto.getCstCd());
			// 店舗CD
			m_DbAccess.setString(++setCnt, m_Accme11Dto.getShopCd());
			// 店舗枝番
			m_DbAccess.setString(++setCnt, m_Accme11Dto.getShopSbno());
			// 売上日
			m_DbAccess.setString(++setCnt, m_Accme11Dto.getSld());
			// 締めフラグ
			m_DbAccess.setString(++setCnt, GeneralFlg.OFF);

			// 共通項目
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 排他キー
			m_DbAccess.setLong(++setCnt, m_Accme11Dto.getExclusiveKey());

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 排他チェック
			if (ret == 0) {
				// 更新対象無し(楽観排他)
				m_DbAccess.rollback();

				// エラー情報を設定
				setMessageInfo(m_Accme11DispBean, AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST);

				// アクセスログ情報の作成
				AmallExceptionInfo amei = new AmallExceptionInfo();
				amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_ACS_OPT_ERROR, "N_CLMY_ENT_DAT"));
				setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

				return false;
			}

			// 更新結果判定
			if (ret != 1) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR,
						"N_CLMY_ENT_DAT");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_CLMY_ENT_DAT");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}

	/*************************************************************************************
	 * 回収金集票入力データ(DB)登録
	 * <p>
	 * 回収金集票入力データ(DB)にレコードを登録する
	 * </p>
	 * @param moneyNumList 金額枚数リスト(金額降順)
	 * @param moneyTotalList 金額リスト(金額降順)
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	private boolean insertClmyEntDat(List<Integer> moneyNumList, List<Integer> moneyTotalList) throws AmallException {

		String methodName = "insertScrRoleMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// SQL生成
			sql.append("    INSERT INTO N_CLMY_ENT_DAT (");
			sql.append("        CST_CD,");
			sql.append("        SHOP_CD,");
			sql.append("        SHOP_SBNO,");
			sql.append("        SLD,");

			sql.append("        CLD,");
			sql.append("        ENT_FIN_DY,");

			sql.append("        CENTER_CD,");
			sql.append("        SR_CT_CD,");
			sql.append("        SR_SHOP_CD,");
			sql.append("        SR_CD,");

			sql.append("        SPCCMT_10000Y_MAI,");
			sql.append("        SPCCMT_5000Y_MAI,");
			sql.append("        SPCCMT_2000Y_MAI,");
			sql.append("        SPCCMT_1000Y_MAI,");
			sql.append("        SPCCMT_500Y_MAI,");
			sql.append("        SPCCMT_100Y_MAI,");
			sql.append("        SPCCMT_50Y_MAI,");
			sql.append("        SPCCMT_10Y_MAI,");
			sql.append("        SPCCMT_5Y_MAI,");
			sql.append("        SPCCMT_1Y_MAI,");

			sql.append("        SPCCMT_10000Y_AMT,");
			sql.append("        SPCCMT_5000Y_AMT,");
			sql.append("        SPCCMT_2000Y_AMT,");
			sql.append("        SPCCMT_1000Y_AMT,");
			sql.append("        SPCCMT_500Y_AMT,");
			sql.append("        SPCCMT_100Y_AMT,");
			sql.append("        SPCCMT_50Y_AMT,");
			sql.append("        SPCCMT_10Y_AMT,");
			sql.append("        SPCCMT_5Y_AMT,");
			sql.append("        SPCCMT_1Y_AMT,");

			sql.append("        SPCCMT,");
			sql.append("        STATUS_CLS,");
			sql.append("        SEND_FLG,");
			sql.append("        FIN_FLG,");
			sql.append("        SLD_ENT_CLS,");

			sql.append("        UPD_CNT,");
			sql.append("        UPD_ENT_USER_ID,");
			sql.append("        UPD_ENT_USER_NM,");

			sql.append("        UPD_ENT_DT,");

			sql.append("        EXCLUSIVE_KEY,");
			sql.append("        DEL_FLG,");

			sql.append("        CR_PGM_ID,");
			sql.append("        CR_USER_ID,");

			sql.append("        CR_DT,");

			sql.append("        UPD_PGM_ID,");
			sql.append("        UPD_USER_ID,");

			sql.append("        UPD_DT");

			sql.append("    ) VALUES (");
			// 基本情報
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");

			sql.append("        ?,");
			sql.append("        ?,");

			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");

			// 入力枚数(金額)
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");

			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        ?,");

			// 合計
			sql.append("        ?,");

			// ステータス
			sql.append("        ?,");
			// 送信フラグ
			sql.append("        ?,");
			// 締めフラグ
			sql.append("        ?,");
			// 売上日入力区分
			sql.append("        ?,");

			// アップデート回数
			sql.append("        ?,");
			// ID
			sql.append("        ?,");
			// 更新社名
			sql.append("        ?,");
			sql.append("        SYSDATE,");
			// 排他
			sql.append("        0,");
			// 削除
			sql.append("        0,");
			// 登録プログラムＩＤ
			// 登録ユーザＩＤ
			sql.append("        ?,");
			sql.append("        ?,");
			sql.append("        SYSDATE,");
			// 更新プログラムＩＤ
			// 更新ユーザＩＤ
			sql.append("        ?,");
			sql.append("       	?,");
			sql.append("        SYSDATE");
			sql.append("    )");

			// 登録値のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;
			// 基本情報
			m_DbAccess.setString(++setCnt, m_Accme11Dto.getCstCd());
			m_DbAccess.setString(++setCnt, m_Accme11Dto.getShopCd());
			m_DbAccess.setString(++setCnt, m_Accme11Dto.getShopSbno());
			m_DbAccess.setString(++setCnt, m_Accme11Dto.getSld());

			// 回収日
			String cld = AmallUtilities.addDate(m_Accme11Dto.getSld(), 1, 1);
			m_DbAccess.setString(++setCnt, cld);
			m_DbAccess.setString(++setCnt, cld + insertDto.getEntFinDt());

			// 主管センターコード
			m_DbAccess.setString(++setCnt, insertDto.getCenterCd());
			m_DbAccess.setString(++setCnt, insertDto.getSrCstCd());
			m_DbAccess.setString(++setCnt, insertDto.getSrShopCd());
			m_DbAccess.setString(++setCnt, insertDto.getSrCd());

			// 枚数 10回
			for (int num : moneyNumList) {
				m_DbAccess.setInt(++setCnt, num);
			}

			// 金額 10回
			for (int num : moneyTotalList) {
				m_DbAccess.setInt(++setCnt, num);
			}

			// 合計金額
			m_DbAccess.setString(++setCnt, m_Accme11Form.getSpccmt());

			// ステータスクラス
			m_DbAccess.setString(++setCnt, "01");

			// 送信フラグ
			m_DbAccess.setString(++setCnt, "0");

			// 締めフラグ
			m_DbAccess.setString(++setCnt, "0");
			// 売上日入力区分
			m_DbAccess.setString(++setCnt, insertDto.getSldFlg());

			// アップデート回数
			m_DbAccess.setLong(++setCnt, 0);
			// 金種票更新者ID
			m_DbAccess.setString(++setCnt, m_Accme11DispBean.getH_loginId());
			// 金種票更新者名
			m_DbAccess.setString(++setCnt, m_Accme11DispBean.getH_loginDispName());

			// 登録プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 登録ユーザーID
			m_DbAccess.setString(++setCnt, m_Accme11DispBean.getH_loginId());

			// 更新プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 更新ユーザーID
			m_DbAccess.setString(++setCnt, m_Accme11DispBean.getH_loginId());

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 更新結果判定
			if (ret <= 0) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR,
						"N_CLMY_ENT_DAT");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_CLMY_ENT_DAT");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}

	/*************************************************************************************
	 * insertにおける必要項目取得
	 * <p>
	 * insertにおける必要項目を取得する
	 * </p>
	 * @param なし
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	private boolean searchInsertItem() throws AmallException, Exception {

		// メソッド名
		String methodName = "searchInsertItem()";
		// 結果
		ResultSet rs = null;
		// 返却用チェックリスト
		List<AccmeItemInsertDto> retList = new ArrayList<>();

		// システム日付
		String systemDt = m_Accme11DispBean.getServiceDate();
		// 顧客CD
		String cstCd = m_Accme11Dto.getCstCd();
		String shopCd = m_Accme11Dto.getShopCd();
		String shopSbno = m_Accme11Dto.getShopSbno();
		String sld = m_Accme11Dto.getSld();

		try {

			// 汎用マスタより入力締め日の時間帯入手
			// 金種取得（汎用マスタ）
			AmdtoGeneralMst hms = AmallUtilities.getGeneralMstDataRecord(m_DbAccess, GeneralMstKey.ENT_FIN_DY, null,
					null, m_Accme11DispBean.getServiceDate());
			// 入力締め日時間帯DTOセット
			insertDto.setEntFinDt(hms.getGeneralNm1());

			StringBuffer sql = new StringBuffer();
			List<String> bindParam = new ArrayList<String>();

			// SQL SELECT
			sql.delete(0, sql.length());

			sql.append("SELECT");
			sql.append("	nsm.MAINP_CT_CD AS CENTER_CD");
			sql.append(",	nssm.SR_CST_CD AS SR_CST_CD");
			sql.append(",	nssm.SR_SHOP_CD AS SR_SHOP_CD");
			sql.append(",	nssm.SR_CD AS SR_CD");
			sql.append(",	ncsd.MCD_ODRN AS MCD_ODRN");
			sql.append(",    CASE");
			sql.append("            WHEN NCSD.MCD_ODRN IS NULL THEN '00'");
			sql.append("            ELSE '01'");
			sql.append("        END");
			sql.append("    SLD_FLG");

			// SQL FROM & WHERE
			sql.append("  FROM");
			sql.append("		N_SHOP_M nsm");

			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_SB_M nssm");
			sql.append("	  ON");
			sql.append("		nsm.CST_CD = nssm.CST_CD");
			sql.append("		AND nsm.SHOP_CD = nssm.SHOP_CD");
			// 有効期間
			sql.append("		AND ? BETWEEN nssm.EFST_DY AND nssm.EFED_DY");
			bindParam.add(systemDt);
			sql.append("		AND nssm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_CLMY_SLD_DAT ncsd");
			sql.append("	  ON");
			sql.append("		nsm.CST_CD = ncsd.CST_CD");
			sql.append("		AND nsm.SHOP_CD = ncsd.SHOP_CD");
			sql.append("		AND nsm.MAINP_CT_CD = ncsd.CENTER_CD");
			sql.append("		AND nssm.SHOP_SBNO = ncsd.SHOP_SBNO");
			sql.append("		AND ncsd.SLD = ?");
			bindParam.add(sld);
			sql.append(" WHERE");
			// 有効期間
			sql.append("		 ? BETWEEN nsm.EFST_DY AND nsm.EFED_DY");
			bindParam.add(systemDt);
			sql.append("		AND nsm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");

			// 顧客コード
			sql.append("	AND nsm.CST_CD = ?");
			bindParam.add(cstCd);

			// 店舗コード(お客様店舗コード)
			sql.append("	AND nsm.SHOP_CD = ?");
			bindParam.add(shopCd);
			// 店舗枝番コード(お客様店舗コード)
			sql.append("	AND nssm.SHOP_SBNO = ?");
			bindParam.add(shopSbno);

			// SQL ORDER

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < bindParam.size(); i++) {
				m_DbAccess.setString(i + 1, bindParam.get(i));
			}

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 実行結果チェック
			// 結果取得
			insertDto = new AccmeItemInsertDto();

			while (rs.next()) {

				// 主管センターコード
				insertDto.setCenterCd(m_DbAccess.getString(rs, "CENTER_CD"));
				// SR顧客コード
				insertDto.setCenterCd(m_DbAccess.getString(rs, "SR_CST_CD"));
				// SR店舗コード
				insertDto.setCenterCd(m_DbAccess.getString(rs, "SR_SHOP_CD"));
				// SRコード
				insertDto.setCenterCd(m_DbAccess.getString(rs, "SR_CD"));
				// 売上日データ存在フラグ
				insertDto.setSldFlg(m_DbAccess.getString(rs, "SLD_FLG"));

				// リストに追加
				retList.add(insertDto);

			}

			// 結果チェック
			if (retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}

			/* StringBuffer 開放  */
			sql.delete(0, sql.length());
			sql = null;

		} catch (AmallException ame) {
			m_DbAccess.rollback();
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					getItemDispName(ITEM_ID_SCREEN_NAME, m_Accme11DispBean));
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

		return true;

	}
}