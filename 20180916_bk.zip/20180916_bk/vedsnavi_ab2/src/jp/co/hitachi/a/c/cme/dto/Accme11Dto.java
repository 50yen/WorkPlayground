/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Accme11Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cme.dto;

import java.util.List;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Accme11Dtoクラス<br>
 *****************************************************************************************/
public class Accme11Dto extends AmclsDtoBase {

	/** メンバ変数 */

	/** 顧客Cd */
	private String cstCd = null;
	/** 顧客名 */
	private String cstNm = null;
	/** 店舗Cd */
	private String shopCd = null;
	/** 店舗名 */
	private String shopNm = null;
	/** 店舗枝番（レジNo） */
	private String shopSbno = null;
	/** 店舗枝番名（レジ名） */
	private String shopSbnm = null;
	/** 金種(表示) */
	private String dispDenomi = null;
	/** 金種 */
	private int denomi = 0;
	/** 枚数 */
	private String moneyNum = null;
	/** 金額(表示用) */
	private String dispMoneyTotal = null;
	/** 金額 */
	private int moneyTotal = 0;
	/** 売上日 */
	private String sld = null;
	/** 排他キー */
	private Long exclusiveKey = null;

	/** リスト存在フラグ */
	private String listFlg = null;
	/** 戻るボタンフラグ */
	private String returnFlg = null;

	/** リストカウント */
	private int count = 0;
	/** 遷移元情報取得 */
	private List<AccmeItemDispDto> infoList = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Accme11Dto() {
		clear();
	}

	/*************************************************************************************
	 * クリア
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		cstCd = null;
		cstNm = null;
		shopCd = null;
		shopNm = null;
		shopSbno = null;
		shopSbnm = null;
		dispDenomi = null;
		denomi = 0;
		moneyNum = null;
		dispMoneyTotal = null;
		moneyTotal = 0;
		sld = null;
		exclusiveKey = null;
		listFlg = null;
		returnFlg = null;
		count = 0;
		infoList = null;
	}

	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getCstCd() {
		return cstCd;
	}

	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}

	public String getCstNm() {
		return cstNm;
	}

	public void setCstNm(String cstNm) {
		this.cstNm = cstNm;
	}

	public String getShopCd() {
		return shopCd;
	}

	public void setShopCd(String shopCd) {
		this.shopCd = shopCd;
	}

	public String getShopNm() {
		return shopNm;
	}

	public void setShopNm(String shopNm) {
		this.shopNm = shopNm;
	}

	public String getShopSbno() {
		return shopSbno;
	}

	public void setShopSbno(String shopSbno) {
		this.shopSbno = shopSbno;
	}

	public String getShopSbnm() {
		return shopSbnm;
	}

	public void setShopSbnm(String shopSbnm) {
		this.shopSbnm = shopSbnm;
	}

	public String getDispDenomi() {
		return dispDenomi;
	}

	public void setDispDenomi(String dispDenomi) {
		this.dispDenomi = dispDenomi;
	}

	public int getDenomi() {
		return denomi;
	}

	public void setDenomi(int denomi) {
		this.denomi = denomi;
	}

	public String getMoneyNum() {
		return moneyNum;
	}

	public void setMoneyNum(String moneyNum) {
		this.moneyNum = moneyNum;
	}

	public String getDispMoneyTotal() {
		return dispMoneyTotal;
	}

	public void setDispMoneyTotal(String dispMoneyTotal) {
		this.dispMoneyTotal = dispMoneyTotal;
	}

	public int getMoneyTotal() {
		return moneyTotal;
	}

	public void setMoneyTotal(int moneyTotal) {
		this.moneyTotal = moneyTotal;
	}

	public String getSld() {
		return sld;
	}

	public void setSld(String sld) {
		this.sld = sld;
	}

	public String getListFlg() {
		return listFlg;
	}

	public void setListFlg(String listFlg) {
		this.listFlg = listFlg;
	}

	public Long getExclusiveKey() {
		return exclusiveKey;
	}

	public void setExclusiveKey(Long key) {
		this.exclusiveKey = key;
	}

	public String getReturnFlg() {
		return returnFlg;
	}

	public void setReturnFlg(String returnFlg) {
		this.returnFlg = returnFlg;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public List<AccmeItemDispDto> getInfoList() {
		return infoList;
	}

	public void setInfoList(List<AccmeItemDispDto> infoList) {
		this.infoList = infoList;
	}

}
