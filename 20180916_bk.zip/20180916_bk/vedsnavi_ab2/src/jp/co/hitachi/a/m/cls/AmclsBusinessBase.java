/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmclsBusinessBase.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.cls;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.CssStyleCom;
import jp.co.hitachi.a.m.all.AmallConst.DateFormatCom;
import jp.co.hitachi.a.m.all.AmallConst.FowardCom;
import jp.co.hitachi.a.m.all.AmallConst.GeneralFlg;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallConst.ItemMapKey;
import jp.co.hitachi.a.m.all.AmallConst.LogDbOut;
import jp.co.hitachi.a.m.all.AmallConst.LogTable;
import jp.co.hitachi.a.m.all.AmallConst.LogType;
import jp.co.hitachi.a.m.all.AmallConst.MsgLvl;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallConst.ScrExp;
import jp.co.hitachi.a.m.all.AmallConst.SystemName;
import jp.co.hitachi.a.m.all.AmallConst.SystemType;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoCommonInfo;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;
import jp.co.hitachi.a.m.dto.AmdtoLoginInfo;
import jp.co.hitachi.a.m.dto.AmdtoScreen;
import jp.co.hitachi.a.m.dto.AmdtoScreenCategory;
import jp.co.hitachi.a.m.dto.AmdtoScreenInfo;
import jp.co.hitachi.a.m.dto.AmdtoScreenMenu;
import jp.co.hitachi.cocktail.jxpand.util.JXDateFormat;

/*****************************************************************************************
 * Businessのスーパークラス<br>
 *****************************************************************************************/
public abstract class AmclsBusinessBase implements java.io.Serializable {

	/** メンバ定数 */
	/** アクセスログ定義初期表示フラグ ON */
	private static final String INIT_FLG_ON = "1";

	/** メンバ変数 */
	/** GIDパラメータ */
	protected String m_Gid = null;
	/** EVENTパラメータ */
	protected String m_Event = null;

	/** HttpServletRequest */
	protected HttpServletRequest m_Request = null;
	/** HttpServletResponse */
	protected HttpServletResponse m_Response = null;

	/** クラス名称 */
	protected String m_ClassName = null;
	/** システム種別 */
	protected int m_systemKind = 0;
	/** アクセスログ出力可否 */
	protected boolean m_AccessLogDisp = true;

	/** DTO管理データ */
	protected Map<String, Object> m_DtoHashtable = null;
	/** DBアクセスクラス */
	protected AmallDbAccess m_DbAccess = null;

	/**
	 * エラー情報
	 */
	/** ログインID */
	protected String m_eLoginID = null;
	/** 区分  */
	protected String m_eKind = null;
	/** 業務情報 */
	protected String m_eBusinessName = null;
	/** ログ情報ヘッダ */
	protected String m_eLogInfoHeader = null;

	//必ずオーバライドすること
	/*************************************************************************************
	 * execute処理呼び出し(抽象メソッド)
	 * <p>
	 * execute処理を呼び出すDAOを定義する。
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public abstract String execute() throws AmallException;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmclsBusinessBase() {
		this.m_Request = null;
		this.m_Response = null;
		this.m_DbAccess = null;
		this.m_Gid = "";
		this.m_Event = "";
		this.m_DtoHashtable = null;
		this.m_eLoginID = "";
		this.m_eKind = "";
		this.m_eBusinessName = "";
		this.m_eLogInfoHeader = "";
		this.m_AccessLogDisp = true;
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  mapping
	 * @param  form
	 * @param  request
	 * @param  response
	 * @param  context
	 * @return 無し
	 ************************************************************************************/
	public AmclsBusinessBase(HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event) throws AmallException {
		this.m_Request = request;
		this.m_Response = response;
		this.m_DbAccess = null;
		this.m_Gid = gid;
		this.m_Event = event;
		getDTO();
		this.m_AccessLogDisp = true;
	}

	/*************************************************************************************
	 * 業務処理呼び出し処理
	 * <p>
	 * ・DBインスタンスの生成
	 * ・アクセスログ出力（開始、終了、エラー）
	 * ・業務処理の呼び出し
	 * </p>
	 * @param  無し
	 * @return フォワード名
	 ************************************************************************************/
	public String executeProc() throws AmallException {
		String methodName = "executeProc";
		String forwardStr = "";
		String accessMsglvl = "";
		String loginId = "";

		boolean isSystemStopFlg = false;
		try {

			// ログイン情報DTO取得
			AmdtoLoginInfo loginInfo = getLoginInfoDTO();
			if (loginInfo != null) {
				loginId = loginInfo.getM_User_Cd();
			}

			// DBインスタンス生成
			m_DbAccess = new AmallDbAccess(m_systemKind);
			// DB接続
			if (m_DbAccess != null) {
				m_DbAccess.initDB();
			}

			// 共通情報DTOの取得
			AmdtoCommonInfo commonInfo = getCommonInfoDTO();
			if (commonInfo == null && loginInfo != null) {
				commonInfo = new AmdtoCommonInfo();
				// 共通DTOをDBから取得
				getCommonInfoDB(commonInfo, loginInfo);
				// 取得DTOをセット
				putSpecifiedDTO(ParamKey.DTO_COMMONINFO, commonInfo);
			}

			//業務支援の時
			if (m_systemKind == SystemType.BUSINESS) {
				// ログテーブルを指定
				m_DbAccess.setLogTable(LogTable.BUSINESS);
			}
			// アクセスログ開始判定処理
			writeAccessLogStart(loginId, commonInfo);

			// 業務処理呼び出し
			forwardStr = execute();

			// メッセージレベルを正常にセット
			accessMsglvl = MsgLvl.NORMAL;

			// 楽観的排他の判定
			AmallExceptionInfo amei = (AmallExceptionInfo) getReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO);

			// アクセスログ可否判定
			if (isM_AccessLogDisp()) {
				if (amei != null) { // 楽観的排他異常あり？
					// アクセスログ（エラー）出力処理
					accessMsglvl = MsgLvl.ERROR;
					m_DbAccess.putErrorLog(amei.getMessage());
				}
			}
		} catch (AmallException ame) {
			setAmallException(ame);
			/*
			 * アクセスログ可否判定
			 */
			if (isM_AccessLogDisp()) {
				/*
				 * 例外発生時に以下を作成する
				 * ・アクセスログ（例外用）
				 * ・アクセスログ（終了）
				 */
				accessMsglvl = MsgLvl.EXCEPTION;
				m_DbAccess.putErrorLog(ame.getMessage());
			}
			// 例外をスローする
			throw ame;
		} catch (Exception e) {
			// ここで例外が発生したら障害情報の出力のみとする
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, LogType.ERROR, e);
			setAmallException(ee);
			throw ee;
		} finally {
			// アクセスログ終了判定処理
			writeAccessLogEnd(loginId, isSystemStopFlg, accessMsglvl);
			/*
			 * DB切断
			 * コミットされてない場合はrollbackする
			 */
			if (m_DbAccess != null) {
				try {
					m_DbAccess.rollback();
				} catch (AmallException ame) {

				} catch (Exception e) {

				} finally {
					try {
						m_DbAccess.exitDB();
					} catch (AmallException ame) {

					} catch (Exception e) {

					}
				}
			}
		}
		return forwardStr;
	}

	/*************************************************************************************
	* アクセスログ開始書き込み処理
	* <p>
	* アクセスログの開始を書き込む
	* </p>
	* @param  loginId ログインID
	* @return commonInfo　共通情報DTO
	************************************************************************************/
	protected void writeAccessLogStart(String loginId, AmdtoCommonInfo commonInfo) {
		String accessMsglvl = "";
		try {
			// アクセスログ可否判定
			if (isM_AccessLogDisp()) {

				// ログインIDが指定されたときはログ出力を有効にする
				if (loginId == null) {
					// アクセスログ（開始）出力処理
					AmdtoLoginInfo loginInfo = getLoginInfoDTO();
					if (loginInfo == null || loginInfo.getM_User_Cd() == null
							|| getLoginInfoDTO().getM_User_Cd().length() == 0)
						m_DbAccess.setLogOutput(false);
					else {
						m_DbAccess.setLogOutput(true);
						loginId = loginInfo.getM_User_Cd();
					}
				} else {
					m_DbAccess.setLogOutput(true);
				}

				// 共通情報が存在する場合は、アクセスログ有無をセットする
				if (commonInfo != null) {
					boolean logFlg = true;
					if (LogDbOut.OFF.equals(commonInfo.getM_AccessLogEnable())) {
						logFlg = false;
					}
					m_DbAccess.setLogOutput(logFlg);
				}
				// アクセスログ定義を取得する
				String[] property = getAccessProperty(m_Gid, m_Event, AmallMessageConst.ERR_LOG_STATUS_START, "");
				if (INIT_FLG_ON.equals(property[2])) {
					// 初期表示の場合
					accessMsglvl = MsgLvl.APLTRACE;
				} else {
					accessMsglvl = MsgLvl.NORMAL;
				}
				// 開始ログをDBへ出力する
				m_DbAccess.putEventStartLog(loginId, property[4], accessMsglvl, m_Gid, property[1], property[0],
						loginId);

				// 障害時情報のセット
				if (m_systemKind == SystemType.CUSTOMER) {
					m_eKind = SystemType.CUSTOMER_NM;
				} else if (m_systemKind == SystemType.BUSINESS) {
					m_eKind = SystemType.BUSINESS_NM;
				}
				m_eBusinessName = m_Gid;
				m_eLogInfoHeader = property[1];
			}
		} catch (Exception e) {
		}
	}

	/*************************************************************************************
	* アクセスログ終了書き込み処理
	* <p>
	* アクセスログの終了を書き込む
	* </p>
	* @param  loginId ログインID
	* @return isSystemStopFlg　システム停止フラグ
	************************************************************************************/
	protected void writeAccessLogEnd(String loginId, boolean isSystemStopFlg, String accessMsglvl) {
		try {
			/*
			 * アクセスログ可否判定
			 */
			if (isM_AccessLogDisp()) {
				if (isSystemStopFlg == false && m_DbAccess != null) {

					// アクセスログ（終了）
					String[] property = getAccessProperty(m_Gid, m_Event, AmallMessageConst.ERR_LOG_STATUS_END,
							accessMsglvl);
					m_DbAccess.putEventEndLog(loginId, property[4], accessMsglvl, m_Gid, property[1], property[0],
							loginId);
				}
			}
		} catch (Exception e) {
		}
	}

	/*************************************************************************************
	 * アクセスログプロパティ取得処理
	 * <p>
	 * プロパティファイルからアクセスログ用の該当画面に対するプロパティを取得する
	 * </p>
	 * @param  画面Id
	 * @param　　イベント
	 * @param  開始・終了ステータス
	 * @param  メッセージレベル
	 * @return フォワード名
	 ************************************************************************************/
	protected String[] getAccessProperty(String gid //画面ID
			, String event //イベント
			, String status //開始/終了
			, String msglvl //メッセージレベル
	) throws AmallException, Exception {
		String logInfo = ""; //ログ情報
		boolean ret = true;
		String[] property = new String[5];

		// 引数チェック
		if (gid == null || event == null) {
			return property;
		}
		// アクセスログ定義取得
		property = getAccessLogDefineDB(gid, event);

		if (INIT_FLG_ON.equals(property[2])) { // 初期表示フラグのチェック
			if (AmallMessageConst.ERR_LOG_STATUS_START.equals(status)) {
				ret = true;
			} else {
				ret = false;
			}
		} else {
			ret = false;
		}

		if (ret) {
			logInfo = new String(property[0] + ":" + AmallMessageConst.ERR_LOG_STATUS_START);
		} else {
			if (MsgLvl.ERROR.equals(msglvl))
				logInfo = property[0] + ":" + property[3] + ":" + status;
			else
				logInfo = property[0] + ":" + property[3] + ":" + status;
		}
		property[0] = logInfo;

		return property;
	}

	/*************************************************************************************
	 * エラー情報作成
	 * <p>
	 * リクエストスコープの変数を登録する(Bean専用それ以外は、禁止)
	 * </p>
	 * @param  str キー
	 * @param  obj 登録値
	 * @return 無し
	 ************************************************************************************/
	protected void setAmallException(AmallException e) {
		e.setM_GTime(new Date());
		e.setM_LoginID(m_eLoginID);
		e.setM_Kind(m_eKind);
		e.setM_BusinessName(m_eBusinessName);
		e.setM_LogInfoHeader(m_eLogInfoHeader);
		e.setM_SessionID(getSessionID());
		return;
	}

	/*************************************************************************************
	 * セッションＩＤ取得
	 * <p>
	 * セッションＩＤを取得する
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	protected String getSessionID() {
		String id = "";
		HttpSession session = this.m_Request.getSession(false);
		if (session != null) {
			id = session.getId();
		}
		return id;
	}

	/*************************************************************************************
	 * リクエストスコープ変数登録
	 * <p>
	 * リクエストスコープの変数を登録する(Bean専用それ以外は、禁止)
	 * </p>
	 * @param  str キー
	 * @param  obj 登録値
	 * @return 無し
	 ************************************************************************************/
	protected void setReqScopeAttribute(String str, Object obj) {
		this.m_Request.setAttribute(str, obj);
		return;
	}

	/*************************************************************************************
	 * リクエストスコープ変数取得
	 * <p>
	 * リクエストスコープの変数を取得する(Bean専用それ以外は、禁止)
	 * </p>
	 * @param  str キー
	 * @return 取得値
	 ************************************************************************************/
	protected Object getReqScopeAttribute(String str) {
		Object obj = null;
		obj = this.m_Request.getAttribute(str);
		return obj;
	}

	/*************************************************************************************
	 * セッションスコープ変数取得
	 * <p>
	 * セッションスコープの変数を取得する(DTO専用それ以外は、禁止)
	 * </p>
	 * @param  str キー
	 * @return 取得値
	 ************************************************************************************/
	private Object getSesScopeAttribute(String str) throws AmallException {
		String methodName = "getSesScopeAttribute()";
		Object obj = null;
		HttpSession session = this.m_Request.getSession(false);
		if (session != null) {
			obj = session.getAttribute(str);
		} else {
			AmallException ee = new AmallException();
			ee.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_SYS_SESSION_GET_ERROR);
			throw ee;
		}
		return obj;
	}

	/*************************************************************************************
	 * DTO管理データ取得処理
	 * <p>
	 * DTO管理データを取得し、メンバ変数(m_DtoHashtable)にセットする
	 * </p>
	 * @param  str キー
	 * @return 無し
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	private void getDTO() throws AmallException {
		String methodName = "getDTO()";
		try {
			this.m_DtoHashtable = (Map<String, Object>) getSesScopeAttribute(ParamKey.DTO);
			if (this.m_DtoHashtable == null) {
				AmallException e = new AmallException();
				e.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_SYS_DTO_MNG_DATA_GET_ERROR,
						"m_DtoHashtable(null)");
				throw e;
			}
		} catch (AmallException e) {
			e.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_SYS_DTO_MNG_DATA_GET_ERROR, "");
			throw e;
		}
	}

	/*************************************************************************************
	 * DTO管理データクリア処理
	 * <p>
	 * DTO管理データを全てクリアする
	 * </p>
	 * @return 無し
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	private void clearDTO() throws AmallException {
		String methodName = "clearDTO()";
		try {
			Map<String, Object> dto = (Map<String, Object>) getSesScopeAttribute(ParamKey.DTO);
			if (dto != null) {
				boolean loop = true;
				while (loop) {
					Set set = dto.keySet();
					Iterator iterator = set.iterator();
					if (!iterator.hasNext())
						break;
					while (iterator.hasNext()) {
						String gid = (String) iterator.next();
						try {
							AmclsDtoBase dtoCls = (AmclsDtoBase) dto.get(gid);
							dtoCls.clear();
						} catch (Exception e) {
						}
						iterator.remove();
						break;
					}
				}
			}

		} catch (AmallException ame) {
			throw ame;
		} catch (Exception e) {
			AmallException ame = new AmallException();
			ame.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_SYS_MNG_DATA_CLEAR_ERROR);
			throw ame;
		}
	}

	/*************************************************************************************
	 * 指定DTO判定処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)に指定したDTOが存在するか否か
	 * </p>
	 * @param  str キー
	 * @return 判定結果
	 *          true :有り
	 *          false:無し
	 ************************************************************************************/
	protected boolean isSpecifiedDTO(String str) {
		if (this.m_DtoHashtable.get(str) == null) {
			return false;
		}
		return true;
	}

	/*************************************************************************************
	 * 指定DTO取得処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)から指定したDTOを取得する
	 * </p>
	 * @param  str キー
	 * @return 指定DTO
	 ************************************************************************************/
	protected Object getSpecifiedDTO(String str) {
		return this.m_DtoHashtable.get(str);
	}

	/*************************************************************************************
	 * 指定DTO追加処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)に指定したDTOを追加する
	 * </p>
	 * @param  str キー
	 * @param  obj 登録値
	 * @return 無し
	 ************************************************************************************/
	protected void putSpecifiedDTO(String str, Object obj) {
		this.m_DtoHashtable.put(str, obj);
		return;
	}

	/*************************************************************************************
	 * 指定DTO削除処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)から指定したDTOを削除する
	 * </p>
	 * @param  str キー
	 * @return 指定DTO
	 ************************************************************************************/
	protected void delSpecifiedDTO(String str) {
		if (isSpecifiedDTO(str)) {
			this.m_DtoHashtable.remove(str);
		}
		return;
	}

	/*************************************************************************************
	 * 指定画面DTO追加処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)に指定した画面DTOを追加する
	 * </p>
	 * @param  gid 画面ID
	 * @param  str キー
	 * @param  obj 登録値
	 * @return 無し
	 * @throws AmallException
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	protected void putSpecifiedDTO(String gid, String str, Object obj) throws AmallException {

		Map<String, ArrayList> hmsal = null;
		if (isSpecifiedDTO(ParamKey.DTO_SCREEN)) {
			//画面DTO有
			hmsal = (Map<String, ArrayList>) this.m_DtoHashtable.get(ParamKey.DTO_SCREEN);
		} else {
			hmsal = new ConcurrentHashMap<String, ArrayList>();
		}
		// 指定画面情報取得
		ArrayList<AmdtoScreenInfo> alo = (ArrayList<AmdtoScreenInfo>) hmsal.get(gid);

		if (alo == null) {
			//指定画面情報なし
			alo = new ArrayList<AmdtoScreenInfo>(); //指定画面情報生成
		}
		AmdtoScreenInfo scrInfo = new AmdtoScreenInfo(); //要素生成
		scrInfo.setM_DtoName(str);
		scrInfo.setM_Dto(obj);
		alo.add(scrInfo); //要素追加
		hmsal.put(gid, alo);
		this.m_DtoHashtable.put(ParamKey.DTO_SCREEN, hmsal);
		return;
	}

	/*************************************************************************************
	 * 指定DTO取得処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)から指定したDTOを取得する
	 * </p>
	 * @param  str キー
	 * @return 指定DTO
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	protected Object getSpecifiedDTO(String gid, String str) {

		if (!isSpecifiedDTO(ParamKey.DTO_SCREEN)) {
			//画面DTOなし
			return null;
		}

		Map<String, ArrayList> hmsal = (Map<String, ArrayList>) this.m_DtoHashtable.get(ParamKey.DTO_SCREEN);

		//指定画面情報取得
		ArrayList<AmdtoScreenInfo> alo = (ArrayList<AmdtoScreenInfo>) hmsal.get(gid);
		if (alo == null) {
			//指定画面情報なし
			return null;
		}

		Object obj = null;
		for (int i = 0; i < alo.size(); i++) {
			AmdtoScreenInfo scrInfo = alo.get(i);
			// DTO名から判別
			if (str.equals(scrInfo.getM_DtoName())) {
				obj = scrInfo.getM_Dto();
				break;
			}
		}
		return obj;
	}

	/*************************************************************************************
	 * 指定画面DTO削除処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)に指定した画面DTOを削除する
	 * </p>
	 * @param  gid 画面ID
	 * @return 無し
	 * @throws AmallException
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	protected void deleteSpecifiedDTO(String gid) throws AmallException {
		if (isSpecifiedDTO(ParamKey.DTO_SCREEN)) {
			// 画面DTO登録あり
			Map<String, ArrayList> hmsal = (Map<String, ArrayList>) this.m_DtoHashtable
					.get(ParamKey.DTO_SCREEN);
			// 指定画面情報取得
			ArrayList<AmdtoScreenInfo> alo = (ArrayList<AmdtoScreenInfo>) hmsal.get(gid);
			if (alo != null) {
				//指定画面情報あり
				for (int i = alo.size() - 1; i >= 0; i--) { //登録数分ループ
					AmdtoScreenInfo scrInfo = (AmdtoScreenInfo) alo.get(i); //要素取得
					AmclsDtoBase dto = (AmclsDtoBase) scrInfo.getM_Dto();//DTOオブジェクト取得
					if (dto != null) {
						dto.clear(); //DTO削除
						dto = null;
					}
					scrInfo.clear();
					scrInfo = null;
					alo.remove(i);
				} //
				alo.clear(); //要素配列クリア
				hmsal.remove(gid); //指定画面情報クリア
			}
		}
		return;
	}

	/*************************************************************************************
	 * 指定画面DTO削除処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)からすべての画面DTOを削除する
	 * </p>
	 * @param  gid 画面ID
	 * @return 無し
	 * @throws AmallException
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	protected void deleteSpecifiedDTO() throws AmallException {
		if (isSpecifiedDTO(ParamKey.DTO_SCREEN)) {
			// 画面DTO登録あり
			Map<String, ArrayList> hmsal = (Map<String, ArrayList>) this.m_DtoHashtable
					.get(ParamKey.DTO_SCREEN);
			Set set = hmsal.keySet();
			Iterator iterator = set.iterator();
			while (iterator.hasNext()) {
				String gid = (String) iterator.next();
				ArrayList<AmdtoScreenInfo> alo = (ArrayList<AmdtoScreenInfo>) hmsal.get(gid); //指定画面情報取得
				for (int i = alo.size() - 1; i >= 0; i--) { //登録数分ループ
					AmdtoScreenInfo scrInfo = (AmdtoScreenInfo) alo.get(i); //要素取得
					AmclsDtoBase dto = (AmclsDtoBase) scrInfo.getM_Dto();//DTOオブジェクト取得
					if (dto != null) {
						dto.clear(); //DTO削除
						dto = null;
					}
					scrInfo.clear();
					scrInfo = null;
					alo.remove(i);
				} //
				alo.clear(); //要素配列クリア
			}
			hmsal.clear(); //指定画面情報クリア
		}
		return;
	}

	/*************************************************************************************
	 * ログイン情報(DTO)取得処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)からログイン情報(DTO)を取得する
	 * </p>
	 * @param  str キー
	 * @return 無し
	 ************************************************************************************/
	protected AmdtoLoginInfo getLoginInfoDTO() {
		AmdtoLoginInfo dto = (AmdtoLoginInfo) getSpecifiedDTO(ParamKey.DTO_LOGININFO);
		if (dto != null) {
			m_eLoginID = dto.getM_User_Cd();
		} else {
			m_eLoginID = "";
		}
		return dto;
	}

	/*************************************************************************************
	 * ログイン情報(DTO)追加処理
	 * <p>
	 * ログイン情報(DTO)をDTO管理データ(m_DtoHashtable)に追加する
	 * </p>
	 * @param  obj ログイン情報
	 * @return 無し
	 ************************************************************************************/
	protected void putLoginInfoDTO(AmdtoLoginInfo obj) {
		putSpecifiedDTO(ParamKey.DTO_LOGININFO, obj);
	}

	/*************************************************************************************
	 * 共通情報(DTO)取得処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)から共通情報(DTO)を取得する
	 * </p>
	 * @param  無し
	 * @return obj 共通情報
	 ************************************************************************************/
	protected AmdtoCommonInfo getCommonInfoDTO() {
		return (AmdtoCommonInfo) getSpecifiedDTO(ParamKey.DTO_COMMONINFO);
	}

	/*************************************************************************************
	 * 共通情報(DTO)追加処理
	 * <p>
	 * 共通情報(DTO)をDTO管理データ(m_DtoHashtable)に追加する
	 * </p>
	 * @param  obj 共通情報
	 * @return 無し
	 ************************************************************************************/
	protected void putVariousCodesDTO(AmdtoCommonInfo obj) {
		putSpecifiedDTO(ParamKey.DTO_COMMONINFO, obj);
	}

	/*************************************************************************************
	 * 画面メッセージセット処理
	 * <p>
	 * 画面に表示するメッセージをセットする
	 * </p>
	 * @param  obj AmclsBeanBase
	 * @return 無し
	 ************************************************************************************/
	protected void setMessageInfo(AmclsBeanBase bean, String mid, String... val) {

		// 既存のメッセージ/メッセージ種別を取得
		List<String> preMsg = bean.getMessage();
		int preType = bean.getMessageType();

		// メッセージの取得
		if (val == null) {
			preMsg.add(AmallMessage.getMessage(mid));
		} else {
			preMsg.add(AmallMessage.getMessage(mid, val));
		}
		bean.setMessage(preMsg);

		// メッセージタイプの取得
		int ctg = AmallMessage.getMessageType(mid);
		if (preType == 0 || preType > ctg) {
			// 正常か今回のメッセージが強い場合
			bean.setMessageType(ctg);
		}

	}

	/*************************************************************************************
	 * システム共通情報作成
	 * <p>
	 * システム共通情報を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @return 無し
	 ************************************************************************************/
	protected void createSystemCommonInfo(String gid, AmclsBeanBase obj) throws AmallException {


		// 共通情報(セッション)の取得
		AmdtoCommonInfo comDto = getCommonInfoDTO();
		if (comDto != null) {
			// 画面情報の取得
			createScreenData(obj, comDto);

			// 権限マップ作成
			createEachAuthority(gid, obj, comDto);

			// 顧客範囲データリスト作成
			createCustomerRange(gid, obj, comDto);

			// 店舗範囲データリスト作成
			createShopRange(gid, obj, comDto);

			// ヘッダ情報作成
			createHeader(gid, obj, comDto);

			// Javascript用メッセージ定義作成
			createJSMessageConst(obj, comDto);

			// 表示件数プルダウンリストデータ作成
			createDispCountList(obj, comDto);

			// 業務日付の取得
			obj.setServiceDate(comDto.getM_BusinessDate());
		}

	}

	/*************************************************************************************
	 * 画面表示情報作成
	 * <p>
	 * 画面表示情報を作成する
	 * </p>
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createScreenData(AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {

		List<AmdtoScreenCategory> categoryList = comDto.getM_ScreenList();

		// 存在チェック
		if (categoryList != null) {

			// カテゴリ単位の表示設定
			for (AmdtoScreenCategory screenCategory : categoryList) {
				boolean setDispCategory = false;

				// メニュー単位の表示設定
				for (AmdtoScreenMenu screenMenu : screenCategory.getM_MenuList()) {
					boolean setDispMenu = false;

					for (AmdtoScreen screen : screenMenu.getM_ScreenList()) {
						// 全部falseかチェック
						if(screen.isM_Display()) {
							// trueが存在した場合
							setDispMenu = true;
							setDispCategory = true;
							break;
						}
					}
					// 結果を対象メニューに設定
					screenMenu.setM_Display(setDispMenu);
				}
				// 結果を対象カテゴリに設定
				screenCategory.setM_Display(setDispCategory);
			}

			obj.setOwdScreenList(categoryList);
		}
	}

	/*************************************************************************************
	 * ヘッダー情報作成
	 * <p>
	 * ヘッダー情報を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createHeader(String gid, AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {

		String methodName = "createHeader()";

		try {
			// システム名称
			if (m_systemKind == SystemType.CUSTOMER) {
				obj.setH_systemName(SystemName.CUSTOMER);
			} else if (m_systemKind == SystemType.BUSINESS) {
				obj.setH_systemName(SystemName.BUSINESS);
			}

			// 権限マップより判定
			Map<String, Map<String, String>> owdMap = obj.getOwdRole();
			if(owdMap != null && owdMap.size() > 0) {
				// 画面名が存在するか
				if(owdMap.containsKey(ItemMapKey.SCREEN_NAME)) {
					// 画面名が存在する場合はヘッダー部表示フラグを設定
					obj.setH_dispFlg(true);

					// 画面名称を取得
					obj.setH_screenName(owdMap.get(ItemMapKey.SCREEN_NAME).get(ItemMapKey.NAME));

					// システム日付
					JXDateFormat jxd = JXDateFormat.getInstance(DateFormatCom.YYYYMMDD24HMISS);
					Calendar cal = Calendar.getInstance();
					Date dt = cal.getTime();
					String systemDate = jxd.format(dt);
					obj.setH_systemDate(systemDate);

				} else {
					// 画面名が存在しない場合はヘッダー部表示しない
					obj.setH_dispFlg(false);
				}

			}

			// 共通情報から取得する
			if(comDto != null) {
				// 画面情報マップを取得する
				Map<String, AmdtoScreen> screenInfoMap = comDto.getM_ScreenInfoMap();
				// 存在チェック
				if(screenInfoMap != null) {
					// 画面IDから対象情報を抜き出す
					if(screenInfoMap.containsKey(gid)) {
						AmdtoScreen infoData = screenInfoMap.get(gid);

						// 画面照会IDを取得
						obj.setH_screenRefId(infoData.getM_ScreenRefId());

						// マニュアル用リンクを取得
						obj.setH_screenManualPath(infoData.getM_LinkPath());

					}
				}

			}
			// ログイン情報から取得する
			AmdtoLoginInfo logDto = getLoginInfoDTO();
			if (logDto != null) {
				// ログインID
				obj.setH_loginId(logDto.getM_User_Cd());

				// ログイン表示名称
				StringBuffer customerInfo = new StringBuffer();
				customerInfo.append(logDto.getM_User_Nm());
				customerInfo.append(AmallConst.USER_NAME_SUFFIX);
				obj.setH_loginDispName(customerInfo.toString());
			}


			return;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 権限情報作成
	 * <p>
	 * 権限情報を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createEachAuthority(String gid, AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {

		Map<String, Map<String, Map<String, String>>> itemMap = comDto.getM_ItemDispAuth();

		// 存在チェック
		if (itemMap != null && itemMap.containsKey(gid)) {
			// 画面IDから対象画面の項目権限を取得し、Beanに登録
			obj.setOwdRole(itemMap.get(gid));
		}
	}

	/*************************************************************************************
	 * 顧客範囲データリスト作成
	 * <p>
	 * 顧客範囲データリスト情報を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createCustomerRange(String gid, AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {

		// 顧客リスト取得
		List<String> customerList = comDto.getM_CustomerCdList();

		// 顧客制限マップ取得
		Map<String, List<String>> limitedMap = comDto.getM_LimitCustomerMap();

		// 存在チェック
		if (limitedMap != null && limitedMap.containsKey(gid)) {

			// 画面IDから対象画面の顧客制限リストを取得する。
			List<String> limitedList = limitedMap.get(gid);

			// 顧客リストから制限リストに含まれるデータを削除する
			for (String customerCd : limitedList) {
				if(customerList.contains(customerCd)) {
					customerList.remove(customerList.indexOf(customerCd));
				}

			}

		}
		// 生成した顧客リストをbeanにセットする。
		obj.setCustomerCdList(customerList);
		// 全顧客フラグをセットする
		obj.setCustomerCdAllFlg(comDto.isM_CustomerCdAllFlg());
	}

	/*************************************************************************************
	 * 店舗範囲データリストマップ作成
	 * <p>
	 * 店舗範囲データリスト情報を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createShopRange(String gid, AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {
		// 店舗リスト取得
		Map<String, List<String>> shopListMap = comDto.getM_ShopCdListMap();

		// 店舗制限マップ取得
		Map<String, Map<String, List<String>>> limitedMap = comDto.getM_LimitShopMap();

		// 存在チェック
		if (limitedMap != null && limitedMap.containsKey(gid)) {

			// 画面IDから対象画面の店舗制限リストを取得する。
			Map<String, List<String>> limitedListMap = limitedMap.get(gid);

			// 店舗リストから制限リストに含まれるデータを削除する
			for (Entry<String, List<String>> entry : limitedListMap.entrySet()) {

				// 顧客コードを取得
				String cstCd = entry.getKey();
				// 店舗リストマップに対象の顧客コードが存在するか
				if (shopListMap.containsKey(cstCd)) {
					// 存在する場合制限リストを取得
					List<String>  limitedList = entry.getValue();
					// 店舗リストをマップから取得
					List<String> shopList = shopListMap.get(cstCd);

					// 制限リストのデータを削除
					for (String limit : limitedList) {
						if(shopList.contains(limit)) {
							shopList.remove(shopList.indexOf(limit));
						}
					}

					// マップに再セット
					shopListMap.put(cstCd, shopList);
				}
			}
		}
		// 生成した店舗リストマップをbeanにセットする。
		obj.setShopCdListMap(shopListMap);
		// 全店舗フラグをセットする
		obj.setShopCdAllFlg(comDto.isM_ShopCdAllFlg());
	}

	/*************************************************************************************
	 * Javascript用メッセージ定義作成
	 * <p>
	 * Javascript用メッセージ定義を作成する
	 * </p>
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createJSMessageConst(AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {

		// メッセージ定義設定
		Map<String, String> msgMap = comDto.getM_JsMessageMap();
		// 存在チェック
		if (msgMap != null) {
			// メッセージを設定
			obj.setJsMessageMap(msgMap);
		}
	}

	/*************************************************************************************
	 * 表示件数プルダウンリストデータ作成
	 * <p>
	 * 表示件数プルダウンリストと初期値を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @return 無し
	 ************************************************************************************/
	protected void createDispCountList(AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {

		// メッセージ定義設定
		List<String> dispList = comDto.getM_DispCountList();
		// 存在チェック
		if (dispList != null && dispList.size() > 0) {
			// リストを設定
			obj.setDispCountList(dispList);
			// 初期値を設定
			obj.setDispCountDefault(comDto.getM_DispCountDefault());
			// 子画面初期値を設定
			obj.setDispCountChildDefault(comDto.getM_DispCountChildDefault());
		}
	}

	/*************************************************************************************
	 * 共通情報(DB)取得処理
	 * <p>
	 * 共通情報(DTO)を取得する
	 * </p>
	 * @param  obj 共通情報DTO
	 * @param  loginInfo ログイン情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void getCommonInfoDB(AmdtoCommonInfo obj, AmdtoLoginInfo loginInfo) throws AmallException, Exception {

		String methodName = "getCommonInfoDB()";
		ResultSet rs = null;

		try {

			// == 業務日付の取得 ==
			AmdtoGeneralMst gyomuDtDto = AmallUtilities.getGeneralMstDataRecord(m_DbAccess, GeneralMstKey.GYOMU_DATE, null, null, null);
			// 業務日付の設定
			obj.setM_BusinessDate(gyomuDtDto.getGeneralNm1());
			// 取得結果のチェック
			if (obj.getM_BusinessDate() == null) {
				AmallException e = new AmallException();
				e.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_SYS_DTO_MNG_DATA_GET_ERROR,
						"m_CommonInfo");
				throw e;
			}

			// == アクセスログ有無の取得 ==
			AmdtoGeneralMst accessLogDto = AmallUtilities.getGeneralMstDataRecord(m_DbAccess, GeneralMstKey.ACCESS_LOG_OUTPUT_FLG, null, null, obj.getM_BusinessDate());
			// アクセスログ有無の設定
			obj.setM_AccessLogEnable(accessLogDto.getGeneralNm1());
			// 取得結果のチェック
			if (obj.getM_AccessLogEnable() == null) {
				AmallException e = new AmallException();
				e.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_SYS_DTO_MNG_DATA_GET_ERROR,
						"m_CommonInfo");
				throw e;
			}
			// == 顧客データリストの取得 ==
			getCsutomerDefine(obj ,loginInfo);


			// == 店舗データリストの取得 ==
			getShopDefine(obj ,loginInfo);


			// == 制限顧客データリストの取得 ==
			if (!obj.isM_CustomerCdAllFlg()) {
				// 全顧客フラグがONではないとき
				obj.setM_LimitCustomerMap(getLimitedCustomerDefine(obj ,loginInfo));
			}


			// == 制限店舗データリストの取得 ==
			if (!obj.isM_CustomerCdAllFlg()) {
				// 全店舗フラグがONではないとき
				obj.setM_LimitShopMap(getLimitedShopDefine(obj ,loginInfo));
			}

			// == 画面情報リストの取得 ==
			List<AmdtoScreen> screenList = getScreenDefineDB();
			// 画面情報リストが存在する場合
			if(screenList.size() > 0) {
				// 画面メニューデータの設定
				getMenuGrpDefineDB(screenList, obj, loginInfo);
				// 画面権限判定
				getMenuGrpAuth(obj, loginInfo);
			}

			// == 画面項目情報マップの取得 ==
			obj.setM_ItemDispAuth(getItemDispDefineDB(loginInfo));


			// == 画面用JavaScriptメッセージの取得 ==
			List<AmdtoGeneralMst> jsMsgDtoList = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.JAVASCRIPT_MSG_CONST, null, null, obj.getM_BusinessDate());

			// メッセージデータの生成
			Map<String, String> msgMap = new ConcurrentHashMap<>();
			for (AmdtoGeneralMst mst : jsMsgDtoList) {
				msgMap.put(mst.getGeneralNm1(), AmallMessage.getMessage(mst.getGeneralNm1()));
			}
			obj.setM_JsMessageMap(msgMap);

			// == 表示件数プルダウンリストの内容取得 ==
			List<AmdtoGeneralMst> dispCntDtoList = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.DISPLAY_LIST_COUNT, null, null, obj.getM_BusinessDate());

			// プルダウンリストデータの生成
			List<String> dispCountList = new ArrayList<>();
			for (AmdtoGeneralMst mst : dispCntDtoList) {
				dispCountList.add(mst.getGeneralNm1());
				if(GeneralFlg.ON.equals(mst.getChar1())) {
					// == 表示件数プルダウンリストのデフォルト値取得 ==
					obj.setM_DispCountDefault(mst.getGeneralNm1());
				}
				if(GeneralFlg.ON.equals(mst.getChar2())) {
					// == 表示件数プルダウンリスト(子画面)のデフォルト値取得 ==
					obj.setM_DispCountChildDefault(mst.getGeneralNm1());
				}
			}
			obj.setM_DispCountList(dispCountList);


		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	/*************************************************************************************
	 * アクセスログ定義(DB)取得処理
	 * <p>
	 * アクセスログ定義(DB)からアクセスログ定義を取得する
	 * </p>
	 * @param  gid 画面ID
	 * @param  event イベントID
	 * @return 無し
	 ************************************************************************************/
	protected String[] getAccessLogDefineDB(String gid, String event) throws AmallException, Exception {

		String methodName = "getAccessLogDefineDB()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		String[] property = new String[5];

		try {

			sql.append("SELECT");
			sql.append("	SCREEN_NM");
			sql.append(",	PROGRAM_NM");
			sql.append(",	INIT_FLG");
			sql.append(",	EVENT_NM");
			sql.append(",	CONDITION");
			sql.append("  FROM N_ACCESS_LOG_M");
			sql.append(" WHERE");
			sql.append("	SCREEN_CD =  ?");
			sql.append("	AND EVENT_ID = ?");
			sql.append("	AND DEL_FLG = ?");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			m_DbAccess.setString(1, gid);
			m_DbAccess.setString(2, event);
			m_DbAccess.setString(3, AmallConst.DEFAULT_DEL_FLG);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				// 画面名称
				property[0] = m_DbAccess.getString(rs, "SCREEN_NM");
				// プログラム日本語名
				property[1] = m_DbAccess.getString(rs, "PROGRAM_NM");
				// 初期表示キーワードフラグ
				property[2] = m_DbAccess.getString(rs, "INIT_FLG");
				// ボタン名称
				property[3] = m_DbAccess.getString(rs, "EVENT_NM");
				// 照会条件
				property[4] = m_DbAccess.getString(rs, "CONDITION");

			}

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
		return property;
	}
	/*************************************************************************************
	 * 画面情報マスタ(DB)取得処理
	 * <p>
	 * 画面マスタテーブル(DB)からデータを取得する
	 * </p>
	 * @return 画面情報マスタリスト
	 ************************************************************************************/
	protected List<AmdtoScreen> getScreenDefineDB() throws AmallException, Exception {

		String methodName = "getScreenDefineDB()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		List<AmdtoScreen> retList = new ArrayList<>();

		try {

			sql.append("SELECT");
			sql.append("	SCREEN_CD");
			sql.append(",	SCREEN_NM");
			sql.append(",	FOWARD_CD");
			sql.append(",	LINK_PATH");
			sql.append("  FROM N_SCREEN_M");
			sql.append(" WHERE");
			sql.append("	DEL_FLG =  ?");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			m_DbAccess.setString(1, AmallConst.DEFAULT_DEL_FLG);
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				AmdtoScreen dto = new AmdtoScreen();
				// 画面ID
				dto.setM_ScreenId(m_DbAccess.getString(rs, "SCREEN_CD"));
				// 名称
				dto.setM_ScreenName(m_DbAccess.getString(rs, "SCREEN_NM"));
				// FOWARD値
				dto.setM_FowardData(m_DbAccess.getString(rs, "FOWARD_CD"));
				// リンクパス
				dto.setM_LinkPath(m_DbAccess.getString(rs, "LINK_PATH"));
				// 返却リストに追加
				retList.add(dto);

			}

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
		return retList;
	}
	/*************************************************************************************
	 * 画面メニューグループマスタ(DB)取得処理
	 * <p>
	 * 画面グループ定義(DB)からデータを取得する
	 * </p>
	 * @param  list 画面CDリスト
	 * @param  obj 共通情報DTO(顧客範囲・店舗範囲リストが設定されていること)
	 * @param  loginInfo ログイン情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void getMenuGrpDefineDB(List<AmdtoScreen> list, AmdtoCommonInfo obj, AmdtoLoginInfo loginInfo) throws AmallException, Exception {

		String methodName = "getMenuGrpDefineDB()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		// 画面メニューデータの取得
		Map<String, AmdtoScreen> screenInfoMap = new ConcurrentHashMap<>();
		// 画面情報マップの生成
		for (AmdtoScreen amdtoScreen : list) {
			screenInfoMap.put(amdtoScreen.getM_ScreenId(), amdtoScreen);
		}
		// カテゴリリスト
		List<AmdtoScreenCategory> catList = new ArrayList<>();

		try {

			// SQLの生成
			sql.append("SELECT");
			sql.append("	D.MENU_GRP_CD AS CATEGORY_CD,");
			sql.append("	D.MENU_GRP_NM AS CATEGORY_NM,");
			sql.append("	D.DISP_TYPE,");
			sql.append("	D.TOP_IMG_PATH,");
			sql.append("	D.SIDE_IMG_PATH,");
			sql.append("	C.MENU_GRP_CD,");
			sql.append("	C.MENU_GRP_NM,");
			sql.append("	C.MENU_NM,");
			sql.append("	C.SCREEN_CD,");
			sql.append("	C.VISIBLE,");
			sql.append("	D.MENU_GRP_REF_CD || '-' || C.MENU_GRP_REF_CD || '-' || C.MENU_REF_CD AS REF_ID");
			sql.append("  FROM");
			sql.append("	(");
			sql.append("		SELECT");
			sql.append("			B.PARENT_MENU_GRP_CD,");
			sql.append("			B.MENU_GRP_CD,");
			sql.append("			B.MENU_GRP_NM,");
			sql.append("			B.MENU_GRP_REF_CD,");
			sql.append("			A.MENU_NM,");
			sql.append("			A.SCREEN_CD,");
			sql.append("			A.MENU_REF_CD,");
			sql.append("			A.VISIBLE,");
			sql.append("			A.VIEW_ORDER AS SCR_VIEW_ORDER,");
			sql.append("			B.VIEW_ORDER AS MNU_VIEW_ORDER");
			sql.append("		  FROM");
			sql.append("			(");
			sql.append("				SELECT");
			sql.append("					MENU_GRP_CD,");
			sql.append("					MENU_NM,");
			sql.append("					SCREEN_CD,");
			sql.append("					MENU_REF_CD,");
			sql.append("					VISIBLE,");
			sql.append("					VIEW_ORDER");
			sql.append("				  FROM");
			sql.append("					N_MENU_M");
			sql.append("				 WHERE");
			sql.append("					SCREEN_CD IN (");
			for (AmdtoScreen amdtoScreen : list) {
				sql.append("						'");
				sql.append(amdtoScreen.getM_ScreenId());
				sql.append("',");
			}
			sql.append("					'')");
			sql.append("					AND DEL_FLG = ?");
			sql.append("			) A,");
			sql.append("			N_MENU_GRP_M B");
			sql.append("		 WHERE");
			sql.append("			B.MENU_GRP_CD = A.MENU_GRP_CD");
			sql.append("			AND B.DEL_FLG = ?");
			sql.append("	) C,");
			sql.append("	N_MENU_GRP_M D");
			sql.append(" WHERE");
			sql.append("	D.MENU_GRP_CD = C.PARENT_MENU_GRP_CD");
			sql.append("	AND D.DEL_FLG = ?");
			sql.append(" ORDER BY");
			sql.append("	D.VIEW_ORDER, C.MNU_VIEW_ORDER, C.SCR_VIEW_ORDER");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			m_DbAccess.setString(1, AmallConst.DEFAULT_DEL_FLG);
			m_DbAccess.setString(2, AmallConst.DEFAULT_DEL_FLG);
			m_DbAccess.setString(3, AmallConst.DEFAULT_DEL_FLG);
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			AmdtoScreenCategory category = new AmdtoScreenCategory();
			// 画面IDリスト
			List<AmdtoScreen> scrList = new ArrayList<>();
			// メニューリスト
			List<AmdtoScreenMenu> mnuList = new ArrayList<>();
			AmdtoScreenMenu menu = new AmdtoScreenMenu();
			while (rs.next()) {

				// カテゴリCD
				String categoryCd = m_DbAccess.getString(rs, "CATEGORY_CD");
				if(category.getM_CategoryId() == null || (categoryCd != null && !categoryCd.equals(category.getM_CategoryId()))) {
					// 前回と違うカテゴリの場合
					if(category.getM_CategoryId() != null) {

						// カテゴリIDが存在する場合は追加
						// 画面IDリストを追加
						menu.setM_ScreenList(scrList);
						// 画面IDリストを生成
						scrList = new ArrayList<>();
						// メニューに追加
						mnuList.add(menu);
						// メニューリストをカテゴリに追加
						category.setM_MenuList(mnuList);
						// メニューを生成
						menu = new AmdtoScreenMenu();
						// メニューリストを生成
						mnuList = new ArrayList<>();
						// カテゴリリストに追加
						catList.add(category);
					}
					// カテゴリDTOを生成
					category = new AmdtoScreenCategory();
					// カテゴリCD
					category.setM_CategoryId(categoryCd);
					// カテゴリ名
					category.setM_CategoryName(m_DbAccess.getString(rs, "CATEGORY_NM"));
					// 表示タイプ
					String strDispType = m_DbAccess.getString(rs, "DISP_TYPE");
					int nDispType= 0;
					if (strDispType != null) {
						nDispType = Integer.valueOf(strDispType);
					}
					category.setM_DispPattern(nDispType);
					// TOP画像
					category.setM_TopImgPath(m_DbAccess.getString(rs, "TOP_IMG_PATH"));
					// SIDE画像
					category.setM_SideImgPath(m_DbAccess.getString(rs, "SIDE_IMG_PATH"));
				}

				// メニューグループCD
				String menuGrpCd = m_DbAccess.getString(rs, "MENU_GRP_CD");
				if(menu.getM_MenuId() == null || (menuGrpCd != null && !menuGrpCd.equals(menu.getM_MenuId()))) {
					// 前回と違うメニューの場合
					if(menu.getM_MenuId() != null) {
						// メニューグループCDが存在する場合は追加
						// 画面IDリストを追加
						menu.setM_ScreenList(scrList);
						// 画面IDリストを生成
						scrList = new ArrayList<>();
						// メニューリストに追加
						mnuList.add(menu);
					}
					// メニューグループDTOを生成
					menu = new AmdtoScreenMenu();
					// メニューグループCD
					menu.setM_MenuId(menuGrpCd);
					// メニューグループ名
					menu.setM_MenuName(m_DbAccess.getString(rs, "MENU_GRP_NM"));
				}

				// 画面IDからデータを取得
				AmdtoScreen scrData = screenInfoMap.get(m_DbAccess.getString(rs, "SCREEN_CD"));
				// 設定用のDTOを作成
				AmdtoScreen scrSetData = scrData.clone();
				// メニュー名称
				scrSetData.setM_ScreenName(m_DbAccess.getString(rs, "MENU_NM"));

				// 表示可否
				String strDisp = m_DbAccess.getString(rs, "VISIBLE");


				// メニュー表示可否フラグ(メニュー機能としてのデータか)
				boolean dispFlg = false;
				if(GeneralFlg.ON.equals(strDisp)) {
					dispFlg = true;
				} else {
					// メニュー表示機能としてのデータではない場合は必ず非表示とする
					dispFlg = false;
				}
				// 判定した表示可否を設定
				scrSetData.setM_Display(dispFlg);

				// 識別CDを更新
				scrData.setM_ScreenRefId(m_DbAccess.getString(rs, "REF_ID"));

				// 画面IDリストに追加
				scrList.add(scrSetData);

			}

			// カテゴリが存在する場合(終端処理)
			if(category.getM_CategoryId() != null) {
				// 画面IDリストを追加
				menu.setM_ScreenList(scrList);
				// 画面IDリストを生成
				scrList = new ArrayList<>();
				// メニューリストに追加
				mnuList.add(menu);
				// メニューリストをカテゴリに追加
				category.setM_MenuList(mnuList);
				// メニューリストを生成
				mnuList = new ArrayList<>();
				// カテゴリリストに追加
				catList.add(category);
			}

			// 共通情報DTOに設定
			// 画面権限リストの設定
			if(catList.size() > 0) {
				obj.setM_ScreenList(catList);
			}

			// 画面情報マップの設定
			if(screenInfoMap.size() > 0) {
				obj.setM_ScreenInfoMap(screenInfoMap);
			}
		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
		return;
	}
	/*************************************************************************************
	 * 画面権限判定処理
	 * <p>
	 * 画面権限における表示判定を行う
	 * </p>
	 * @param  obj 共通情報DTO
	 * @param  loginInfo ログイン情報DTO
	 * @return なし
	 ************************************************************************************/
	protected void getMenuGrpAuth(AmdtoCommonInfo obj, AmdtoLoginInfo loginInfo) throws AmallException, Exception {

		// 画面権限表示可否マップの作製
		Map<String, String> screenRoleMap = getScreenRoleDefineDB(loginInfo);


		// 画面権限リストを取得
		List<AmdtoScreenCategory> categoryList = obj.getM_ScreenList();

		// カテゴリ分繰り返す
		for (AmdtoScreenCategory category : categoryList) {

			// カテゴリ内のメニューを取得し、繰り返す
			List<AmdtoScreenMenu> menuList = category.getM_MenuList();
			for (AmdtoScreenMenu menu : menuList) {

				// メニュー内の画面リストを取得し、繰り返す
				List<AmdtoScreen> screenList = menu.getM_ScreenList();

				for (AmdtoScreen screen : screenList) {
					// メニューの表示機能の判定
					if(screen.isM_Display()) {
						// 表示する場合のみ権限判定する。
						// 権限マップに対象画面が存在するか判定
						if (screenRoleMap.containsKey(screen.getM_ScreenId())) {
							// 権限に応じた表示可否判定
							boolean setFlg = screenVisibleTypeCheck(loginInfo, obj, screen.getM_ScreenId(), screenRoleMap);
							// 判定結果を反映
							screen.setM_Display(setFlg);
						}
					}
				}
			}
		}

	}



	/*************************************************************************************
	 * 画面権限判定
	 * <p>
	 * 画面権限における表示判定を行う
	 * </p>
	 * @param  loginInfo ログイン情報DTO
	 * @param  obj 共通情報DTO
	 * @param  screenCd 画面コード
	 * @return true: 表示 false:非表示
	 ************************************************************************************/
	private boolean screenVisibleTypeCheck(AmdtoLoginInfo loginInfo, AmdtoCommonInfo obj, String screenCd, Map<String, String> screenRoleMap) throws AmallException, Exception {

		// 対象画面の表示フラグ
		boolean screenDispFlg = false;

		// 権限グループより設定値を取得
		String strDisp = screenRoleMap.get(screenCd);
		if(ScrExp.DISPLAY_ON.equals(strDisp)) {
			// 権限グループの設定上は表示設定
			screenDispFlg = true;
		}

		// 汎用マスタから適用順を取得
		List<AmdtoGeneralMst> mstDto = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.IND_AUTH_PRIORITY, null, null, obj.getM_BusinessDate());

		// 適用順で設定
		for (AmdtoGeneralMst amdtoGeneralMst : mstDto) {

			// 分類コードを取得
			String expType = amdtoGeneralMst.getGeneralCd1();
			List<String> cdList = new ArrayList<>();

			// 分類コードで対象リスト判定
			switch (expType) {
				case ScrExp.EXP_TYPE_CUSTOMER:
					// 分類コードが顧客の場合
					cdList = obj.getM_CustomerCdList();
					break;
				case ScrExp.EXP_TYPE_SHOP:
					// 分類コードが店舗の場合
					Map<String, List<String>> shopCdListMap = obj.getM_ShopCdListMap();
					for (Entry<String, List<String>> entry : shopCdListMap.entrySet()) {
			            // バリューリストを取得
						List<String> value = entry.getValue();
						for (String cd : value) {
							// 顧客コード+店舗コードを作成する
							String data = entry.getKey() + cd;
							cdList.add(data);
						}
			        }
					break;
				case ScrExp.EXP_TYPE_USER:
					// 分類コードがユーザーの場合
					cdList.add(loginInfo.getM_User_Cd());
					break;
				default:
					break;
			}

			// コードリストが存在しない場合
			if (cdList.size() == 0) {
				continue;
			}

			// 現状の表示設定に応じて設定方法を変更
			if (screenDispFlg) {
				// 現状の表示設定が「表示」の場合 対象がすべて「非表示」であれば更新
				List<String> dispList = getLimitedDefineDB(screenCd, expType, ScrExp.DISPLAY_OFF, cdList);

				// 対象がすべて非表示 = コードリストと返却されたリストの数が一致
				if (cdList.size() == dispList.size()) {
					screenDispFlg = false;
				}

			} else {
				// 現状の表示設定が「非表示」の場合 対象のいずれかが「表示」であれば更新
				List<String> dispList = getLimitedDefineDB(screenCd, expType, ScrExp.DISPLAY_ON, cdList);

				// いずれかが表示 = 返却されたリストが1件以上存在
				if (dispList.size() > 0) {
					screenDispFlg = true;
				}
			}

		}

		return screenDispFlg;

	}

	/*************************************************************************************
	 * 画面項目情報マスタ(DB)取得処理
	 * <p>
	 * 画面項目マスタテーブル(DB)からデータを取得する
	 * </p>
	 * @return 画面項目情報マスタデータマップ
	 ************************************************************************************/
	protected Map<String, Map<String, Map<String, String>>> getItemDispDefineDB(AmdtoLoginInfo loginInfo) throws AmallException, Exception {

		String methodName = "getItemDispDefineDB()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用マップ
		Map<String, Map<String, Map<String, String>>> retMap = new ConcurrentHashMap<>();
		// 画面ID単位のマップを定義
		Map<String, Map<String, String>> screenMap = null;

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	A.SCREEN_CD");
			sql.append(",	A.ITEM_CD");
			sql.append(",	A.ITEM_NM");
			sql.append(",	A.ITEM_IMG_PATH");
			sql.append(",	CASE");
			sql.append("		WHEN B.SCREEN_CD IS NULL");
			sql.append("		 AND B.ITEM_CD IS NULL");
			sql.append("		THEN A.VISIBLE");
			sql.append("		ELSE B.VISIBLE");
			sql.append("	 END AS VISIBLE");
			sql.append(",	CASE");
			sql.append("		WHEN B.SCREEN_CD IS NULL");
			sql.append("		 AND B.ITEM_CD IS NULL");
			sql.append("		THEN A.EDITABLE");
			sql.append("		ELSE B.EDITABLE");
			sql.append("	 END AS EDITABLE");
			sql.append("  FROM");
			sql.append("  	N_ITEM_M A");
			sql.append("  	LEFT JOIN");
			sql.append("  		N_ITEM_ROLE_M B");
			sql.append("  		ON");
			sql.append("  			A.SCREEN_CD = B.SCREEN_CD");
			sql.append("  		AND A.ITEM_CD = B.ITEM_CD");
			sql.append("  		AND B.ROLE_GRP_CD = ?");
			sql.append("  		AND B.DEL_FLG = ?");
			sql.append(" WHERE");
			sql.append("	A.DEL_FLG =  ?");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			m_DbAccess.setString(1, loginInfo.getM_Auth_Grp_Cd());
			m_DbAccess.setString(2, AmallConst.DEFAULT_DEL_FLG);
			m_DbAccess.setString(3, AmallConst.DEFAULT_DEL_FLG);
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				// 画面CD
				String screenCd = m_DbAccess.getString(rs, "SCREEN_CD");
				// 対象の画面CDがMapに存在しない場合
				if(retMap.containsKey(screenCd) == false) {
					// マップの生成
					screenMap = new ConcurrentHashMap<>();
				} else {
					// マップの取得
					screenMap = retMap.get(screenCd);
				}
				// 項目ID
				String itemIdKey = m_DbAccess.getString(rs, "ITEM_CD");

				// 設定用Mapの生成
				Map<String, String> dataMap = new ConcurrentHashMap<>();
				// 項目名
				String itemNm = m_DbAccess.getString(rs, "ITEM_NM");
				if(itemNm.length() > 0) {
					dataMap.put(ItemMapKey.NAME,itemNm);
				}

				// 画像パス
				String itemImg = m_DbAccess.getString(rs, "ITEM_IMG_PATH");
				if(itemImg.length() > 0) {
					dataMap.put(ItemMapKey.IMG,itemImg);
				}

				// 表示可否
				String itemDisp = m_DbAccess.getString(rs, "VISIBLE");
				if(itemDisp.length() > 0) {
					if (GeneralFlg.ON.equals(itemDisp)) {
						dataMap.put(ItemMapKey.DISP,"true");
					} else {
						dataMap.put(ItemMapKey.DISP,"false");
					}
				}

				// 編集可否
				String itemEdit = m_DbAccess.getString(rs, "EDITABLE");
				if(itemEdit.length() > 0) {
					if (GeneralFlg.ON.equals(itemEdit)) {
						dataMap.put(ItemMapKey.ENABLE,"true");
					} else {
						dataMap.put(ItemMapKey.ENABLE,"false");
					}
				}

				// マップに設定
				screenMap.put(itemIdKey, dataMap);
				retMap.put(screenCd, screenMap);

			}

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
		return retMap;
	}
	/*************************************************************************************
	 * 画面権限マスタ(DB)取得処理
	 * <p>
	 * 画面権限マスタテーブル(DB)からデータを取得して表示可否を取得する
	 * </p>
	 * @return 画面権限マスタ表示可否マップ
	 ************************************************************************************/
	protected Map<String, String> getScreenRoleDefineDB(AmdtoLoginInfo loginInfo) throws AmallException, Exception {

		String methodName = "getScreenRoleDefineDB()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用マップ 画面ID ->表示可否
		Map<String, String> retMap = new ConcurrentHashMap<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	SCREEN_CD");
			sql.append(",	VISIBLE");
			sql.append("  FROM");
			sql.append("  	N_SCREEN_ROLE_M");
			sql.append(" WHERE");
			sql.append("	ROLE_GRP_CD = ?");
			sql.append("	AND DEL_FLG = ?");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			m_DbAccess.setString(1, loginInfo.getM_Auth_Grp_Cd());
			m_DbAccess.setString(2, AmallConst.DEFAULT_DEL_FLG);
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				// 画面CD
				String screenCd = m_DbAccess.getString(rs, "SCREEN_CD");
				// 表示可否
				String visibleData = m_DbAccess.getString(rs, "VISIBLE");
				// マップに設定
				retMap.put(screenCd, visibleData);
			}
			return retMap;

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	/*************************************************************************************
	 * 顧客データリスト取得処理
	 * <p>
	 * ログイン情報の顧客グループコード・顧客コードからデータを取得する
	 * </p>
	 * @param obj 共通情報DTO
	 * @param loginInfo ログイン情報DTO
	 * @return なし
	 ************************************************************************************/
	protected void getCsutomerDefine(AmdtoCommonInfo obj, AmdtoLoginInfo loginInfo) throws AmallException, Exception {

		// 顧客データリスト
		List<String> customerList = new ArrayList<>();
		// 全顧客フラグ
		boolean customerAllFlg = false;

		// 顧客グループコードの取得
		String customerGrpCd = loginInfo.getM_Customer_Grp_Cd();

		// 顧客グループコードの存在チェック
		if (customerGrpCd != null && customerGrpCd.length() > 0) {
			// 全顧客のチェック
			if (AmallConst.CUSTOMER_GRP_CD_ALL.equals(customerGrpCd)) {
				// 全顧客の場合
				customerAllFlg = true;
			} else {
				// 全顧客以外
				customerList = getCsutomerDefineDB(customerGrpCd, obj.getM_BusinessDate());
			}
		} else {
			// 顧客グループコードが存在しない場合
			if (loginInfo.getM_Customer_Cd().length() > 0) {
				customerList.add(loginInfo.getM_Customer_Cd());
			}
		}

		// 共通情報DTOにセット
		obj.setM_CustomerCdAllFlg(customerAllFlg);
		obj.setM_CustomerCdList(customerList);

		return;
	}
	/*************************************************************************************
	 * 顧客コードリスト(DB)取得処理
	 * <p>
	 * 顧客グループコードから顧客コードデータリストを取得する
	 * </p>
	 * @param customerGrpCd 顧客グループコード
	 * @param systemDt 業務日付
	 * @return List<String 顧客データリスト
	 ************************************************************************************/
	protected List<String> getCsutomerDefineDB(String customerGrpCd, String systemDt) throws AmallException, Exception {

		String methodName = "getCsutomerDefineDB()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	CST_CD");
			sql.append("  FROM N_CST_GRP_M");
			sql.append(" WHERE");
			sql.append("	CST_GRP_CD = ?");
			sql.append("	AND ? BETWEEN EFST_DY AND EFED_DY");
			sql.append("	AND DEL_FLG = ?");

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			// 顧客グループコード
			m_DbAccess.setString(1, customerGrpCd);
			// 業務日付
			m_DbAccess.setString(2, systemDt);
			// 削除フラグ
			m_DbAccess.setString(3, AmallConst.DEFAULT_DEL_FLG);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				// 顧客コード
				String customerCd = m_DbAccess.getString(rs, "CST_CD");
				// 顧客コードリストに設定
				retList.add(customerCd);
			}
			return retList;

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	/*************************************************************************************
	 * 店舗データリストマップ取得処理
	 * <p>
	 * ログイン情報のユーザーID・店舗コードからデータを取得する
	 * </p>
	 * @param obj 共通情報DTO
	 * @param loginInfo ログイン情報DTO
	 * @return なし
	 ************************************************************************************/
	protected void getShopDefine(AmdtoCommonInfo obj, AmdtoLoginInfo loginInfo) throws AmallException, Exception {

		// 店舗データリスト
		Map<String, List<String>> shopListMap = new ConcurrentHashMap<>();
		// 全店舗フラグ
		boolean shopAllFlg = false;

		// 店舗グループコードの取得
		List<String> shopGrpCdList = getShopGrpDefineDB(loginInfo.getM_User_Cd());

		// 店舗グループコードの存在チェック
		if (shopGrpCdList != null && shopGrpCdList.size() > 0) {
			// 全店舗のチェック
			if (shopGrpCdList.contains(AmallConst.SHOP_GRP_CD_ALL)) {
				// 全店舗の場合、全顧客フラグを取得
				if (obj.isM_CustomerCdAllFlg()) {
					// 全顧客フラグONの場合 全店舗フラグON
					shopAllFlg = true;
				} else {
					// 顧客の範囲内での全店舗の場合
					// 全顧客以外
					shopListMap = getShopDefineDB(obj.getM_CustomerCdList(), null, obj.getM_BusinessDate());
				}
			} else {
				// 全顧客以外
				shopListMap = getShopDefineDB(obj.getM_CustomerCdList(), shopGrpCdList, obj.getM_BusinessDate());
			}
		} else {
			// 店舗グループコードが存在しない場合
			if (loginInfo.getM_Shop_Cd().length() > 0) {
				List<String> setList = new ArrayList<>();
				setList.add(loginInfo.getM_Shop_Cd());
				shopListMap.put(loginInfo.getM_Customer_Cd(),setList);
			}
		}

		// 共通情報DTOにセット
		obj.setM_ShopCdAllFlg(shopAllFlg);
		obj.setM_ShopCdListMap(shopListMap);

		return;
	}

	/*************************************************************************************
	 * 店舗グループコード(DB)取得処理
	 * <p>
	 * 店舗グループコード管理マスタ(DB)から店舗グループコードデータリストを取得する
	 * </p>
	 * @param shopGrpCd ユーザーID
	 * @return List<String 店舗グループコードデータリスト
	 ************************************************************************************/
	protected List<String> getShopGrpDefineDB(String user_Id) throws AmallException, Exception {

		String methodName = "getShopGrpDefineDB()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		// 返却用リスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	SHOP_GRP_CD");
			sql.append("  FROM N_SHOP_GRP_MNG_M");
			sql.append(" WHERE");
			sql.append("	USER_ID = ?");
			sql.append("	AND DEL_FLG = ?");

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			// ユーザーID
			m_DbAccess.setString(1, user_Id);
			// 削除フラグ
			m_DbAccess.setString(2, AmallConst.DEFAULT_DEL_FLG);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				// 店舗グループコード
				String customerCd = m_DbAccess.getString(rs, "SHOP_GRP_CD");
				// 店舗グループコードリストに設定
				retList.add(customerCd);
			}
			return retList;

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	/*************************************************************************************
	 * 店舗コードリスト(DB)取得処理
	 * <p>
	 * 店舗グループコードから店舗コードデータリストを取得する
	 * </p>
	 * @param customerCdList 顧客コードリスト
	 * @param shopGrpCd 店舗グループコード
	 * @param systemDt 業務日付
	 * @return List<String 店舗データリスト
	 ************************************************************************************/
	protected Map<String, List<String>> getShopDefineDB(List<String> customerCdList, List<String> shopGrpCdList, String systemDt) throws AmallException, Exception {

		String methodName = "getShopDefineDB()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却マップ
		Map<String, List<String>> retMap = new ConcurrentHashMap<>();
		// 結果用リスト
		List<String> exList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	CST_CD");
			sql.append(",	SHOP_CD");
			sql.append("  FROM N_SHOP_M");
			sql.append(" WHERE");
			sql.append("	1 = 1");
			if (customerCdList != null && customerCdList.size() > 0) {
				// 顧客コードリストが存在する場合
				sql.append("	AND CST_CD IN (");
				for (String cstCd : customerCdList) {
					sql.append("'").append(cstCd).append("',");
				}
				sql.append("'')");
			}
			if (shopGrpCdList != null && shopGrpCdList.size() > 0) {
				// 店舗グループコードが存在する場合
				sql.append("	AND SHOP_CD IN (");
				sql.append("					SELECT");
				sql.append("						SHOP_CD");
				sql.append("					  FROM");
				sql.append("						N_SHOP_GRP_M");
				sql.append("					 WHERE");
				sql.append("						SHOP_GRP_CD IN (");
				for (String shopCd : shopGrpCdList) {
					sql.append("'").append(shopCd).append("',");
				}
				sql.append("'')");
				if (customerCdList != null && customerCdList.size() > 0) {
					// 顧客コードリストが存在する場合
					sql.append("	AND CST_CD IN (");
					for (String cstCd : customerCdList) {
						sql.append("'").append(cstCd).append("',");
					}
					sql.append("'')");
				}
				sql.append("						AND ? BETWEEN EFST_DY AND EFED_DY");
				sql.append("						AND DEL_FLG =?");
				sql.append("					)");
			}
			sql.append("	AND ? BETWEEN EFST_DY AND EFED_DY");
			sql.append("	AND DEL_FLG = ?");

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			// 業務日付
			m_DbAccess.setString(1, systemDt);
			// 削除フラグ
			m_DbAccess.setString(2, AmallConst.DEFAULT_DEL_FLG);
			if (shopGrpCdList != null && shopGrpCdList.size() > 0) {
				// 業務日付
				m_DbAccess.setString(3, systemDt);
				// 削除フラグ
				m_DbAccess.setString(4, AmallConst.DEFAULT_DEL_FLG);
			}

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				// 顧客コード
				String cstCd = m_DbAccess.getString(rs, "CST_CD");
				// 対象の顧客コードがMapに存在しない場合
				if(retMap.containsKey(cstCd) == false) {
					// リストの生成
					exList = new ArrayList<>();
				} else {
					// リストの取得
					exList = retMap.get(cstCd);
				}
				// 店舗コード
				String shopCd = m_DbAccess.getString(rs, "SHOP_CD");

				// リストに追加
				exList.add(shopCd);
				// マップに設定
				retMap.put(cstCd, exList);
			}
			return retMap;

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}
	/*************************************************************************************
	 * 制限顧客データリスト取得処理
	 * <p>
	 * 画面ごとに表示が制限される顧客のデータを取得する
	 * </p>
	 * @param obj 共通情報DTO
	 * @param loginInfo ログイン情報DTO
	 * @return なし
	 ************************************************************************************/
	protected Map<String, List<String>> getLimitedCustomerDefine(AmdtoCommonInfo obj, AmdtoLoginInfo loginInfo) throws AmallException, Exception {

		// 返却マップ
		Map<String, List<String>> retMap = new ConcurrentHashMap<>();

		// 顧客コードリストの取得
		List<String> customerCdList = obj.getM_CustomerCdList();
		if (customerCdList == null || customerCdList.size() == 0) {
			// 顧客コードリストが存在しない場合
			return retMap;
		}

		// テーブルより取得
		retMap = getLimitedScreenDefineDB(ScrExp.EXP_TYPE_CUSTOMER, ScrExp.DISPLAY_OFF, customerCdList);
		return retMap;
	}
	/*************************************************************************************
	 * 制限店舗データリスト取得処理
	 * <p>
	 * 画面ごとに表示が制限される顧客のデータを取得する
	 * </p>
	 * @param obj 共通情報DTO
	 * @param loginInfo ログイン情報DTO
	 * @return なし
	 ************************************************************************************/
	protected Map<String, Map<String, List<String>>> getLimitedShopDefine(AmdtoCommonInfo obj, AmdtoLoginInfo loginInfo) throws AmallException, Exception {

		// 返却マップ
		Map<String, Map<String, List<String>>> retMap = new ConcurrentHashMap<>();

		// 店舗コードリストマップの取得
		Map<String, List<String>> shopCdListMap = obj.getM_ShopCdListMap();
		if (shopCdListMap == null || shopCdListMap.isEmpty()) {
			// 店舗コードリストマップが存在しない場合
			return retMap;
		}

		// 画面項目権限用のデータリスト作成
		List<String> dataList = new ArrayList<>();
		for (Entry<String, List<String>> entry : shopCdListMap.entrySet()) {
            // バリューリストを取得
			List<String> value = entry.getValue();
			for (String cd : value) {
				// 顧客コード+店舗コードを作成する
				String data = entry.getKey() + cd;
				dataList.add(data);
			}
        }

		// テーブルより取得
		Map<String, List<String>> map = getLimitedScreenDefineDB(ScrExp.EXP_TYPE_SHOP, ScrExp.DISPLAY_OFF, dataList);

		// 取得したデータを加工
		for (Entry<String, List<String>> entry : map.entrySet()) {
            // バリューリストを取得
			List<String> value = entry.getValue();

			// 設定用マップを生成
			Map<String, List<String>> setMap = new ConcurrentHashMap<>();
			// 設定用リスト
			List<String> setList = new ArrayList<>();

			for (String dataCd : value) {

				if(dataCd.length() == InputNum.CST_CD + InputNum.SHOP_CD) {
					// 顧客コード+店舗コードを分割する。
					String cstCd = dataCd.substring(0, InputNum.CST_CD);
					// 対象の顧客コードがMapに存在しない場合
					if(setMap.containsKey(cstCd) == false) {
						// リストの生成
						setList = new ArrayList<>();
					} else {
						// リストの取得
						setList = setMap.get(cstCd);
					}
					// 店舗コード
					String shopCd = dataCd.substring(InputNum.CST_CD);
					// リストに追加
					setList.add(shopCd);
					// マップに設定
					setMap.put(cstCd, setList);
				}
			}
			if(!setMap.isEmpty()) {
				// マップが存在した場合返却MAPに追加
				retMap.put(entry.getKey().toString(), setMap);
			}
        }

		return retMap;
	}
	/*************************************************************************************
	 * 個別画面権限テーブル(DB)取得処理
	 * <p>
	 * 画面ごとに表示が制限される個別権限マスタ(DB)のデータを取得する
	 * </p>
	 * @param cdList コードリスト
	 * @param loginInfo ログイン情報DTO
	 * @return なし
	 ************************************************************************************/
	protected Map<String, List<String>> getLimitedScreenDefineDB(String expType, String visibleType, List<String> cdList) throws AmallException, Exception {

		String methodName = "getLimitedScreenDefineDB()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却マップ
		Map<String, List<String>> retMap = new ConcurrentHashMap<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	SCREEN_CD");
			sql.append(",	EXP_CD");
			sql.append("  FROM");
			sql.append("	N_SCREEN_EXP_AUTH_M");
			sql.append(" WHERE");
			sql.append("	EXP_CD IN (");
			for (String expCd : cdList) {
				sql.append("'").append(expCd).append("',");
			}
			sql.append("'')");
			sql.append("	AND EXP_TYPE = ?");
			sql.append("	AND VISIBLE = ?");
			sql.append("	AND DEL_FLG = ?");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			// 分類
			m_DbAccess.setString(1, expType);
			// 表示可否
			m_DbAccess.setString(2, visibleType);
			// 削除フラグ
			m_DbAccess.setString(3, AmallConst.DEFAULT_DEL_FLG);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			List<String> expCdList = null;
			while (rs.next()) {
				// 画面CD
				String screenCd = m_DbAccess.getString(rs, "SCREEN_CD");
				// 対象の画面CDがMapに存在しない場合
				if(retMap.containsKey(screenCd) == false) {
					// リストの生成
					expCdList = new ArrayList<>();
				} else {
					// リストの取得
					expCdList = retMap.get(screenCd);
				}
				// コード
				String expCd = m_DbAccess.getString(rs, "EXP_CD");

				// リストに追加
				expCdList.add(expCd);
				// マップに設定
				retMap.put(screenCd, expCdList);
			}
			return retMap;

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}
	/*************************************************************************************
	 * 個別画面権限テーブル(DB)取得処理
	 * <p>
	 * 個別権限マスタ(DB)のデータを取得する
	 * </p>
	 * @param screenId 画面コード
	 * @param expType 分類
	 * @param visibleType 表示可否
	 * @param cdList 検索範囲
	 * @return なし
	 ************************************************************************************/
	protected List<String> getLimitedDefineDB(String screenId, String expType, String visibleType, List<String> cdList) throws AmallException, Exception {

		String methodName = "getLimitedCustomerDefine()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却リスト
		List<String> expCdList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	EXP_CD");
			sql.append("  FROM");
			sql.append("	N_SCREEN_EXP_AUTH_M");
			sql.append(" WHERE");
			sql.append("	EXP_CD IN (");
			for (String expCd : cdList) {
				sql.append("'").append(expCd).append("',");
			}
			sql.append("'')");
			sql.append("	AND SCREEN_CD = ?");
			sql.append("	AND EXP_TYPE = ?");
			sql.append("	AND VISIBLE = ?");
			sql.append("	AND DEL_FLG = ?");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			// 画面コード
			m_DbAccess.setString(1, screenId);
			// 分類
			m_DbAccess.setString(2, expType);
			// 表示可否
			m_DbAccess.setString(3, visibleType);
			// 削除フラグ
			m_DbAccess.setString(4, AmallConst.DEFAULT_DEL_FLG);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				// コード
				String expCd = m_DbAccess.getString(rs, "EXP_CD");

				// リストに追加
				expCdList.add(expCd);
			}
			return expCdList;

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	/*************************************************************************************
	 * ログアウト処理
	 * <p>
	 * DTO管理情報に存在するすべてのインスタンスを解放する
	 * </p>
	 * @param  なし
	 * @return ログイン画面へのグローバルフォワード名
	 ************************************************************************************/
	protected String logoutProc() throws AmallException {

		try {
			// ログアウト先設定
			String fowardStr =  FowardCom.LOGIN;
			if (SystemType.BUSINESS == m_systemKind) {
				// システム種別が業務支援だった場合
				fowardStr =  FowardCom.LOGIN_BUSINESS;
			}

			// 画面DTO削除処理
			deleteSpecifiedDTO();
			// DTO削除
			clearDTO();

			return fowardStr;

		} catch (AmallException ame) {
			throw ame;
		}

	}

	/*************************************************************************************
	 * スタイル設定処理
	 * <p>
	 * 指定されたbeanBaseのインスタンスを使用して該当キーに指定スタイルをセットする
	 * </p>
	 * @param  表示用ビーンインスタンス
	 * @param  項目名
	 * @param  スタイル
	 * @return なし
	 ************************************************************************************/
	protected void setStyle(AmclsBeanBase beanBase, String key, String style) {
		beanBase.getStyleMap().put(key, style);
	}

	/*************************************************************************************
	 * エラースタイル設定処理
	 * <p>
	 * 指定されたbeanBaseのインスタンスを使用して該当キーにエラースタイルをセットする
	 * </p>
	 * @param  表示用ビーンインスタンス
	 * @param  項目名
	 * @return なし
	 ************************************************************************************/
	protected void setError(AmclsBeanBase beanBase, String key) {
		setStyle(beanBase, key, CssStyleCom.ERROR);
	}

	/*************************************************************************************
	 * 警告スタイル設定処理
	 * <p>
	 * 指定されたbeanBaseのインスタンスを使用して該当キーに警告スタイルをセットする
	 * </p>
	 * @param  表示用ビーンインスタンス
	 * @param  項目名
	 * @return なし
	 ************************************************************************************/
	public void setWarning(AmclsBeanBase beanBase, String key) {
		setStyle(beanBase, key, CssStyleCom.WARNING);
	}

	/*************************************************************************************
	 * 正常スタイル設定処理
	 * <p>
	 * 指定されたbeanBaseのインスタンスを使用して該当キーに正常スタイルをセットする
	 * </p>
	 * @param  表示用ビーンインスタンス
	 * @param  項目名
	 * @return なし
	 ************************************************************************************/
	public void setNormal(AmclsBeanBase beanBase, String key) {
		setStyle(beanBase, key, CssStyleCom.NORMAL);
	}

	/*************************************************************************************
	 * システム種別取得処理
	 * <p>
	 * システム種別取得処理を行う
	 * </p>
	 * @param  なし
	 * @return システム種別
	 ************************************************************************************/
	protected int getM_systemKind() {
		return m_systemKind;
	}

	/*************************************************************************************
	 * システム種別設定処理
	 * <p>
	 * システム種別設定処理を行う
	 * </p>
	 * @param  kind システム種別
	 * @return なし
	 ************************************************************************************/
	protected void setM_systemKind(int kind) {
		m_systemKind = kind;
	}

	/*************************************************************************************
	 * アクセスログ可否取得処理
	 * <p>
	 * アクセスログ可否取得処理を行う
	 * </p>
	 * @param  なし
	 * @return アクセスログ可否
	 ************************************************************************************/
	public boolean isM_AccessLogDisp() {
		return m_AccessLogDisp;
	}

	/*************************************************************************************
	 * アクセスログ可否設定処理
	 * <p>
	 * アクセスログ可否設定処理を行う
	 * </p>
	 * @param  アクセスログ可否
	 * @return なし
	 ************************************************************************************/
	public void setM_AccessLogDisp(boolean accessLogDisp) {
		m_AccessLogDisp = accessLogDisp;
	}

	/*************************************************************************************
	* 障害時情報設定処理
	* <p>
	* ・障害時情報を設定する
	* </p>
	* @param  gid	画面ID
	* @param  systemKind システム種類
	* @return なし
	************************************************************************************/
	protected void setErrString(String gid, int systemKind) throws AmallException {

		try {
			// システム種類のセット
			m_systemKind = systemKind;

			// アクセスログ定義を取得する
			String[] property = getAccessProperty(m_Gid, m_Event, AmallMessageConst.ERR_LOG_STATUS_START, "");

			// 障害時情報のセット
			if (m_systemKind == SystemType.CUSTOMER) {
				m_eKind = SystemType.CUSTOMER_NM;
			} else if (m_systemKind == SystemType.BUSINESS) {
				m_eKind = SystemType.BUSINESS_NM;
			}
			m_eBusinessName = m_Gid;
			m_eLogInfoHeader = property[1];
		} catch (Exception e) {

		}
	}

	/*************************************************************************************
	 * 項目名称取得
	 * <p>
	 * 権限情報を元に対象IDの項目表示名称を取得する
	 * </p>
	 * @param  itemId 項目ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @return 項目名称
	 ************************************************************************************/
	protected String getItemDispName(String itemId, AmclsBeanBase obj) throws AmallException {

		// 権限情報マップの取得
		Map<String, Map<String, String>> itemMap = obj.getOwdRole();

		// 存在チェック
		if (itemMap.containsKey(itemId)) {
			// 項目IDから対象項目のデータリストを取得する。
			Map<String, String> itemData = itemMap.get(itemId);

			// 名称キーを取得
			if (itemData.containsKey(ItemMapKey.NAME)) {
				// 名称を返却
				return itemData.get(ItemMapKey.NAME);
			}
		}
		return "";

	}

}