/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoScreenInfo.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * 画面毎情報 <br>
 *****************************************************************************************/
public class AmdtoScreenInfo extends AmclsDtoBase {

	/** メンバ変数 */
	/** DTO名 */
	private String m_DtoName = null;
	/** DTO */
	private Object m_Dto = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmdtoScreenInfo() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		m_DtoName = null;
		m_Dto = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getM_DtoName() {
		return m_DtoName;
	}

	public void setM_DtoName(String m_DtoName) {
		this.m_DtoName = m_DtoName;
	}

	public Object getM_Dto() {
		return m_Dto;
	}

	public void setM_Dto(Object m_Dto) {
		this.m_Dto = m_Dto;
	}
}
