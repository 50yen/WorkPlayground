/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Accpw01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cpw.business;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.cpw.action.Accpw01Action;
import jp.co.hitachi.a.c.cpw.bean.Accpw01DispBean;
import jp.co.hitachi.a.m.all.AmallConst.GeneralFlg;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallConst.LoginFlg;
import jp.co.hitachi.a.m.all.AmallConst.MsgCode;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallLoginControl;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallPasswordControl;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;
import jp.co.hitachi.a.m.dto.AmdtoLoginInfo;

/*****************************************************************************************
 * Accpw01Businessクラス<br>
 *****************************************************************************************/
public class Accpw01Business extends AccpwBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Accpw01DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 画面表示(ログイン画面から) */
	public static final String FORWARD_DISP_LOGIN = "DISPLOGIN";
	/** 画面表示(TOP画面から) */
	public static final String FORWARD_DISP_TOP = "DISPTOP";
	/** 登録 */
	public static final String FORWARD_REGIST = "REGIST";
	/** 登録後移動(ログインからの遷移のみ) */
	public static final String FORWARD_REGIST_AFTER = "REGISTLOGIN";

	/**
	 * 画面項目ID
	 */
	/** パスワード */
	public static final String ITEM_ID_PASS = "passwordInput";
	/** 再パスワード */
	public static final String ITEM_ID_RE_PASS = "rePasswordInput";

	/** メンバ変数 */
	/** アクションフォーム */
	private Accpw01Action m_Accpw01Form = null;
	/** 表示用画面Bean */
	private Accpw01DispBean m_Accpw01DispBean = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Accpw01Business(
			Accpw01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Accpw01Business.class.getName();
		m_Accpw01Form = form;
		m_Accpw01DispBean = new Accpw01DispBean();
		setErrString(gid, m_Accpw01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Accpw01DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Accpw01Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP_LOGIN.equals(m_Event)) {
				// 画面表示処理(ログイン画面から)の場合
				forwardStr = dispLogin();
			} else if (FORWARD_DISP_TOP.equals(m_Event)) {
				// 画面表示処理(TOP画面から)の場合
				forwardStr = dispTop();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				// 登録ボタン押下処理
				forwardStr = regist();
			} else if (FORWARD_REGIST_AFTER.equals(m_Event)) {
				// 自動遷移処理
				forwardStr = FORWARD_REGIST_AFTER;
			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Accpw01DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理(ログインからの遷移)
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String dispLogin() throws AmallException {

		// サイドバー表示なし(＋TOPへのリンク無し)
		m_Accpw01DispBean.setSidebar(null);

		// ログイン情報を取得する
		AmdtoLoginInfo logDto = getLoginInfoDTO();
		if (logDto != null) {
			// 仮パスワードフラグチェック
			if (LoginFlg.PRE_PASS.equals(logDto.getM_Password_Flg())) {
				// 仮パスワードであることをメッセージで出力する
				setMessageInfo(m_Accpw01DispBean, AmallMessageConst.MSG_WRN_NOW_TMP_PASSWORD);
			}

			// 有効期限切れチェック
			if (!LoginFlg.VALID_LIMIT_OFF.equals(logDto.getM_Password_Exp_Flg())) {
				// 有効期限があり

				// 有効期限切れチェック
				// 有効期限を取得
				Date passExpTime = logDto.getM_Password_Exp_Date();
				if (passExpTime != null) {

					// 現在時刻を取得
					Date nowDate = new Date();

					// ミリ秒で差分を算出
					long diffExpTime = passExpTime.getTime() - nowDate.getTime();
					if (diffExpTime < 0) {
						// 有効期限切れであることをメッセージで出力する
						setMessageInfo(m_Accpw01DispBean, AmallMessageConst.MSG_WRN_PASSWORD_EXPIRED);
					}
				}
			}
		}

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 初期表示処理(TOPからの遷移)
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String dispTop() throws AmallException {

		// サイドバー表示あり
		m_Accpw01DispBean.setSidebar(GeneralFlg.ON);

		// TOPからの遷移であることを設定
		m_Accpw01Form.setFromTopScreen(GeneralFlg.ON);

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 登録ボタン押下処理
	 * <p>
	 * パスワードの変更を行う
	 * 遷移元がログイン画面の場合は自動でTOP画面に遷移する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException, Exception {

		// ログ用メソッド名
		String methodName = "regist()";

		// パスワード取得
		String pwd = m_Accpw01Form.getPassword();
		// 再パスワード取得
		String rePwd = m_Accpw01Form.getRePassword();

		// 自動遷移秒数取得
		AmdtoGeneralMst autoSecDto = AmallUtilities.getGeneralMstDataRecord(m_DbAccess, GeneralMstKey.PASSWORD_CNG_AUTO_MOVE,	null, null, m_Accpw01DispBean.getServiceDate());
		Long autoSec = autoSecDto.getNo1();
		Long autoMilliSec = autoSecDto.getNo2();

		// サイドバー表示の設定
		if (GeneralFlg.ON.equals(m_Accpw01Form.getFromTopScreen())) {
			// サイドバー表示あり
			m_Accpw01DispBean.setSidebar(GeneralFlg.ON);
		}

		// ログイン情報取得
		AmdtoLoginInfo loginInfo = getLoginInfoDTO();

		// ログイン情報存在チェック
		if(loginInfo == null) {
			// 例外を投げる
			AmallException e = new AmallException();
			e.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_SYS_DTO_MNG_DATA_GET_ERROR,
					"m_loginInfo");
			throw e;
		}

		// 入力値チェック
		if(!checkInput(pwd, rePwd)) {
			// 異常の場合
			return FORWARD_DISP;
		}

		// 入力値の内容チェック
		List<String> msglist = AmallPasswordControl.passwordValidateCheck(pwd, loginInfo, m_DbAccess);
		if (msglist.size() > 0) {
			// メッセージを設定
			m_Accpw01DispBean.setMessage(msglist);
			m_Accpw01DispBean.setMessageType(MsgCode.ERROR);
			// 欄を赤く
			setError(m_Accpw01DispBean, ITEM_ID_PASS);
			setError(m_Accpw01DispBean, ITEM_ID_RE_PASS);
			return FORWARD_DISP;

		}

		// パスワードの登録
		if(!AmallPasswordControl.updatePasswordData(pwd, false, loginInfo, m_DbAccess, m_systemKind)) {
			// falseの場合は楽観排他エラー

			// エラー情報を設定
			// 登録がエラーとなったため自動的にログアウトするように設定
			setMessageInfo(m_Accpw01DispBean, AmallMessageConst.MSG_ERR_OPT_PASSWORD_UPDATE, autoSec.toString());

			// 自動ログアウト設定
			m_Accpw01Form.setAutoLogOutMoveSec(autoMilliSec);

			// アクセスログ情報の作成
			AmallExceptionInfo amei = new AmallExceptionInfo();
			amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_UPDATE_OPTIMISTIC_ERROR, loginInfo.getM_User_Cd()));
			setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

			// サイドバー表示なし
			m_Accpw01DispBean.setSidebar(null);

			return FORWARD_DISP;

		}

		// 正常に登録できた場合
		// ログイン情報を取得しなおしてリクエストにセット
		AmdtoLoginInfo amdtoLoginInfo = AmallLoginControl.getLoginInfoDB(m_DbAccess, loginInfo.getM_User_Cd(), m_systemKind);
		// ログイン情報を取得してリクエストにセット
		putLoginInfoDTO(amdtoLoginInfo);

		// 遷移設定
		if (GeneralFlg.ON.equals(m_Accpw01Form.getFromTopScreen())) {
			// サイドバー表示あり
			m_Accpw01DispBean.setSidebar(GeneralFlg.ON);

			// 登録が完了したことを表示する
			setMessageInfo(m_Accpw01DispBean, AmallMessageConst.MSG_INF_PASSWORD_UPDATE);

		} else {

			// 登録が完了したことを表示する(＋自動遷移)
			setMessageInfo(m_Accpw01DispBean, AmallMessageConst.MSG_INF_PASSWORD_UPDATE_AUTO_MOVE, autoSec.toString());


			// ログインからの遷移であることを設定(自動遷移の秒数)
			m_Accpw01Form.setAutoTopMoveSec(autoMilliSec);
		}
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 入力値チェック処理
	 * <p>
	 * 入力値のチェックを行う
	 * </p>
	 * @param  pwd		パスワード
	 * @param  rePwd	再パスワード
	 * @return true  : 入力正常
	 *          false : 入力エラー
	 ************************************************************************************/
	private boolean checkInput(String pwd, String rePwd) throws AmallException {

		// 返却フラグ
		boolean retFlg = true;

		// 必須入力チェック
		// Password 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(pwd)) {
			setMessageInfo(m_Accpw01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_PASS, m_Accpw01DispBean));
			setError(m_Accpw01DispBean, ITEM_ID_PASS);
			setError(m_Accpw01DispBean, ITEM_ID_RE_PASS);
			retFlg = false;
		}

		// 再Password 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(rePwd)) {
			setMessageInfo(m_Accpw01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_RE_PASS, m_Accpw01DispBean));
			setError(m_Accpw01DispBean, ITEM_ID_PASS);
			setError(m_Accpw01DispBean, ITEM_ID_RE_PASS);
			retFlg = false;
		}

		// パスワード・再パスワードの一致
		if (retFlg == true && !pwd.equals(rePwd)) {
			setMessageInfo(m_Accpw01DispBean, AmallMessageConst.MSG_ERR_PASSWORD_NOT_SAME);
			setError(m_Accpw01DispBean, ITEM_ID_PASS);
			setError(m_Accpw01DispBean, ITEM_ID_RE_PASS);
			retFlg = false;
		}
		// 正常終了
		return retFlg;
	}


}