/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acsgm11Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.sgm.action;

import java.util.List;

import jp.co.hitachi.a.c.sgm.bean.Acsgm11DispBean;
import jp.co.hitachi.a.c.sgm.business.Acsgm11Business;
import jp.co.hitachi.a.c.sgm.dto.AcsgmShopGrpDto;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Acsgm11Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Acsgm11DispBean acsgm11DispBean;

	/** 店舗グループコード */
	private String shopGrpCd = null;
	/** 店舗グループ名 */
	private String shopGrpNm = null;
	/** 更新日時 */
	private String updateDateDisp = null;
	/** 更新者 */
	private String updateUserDisp = null;

	/** 一覧表示データ */
	private List<AcsgmShopGrpDto> itemDispList = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAcsgm11DispBean((Acsgm11DispBean)request.getAttribute("Acsgm11DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Acsgm11Business dao = new Acsgm11Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Acsgm11DispBean getAcsgm11DispBean() {
		return acsgm11DispBean;
	}

	public void setAcsgm11DispBean(Acsgm11DispBean acsgm11DispBean) {
		this.acsgm11DispBean = acsgm11DispBean;
	}

	public synchronized String getShopGrpCd() {
		return shopGrpCd;
	}

	public synchronized void setShopGrpCd(String shopGrpCd) {
		this.shopGrpCd = shopGrpCd;
	}

	public synchronized String getShopGrpNm() {
		return shopGrpNm;
	}

	public synchronized void setShopGrpNm(String shopGrpNm) {
		this.shopGrpNm = shopGrpNm;
	}

	public String getUpdateDateDisp() {
		return updateDateDisp;
	}

	public void setUpdateDateDisp(String updateDateDisp) {
		this.updateDateDisp = updateDateDisp;
	}

	public String getUpdateUserDisp() {
		return updateUserDisp;
	}

	public void setUpdateUserDisp(String updateUserDisp) {
		this.updateUserDisp = updateUserDisp;
	}

	public List<AcsgmShopGrpDto> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<AcsgmShopGrpDto> itemDispList) {
		this.itemDispList = itemDispList;
	}

}
