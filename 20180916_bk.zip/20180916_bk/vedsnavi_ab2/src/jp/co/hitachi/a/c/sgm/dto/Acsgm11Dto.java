/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acsgm11Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.sgm.dto;

import java.util.ArrayList;
import java.util.List;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Acsgm11Dtoクラス<br>
 *****************************************************************************************/
public class Acsgm11Dto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 一覧保存データ */
	private List<AcsgmShopGrpDto> itemSavedList = null;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public Acsgm11Dto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		itemSavedList = new ArrayList<>();;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public synchronized List<AcsgmShopGrpDto> getItemSavedList() {
		return itemSavedList;
	}
	public synchronized void setItemSavedList(List<AcsgmShopGrpDto> itemSavedList) {
		this.itemSavedList = itemSavedList;
	}
}
