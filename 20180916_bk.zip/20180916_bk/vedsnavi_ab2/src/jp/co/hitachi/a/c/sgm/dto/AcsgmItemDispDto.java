/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acsgm02Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.sgm.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * AcsgmItemDispDtoクラス<br>
 *****************************************************************************************/
public class AcsgmItemDispDto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 店舗グループコード */
	private String shopGrpCd = null;
	/** 店舗グループ名 */
	private String shopGrpNm = null;
	/** 登録店舗件数 */
	private Long shopCount = null;
	/** 顧客入力値 */
	private String inputedCstCd = null;
	/** 店舗入力値 */
	private String inputedShopCd = null;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public AcsgmItemDispDto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		shopGrpCd = null;
		shopGrpNm = null;
		shopCount = null;
		inputedCstCd = null;
		inputedShopCd = null;
	}
	public String getShopGrpNm() {
		return shopGrpNm;
	}
	public void setShopGrpNm(String shopGrpNm) {
		this.shopGrpNm = shopGrpNm;
	}
	public Long getShopCount() {
		return shopCount;
	}
	public void setShopCount(Long shopCount) {
		this.shopCount = shopCount;
	}
	public String getInputedCstCd() {
		return inputedCstCd;
	}
	public void setInputedCstCd(String inputedCstCd) {
		this.inputedCstCd = inputedCstCd;
	}
	public String getInputedShopCd() {
		return inputedShopCd;
	}
	public void setInputedShopCd(String inputedShopCd) {
		this.inputedShopCd = inputedShopCd;
	}
	public String getShopGrpCd() {
		return shopGrpCd;
	}
	public void setShopGrpCd(String shopGrpCd) {
		this.shopGrpCd = shopGrpCd;
	}

}
