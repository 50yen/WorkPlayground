/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acsgm11DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.sgm.business;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.sgm.action.Acsgm11Action;
import jp.co.hitachi.a.c.sgm.bean.Acsgm11DispBean;
import jp.co.hitachi.a.c.sgm.dto.Acsgm11Dto;
import jp.co.hitachi.a.c.sgm.dto.AcsgmItemDispDto;
import jp.co.hitachi.a.c.sgm.dto.AcsgmShopGrpDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;

/*****************************************************************************************
 * Acsgm11Businessクラス<br>
 *****************************************************************************************/
public class Acsgm11Business extends AcsgmBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Acsgm11DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	private static final String FORWARD_DISP = "DISP";
	/** 店舗追加 */
	private static final String FORWARD_ADD = "ADD";
	/** 削除 */
	private static final String FORWARD_DELETE = "DELETE";
	/** 登録 */
	private static final String FORWARD_REGIST = "REGIST";
	/** 戻る */
	private static final String FORWARD_RETURN = "RETURNPAGE";
	/** 戻る(削除処理完了時) */
	private static final String FORWARD_RETURN_DEL = "DELRETURN";
	/** DTOキー名 */
	private static final String DTO_ACSGM11 = "DTO_ACSGM11";
	/**
	 * 画面項目ID
	 */
	/** 店舗グループ名 */
	private static final String ITEM_ID_SHOP_GRP_NAME = "shopGroupNm";
	/** お客様コード */
	private static final String ITEM_ID_CST_CD = "customerCd";

	/** メンバ変数 */
	/** アクションフォーム */
	private Acsgm11Action m_Acsgm11Form = null;
	/** 表示用画面Bean */
	private Acsgm11DispBean m_Acsgm11DispBean = null;
	/** 画面用DTO */
	private Acsgm11Dto m_Acsgm11Dto = null;


	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Acsgm11Business(
			Acsgm11Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Acsgm11Business.class.getName();
		m_Acsgm11Form = form;
		m_Acsgm11DispBean = new Acsgm11DispBean();
		setErrString(gid, m_Acsgm11Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Acsgm11DispBean);

			/* 内部記憶情報の生成 */
			m_Acsgm11Dto = (Acsgm11Dto) getSpecifiedDTO(m_Gid, DTO_ACSGM11);
			if (m_Acsgm11Dto == null || FORWARD_DISP.equals(m_Event)) {
				deleteSpecifiedDTO(m_Gid);
				m_Acsgm11Dto = new Acsgm11Dto();
				putSpecifiedDTO(m_Gid, DTO_ACSGM11, m_Acsgm11Dto);
			}

			// 遷移元情報取得
			AcsgmItemDispDto transDto = (AcsgmItemDispDto) getSpecifiedDTO(ACSGM_INFO_KEY);
			if (transDto != null) {
				// 遷移元から店舗グループコードを取得
				m_Acsgm11Form.setShopGrpCd(transDto.getShopGrpCd());
				// DTO削除
				delSpecifiedDTO(ACSGM_INFO_KEY);
			}

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Acsgm11Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_ADD.equals(m_Event)) {
				// 店舗追加ボタン押下の場合
				forwardStr = add();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				// 登録ボタン押下の場合
				forwardStr = regist();
			} else if (FORWARD_DELETE.equals(m_Event)) {
				// 削除ボタン押下の場合
				forwardStr = delete();
			} else if (FORWARD_RETURN.equals(m_Event)) {
				// 戻るボタン押下処理の場合
				forwardStr = back();
			} else {
				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Acsgm11DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException, Exception {

		// 遷移元から店舗グループコードを取得していた場合
		String shopGrpCd = m_Acsgm11Form.getShopGrpCd();
		if(!AmallUtilities.isEmpty(shopGrpCd)) {
			// 検索処理を実施
			search(shopGrpCd);

		} else {
			// 初期化
			List<AcsgmShopGrpDto> list = new ArrayList<>();
			// 1行目を追加
			AcsgmShopGrpDto dto = new AcsgmShopGrpDto();
			list.add(dto);
			m_Acsgm11Form.setItemDispList(list);
		}


		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 検索処理
	 * <p>
	 * 店舗グループコードを元に検索処理を実行する
	 * </p>
	 * @param  shopGrpCd 店舗グループコード
	 * @return ActionForward名称
	 ************************************************************************************/
	private void search(String shopGrpCd) throws AmallException, Exception {

		List<AcsgmShopGrpDto> dataList = getShopGrpMst(shopGrpCd, m_Acsgm11DispBean.getServiceDate());
		if (dataList ==  null ||  dataList.size() == 0) {
			// データが存在しない場合
			setMessageInfo(m_Acsgm11DispBean, AmallMessageConst.MSG_ERR_SELECT_CON_NO_DATA,
					getItemDispName(ITEM_ID_SHOP_GRP_NAME, m_Acsgm11DispBean));
			return;
		}

		// 1件目のデータをヘッダに設定
		// 店舗グループコード
		m_Acsgm11Form.setShopGrpCd(dataList.get(0).getShopGrpCd());
		// 店舗グループ名
		m_Acsgm11Form.setShopGrpNm(dataList.get(0).getShopGrpNm());
		// 更新日時
		m_Acsgm11Form.setUpdateDateDisp(dataList.get(0).getUpDate());
		// 更新者
		m_Acsgm11Form.setUpdateUserDisp(dataList.get(0).getUpDateUser());

		// 表示リスト
		m_Acsgm11Form.setItemDispList(dataList);

		return;
	}
	/*************************************************************************************
	 * 店舗追加ボタン押下処理実行
	 * <p>
	 * 店舗追加ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String add() throws AmallException {

		// リストを取得
		List<AcsgmShopGrpDto> list = m_Acsgm11Form.getItemDispList();
		if (list == null) {
			// nullの場合生成
			list = new ArrayList<>();
		}
		// 空行を追加
		AcsgmShopGrpDto dto = new AcsgmShopGrpDto();
		list.add(dto);
		m_Acsgm11Form.setItemDispList(list);


		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 削除ボタン押下処理実行
	 * <p>
	 * 削除ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String delete() throws AmallException, Exception  {

		// 排他チェックを行う
		if(!exclutionCheck()) {
			return FORWARD_DISP;
		}

		// 店舗グループコードを取得
		String shopGrpCd = m_Acsgm11Form.getShopGrpCd();
		// 削除処理を呼ぶ
		if(!deleteShopGrpMst(shopGrpCd, m_Acsgm11DispBean.getServiceDate())) {
			return FORWARD_DISP;
		}
		// コミット処理
		m_DbAccess.commit();
		// 前のページに戻る(削除正常：メッセージは遷移先で設定)
		return FORWARD_RETURN_DEL;
	}

	/*************************************************************************************
	 * 登録処理
	 * <p>
	 * 登録処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException, Exception {

		// 入力チェックを行う
		if(!inputCheck()) {
			return FORWARD_DISP;
		}

		// 店舗グループコードを取得
		String shopGrpCd = m_Acsgm11Form.getShopGrpCd();

		// 店舗グループ名を取得
		String shopGrpNm = m_Acsgm11Form.getShopGrpNm();

		// 登録対象を取得
		List<AcsgmShopGrpDto> list = m_Acsgm11Form.getItemDispList();

		if(!AmallUtilities.isEmpty(shopGrpCd)) {
			// 更新
			// 排他チェックを行う
			if(!exclutionCheck()) {
				return FORWARD_DISP;
			}
			// 削除処理を呼ぶ
			if(!deleteShopGrpMst(shopGrpCd, m_Acsgm11DispBean.getServiceDate())) {
				return FORWARD_DISP;
			}


			for (AcsgmShopGrpDto shopGrpDto : list) {
				// 企業店舗コード変換判定
				String shopCd = existsShopCnvMst(shopGrpDto.getDispShopCd(), shopGrpDto.getCstCd(), m_Acsgm11DispBean.getServiceDate());

				// 登録処理を呼ぶ
				if(!insertShopGrpMst(shopGrpCd, shopGrpDto.getCstCd(), shopCd, shopGrpNm)) {
					return FORWARD_DISP;
				}
			}
		} else {
			// 新規
			// お客様グループコード自動採番処理
			Long nextVal = AmallUtilities.getSequenceNextval("S_SHOP_GRP_CD", m_DbAccess);

			//nullチェック
			if(nextVal == null || nextVal.longValue() == 0) {
				setMessageInfo(m_Acsgm11DispBean, AmallMessageConst.MSG_ERR_DB_ACCESS);
				return FORWARD_DISP;
			}

			//0埋めされた店舗グループコードを取得
			shopGrpCd = String.format(AmallConst.SHOP_GRP_CD_FORMAT, nextVal);

			for (AcsgmShopGrpDto shopGrpDto : list) {
				// 企業店舗コード変換判定
				String shopCd = existsShopCnvMst(shopGrpDto.getDispShopCd(), shopGrpDto.getCstCd(), m_Acsgm11DispBean.getServiceDate());

				// 登録処理を呼ぶ
				if(!insertShopGrpMst(shopGrpCd, shopGrpDto.getCstCd(), shopCd, shopGrpNm)) {
					return FORWARD_DISP;
				}
			}
		}
		// 正常終了メッセージ
		// コミット処理
		m_DbAccess.commit();
		// 正常完了処理メッセージ
		setMessageInfo(m_Acsgm11DispBean, AmallMessageConst.MSG_INF_NML_REGIST_END);

		// 再検索処理
		search(shopGrpCd);

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 戻る処理
	 * <p>
	 * 登録処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String back() throws AmallException {

		// 内部保存値の削除
		deleteSpecifiedDTO(m_Gid);
		return FORWARD_RETURN;
	}
	/*************************************************************************************
	 * 入力値チェック
	 * <p>
	 * 入力値チェックを実施する
	 * </p>
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheck() throws  AmallException {
		// 返却フラグ
		boolean ret = true;

		// 店舗グループ名
		String shopGrpNm = m_Acsgm11Form.getShopGrpNm();

		// 入力値チェック(店舗グループ名)
		if (!AmallUtilities.isEmpty(shopGrpNm)) {
			// 入力値が存在する場合
			if (AmallUtilities.getLengthAsHalf(shopGrpNm) > (InputNum.SHOP_GRP_NM * 2)) {
				// 60文字以上が設定されている
				setMessageInfo(m_Acsgm11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_STR_WTN,
						getItemDispName(ITEM_ID_SHOP_GRP_NAME, m_Acsgm11DispBean), String.valueOf(InputNum.SHOP_GRP_NM));
				setError(m_Acsgm11DispBean, ITEM_ID_SHOP_GRP_NAME);

				ret = false;
			}
		} else {
			// 入力がない場合
			setMessageInfo(m_Acsgm11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
					getItemDispName(ITEM_ID_SHOP_GRP_NAME, m_Acsgm11DispBean));
			setError(m_Acsgm11DispBean, ITEM_ID_SHOP_GRP_NAME);
			ret = false;
		}

		// リストを取得
		List<AcsgmShopGrpDto> list = m_Acsgm11Form.getItemDispList();
		// 整理後リストを生成
		List<AcsgmShopGrpDto> afterList = new ArrayList<>();
		// 設定数を取得
		for (AcsgmShopGrpDto shopGrpDto : list) {
			if (!AmallUtilities.isEmpty(shopGrpDto.getDispShopCd())) {
				// 表示用店舗コードが存在する場合
				afterList.add(shopGrpDto);
			}
		}

		// リスト件数チェック
		if(afterList.size() == 0) {
			// 登録内容がない場合
			setMessageInfo(m_Acsgm11DispBean, AmallMessageConst.MSG_ERR_REGIST_NOTHING_DATA);
			ret = false;
		} else {
			// 重複チェック
			for (AcsgmShopGrpDto orgDto : afterList) {

				int count = 0;
				for (AcsgmShopGrpDto compareDto : afterList) {

					// 同一店舗コードの数をカウント
					if (compareDto.getDispShopCd().equals(orgDto.getDispShopCd())) {
						count++;
					}
				}
				// 2件以上ある場合
				if(count >= 2) {
					setMessageInfo(m_Acsgm11DispBean, AmallMessageConst.MSG_ERR_REGIST_DUPLICATION_DATA);
					ret = false;
					break;
				}
			}

			// 顧客またがりチェック
			// 一件目を取得
			AcsgmShopGrpDto firstDto = afterList.get(0);

			for (AcsgmShopGrpDto compareDto : afterList) {

				// 同一顧客コードをチェック
				if (!compareDto.getCstCd().equals(firstDto.getCstCd())) {
					// 一致しない顧客コードが存在した場合
					setMessageInfo(m_Acsgm11DispBean, AmallMessageConst.MSG_ERR_REGIST_EXISTENCE_DATA, "２つ以上別の" + getItemDispName(ITEM_ID_CST_CD, m_Acsgm11DispBean));
					ret = false;

					break;
				}
			}

		}

		// 正常の場合 整理後リストを設定
		if(ret) {
			m_Acsgm11Form.setItemDispList(afterList);
		}

		return ret;
	}
	/*************************************************************************************
	 * 排他チェック
	 * <p>
	 * 排他チェックを実施する
	 * </p>
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean exclutionCheck() throws  AmallException , Exception {
		// 返却フラグ
		boolean ret = true;


		// 内部保存値からリストを取得する
		List<AcsgmShopGrpDto> list = m_Acsgm11Dto.getItemSavedList();

		for (AcsgmShopGrpDto shopGrpDto : list) {
			if (!existsShopGrpMst(shopGrpDto.getShopGrpCd(), shopGrpDto.getCstCd(), shopGrpDto.getShopCd(), shopGrpDto.getCreateDate(), m_Acsgm11DispBean.getServiceDate())) {
				ret = false;
				break;
			}
		}

		return ret;
	}
	/*************************************************************************************
	 * 店舗グループマスタ(DB)取得
	 * <p>
	 * 店舗グループマスタ(DB)からデータを取得する
	 * 遷移元からの検索条件と合致する一覧を取得する、取得されるデータは内部保存値にも保存する
	 * </p>
	 * @param  shopGrpCd 店舗グループコード
	 * @param  systemDt 業務日付
	 * @return List<AcsgmShopGrpDto> データリスト
	 ************************************************************************************/
	private List<AcsgmShopGrpDto> getShopGrpMst(String shopGrpCd, String systemDt) throws AmallException, Exception {

		String methodName = "getShopGrpMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<AcsgmShopGrpDto> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	nsgm.SHOP_GRP_CD");
			sql.append(",	nsgm.SHOP_GRP_NM");
			sql.append(",	nsgm.CST_CD");
			sql.append(",	ncm.CST_NM");
			sql.append(",	CASE");
			sql.append("		WHEN nscm.COMPANY_SHOP_CD IS NOT NULL THEN TRIM(nscm.COMPANY_SHOP_CD)");
			sql.append("		ELSE nsgm.SHOP_CD");
			sql.append("	END AS DISP_CD");
			sql.append(",	CASE");
			sql.append("		WHEN nscm.COMPANY_SHOP_NM IS NOT NULL THEN nscm.COMPANY_SHOP_NM");
			sql.append("		ELSE nsm.SHOP_NM");
			sql.append("	END AS DISP_NM");
			sql.append(",	nsgm.SHOP_CD");
			sql.append(",	nsm.SHOP_NM");
			sql.append(",	TO_CHAR(nsgm.UPD_DT,'YYYY/MM/DD HH:MI:SS') AS UPD_DT");
			sql.append(",	nsgm.UPD_USER_ID || ' ' || nucm.USER_NM AS UPD_USER");
			sql.append(",	nsgm.CR_DT");
			sql.append("  FROM");
			sql.append("	N_SHOP_GRP_M nsgm");
			sql.append("	INNER JOIN");
			sql.append("		N_CST_M ncm");
			sql.append("	ON");
			sql.append("		nsgm.CST_CD = ncm.CST_CD");
			sql.append("		AND ncm.DEL_FLG = ?");
			sql.append("	INNER JOIN");
			sql.append("		N_SHOP_M nsm");
			sql.append("	ON");
			sql.append("		nsgm.CST_CD = nsm.CST_CD");
			sql.append("		AND nsgm.SHOP_CD = nsm.SHOP_CD");
			sql.append("		AND ? BETWEEN nsm.EFST_DY AND nsm.EFED_DY");
			sql.append("		AND nsm.DEL_FLG = ?");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_CNV_M nscm");
			sql.append("	ON");
			sql.append("		nsgm.CST_CD = nscm.CST_CD");
			sql.append("		AND nsgm.SHOP_CD = nscm.SHOP_CD");
			sql.append("		AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
			sql.append("		AND nscm.DEL_FLG = ?");
			sql.append("	LEFT JOIN");
			sql.append("		(");
			sql.append("			SELECT");
			sql.append("				USER_ID");
			sql.append(",				USER_NM");
			sql.append(",				DEL_FLG");
			sql.append("			  FROM");
			sql.append("				N_USER_CST_M");
			sql.append("			 WHERE");
			sql.append("			 	DEL_FLG = ?");
			sql.append("			UNION");
			sql.append("			SELECT");
			sql.append("				USER_ID");
			sql.append(",				USER_NM");
			sql.append(",				DEL_FLG");
			sql.append("			  FROM");
			sql.append("				N_USER_EMP_M");
			sql.append("			 WHERE");
			sql.append("			 	DEL_FLG = ?");
			sql.append("		) nucm");
			sql.append("	ON");
			sql.append("		nsgm.UPD_USER_ID = nucm.USER_ID");
			sql.append("		AND nucm.DEL_FLG = ?");
			sql.append(" WHERE");
			sql.append("	nsgm.SHOP_GRP_CD = ?");
			sql.append("	AND nsgm.DEL_FLG = ?");
			sql.append("	AND ? BETWEEN nsgm.EFST_DY AND nsgm.EFED_DY");
			sql.append(" ORDER BY");
			sql.append("	nsgm.SHOP_GRP_CD");
			sql.append(",	nsgm.CST_CD");
			sql.append(",	nsgm.SHOP_CD");

			m_DbAccess.createPreparedStatement(sql.toString());

			// 条件設定
			int setCnt = 0;
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, systemDt);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, systemDt);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 店舗グループコード
			m_DbAccess.setString(++setCnt, shopGrpCd);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, systemDt);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				// DTOを生成
				AcsgmShopGrpDto dto = new AcsgmShopGrpDto();
				// 店舗グループコード
				dto.setShopGrpCd(m_DbAccess.getString(rs, "SHOP_GRP_CD"));
				// 店舗グループ名
				dto.setShopGrpNm(m_DbAccess.getString(rs, "SHOP_GRP_NM"));
				// 顧客コード
				dto.setCstCd(m_DbAccess.getString(rs, "CST_CD"));
				// 顧客名
				dto.setCstNm(m_DbAccess.getString(rs, "CST_NM"));
				// 表示店舗コード
				dto.setDispShopCd(m_DbAccess.getString(rs, "DISP_CD"));
				// 表示店舗名
				dto.setDispShopNm(m_DbAccess.getString(rs, "DISP_NM"));
				// 店舗コード
				dto.setShopCd(m_DbAccess.getString(rs, "SHOP_CD"));
				// 店舗名
				dto.setShopNm(m_DbAccess.getString(rs, "SHOP_NM"));
				// 更新日時
				dto.setUpDate(m_DbAccess.getString(rs, "UPD_DT"));
				// 更新者
				dto.setUpDateUser(m_DbAccess.getString(rs, "UPD_USER"));
				// 登録日時
				dto.setCreateDate(rs.getDate("CR_DT"));

				// リストに追加
				retList.add(dto);
			}

			// 内部保存情報に保存
			m_Acsgm11Dto.setItemSavedList(retList);

			return retList;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_SHOP_GRP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 店舗グループマスタ(DB)存在チェック
	 * <p>
	 * 店舗グループマスタ(DB)からデータの存在を確認する
	 * 登録日時を比較するため排他チェックの代替とする
	 * </p>
	 * @param  shopGrpCd 店舗グループコード
	 * @param  shopCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @param  crDt 登録日時
	 * @param  systemDt システム日付
	 * @return boolean true : 存在する false : 存在しない
	 ************************************************************************************/
	private boolean existsShopGrpMst(String shopGrpCd, String cstCd, String shopCd, Date crDt, String systemDt) throws AmallException, Exception {

		String methodName = "existsShopGrpMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	COUNT(*)");
			sql.append("  FROM");
			sql.append("	N_SHOP_GRP_M");
			sql.append(" WHERE");
			sql.append("	SHOP_GRP_CD = ?");
			sql.append("	AND CST_CD = ?");
			sql.append("	AND SHOP_CD = ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND ? BETWEEN EFST_DY AND EFED_DY");
			sql.append("	AND CR_DT = ?");

			m_DbAccess.createPreparedStatement(sql.toString());

			// 条件設定
			int setCnt = 0;
			// 店舗グループコード
			m_DbAccess.setString(++setCnt, shopGrpCd);
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);
			// 店舗コード
			m_DbAccess.setString(++setCnt, shopCd);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, systemDt);
			// 登録日時
			m_DbAccess.setDate(++setCnt, crDt);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			int count = 0;
			while (rs.next()) {
				count = rs.getInt(1);
			}

			// 結果を確認
			if (count > 0) {
				return true;
			} else {
				// 楽観排他

				// エラー情報を設定
				setMessageInfo(m_Acsgm11DispBean, AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST);

				// アクセスログ情報の作成
				AmallExceptionInfo amei = new AmallExceptionInfo();
				amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_ACS_OPT_ERROR, "N_SHOP_GRP_M"));
				setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

				return false;
			}
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_SHOP_GRP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * お客様店舗マスタ(DB)存在チェック
	 * <p>
	 * お客様店舗マスタ(DB)からデータの存在を確認する
	 * </p>
	 * @param  dispCd 検索値(企業店舗コード)
	 * @param  cstCd 顧客コード
	 * @param  systemDt システム日付
	 * @return String 店舗コード(企業店舗コードが存在しない場合は検索値を返却)
	 ************************************************************************************/
	private String existsShopCnvMst(String dispCd, String cstCd, String systemDt) throws AmallException, Exception {

		String methodName = "existsShopCnvMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	SHOP_CD");
			sql.append("  FROM");
			sql.append("	N_SHOP_CNV_M");
			sql.append(" WHERE");
			sql.append("	TRIM(COMPANY_SHOP_CD) = ?");
			sql.append("	AND CST_CD = ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND ? BETWEEN EFST_DY AND EFED_DY");

			m_DbAccess.createPreparedStatement(sql.toString());

			// 条件設定
			int setCnt = 0;
			// 検索値
			m_DbAccess.setString(++setCnt, dispCd);
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, systemDt);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			String retShopCd = "";
			while (rs.next()) {
				// 店舗コード
				retShopCd = m_DbAccess.getString(rs, "SHOP_CD");
			}

			// 結果を確認
			if (AmallUtilities.isEmpty(retShopCd)) {

				// 企業店舗コードが取得出来ない場合
				retShopCd = dispCd;

			}

			return retShopCd;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_SHOP_GRP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 店舗グループマスタ(DB)登録
	 * <p>
	 * 店舗グループマスタ(DB)にレコードを登録する
	 * </p>
	 * @param shopGrpCd 店舗グループコード
	 * @param cstCd 顧客コード
	 * @param shopCd 店舗コード
	 * @param shopGrpNm 店舗グループ名
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	public boolean insertShopGrpMst(String shopGrpCd, String cstCd, String shopCd, String shopGrpNm) throws AmallException {

		String methodName = "insertShopGrpMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// SQL生成
			sql.append("INSERT INTO");
			sql.append("	N_SHOP_GRP_M (");
			sql.append("		SHOP_GRP_CD");
			sql.append(",		CST_CD");
			sql.append(",		SHOP_CD");
			sql.append(",		EFST_DY");
			sql.append(",		EFED_DY");
			sql.append(",		SHOP_GRP_NM");
			sql.append(",		EXCLUSIVE_KEY");
			sql.append(",		DEL_FLG");
			sql.append(",		CR_PGM_ID");
			sql.append(",		CR_USER_ID");
			sql.append(",		CR_DT");
			sql.append(",		UPD_PGM_ID");
			sql.append(",		UPD_USER_ID");
			sql.append(",		UPD_DT");
			sql.append("	) VALUES (");
			sql.append("		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			// 共通部分
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append("	)");

			// 登録値のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;

			// 店舗グループコード
			m_DbAccess.setString(++setCnt, shopGrpCd);
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);
			// 店舗コード
			m_DbAccess.setString(++setCnt, shopCd);
			// 有効開始日
			m_DbAccess.setString(++setCnt, AmallConst.EFST_DY_DEFAULT);
			// 有効終了日
			m_DbAccess.setString(++setCnt, AmallConst.EFED_DY_DEFAULT);
			// 店舗グループ名
			m_DbAccess.setString(++setCnt, shopGrpNm);


			// 排他キー
			m_DbAccess.setLong(++setCnt, 0);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 登録プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 登録ユーザーID
			m_DbAccess.setString(++setCnt, m_Acsgm11DispBean.getH_loginId());
			// 更新プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 更新ユーザーID
			m_DbAccess.setString(++setCnt, m_Acsgm11DispBean.getH_loginId());

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 更新結果判定
			if (ret <= 0) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_SHOP_GRP_M");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_SHOP_GRP_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}
	/*************************************************************************************
	 * 店舗グループマスタ(DB)削除
	 * <p>
	 * 店舗グループマスタ(DB)を削除する
	 * </p>
	 * @param shopGrpCd 店舗グループコード
	 * @param  systemDt システム日付
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	public boolean deleteShopGrpMst(String shopGrpCd, String systemDt) throws AmallException {

		String methodName = "deleteShopGrpeMst()";
		StringBuffer sql = new StringBuffer();

		try {
			// SQL生成
			sql.append("DELETE FROM");
			sql.append("	N_SHOP_GRP_M");
			// 条件指定
			sql.append(" WHERE");
			sql.append("	SHOP_GRP_CD = ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND ? BETWEEN EFST_DY AND EFED_DY");


			// パラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;

			// WHERE句のパラメタ設定
			// 店舗グループコード
			m_DbAccess.setString(++setCnt, shopGrpCd);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// システム日付
			m_DbAccess.setString(++setCnt, systemDt);

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 排他チェック
			if(ret == 0) {
				// 更新対象無し(楽観排他)
				m_DbAccess.rollback();

				// エラー情報を設定
				setMessageInfo(m_Acsgm11DispBean, AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST);

				// アクセスログ情報の作成
				AmallExceptionInfo amei = new AmallExceptionInfo();
				amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_ACS_OPT_ERROR, "N_SHOP_GRP_M"));
				setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

				return false;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_CST_GRP_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}
}