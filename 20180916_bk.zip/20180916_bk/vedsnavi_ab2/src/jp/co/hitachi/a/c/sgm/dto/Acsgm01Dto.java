/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acsgm01Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.sgm.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Acsgm01Dtoクラス<br>
 *****************************************************************************************/
public class Acsgm01Dto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 顧客CD */
	private String inputedCstCd = null;
	/** 店舗CD */
	private String inputedShopCd = null;
	/** 表示件数 */
	private int dispResults = 0;
	/** ページ番号 */
	private int displayNum = 0;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public Acsgm01Dto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		inputedCstCd = null;
		inputedShopCd = null;
		dispResults = 0;
		displayNum = 0;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getInputedCstCd() {
		return inputedCstCd;
	}
	public void setInputedCstCd(String inputedCstCd) {
		this.inputedCstCd = inputedCstCd;
	}
	public String getInputedShopCd() {
		return inputedShopCd;
	}
	public void setInputedShopCd(String inputedShopCd) {
		this.inputedShopCd = inputedShopCd;
	}
	public int getDispResults() {
		return dispResults;
	}
	public void setDispResults(int dispResults) {
		this.dispResults = dispResults;
	}
	public int getDisplayNum() {
		return displayNum;
	}
	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}
}
