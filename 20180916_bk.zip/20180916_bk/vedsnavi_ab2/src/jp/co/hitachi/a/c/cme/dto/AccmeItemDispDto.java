/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AccmeItemDispDto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cme.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * AccmeItemDispDtoクラス<br>
 *****************************************************************************************/
public class AccmeItemDispDto extends AmclsDtoBase {

	/** メンバ変数 */
	/** 確定状況 */
	private boolean listCheck = false;
	/** 確定状況 */
	private String finFlg = null;
	/** 送信状態 */
	private String statusCls = null;
	/** 売上日 */
	private String sld = null;
	/** 顧客CD(遷移用) */
	private String cstCd = null;
	/** 顧客CD */
	private String dispCstCd = null;
	/** 顧客名 */
	private String dispCstNm = null;
	/** 店舗Cd(遷移用) */
	private String shopCd = null;
	/** 店舗Cd */
	private String dispShopCd = null;
	/** 店舗名 */
	private String dispShopNm = null;
	/** 店舗枝番（レジNo） */
	private String shopSbno = null;
	/** 店舗枝番（遷移用） */
	private String dispShopSbno = null;
	/** 店舗枝番名（レジ名） */
	private String dispShopSbnm = null;
	/** 合計金額 */
	private String spccmt = null;
	/** 1万円枚数 */
	private String spccmt10000YMai = null;
	/** 5千円枚数 */
	private String spccmt5000YMai = null;
	/** 2千円枚数 */
	private String spccmt2000YMai = null;
	/** 1千円枚数 */
	private String spccmt1000YMai = null;
	/** 5百円枚数 */
	private String spccmt500YMai = null;
	/** 百円枚数 */
	private String spccmt100YMai = null;
	/** 5十円枚数 */
	private String spccmt50YMai = null;
	/** 十円枚数 */
	private String spccmt10YMai = null;
	/** 5円枚数 */
	private String spccmt5YMai = null;
	/** 1円枚数 */
	private String spccmt1YMai = null;

	/** 更新日時 */
	private String updateDate = null;



	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AccmeItemDispDto() {
		clear();
	}

	/*************************************************************************************
	 * クリア
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		finFlg = null;
		statusCls = null;
		sld = null;
		cstCd = null;
		dispCstCd = null;
		dispCstNm = null;
		shopCd = null;
		dispShopNm = null;
		shopSbno = null;
		dispShopSbnm = null;
		spccmt = null;
		spccmt10000YMai = null;
		spccmt5000YMai = null;
		spccmt2000YMai = null;
		spccmt1000YMai = null;
		spccmt500YMai = null;
		spccmt100YMai = null;
		spccmt50YMai = null;
		spccmt10YMai = null;
		spccmt5YMai = null;
		spccmt1YMai = null;
	}

	public boolean isListCheck() {
		return listCheck;
	}

	public void setListCheck(boolean listCheck) {
		this.listCheck = listCheck;
	}

	public String getFinFlg() {
		return finFlg;
	}

	public void setFinFlg(String finFlg) {
		this.finFlg = finFlg;
	}

	public String getStatusCls() {
		return statusCls;
	}

	public void setStatusCls(String statusCls) {
		this.statusCls = statusCls;
	}

	public String getSld() {
		return sld;
	}

	public void setSld(String sld) {
		this.sld = sld;
	}

	public String getCstCd() {
		return cstCd;
	}

	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}

	public String getDispCstCd() {
		return dispCstCd;
	}

	public void setDispCstCd(String dispCstCd) {
		this.dispCstCd = dispCstCd;
	}

	public String getDispCstNm() {
		return dispCstNm;
	}

	public void setDispCstNm(String dispCstNm) {
		this.dispCstNm = dispCstNm;
	}

	public String getShopCd() {
		return shopCd;
	}

	public void setShopCd(String shopCd) {
		this.shopCd = shopCd;
	}

	public String getDispShopNm() {
		return dispShopNm;
	}

	public void setDispShopNm(String dispShopNm) {
		this.dispShopNm = dispShopNm;
	}

	public String getShopSbno() {
		return shopSbno;
	}

	public void setShopSbno(String shopSbno) {
		this.shopSbno = shopSbno;
	}

	public String getDispShopSbnm() {
		return dispShopSbnm;
	}

	public void setDispShopSbnm(String dispShopSbnm) {
		this.dispShopSbnm = dispShopSbnm;
	}

	public String getSpccmt() {
		return spccmt;
	}

	public void setSpccmt(String spccmt) {
		this.spccmt = spccmt;
	}

	public String getSpccmt10000YMai() {
		return spccmt10000YMai;
	}

	public void setSpccmt10000YMai(String spccmt10000yMai) {
		spccmt10000YMai = spccmt10000yMai;
	}

	public String getSpccmt5000YMai() {
		return spccmt5000YMai;
	}

	public void setSpccmt5000YMai(String spccmt5000yMai) {
		spccmt5000YMai = spccmt5000yMai;
	}

	public String getSpccmt2000YMai() {
		return spccmt2000YMai;
	}

	public void setSpccmt2000YMai(String spccmt2000yMai) {
		spccmt2000YMai = spccmt2000yMai;
	}

	public String getSpccmt1000YMai() {
		return spccmt1000YMai;
	}

	public void setSpccmt1000YMai(String spccmt1000yMai) {
		spccmt1000YMai = spccmt1000yMai;
	}

	public String getSpccmt500YMai() {
		return spccmt500YMai;
	}

	public void setSpccmt500YMai(String spccmt500yMai) {
		spccmt500YMai = spccmt500yMai;
	}

	public String getSpccmt100YMai() {
		return spccmt100YMai;
	}

	public void setSpccmt100YMai(String spccmt100yMai) {
		spccmt100YMai = spccmt100yMai;
	}

	public String getSpccmt50YMai() {
		return spccmt50YMai;
	}

	public void setSpccmt50YMai(String spccmt50yMai) {
		spccmt50YMai = spccmt50yMai;
	}

	public String getSpccmt10YMai() {
		return spccmt10YMai;
	}

	public void setSpccmt10YMai(String spccmt10yMai) {
		spccmt10YMai = spccmt10yMai;
	}

	public String getSpccmt5YMai() {
		return spccmt5YMai;
	}

	public void setSpccmt5YMai(String spccmt5yMai) {
		spccmt5YMai = spccmt5yMai;
	}

	public String getSpccmt1YMai() {
		return spccmt1YMai;
	}

	public void setSpccmt1YMai(String spccmt1yMai) {
		spccmt1YMai = spccmt1yMai;
	}

	public String getDispShopCd() {
		return dispShopCd;
	}

	public void setDispShopCd(String dispShopCd) {
		this.dispShopCd = dispShopCd;
	}

	public String getDispShopSbno() {
		return dispShopSbno;
	}

	public void setDispShopSbno(String dispShopSbno) {
		this.dispShopSbno = dispShopSbno;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

}
