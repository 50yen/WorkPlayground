/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoGeneralMst.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import java.sql.Date;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * 汎用マスタ情報 <br>
 *****************************************************************************************/
public class AmdtoGeneralMst extends AmclsDtoBase {

	/** メンバ変数 */
	/** 汎用区分 */
	private String generalCls = null;
	/** 汎用区分名称 */
	private String generalClsNm = null;
	/** 汎用コード１ */
	private String generalCd1 = null;
	/** 汎用名称１ */
	private String generalNm1 = null;
	/** 汎用コード２ */
	private String generalCd2 = null;
	/** 汎用名称２ */
	private String generalNm2 = null;
	/** 適用開始日 */
	private String efstDy = null;
	/** 適用終了日 */
	private String efedDy = null;
	/** CHAR1 */
	private String char1 = null;
	/** CHAR2 */
	private String char2 = null;
	/** CHAR3 */
	private String char3 = null;
	/** CHAR4 */
	private String char4 = null;
	/** CHAR5 */
	private String char5 = null;
	/** CHAR6 */
	private String char6 = null;
	/** CHAR7 */
	private String char7 = null;
	/** CHAR8 */
	private String char8 = null;
	/** CHAR9 */
	private String char9 = null;
	/** CHAR10 */
	private String char10 = null;
	/** NO1 */
	private Long no1 = null;
	/** NO2 */
	private Long no2 = null;
	/** NO3 */
	private Long no3 = null;
	/** NO4 */
	private Long no4 = null;
	/** NO5 */
	private Long no5 = null;
	/** NO6 */
	private Long no6 = null;
	/** NO7 */
	private Long no7 = null;
	/** NO8 */
	private Long no8 = null;
	/** NO9 */
	private Long no9 = null;
	/** NO10 */
	private Long no10 = null;
	/** CMT1 */
	private String cmt1 = null;
	/** CMT2 */
	private String cmt2 = null;
	/** CMT3 */
	private String cmt3 = null;
	/** CMT4 */
	private String cmt4 = null;
	/** CMT5 */
	private String cmt5 = null;
	/** CMT6 */
	private String cmt6 = null;
	/** CMT7 */
	private String cmt7 = null;
	/** CMT8 */
	private String cmt8 = null;
	/** CMT9 */
	private String cmt9 = null;
	/** CMT10 */
	private String cmt10 = null;
	/** デフォルト区分 */
	private String defaultFlg = null;
	/** 表示順 */
	private Long sortNo = null;
	/** 備考 */
	private String remarks = null;
	/** 排他キー */
	private Long exclusiveKey = null;
	/** 削除フラグ */
	private String delFlg = null;
	/** 登録プログラムＩＤ */
	private String crpgmId = null;
	/** 登録ユーザＩＤ */
	private String cruserId = null;
	/** 登録日時 */
	private Date crDt = null;
	/** 更新プログラムＩＤ */
	private String updPgmId = null;
	/** 更新ユーザＩＤ */
	private String updUserId = null;
	/** 更新日時 */
	private Date updDt = null;


	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmdtoGeneralMst() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		generalCls = null;
		generalClsNm = null;
		generalCd1 = null;
		generalNm1 = null;
		generalCd2 = null;
		generalNm2 = null;
		efstDy = null;
		efedDy = null;
		char1 = null;
		char2 = null;
		char3 = null;
		char4 = null;
		char5 = null;
		char6 = null;
		char7 = null;
		char8 = null;
		char9 = null;
		char10 = null;
		no1 = null;
		no2 = null;
		no3 = null;
		no4 = null;
		no5 = null;
		no6 = null;
		no7 = null;
		no8 = null;
		no9 = null;
		no10 = null;
		cmt1 = null;
		cmt2 = null;
		cmt3 = null;
		cmt4 = null;
		cmt5 = null;
		cmt6 = null;
		cmt7 = null;
		cmt8 = null;
		cmt9 = null;
		cmt10 = null;
		defaultFlg = null;
		sortNo = null;
		remarks = null;
		exclusiveKey = null;
		delFlg = null;
		crpgmId = null;
		cruserId = null;
		crDt = null;
		updPgmId = null;
		updUserId = null;
		updDt = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getGeneralCls() {
		return generalCls;
	}

	public void setGeneralCls(String generalCls) {
		this.generalCls = generalCls;
	}

	public String getGeneralClsNm() {
		return generalClsNm;
	}

	public void setGeneralClsNm(String generalClsNm) {
		this.generalClsNm = generalClsNm;
	}

	public String getGeneralCd1() {
		return generalCd1;
	}

	public void setGeneralCd1(String generalCd1) {
		this.generalCd1 = generalCd1;
	}

	public String getGeneralNm1() {
		return generalNm1;
	}

	public void setGeneralNm1(String generalNm1) {
		this.generalNm1 = generalNm1;
	}

	public String getGeneralCd2() {
		return generalCd2;
	}

	public void setGeneralCd2(String generalCd2) {
		this.generalCd2 = generalCd2;
	}

	public String getGeneralNm2() {
		return generalNm2;
	}

	public void setGeneralNm2(String generalNm2) {
		this.generalNm2 = generalNm2;
	}

	public String getEfstDy() {
		return efstDy;
	}

	public void setEfstDy(String efstDy) {
		this.efstDy = efstDy;
	}

	public String getEfedDy() {
		return efedDy;
	}

	public void setEfedDy(String efedDy) {
		this.efedDy = efedDy;
	}

	public String getChar1() {
		return char1;
	}

	public void setChar1(String char1) {
		this.char1 = char1;
	}

	public String getChar2() {
		return char2;
	}

	public void setChar2(String char2) {
		this.char2 = char2;
	}

	public String getChar3() {
		return char3;
	}

	public void setChar3(String char3) {
		this.char3 = char3;
	}

	public String getChar4() {
		return char4;
	}

	public void setChar4(String char4) {
		this.char4 = char4;
	}

	public String getChar5() {
		return char5;
	}

	public void setChar5(String char5) {
		this.char5 = char5;
	}

	public String getChar6() {
		return char6;
	}

	public void setChar6(String char6) {
		this.char6 = char6;
	}

	public String getChar7() {
		return char7;
	}

	public void setChar7(String char7) {
		this.char7 = char7;
	}

	public String getChar8() {
		return char8;
	}

	public void setChar8(String char8) {
		this.char8 = char8;
	}

	public String getChar9() {
		return char9;
	}

	public void setChar9(String char9) {
		this.char9 = char9;
	}

	public String getChar10() {
		return char10;
	}

	public void setChar10(String char10) {
		this.char10 = char10;
	}

	public Long getNo1() {
		return no1;
	}

	public void setNo1(Long no1) {
		this.no1 = no1;
	}

	public Long getNo2() {
		return no2;
	}

	public void setNo2(Long no2) {
		this.no2 = no2;
	}

	public Long getNo3() {
		return no3;
	}

	public void setNo3(Long no3) {
		this.no3 = no3;
	}

	public Long getNo4() {
		return no4;
	}

	public void setNo4(Long no4) {
		this.no4 = no4;
	}

	public Long getNo5() {
		return no5;
	}

	public void setNo5(Long no5) {
		this.no5 = no5;
	}

	public Long getNo6() {
		return no6;
	}

	public void setNo6(Long no6) {
		this.no6 = no6;
	}

	public Long getNo7() {
		return no7;
	}

	public void setNo7(Long no7) {
		this.no7 = no7;
	}

	public Long getNo8() {
		return no8;
	}

	public void setNo8(Long no8) {
		this.no8 = no8;
	}

	public Long getNo9() {
		return no9;
	}

	public void setNo9(Long no9) {
		this.no9 = no9;
	}

	public Long getNo10() {
		return no10;
	}

	public void setNo10(Long no10) {
		this.no10 = no10;
	}

	public String getCmt1() {
		return cmt1;
	}

	public void setCmt1(String cmt1) {
		this.cmt1 = cmt1;
	}

	public String getCmt2() {
		return cmt2;
	}

	public void setCmt2(String cmt2) {
		this.cmt2 = cmt2;
	}

	public String getCmt3() {
		return cmt3;
	}

	public void setCmt3(String cmt3) {
		this.cmt3 = cmt3;
	}

	public String getCmt4() {
		return cmt4;
	}

	public void setCmt4(String cmt4) {
		this.cmt4 = cmt4;
	}

	public String getCmt5() {
		return cmt5;
	}

	public void setCmt5(String cmt5) {
		this.cmt5 = cmt5;
	}

	public String getCmt6() {
		return cmt6;
	}

	public void setCmt6(String cmt6) {
		this.cmt6 = cmt6;
	}

	public String getCmt7() {
		return cmt7;
	}

	public void setCmt7(String cmt7) {
		this.cmt7 = cmt7;
	}

	public String getCmt8() {
		return cmt8;
	}

	public void setCmt8(String cmt8) {
		this.cmt8 = cmt8;
	}

	public String getCmt9() {
		return cmt9;
	}

	public void setCmt9(String cmt9) {
		this.cmt9 = cmt9;
	}

	public String getCmt10() {
		return cmt10;
	}

	public void setCmt10(String cmt10) {
		this.cmt10 = cmt10;
	}

	public String getDefaultFlg() {
		return defaultFlg;
	}

	public void setDefaultFlg(String defaultFlg) {
		this.defaultFlg = defaultFlg;
	}

	public Long getSortNo() {
		return sortNo;
	}

	public void setSortNo(Long sortNo) {
		this.sortNo = sortNo;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Long getExclusiveKey() {
		return exclusiveKey;
	}

	public void setExclusiveKey(Long exclusiveKey) {
		this.exclusiveKey = exclusiveKey;
	}

	public String getDelFlg() {
		return delFlg;
	}

	public void setDelFlg(String delFlg) {
		this.delFlg = delFlg;
	}

	public String getCrpgmId() {
		return crpgmId;
	}

	public void setCrpgmId(String crpgmId) {
		this.crpgmId = crpgmId;
	}

	public String getCruserId() {
		return cruserId;
	}

	public void setCruserId(String cruserId) {
		this.cruserId = cruserId;
	}

	public Date getCrDt() {
		return crDt;
	}

	public void setCrDt(Date crDt) {
		this.crDt = crDt;
	}

	public String getUpdPgmId() {
		return updPgmId;
	}

	public void setUpdPgmId(String updPgmId) {
		this.updPgmId = updPgmId;
	}

	public String getUpdUserId() {
		return updUserId;
	}

	public void setUpdUserId(String updUserId) {
		this.updUserId = updUserId;
	}

	public Date getUpdDt() {
		return updDt;
	}

	public void setUpdDt(Date updDt) {
		this.updDt = updDt;
	}

}
