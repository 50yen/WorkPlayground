/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aceum11Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Aceum11Dtoクラス<br>
 *****************************************************************************************/
public class Aceum11Dto extends AmclsDtoBase{

	/** メンバ変数 */
	/** ユーザーID(ログイン者) */
	private String userId = null;
	/** システム種別 */
	private int systemKind = 0;
	/** 表示モード */
	private int dispMode = 0;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public Aceum11Dto(){
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){

	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getSystemKind() {
		return systemKind;
	}
	public void setSystemKind(int systemKind) {
		this.systemKind = systemKind;
	}
	public int getDispMode() {
		return dispMode;
	}
	public void setDispMode(int dispMode) {
		this.dispMode = dispMode;
	}

}
