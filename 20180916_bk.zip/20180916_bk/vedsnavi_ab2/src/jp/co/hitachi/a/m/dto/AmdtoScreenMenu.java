/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoScreenMenu.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import java.util.ArrayList;
import java.util.List;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * 画面メニュー情報 <br>
 *****************************************************************************************/
public class AmdtoScreenMenu extends AmclsDtoBase {

	/** メンバ変数 */
	/** グループID(メニュー) */
	private String m_MenuId = null;
	/** 名称 */
	private String m_MenuName = null;
	/** 画面リスト */
	private List<AmdtoScreen> m_ScreenList = null;
	/** 表示可否 */
	private boolean m_Display = false;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmdtoScreenMenu() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		m_MenuId = null;
		m_MenuName = null;
		m_ScreenList = new ArrayList<>();
		m_Display = false;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getM_MenuId() {
		return m_MenuId;
	}

	public void setM_MenuId(String m_MenuId) {
		this.m_MenuId = m_MenuId;
	}

	public String getM_MenuName() {
		return m_MenuName;
	}

	public void setM_MenuName(String m_MenuName) {
		this.m_MenuName = m_MenuName;
	}

	public List<AmdtoScreen> getM_ScreenList() {
		return m_ScreenList;
	}

	public void setM_ScreenList(List<AmdtoScreen> m_ScreenList) {
		this.m_ScreenList = m_ScreenList;
	}

	public boolean isM_Display() {
		return m_Display;
	}

	public void setM_Display(boolean m_Display) {
		this.m_Display = m_Display;
	}




}
