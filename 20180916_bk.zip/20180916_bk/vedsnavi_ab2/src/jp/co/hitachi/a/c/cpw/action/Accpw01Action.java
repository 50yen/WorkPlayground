/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Accpw01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cpw.action;

import jp.co.hitachi.a.c.cpw.bean.Accpw01DispBean;
import jp.co.hitachi.a.c.cpw.business.Accpw01Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Accpw01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Accpw01DispBean accpw01DispBean;

	/** パスワード */
	private String password = null;
	/** 再パスワード */
	private String rePassword = null;
	/** TOP遷移フラグ */
	private String fromTopScreen = null;
	/** TOP自動遷移ミリ秒数 */
	private Long autoTopMoveSec = 0L;
	/** ログアウト自動遷移ミリ秒数 */
	private Long autoLogOutMoveSec = 0L;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAccpw01DispBean((Accpw01DispBean)request.getAttribute("Accpw01DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {

		// ビジネス層の生成
		Accpw01Business dao = new Accpw01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Accpw01DispBean getAccpw01DispBean() {
		return accpw01DispBean;
	}

	public void setAccpw01DispBean(Accpw01DispBean accpw01DispBean) {
		this.accpw01DispBean = accpw01DispBean;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRePassword() {
		return rePassword;
	}

	public void setRePassword(String rePassword) {
		this.rePassword = rePassword;
	}

	public String getFromTopScreen() {
		return fromTopScreen;
	}

	public void setFromTopScreen(String fromTopScreen) {
		this.fromTopScreen = fromTopScreen;
	}

	public Long getAutoTopMoveSec() {
		return autoTopMoveSec;
	}

	public void setAutoTopMoveSec(Long autoTopMoveSec) {
		this.autoTopMoveSec = autoTopMoveSec;
	}

	public Long getAutoLogOutMoveSec() {
		return autoLogOutMoveSec;
	}

	public void setAutoLogOutMoveSec(Long autoLogOutMoveSec) {
		this.autoLogOutMoveSec = autoLogOutMoveSec;
	}


}
