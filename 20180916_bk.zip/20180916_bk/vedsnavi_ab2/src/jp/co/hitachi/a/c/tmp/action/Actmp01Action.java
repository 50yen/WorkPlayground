/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) XXX Actmp01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.tmp.action;

import jp.co.hitachi.a.c.tmp.bean.Actmp01DispBean;
import jp.co.hitachi.a.c.tmp.business.Actmp01Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Actmp01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	// XXX 対応するBeanを定義する
	/** 画面表示Bean */
	private Actmp01DispBean actmp01DispBean;

	// XXX 画面上で必要な入力エリアと紐づけるメンバ変数
	/** TEMP01 */
	private String temp01 = null;
	/** TEMP02 */
	private String temp02 = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// XXX 対応するBeanに書き換える
    	// 実行結果を画面表示Beanに登録
    	setActmp01DispBean((Actmp01DispBean)request.getAttribute("Actmp01DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// XXX 対応するビジネス層に書き換える
		// ビジネス層の生成
		Actmp01Business dao = new Actmp01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	// XXX ここより下はeclipseの自動生成で行うこと

	public Actmp01DispBean getActmp01DispBean() {
		return actmp01DispBean;
	}

	public void setActmp01DispBean(Actmp01DispBean actmp01DispBean) {
		this.actmp01DispBean = actmp01DispBean;
	}

	public String getTemp01() {
		return temp01;
	}

	public void setTemp01(String temp01) {
		this.temp01 = temp01;
	}

	public String getTemp02() {
		return temp02;
	}

	public void setTemp02(String temp02) {
		this.temp02 = temp02;
	}



}
