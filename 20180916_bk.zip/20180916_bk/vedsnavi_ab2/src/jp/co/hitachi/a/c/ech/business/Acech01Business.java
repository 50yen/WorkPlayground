/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.business;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.ech.action.Acech01Action;
import jp.co.hitachi.a.c.ech.bean.Acech01DispBean;
import jp.co.hitachi.a.c.ech.dto.Acech01Dto;
import jp.co.hitachi.a.c.ech.dto.AcechItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.LogType;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoCalender;

/*****************************************************************************************
 * Acech01Businessクラス<br>
 *****************************************************************************************/
public class Acech01Business extends AcechBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Acech01DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 前月ボタン押下 */
	public static final String FORWARD_PREV = "PREV";
	/** 次月ボタン押下 */
	public static final String FORWARD_NEXT = "NEXT";
	/** エリアボタン押下 */
	public static final String FORWARD_RESULT = "RESULT";
	/** 「戻る」にてページ再表示 */
	public static final String FORWARD_REDISP = "REDISP";
	/** 回収実績エリア押下(日別店舗一覧へ) */
	public static final String FORWARD_RESULT_CLD = "CLDLIST";
	/** 回収実績エリア押下(レジ別一覧へ) */
	public static final String FORWARD_RESULT_REGI = "REGILIST";

	/**
	 * 画面項目ID
	 */
	/** 画面名 */
	public static final String ITEM_ID_SCREEN_NAME = "ScreenName";

	/** メンバ変数 */
	/** アクションフォーム */
	private Acech01Action m_Acech01Form = null;
	/** 表示用画面Bean */
	private Acech01DispBean m_Acech01DispBean = null;
	/** 画面DTO */
	private Acech01Dto m_Acech01Dto;
	/** 遷移先画面キー */
	public static final String ACECH_INFO_KEY = "AcechInfo";
	/** DTOキー名 */
	public static final String DTO_ACECH01 = "DTO_ACECH01";
	/** DTOキー名 */
	public static final String ITEM_DTO_CLD = "DTO_CLD";
	/** 遷移付加メッセージparam */
	private static final String DISP_DATA = "回収金データ";
	/** 回収金有 */
	private static final String COL_MONEY = "回収実績有";
	/** 誤差発生 */
	private static final String COL_ERROR = "誤差発生";

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Acech01Business(
			Acech01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Acech01Business.class.getName();
		m_Acech01Form = form;
		m_Acech01DispBean = new Acech01DispBean();
		setErrString(gid, m_Acech01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}
			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Acech01DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Acech01Form.getM_systemKind());
			m_DbAccess.initDB();
			/* 内部記憶情報の生成 */
			m_Acech01Dto = (Acech01Dto) getSpecifiedDTO(m_Gid, DTO_ACECH01);
			if (m_Acech01Dto == null) {
				m_Acech01Dto = new Acech01Dto();
				putSpecifiedDTO(m_Gid, DTO_ACECH01, m_Acech01Dto);
			}

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_PREV.equals(m_Event)) {
				// 前月ボタン押下処理の場合
				forwardStr = prev();
			} else if (FORWARD_NEXT.equals(m_Event)) {
				//次月ボタン押下処理の場合
				forwardStr = next();
			} else if (FORWARD_RESULT.equals(m_Event)) {
				// エリアボタン押下処理の場合
				forwardStr = resultListMove();
			} else if (FORWARD_REDISP.equals(m_Event)) {
				// 戻るボタンでページに戻ってきた場合
				forwardStr = redisp();
			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Acech01DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		// 現在日付取得(日付は切り捨て)
		String nowDate = m_Acech01DispBean.getServiceDate().substring(0, 6);

		// ヘッダ付加情報セット
		String calDate = AmallUtilities.changeFormatDate(nowDate);
		m_Acech01DispBean.setH_screenNameAddData(calDate);
		// カレンダーデータの作成
		calCreate(nowDate);

		// 遷移ボタン活性設定
		setBtnFlg();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 前月表示処理
	 * <p>
	 * 前月表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String prev() throws AmallException {

		// 表示年月取得
		String dispDate = m_Acech01Dto.getDispDate();
		// 前月取得処理
		dispDate = AmallUtilities.getPrevMonth(dispDate);

		// ヘッダ付加情報セット
		String calDate = AmallUtilities.changeFormatDate(dispDate);
		m_Acech01DispBean.setH_screenNameAddData(calDate);
		// カレンダーデータの作成
		calCreate(dispDate);

		// 遷移ボタン活性設定
		setBtnFlg();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 翌月表示処理
	 * <p>
	 * 翌月表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String next() throws AmallException {

		// 表示年月取得
		String dispDate = m_Acech01Dto.getDispDate();
		// 翌月取得処理
		dispDate = AmallUtilities.getNextMonth(dispDate);

		// ヘッダ付加情報セット
		String calDate = AmallUtilities.changeFormatDate(dispDate);
		m_Acech01DispBean.setH_screenNameAddData(calDate);
		// カレンダーデータの作成
		calCreate(dispDate);

		// 遷移ボタン活性設定
		setBtnFlg();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 再表示処理
	 * <p>
	 * 「戻る」ボタンで戻ってきた場合の再表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String redisp() throws AmallException {

		// 表示年月取得
		String dispDate = m_Acech01Dto.getDispDate();

		// ヘッダ付加情報セット
		String calDate = AmallUtilities.changeFormatDate(dispDate);
		m_Acech01DispBean.setH_screenNameAddData(calDate);
		// カレンダーデータの作成
		calCreate(dispDate);

		// 遷移ボタン活性設定
		setBtnFlg();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 回収実績有エリア押下処理
	 * <p>
	 * 回収実績有エリア押下処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String resultListMove() throws AmallException {

		// ログ用メソッド名
		String methodName = "resultListMove()";

		// 遷移用DTO削除
		delSpecifiedDTO(ACECH_INFO_KEY);

		// TODO 権限
		try {
			// ログインユーザの権限確認
			// 顧客
			if (m_Acech01DispBean.isCustomerCdAllFlg()) {
				// 全顧客フラグがオンの場合→回収日一覧へ
				// Dtoセット
				AcechItemDispDto dto = new AcechItemDispDto();
				dto.setCld(m_Acech01Form.getCld());
				putSpecifiedDTO(ACECH_INFO_KEY, dto);

				return FORWARD_RESULT_CLD;
				//			} else if (m_Acech01DispBean.getCustomerCdList() != null
				//					&& m_Acech01DispBean.getShopCdList().size() > 1) {
				//				// 担当顧客リストが複数存在する
				//				// DTOセット
				//				AcechItemDispDto dto = new AcechItemDispDto();
				//				dto.setCld(m_Acech01Form.getCld());
				//				putSpecifiedDTO(ACECH_INFO_KEY, dto);
				//
				//				return FORWARD_RESULT_CLD;
				//			} else if (m_Acech01DispBean.getCustomerCdList().size() == 1
				//					&& m_Acech01DispBean.getShopCdList().size() == 1) {
				//				// 担当店舗が1店のみの場合
				//				// DTOセット
				//				AcechItemDispDto dto = new AcechItemDispDto();
				//				dto.setCld(m_Acech01Form.getCld());
				//				dto.setCstCd(m_Acech01DispBean.getCustomerCdList().get(0));
				//				dto.setShopCd(m_Acech01DispBean.getShopCdList().get(0));
				//				putSpecifiedDTO(ACECH_INFO_KEY, dto);
				//
				//				return FORWARD_RESULT_REGI;
			} else {
				// 上記以外
				// エラーメッセージのセット
				setMessageInfo(m_Acech01DispBean, AmallMessageConst.MSG_INF_SEARCH_CON_NO_DATA_ARG, DISP_DATA);
				return FORWARD_DISP;
			}

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		}

	}

	/*************************************************************************************
	 * カレンダー作成処理
	 * <p>
	 * カレンダー作成処理を行う
	 * </p>
	 * @param  無し
	 * @return なし
	 ************************************************************************************/
	private void calCreate(String ym) throws AmallException {
		// MethodName
		String methodName = "calCreate(String ym)";

		try {
			// カレンダーデータの作成
			List<List<AmdtoCalender>> calender = AmallUtilities.getCalenderDispData(ym, m_DbAccess);

			// カレンダーヘッダ設定
			m_Acech01Dto.setDispDate(ym);

			// 回収実績取得
			List<AcechItemDispDto> list = search(ym);

			// 内容データの設定
			for (AcechItemDispDto dto : list) {
				if ((AmallConst.GeneralFlg.ON).equals(dto.getDefFlg())) {
					AmallUtilities.setCalenderContentsData(dto.getCld(), AmdtoCalender.CON_TYPE_ERROR, COL_MONEY,
							COL_ERROR, calender);
				} else {
					AmallUtilities.setCalenderContentsData(dto.getCld(), AmdtoCalender.CON_TYPE_ON, COL_MONEY, "",
							calender);
				}
			}

			// 表示カレンダーセット
			m_Acech01DispBean.setCalDataList(calender);

		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR, DISP_BEAN);
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, LogType.ERROR, e);
			throw ee;
		}
	}

	/**********************************************************************************************
	 * 回収実績取得処理
	 * <p>
	 * 回収実績取得処理を行う
	 * </p>
	 * @param
	 * @return
	 *********************************************************************************************/
	public List<AcechItemDispDto> search(String ym) throws AmallException, Exception {
		// methodName
		String methodName = "search(String ym)";
		//
		ResultSet rs = null;
		// 返却用リスト
		List<AcechItemDispDto> retList = new ArrayList<>();

		try {

			// SQL作成
			makeSearchSql(ym);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 実行結果チェック
			while (rs.next()) {
				// データセット
				AcechItemDispDto dto = new AcechItemDispDto();
				dto.setCld(m_DbAccess.getString(rs, "CLD"));
				if (rs.getLong("MIN_DFEMT") != 0) {
					dto.setDefFlg(AmallConst.GeneralFlg.ON);
				}
				if (rs.getLong("MAX_DFEMT") != 0) {
					dto.setDefFlg(AmallConst.GeneralFlg.ON);
				}
				retList.add(dto);
			}
			// リスト返却
			return retList;

		} catch (AmallException ame) {
			m_DbAccess.rollback();
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					getItemDispName(ITEM_ID_SCREEN_NAME, m_Acech01DispBean));
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, LogType.ERROR, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	/*************************************************************************************
	 * SQL作成処理
	 * <p>
	 * 回収金実績の有無を取得するSQLを作成する
	 * </p>
	 * @param ym 表示年月
	 * @return SQL
	 ************************************************************************************/
	protected void makeSearchSql(String ym) throws AmallException {
		String methodName = "makeSearchSql()";

		// システム日付取得
		String systemDt = m_Acech01DispBean.getServiceDate();

		try {

			// SQL作成
			StringBuffer sql = new StringBuffer();
			List<String> bindParam = new ArrayList<String>();
			sql.append("SELECT");
			sql.append(" ncd.CLD AS CLD");
			sql.append(",  MIN(ncd.SPCC_DFEMT) AS MIN_DFEMT");
			sql.append(",  MAX(ncd.SPCC_DFEMT) AS MAX_DFEMT");
			sql.append(" FROM");
			sql.append("	N_CLMY_DAT ncd");
			sql.append(" LEFT JOIN");
			sql.append(" 	N_SHOP_SB_M nssm");
			sql.append(" 	ON ncd.CST_CD = nssm.CST_CD");
			sql.append(" 	AND ncd.SHOP_CD = nssm.SHOP_CD");
			sql.append(" 	AND ncd.SHOP_SBNO = nssm.SHOP_SBNO");
			sql.append(" 	AND nssm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" 	AND nssm.EFST_DY <= ?");
			bindParam.add(systemDt);
			sql.append(" 	AND ? <= nssm.EFED_DY");
			bindParam.add(systemDt);
			// WHERE句
			sql.append(" WHERE");
			sql.append(" ncd.CLD LIKE ?");
			bindParam.add(ym + "__");

			// 全店舗判定
			if (!m_Acech01DispBean.isShopCdAllFlg()) {
				// 全顧客・全店舗ではない場合
				sql.append("	AND (");
				boolean first = true;
				for (Entry<String, List<String>> entry : m_Acech01DispBean.getShopCdListMap().entrySet()) {

					String appCstCd = entry.getKey();
					for (String appShop : entry.getValue()) {
						if (first) {
							sql.append("		(");
							first = false;
						} else {
							sql.append("		OR (");
						}
						sql.append("			ncd.CST_CD = '").append(appCstCd).append("'");
						sql.append("			AND");
						sql.append("			ncd.SHOP_CD = '").append(appShop).append("'");
						sql.append("		)");
					}
				}
				sql.append("	)");
			}


			sql.append(" AND ncd.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" GROUP BY");
			sql.append(" ncd.CLD");

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < bindParam.size(); i++) {
				m_DbAccess.setString(i + 1, bindParam.get(i));
			}

			/* StringBuffer 開放  */
			sql.delete(0, sql.length());
			sql = null;

			/* List<String> 開放  */
			bindParam.clear();
			bindParam = null;

		} catch (AmallException ame) {
			m_DbAccess.rollback();
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR,
					getItemDispName(ITEM_ID_SCREEN_NAME, m_Acech01DispBean));
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

	/**********************************************************************************************
	 * ボタンフラグ設定処理
	 * <p>
	 * ボタンフラグ設定処理を行う
	 * </p>
	 * @param
	 * @return
	 *********************************************************************************************/
	public void setBtnFlg() throws AmallException {
		// methodName
		String methodName = "setBtnFlg()";
		// フラグ初期値
		String nextFlg = AmallConst.GeneralFlg.OFF;
		String prevFlg = AmallConst.GeneralFlg.OFF;

		try {

			// 現在年月取得
			String systemDt = m_Acech01DispBean.getServiceDate().substring(0, 6);
			// 3ヶ月前年月取得
			String[] rangeDate = AmallUtilities.getDateRange(systemDt);
			String threeMonthAgo = rangeDate[0].substring(0, 6);

			// 表示月判別
			if (Integer.parseInt(m_Acech01Dto.getDispDate()) < Integer.parseInt(systemDt)) {
				// 表示月が現在月より前の場合
				nextFlg = AmallConst.GeneralFlg.ON;
			}
			if (Integer.parseInt(m_Acech01Dto.getDispDate()) > Integer.parseInt(threeMonthAgo)) {
				// 表示月が3ヶ月前月より後の場合
				prevFlg = AmallConst.GeneralFlg.ON;
			}

			// フラグセット
			m_Acech01DispBean.setNextPageFlg(nextFlg);
			m_Acech01DispBean.setPrevPageFlg(prevFlg);

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, LogType.ERROR, e);
			throw ee;
		}
	}

}