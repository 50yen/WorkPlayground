/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Accsi01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.csi.business;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.csi.action.Accsi01Action;
import jp.co.hitachi.a.c.csi.bean.Accsi01DispBean;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallPage;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoChildSelectInfo;
import jp.co.hitachi.a.m.dto.AmdtoCommonInfo;
import jp.co.hitachi.a.m.dto.AmdtoPagingSql;

/*****************************************************************************************
 * Accsi01Businessクラス<br>
 *****************************************************************************************/
public class Accsi01Business extends AccsiBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Accsi01DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 顧客検索 */
	public static final String FORWARD_SEARCH = "SEARCH";
	/** 前頁 */
	private static final String FORWARD_PAGEPREV = "PAGEPREV";
	/** 先頭頁処理 */
	private static final String FORWARD_PAGEFIRST = "PAGEFIRST";
	/** 次頁 */
	private static final String FORWARD_PAGENEXT = "PAGENEXT";
	/** 最終頁 */
	private static final String FORWARD_PAGELAST = "PAGELAST";
	/** 件数変更 */
	private static final String FORWARD_DISPRESULTS = "DISPRESULTS";

	/**
	 * 画面項目ID
	 */
	/** 顧客コード */
	public static final String ITEM_ID_CST_CD = "customerCdInput";
	/** 顧客名称 */
	public static final String ITEM_ID_CST_NM = "customerNmInput";

	/** メンバ変数 */
	/** アクションフォーム */
	private Accsi01Action m_Accsi01Form = null;
	/** 表示用画面Bean */
	private Accsi01DispBean m_Accsi01DispBean = null;
	/** ページング処理用 */
	private AmallPage m_Page = null;
	/** SQL作成用 */
	private AmdtoPagingSql m_Page_Sql = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Accsi01Business(
			Accsi01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Accsi01Business.class.getName();
		m_Accsi01Form = form;
		m_Accsi01DispBean = new Accsi01DispBean();
		m_Page = new AmallPage();
		m_Page_Sql = new AmdtoPagingSql();
		setErrString(gid, m_Accsi01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Accsi01DispBean);

			// 呼び出し元親画面の顧客範囲設定
			AmdtoCommonInfo comDto = getCommonInfoDTO();
			createCustomerRange(m_Accsi01Form.getCallgid(), m_Accsi01DispBean, comDto);


			// DB接続
			m_DbAccess = new AmallDbAccess(m_Accsi01Form.getM_systemKind());
			m_DbAccess.initDB();

			// 検索結果の初期化
			m_Accsi01DispBean.setItemDispList(new ArrayList<>());

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_SEARCH.equals(m_Event)) {
				// 検索ボタン押下の場合
				forwardStr = search();
			} else if (FORWARD_PAGEFIRST.equals(m_Event)) {
				// "<<"ボタン押下の場合
				forwardStr = pageFirst();
			} else if (FORWARD_PAGEPREV.equals(m_Event)) {
				// "<"ボタン押下の場合
				forwardStr = pagePrev();
			} else if (FORWARD_PAGENEXT.equals(m_Event)) {
				// ">"ボタン押下の場合
				forwardStr = pageNext();
			} else if (FORWARD_PAGELAST.equals(m_Event)) {
				// ">>"ボタン押下の場合
				forwardStr = pageLast();
			} else if (FORWARD_DISPRESULTS.equals(m_Event)) {
				// 表示件数変更の場合
				forwardStr = changeDispRslts();
			} else {
				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {

			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Accsi01DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * 入力値が存在する場合は初期検索を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		// 引き継いだ値を取得
		String cstCd = m_Accsi01Form.getData();

		// 入力値に設定
		m_Accsi01Form.setInputCustomerCd(cstCd);
		if(AmallUtilities.isEmpty(cstCd)) {
			// 入力なしの場合
			return FORWARD_DISP;
		}
		// 入力値チェック
		if (!inputCheck(cstCd, null)) {
			// エラーの場合
			return FORWARD_DISP;
		}

		// 保存項目に設定する
		m_Accsi01Form.setSavedCustomerCd(cstCd);

		// 初期状態で検索する
		return searchProc();
	}
	/*************************************************************************************
	 * 検索ボタン押下処理実行
	 * <p>
	 * 検索ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String search() throws AmallException {

		// 顧客コード取得
		String cstCd = m_Accsi01Form.getInputCustomerCd();

		// 顧客名取得
		String cstNm = m_Accsi01Form.getInputCustomerNm();


		// 入力値チェック
		if (!inputCheck(cstCd, cstNm)) {
			// 入力なし・エラーの場合
			return FORWARD_DISP;
		}

		// 検索条件を保存する
		m_Accsi01Form.setSavedCustomerCd(cstCd);
		m_Accsi01Form.setSavedCustomerNm(cstNm);

		// 検索処理を呼ぶ
		return searchProc();
	}

	/*************************************************************************************
	 * 入力値チェック
	 * <p>
	 * 入力値チェックを実施する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @param  cstNm 顧客名
	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheck(String cstCd, String cstNm) throws AmallException {

		// 返却フラグ
		boolean ret = true;

		// 入力値チェック(顧客コード)
		if (!AmallUtilities.isEmpty(cstCd)) {
			// 入力値が存在する場合
			if (!AmallUtilities.isHalfWidthCharacterKind(cstCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Accsi01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
						getItemDispName(ITEM_ID_CST_CD, m_Accsi01DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Accsi01DispBean, ITEM_ID_CST_CD);

				ret = false;
			} else if (AmallUtilities.getLengthAsHalf(cstCd) > InputNum.CST_CD) {
				// 10桁より多い数字が設定されている
				setMessageInfo(m_Accsi01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
						getItemDispName(ITEM_ID_CST_CD, m_Accsi01DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Accsi01DispBean, ITEM_ID_CST_CD);

				ret = false;
			}
		}

		// 入力値チェック(顧客名)
		if (!AmallUtilities.isEmpty(cstNm)) {
			// 入力値が存在する場合
			if (AmallUtilities.getLengthAsHalf(cstNm) > (InputNum.CST_NM * 2)) {
				// 60文字より多い数字が設定されている
				setMessageInfo(m_Accsi01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_STR_WTN,
						getItemDispName(ITEM_ID_CST_NM, m_Accsi01DispBean), String.valueOf(InputNum.CST_NM));
				setError(m_Accsi01DispBean, ITEM_ID_CST_NM);

				ret = false;
			}
		}

		return ret;
	}

	/*************************************************************************************
	 * "<"ボタン押下処理実行
	 * <p>
	 * "<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pagePrev() throws AmallException {

		// 保存している条件を入力欄に設定する
		// 顧客コード取得
		m_Accsi01Form.setInputCustomerCd(m_Accsi01Form.getSavedCustomerCd());

		// 顧客名取得
		m_Accsi01Form.setInputCustomerNm(m_Accsi01Form.getSavedCustomerNm());

		// 検索処理を呼ぶ
		return searchProc();
	}

	/*************************************************************************************
	 * "<<"ボタン押下処理実行
	 * <p>
	 * "<<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageFirst() throws AmallException {


		// 保存している条件を入力欄に設定する
		// 顧客コード取得
		m_Accsi01Form.setInputCustomerCd(m_Accsi01Form.getSavedCustomerCd());

		// 顧客名取得
		m_Accsi01Form.setInputCustomerNm(m_Accsi01Form.getSavedCustomerNm());

		// 検索処理を呼ぶ
		return searchProc();
	}

	/*************************************************************************************
	 * ">"ボタン押下処理実行
	 * <p>
	 * ">"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageNext() throws AmallException {


		// 保存している条件を入力欄に設定する
		// 顧客コード取得
		m_Accsi01Form.setInputCustomerCd(m_Accsi01Form.getSavedCustomerCd());

		// 顧客名取得
		m_Accsi01Form.setInputCustomerNm(m_Accsi01Form.getSavedCustomerNm());

		// 検索処理を呼ぶ
		return searchProc();
	}

	/*************************************************************************************
	 * ">>"ボタン押下処理実行
	 * <p>
	 * ">>"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageLast() throws AmallException {


		// 保存している条件を入力欄に設定する
		// 顧客コード取得
		m_Accsi01Form.setInputCustomerCd(m_Accsi01Form.getSavedCustomerCd());

		// 顧客名取得
		m_Accsi01Form.setInputCustomerNm(m_Accsi01Form.getSavedCustomerNm());

		// 検索処理を呼ぶ
		return searchProc();
	}

	/*************************************************************************************
	 * 表示件数変更処理実行
	 * <p>
	 * 表示件数変更処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String changeDispRslts() throws AmallException {

		// 保存している条件を入力欄に設定する
		// 顧客コード取得
		m_Accsi01Form.setInputCustomerCd(m_Accsi01Form.getSavedCustomerCd());

		// 顧客名取得
		m_Accsi01Form.setInputCustomerNm(m_Accsi01Form.getSavedCustomerNm());

		// 検索処理を呼ぶ
		return searchProc();
	}

	/*************************************************************************************
	 * 検索処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String searchProc() throws AmallException {
		// methodName
		String methodName = "search()";
		// 明細部用LIST
		List<AmdtoChildSelectInfo> detailList = new ArrayList<>();

		// システム日付取得
		String systemDt = m_Accsi01DispBean.getServiceDate();

		// 検索条件
		// 顧客コード取得
		String cstCd = m_Accsi01Form.getInputCustomerCd();

		// 顧客名取得
		String cstNm = m_Accsi01Form.getInputCustomerNm();

		try {

			// SQL作成
			makeSearchSql(cstCd, cstNm, systemDt);

			// select句
			String sqlSelect = m_Page_Sql.getSqlSelect();
			// from where 句
			String sqlCondition = m_Page_Sql.getSqlConditinon();
			// order 句
			String sqlOrder = m_Page_Sql.getSqlOrder();
			// param 句
			String[] sqlParam = m_Page_Sql.getSqlParam();
			// 表示件数
			int pageDispCnt = m_Page_Sql.getPageDispCnt();
			// ページ番号
			int pageNo = m_Accsi01Form.getDisplayNum();

			List<Map<String, String>> pageData;
			if (m_Event.equals(FORWARD_DISP)) {
				// 初期検索状態
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEFIRST)) {
				// "<<"ボタン押下時
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEPREV)) {
				// "<"ボタン押下時
				pageData = m_Page.getPrevPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGENEXT)) {
				// ">"ボタン押下時
				pageData = m_Page.getNextPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGELAST)) {
				// ">>"ボタン押下時
				pageData = m_Page.getLastPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else {
				// 検索ボタン押下時、その他
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam,	pageDispCnt);
			}

			// 表示頁NOのセット
			m_Accsi01DispBean.setDisplayNum(m_Page.getNowPage());
			// ページ遷移ボタンセット
			if (!m_Page.isPrevPageExist()) {
				m_Accsi01DispBean.setPrevPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Accsi01DispBean.setPrevPageFlg(AmallConst.GeneralFlg.OFF);
			}
			if (!m_Page.isNextPageExist()) {
				m_Accsi01DispBean.setNextPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Accsi01DispBean.setNextPageFlg(AmallConst.GeneralFlg.OFF);
			}

			// 件数セット
			m_Accsi01DispBean.setDispCountChildDefault(String.valueOf(pageDispCnt));

			// ページ情報がない場合
			if (pageData == null) {
				// エラーメッセージをセット
				setMessageInfo(m_Accsi01DispBean, AmallMessageConst.MSG_INF_SEARCH_CON_NO_DATA);
				return FORWARD_DISP;

			}

			/** 明細部リスト作成 **/
			detailList = makeDetailList(m_Page.getNowPage(), pageData);

			// 表示Beanに一覧データをセット
			m_Accsi01DispBean.setItemDispList(detailList);

			return FORWARD_DISP;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_CST_M");
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		}
	}
	/*************************************************************************************
	 * SQL作成
	 * <p>
	 * SQLを作成する
	 * </p>
	 * @param cstCd 顧客CD
	 * @param cstNm 顧客名
	 * @param systemDt システム日付
	 * @return SQL
	 ************************************************************************************/
	private void makeSearchSql(String cstCd, String cstNm, String systemDt)
			throws AmallException, Exception {

		String methodName = "makeSearchSql()";

		StringBuffer sql = new StringBuffer();
		List<String> list = new ArrayList<>();

		try {
			// 1ページの表示件数
			// 初期表示はデフォルト値を設定する
			if (m_Event.equals(FORWARD_DISP)) {
				m_Page_Sql.setPageDispCnt(Integer.parseInt(m_Accsi01DispBean.getDispCountChildDefault()));
			} else if (m_Event.equals(FORWARD_SEARCH)) {
				// 検索ボタン押下時に表示検索がないときはデフォルト値とする
				int dispCnt = m_Accsi01Form.getDispResults();
				if (dispCnt == 0) {
					m_Page_Sql.setPageDispCnt(Integer.parseInt(m_Accsi01DispBean.getDispCountChildDefault()));
				} else {
					m_Page_Sql.setPageDispCnt(dispCnt);
				}
			} else {
				m_Page_Sql.setPageDispCnt(m_Accsi01Form.getDispResults());
			}

			// SQL SELECT
			sql.delete(0, sql.length());

			sql.append("SELECT");
			sql.append("	CST_CD");
			sql.append(",	CST_NM");
			String sqlSelect = sql.toString();


			// SQL FROM & WHERE
			sql.delete(0, sql.length());
			sql.append("  FROM");
			sql.append("	N_CST_M");
			sql.append(" WHERE");
			sql.append("	1 = 1");

			if(!AmallUtilities.isEmpty(cstCd)) {
				// 顧客コードが存在する場合
				sql.append("	AND CST_CD like ?");
				list.add(cstCd + AmallConst.SQL_LIKE_PER);
			}
			if(!AmallUtilities.isEmpty(cstNm)) {
				// 顧客名が存在する場合(部分一致)
				sql.append("	AND CST_NM like ?");
				list.add(AmallConst.SQL_LIKE_PER + cstNm + AmallConst.SQL_LIKE_PER);
			}
			sql.append("	AND DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");

			// 顧客範囲設定
			// 全顧客判定
			if (!m_Accsi01DispBean.isCustomerCdAllFlg()) {
				// 全顧客ではない場合
				sql.append("	AND CST_CD IN (");
				for (String appCustomer : m_Accsi01DispBean.getCustomerCdList()) {
					sql.append("'").append(appCustomer).append("',");
				}
				sql.append("'')");
			}

			String sqlCondition = sql.toString();


			// SQL ORDER
			sql.delete(0, sql.length());
			sql.append("  ORDER BY");
			sql.append("	CST_CD");
			String sqlOrder = sql.toString();


			// 配列変換
			String[] sqlParam = list.toArray(new String[list.size()]);


			// セット処理
			m_Page_Sql.setSqlSelect(sqlSelect);
			m_Page_Sql.setSqlConditinon(sqlCondition);
			m_Page_Sql.setSqlOrder(sqlOrder);
			m_Page_Sql.setSqlParam(sqlParam);

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}
	/*************************************************************************************
	 * 明細リスト作成処理
	 * <p>
	 * 明細リスト作成処理を実行する
	 * </p>
	 * @param  pageSize	頁数
	 * @param	pageData	頁データ
	 * @return 明細ArrayList
	 ************************************************************************************/
	private List<AmdtoChildSelectInfo> makeDetailList(int pageSize, List<Map<String, String>> pageData)
			throws AmallException {

		String methodName = "makeDetailList()";

		// 返却リスト
		List<AmdtoChildSelectInfo> retList = new ArrayList<>();

		try {
			// ページ情報をリストに追加
			for (Map<String, String> map : pageData) {

				AmdtoChildSelectInfo listdto = new AmdtoChildSelectInfo();

				// 顧客コード
				listdto.setCstCd(map.get("CST_CD"));
				// 顧客名
				listdto.setCstNm(map.get("CST_NM"));

				// 返却リストに追加
				retList.add(listdto);
			}

			return retList;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

	}
}