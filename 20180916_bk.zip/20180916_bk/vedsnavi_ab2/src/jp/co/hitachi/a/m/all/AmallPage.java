/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallPage.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */

package jp.co.hitachi.a.m.all;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.hitachi.a.m.all.AmallConst.LogType;
import jp.co.hitachi.a.m.cls.AmclsPage;

/*****************************************************************************************
 * ページ切り替え(表示件数変則用)クラス<br>
 *****************************************************************************************/
public class AmallPage extends AmclsPage {

	/*************************************************************************************
	 * 前ページ取得
	 * <p>
	 * 前ページ取得を行う
	 * </p>
	 * @param dba			DBハンドル
	 * @param sqlSelect	SQL文 Select句
	 * @param sqlCondition	SQL文 条件句(From + Where)
	 * @param sqlOrder		SQL文 Order by句
	 * @param sqlParam		SQLパラメータ
	 * @param pageNo		表示対象ページNO
	 * @param pageDispCnt	1ページの表示件数
	 * @return				取得ページデータ
	 * @throws AmallException
	 ************************************************************************************/
	public List<Map<String, String>> getPrevPage(AmallDbAccess dba,
			String sqlSelect,
			String sqlCondition,
			String sqlOrder,
			String[] sqlParam,
			int pageNo,
			int pageDispCnt) throws AmallException {
		return getPageData(dba, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo - 1, pageDispCnt);
	}

	/*************************************************************************************
	 * 後ページ取得
	 * <p>
	 * 後ページ取得を行う
	 * </p>
	 * @param dba			DBハンドル
	 * @param sqlSelect	SQL文 Select句
	 * @param sqlCondition	SQL文 条件句(From + Where)
	 * @param sqlOrder		SQL文 Order by句
	 * @param sqlParam		SQLパラメータ
	 * @param pageNo		表示対象ページNO
	 * @param pageDispCnt	1ページの表示件数
	 * @return				取得ページデータ
	 * @throws AmallException
	 ************************************************************************************/
	public List<Map<String, String>>  getNextPage(AmallDbAccess dba,
			String sqlSelect,
			String sqlCondition,
			String sqlOrder,
			String[] sqlParam,
			int pageNo,
			int pageDispCnt) throws AmallException {
		return getPageData(dba, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo + 1, pageDispCnt);
	}

	/*************************************************************************************
	 * 先頭ページ取得
	 * <p>
	 * 先頭ページ取得を行う
	 * </p>
	 * @param dba			DBハンドル
	 * @param sqlSelect	SQL文 Select句
	 * @param sqlCondition	SQL文 条件句(From + Where)
	 * @param sqlOrder		SQL文 Order by句
	 * @param sqlParam		SQLパラメータ
	 * @param pageDispCnt	1ページの表示件数
	 * @return				取得ページデータ
	 * @throws AmallException
	 ************************************************************************************/
	public List<Map<String, String>>  getFirstPage(AmallDbAccess dba,
			String sqlSelect,
			String sqlCondition,
			String sqlOrder,
			String[] sqlParam,
			int pageDispCnt) throws AmallException {
		return getPageData(dba, sqlSelect, sqlCondition, sqlOrder, sqlParam, MIN_PAGE, pageDispCnt);
	}

	/*************************************************************************************
	 *　最終ページ取得
	 * <p>
	 *　最終ページ取得を行う
	 *　</p>
	 * @param dba			DBハンドル
	 * @param sqlSelect	SQL文 Select句
	 * @param sqlCondition	SQL文 条件句(From + Where)
	 * @param sqlOrder		SQL文 Order by句
	 * @param sqlParam		SQLパラメータ
	 * @param pageDispCnt	1ページの表示件数
	 * @return				取得ページデータ
	 * @throws AmallException
	 ************************************************************************************/
	public List<Map<String, String>>  getLastPage(AmallDbAccess dba,
			String sqlSelect,
			String sqlCondition,
			String sqlOrder,
			String[] sqlParam,
			int pageDispCnt) throws AmallException {
		return getPageData(dba, sqlSelect, sqlCondition, sqlOrder, sqlParam, MAX_PAGE, pageDispCnt);
	}

	/*************************************************************************************
	 * 最大ページ数取得
	 * <p>
	 *　最大ページ数取得を行う(最大ページ数表示用)
	 *　</p>
	 * @param dba			DBハンドル
	 * @param sqlCondition	SQL文 条件句(From + Where)
	 * @param sqlParam		SQLパラメータ
	 * @param pageLine		1ページ中の表示行数
	 * @return				最大ページ数
	 * @throws AmallException
	 ************************************************************************************/
	private int getMaxPage(AmallDbAccess dba,
			String sqlCondition,
			String[] sqlParam,
			int pageDispCnt) throws AmallException {
		String methodName = "getMaxPage()";

		// 取得結果
		ResultSet rs = null;

		try {

			// 最大行数
			int lineMaxCount = 0;
			// 最大ページ
			int maxPage = 0;

			// COUNT文作成
			String sql = "SELECT COUNT(*) " + sqlCondition;

			// DBアクセサ生成
			dba.createPreparedStatementPaging(sql);

			// SQLパラメータクリア
			dba.parameterClear();
			// 検索条件指定
			if(sqlParam != null) {
				for (int i = 0; i < sqlParam.length; i++) {
					dba.setString(i + 1, sqlParam[i]);
				}
			}

			// SQL実行
			rs = dba.executeQuery(); //検索
			// 取得結果判定
			if (rs.next()) {
				// データ存在
				lineMaxCount = rs.getInt(1);
			} else {
				lineMaxCount = 0;
			}
			// 最大行数からページ数を算出
			maxPage = (int) lineMaxCount / pageDispCnt;
			int remain = lineMaxCount % pageDispCnt;
			if (remain > 0) {
				// 余りが存在する場合は+1ページ
				maxPage++;
			}
			// 最大ページ数を返却
			return maxPage;
		} catch (AmallException ame) {

			throw ame;

		} catch (SQLException e) {

			AmallException ee = new AmallException();
			ee.addException(dba.getClassName(), methodName, LogType.ERROR, e);
			throw ee;

		} finally {
			if (rs != null) {

				try {
					// クローズ
					rs.close();
					rs = null;
				} catch (SQLException e) {
					AmallException ee = new AmallException();
					ee.addException(dba.getClassName(), methodName, LogType.ERROR, e);
					throw ee;
				}
			}
		}
	}

	/*************************************************************************************
	 * 指定ページ取得
	 * <p>
	 *　指定ページ取得を行う
	 *　</p>
	 * @param dba			DBハンドル
	 * @param sqlSelect	SQL文 Select句
	 * @param sqlCondition	SQL文 条件句(From + Where)
	 * @param sqlOrder		SQL文 Order by句
	 * @param sqlParam		SQLパラメータ
	 * @param pageNo		表示対象ページNO
	 * @param pageDispCnt	1ページの表示件数
	 * @return				取得ページデータ
	 * @throws AmallException
	 ************************************************************************************/
	public List<Map<String, String>> getPageData(AmallDbAccess dba,
			String sqlSelect,
			String sqlCondition,
			String sqlOrder,
			String[] sqlParam,
			int pageNo,
			int pageDispCnt) throws AmallException {
		// メソッド名
		String methodName = "getPageData()";

		// 返却リスト
		List<Map<String, String>> retList = new ArrayList<>();
		// リザルトセット
		ResultSet rs = null;

		// 引数チェック
		if (dba == null || pageNo <= 0 || pageDispCnt <= 0 ||
				sqlSelect == null || sqlSelect.length() < 0 ||
				sqlCondition == null || sqlCondition.length() < 0) {
			return null;
		}

		// ページ状態初期化
		setPrevPageExist(false); // 前ページ存在なし
		setNextPageExist(false); // 次ページ存在なし

		try {

			// 最大ページ取得
			this.maxPage = getMaxPage(dba, sqlCondition, sqlParam, pageDispCnt);

			// ページ存在判定
			if (this.maxPage <= 0) {
				// 存在しない場合は返却
				return null;
			}

			// 表示対象ページのチェック
			if (pageNo < MIN_PAGE) {
				// 1ページ目を指定
				pageNo = MIN_PAGE;
			}
			if (pageNo > this.maxPage) {
				// 最大ページを指定
				pageNo = this.maxPage;
			}

			// 表示対象ページから行数を算出
			// 開始行 0～
			int startRow = pageDispCnt * (pageNo - 1);
			// 終了行
			int endRow = pageDispCnt * pageNo;

			// SQL文生成
			StringBuffer sbf = new StringBuffer();
			sbf.append("SELECT *");
			sbf.append("  FROM (");
			sbf.append(" 		SELECT");
			sbf.append("			PLAIN.*, ROWNUM AS RN");
			sbf.append("		  FROM (");
			sbf.append(" ");
			sbf.append(sqlSelect);
			sbf.append(" ");
			sbf.append(sqlCondition);
			sbf.append(" ");
			sbf.append(sqlOrder);
			sbf.append("		) PLAIN");
			sbf.append("	) EXT");
			sbf.append(" WHERE EXT.RN > " + startRow);
			sbf.append("   AND EXT.RN <= " + endRow);

			// SQL文設定
			dba.createPreparedStatement(sbf.toString());
			// SQLパラメータクリア
			dba.parameterClear();
			// 検索条件指定
			if (sqlParam != null) {
				for (int i = 0; i < sqlParam.length; i++) {
					dba.setString(i + 1, sqlParam[i]);
				}
			}

			// SQL実行
			rs = dba.executeQuery();

			// 実行結果チェック
			ResultSetMetaData metaData = null;
			int maxCol = 0;
			while (rs.next()) {
				//検索正常の時
				if (metaData == null) {
					// メタデータの取得
					metaData = rs.getMetaData();
					maxCol = metaData.getColumnCount();
				}
				Map<String, String> field = new ConcurrentHashMap<String, String>();
				for (int i = 1; i <= maxCol; i++) {//カラム数分ループ
					//フィールドデータ取得
					field.put(metaData.getColumnName(i), dba.getString(rs, metaData.getColumnName(i)));
				}
				//1レコード追加
				retList.add(field);
			}
			//
			if(retList.size() > 0) {
				// 現在ページを設定
				this.nowPage = pageNo;
				// 前後ページの判定
				if(pageNo == MIN_PAGE) {
					setPrevPageExist(false); // 前ページ存在なし
				} else {
					setPrevPageExist(true); // 前ページ存在あり
				}
				if(pageNo == this.maxPage) {
					setNextPageExist(false); // 次ページ存在なし
				} else {
					setNextPageExist(true); // 次ページ存在あり
				}
			}
			return retList;

		} catch (AmallException ame) {

			throw ame;

		} catch (SQLException e) {

			AmallException ee = new AmallException();
			ee.addException(dba.getClassName(), methodName, LogType.ERROR, e);
			throw ee;

		} finally {
			if (rs != null) {

				try {
					// クローズ
					rs.close();
					rs = null;
				} catch (SQLException e) {
					AmallException ee = new AmallException();
					ee.addException(dba.getClassName(), methodName, LogType.ERROR, e);
					throw ee;
				}
			}
		}
	}

}
