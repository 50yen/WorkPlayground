package org.apache.struts2.views.jsp.ui;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;

/*    */ import org.apache.struts2.components.Component;
/*    */ import org.apache.struts2.components.TextField;

/*    */ import com.opensymphony.xwork2.util.ValueStack;
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */
/*    */ public class TextFieldTag extends AbstractUITag_Owd {
/*    */    private static final long serialVersionUID = 5811285953670562288L;
/*    */    protected String maxlength;
/*    */    protected String readonly;
/*    */    protected String size;
/*    */    protected String type;
/*    */    protected String owdbtnid;
/*    */    protected String btnCssClass;
/*    */    protected String col;
/*    */    protected String owdname;
/*    */
/*    */    public Component getBean(ValueStack stack, HttpServletRequest req, HttpServletResponse res) {
/* 44 */       return new TextField(stack, req, res);
/*    */    }
/*    */
/*    */    protected void populateParams() {
/* 48 */       super.populateParams();
/*    */
/* 50 */       TextField textField = (TextField)this.component;
/* 51 */       textField.setMaxlength(this.maxlength);
/* 52 */       textField.setReadonly(this.readonly);
/* 53 */       textField.setSize(this.size);
/* 54 */       textField.setType(this.type);
/* 54 */       textField.setOwdbtnid(this.owdbtnid);
/* 54 */       textField.setBtnCssClass(this.btnCssClass);
/* 54 */       textField.setCol(this.col);
/*  98 */      textField.setOwdname(this.owdname);
/* 55 */    }
/*    */
/*    */    public void setMaxlength(String maxlength) {
/* 58 */       this.maxlength = maxlength;
/* 59 */    }
/*    */
/*    */    public void setReadonly(String readonly) {
/* 62 */       this.readonly = readonly;
/* 63 */    }
/*    */
/*    */    public void setSize(String size) {
/* 66 */       this.size = size;
/* 67 */    }
/*    */
/*    */    public void setType(String type) {
/* 70 */       this.type = type;
/* 71 */    }
/*    */    public void setOwdbtnid(String owdbtnid) {
/* 70 */       this.owdbtnid = owdbtnid;
/* 71 */    }
/*    */    public void setBtnCssClass(String btnCssClass) {
/* 70 */       this.btnCssClass = btnCssClass;
/* 71 */    }
/*    */    public void setCol(String col) {
/* 70 */       this.col = col;
/* 71 */    }
/*     */   public void setOwdname(String owdname) {
/* 185 */      this.owdname = owdname;
/* 186 */   }
/*    */ }

/*
	DECOMPILATION REPORT

	Decompiled from:
	Total time: 98 ms

	Decompiled with FernFlower.
*/