package org.apache.struts2.components;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.views.annotations.StrutsTagAttribute;

import com.opensymphony.xwork2.util.ValueStack;

public abstract class UIBean_Owd extends UIBean {
	protected String owdid;
	protected Object owdrole;
	protected Map<String, Map<String, String>> owdMap = new ConcurrentHashMap<>();

	public UIBean_Owd(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
		super(stack, request, response);
	}

	protected String getDefaultTemplate() {
		return "owd";
	}

	protected void evaluateExtraParams() {
		super.evaluateExtraParams();

		// == owdidの取得 ==
		if (this.owdid != null) {
			this.addParameter("owdid", this.findString(this.owdid));
		}

		// == owdroleの取得 ==
		Object value = null;

		if (owdrole == null) {
			// owdroleの属性値を取得(値変換前)
			owdrole = parameters.get("owdrole");
		}

		if (owdrole instanceof String) {
			// 値変換を実施
			value = findValue((String) owdrole);
		}

		// 値変換がnullとなった場合
		if (value == null) {
			// 属性値をそのまま文字列設定
			value = findValue((owdrole == null) ? (String) owdrole : owdrole.toString());
		}

		// owdroleがMap型の時のみ実施
		if (value instanceof Map) {
			// 想定内のMap型かチェックする
			// 判定フラグ
			boolean chkFlg = false;

			// Map<String , Map<String, String>>のvalue部の取得
			@SuppressWarnings("unchecked")
			Map<Object, Object> tmpMap = (Map<Object, Object>)value;

			// 取得値判定
			if (tmpMap != null && tmpMap.size() > 0) {

				// Mapデータ取得
				for (Object key : tmpMap.keySet()) {

					// value値取得
					Object chkObj = tmpMap.get(key);

					// value部の方がMap型か判定
					if (chkObj instanceof Map) {
						chkFlg = true;
						break;
					}
				}

			}
			if (chkFlg) {
				// Map<String , Map<String, String>>の場合のみ取得
				addParameter("owdMap", value);
			}

		}

	}

	@StrutsTagAttribute(description = "The actual HTML value attribute of the checkbox.")
	public void setOwdid(String owdid) {
		this.owdid = owdid;
	}

	@StrutsTagAttribute(description = "Iterable source to populate from. If this is missing, the select widget is simply not displayed.", required = true)
	public void setOwdrole(Object owdrole) {
		this.owdrole = owdrole;
	}

	@StrutsTagAttribute(description = "Property of list objects to get title from")
	public void setOwdMap(Map<String, Map<String, String>> owdMap) {
		this.owdMap = owdMap;
	}


}
