/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) abiam02.js
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
/****************************************************************
 * @name 表示プルダウン切り替え時処理
 *
 * @description
 * 表示プルダウンを切り替えた時、「非表示」の場合に編集プルダウンを非活性にする
 * OnLoadに設定
 *
 * @return なし
 ****************************************************************/
function changeDispDropDown() {
	// 対象クラスのOnchangeイベントを監視
	$('.dispOnOff').change(function() {
		var dispVal = $(this).val();
		var dispId = $(this).attr('id');
		var objId = dispId + "edit";

		if(dispVal == "0"){
			$("#" + objId).prop('disabled', true);
			$("#" + objId).addClass('disable');
		} else {
			$("#" + objId).prop('disabled', false);
			$("#" + objId).removeClass('disable');
		}
	});
}
/****************************************************************
 * @name 表示プルダウン初期表示処理
 *
 * @description
 * 初期表示時に表示プルダウンが「非表示」の場合に編集プルダウンを非活性にする
 * OnLoadに設定
 *
 * @return なし
 ****************************************************************/
function dispFunc (){

	// 対象クラスのJQueryオブジェクトを取得
	var $dispObj = $('.dispOnOff');

	$dispObj.each(function(index, element){
		var dispVal = $(element).val();

		var dispId = $(element).attr('id');
		var objId = dispId + "edit";

		if(dispVal == "0"){
			$("#" + objId).prop('disabled', true);
			$("#" + objId).addClass('disable');
		} else {
			$("#" + objId).prop('disabled', false);
			$("#" + objId).removeClass('disable');
		}
	});
}
/****************************************************************
 * @name OnLoad処理
 *
 * @description
 * OnLoad処理を以下に記載する
 *
 * @param なし
 * @return なし
 ****************************************************************/
$(function () {

	// 初期プルダウン状態の判定
	dispFunc();

	// Onchangeイベント監視
	changeDispDropDown();

	// 画面項目変更検知
	discoverChangeForm();
});
