/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) aceum01.js
 *
 * ----------------------------------------------------
 * 2018.08.21 新規作成
 * ----------------------------------------------------
 */

/****************************************************************
 * @name ページ遷移
 *
 * @description
 * ユーザー詳細画面遷移を行う
 *
 * @param formName フォームID
 * @param action アクション名
 * @param userId	ユーザーID
 * @param systemKind	システム種別
 * @return なし
 ****************************************************************/
function selectLine(formName, action, userId, systemKind)
{
	$('#transUserId').val(userId);
	$('#transSystemKind').val(systemKind);
	amallSubmit(formName, action);
}