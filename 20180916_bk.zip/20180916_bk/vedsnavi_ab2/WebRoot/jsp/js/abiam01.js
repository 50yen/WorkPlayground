/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) abiam01.js
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
/****************************************************************
 * @name カテゴリプルダウン切り替え時処理
 *
 * @description
 * カテゴリプルダウンを切り替えた時、メニュー・画面プルダウンを切り替える
 * OnLoadに設定
 *
 * @return なし
 ****************************************************************/
function categoryDropDownChange(){
	// 要素取得
	// メニューのプルダウンリストのObject
	var $menu = $('.middle');
	// 最大状態の退避
	var originalMenu = $menu.html();
	// 画面のプルダウンリストのObject
	var $screen = $('.small');
	// 最大状態の退避
	var originalScreen = $screen.html();

	//カテゴリ側のselect要素が変更になるとイベントが発生
	$('.large').change(function() {

		//選択されたカテゴリのvalueを取得し変数に入れる
		var val1 = $(this).val();

		//削除された要素をもとに戻すため.html(original)を入れておく
		$menu.html(originalMenu).find('option').each(function() {
			 //data-valの値を取得
			var val2 = $(this).data('val');

			//valueと異なるdata-valを持つ要素を削除
			if (val1 != val2) {
				$(this).not(':first-child').remove();
			}
		});

		//削除された要素をもとに戻すため.html(original)を入れておく
		$screen.html(originalScreen).find('option').each(function() {
			// data-valを持つ要素を削除
			$(this).not(':first-child').remove();
		});
	});
}

/****************************************************************
 * @name メニュープルダウン切り替え時処理
 *
 * @description
 * メニュープルダウンを切り替えた時、メニュープルダウンを切り替える
 * OnLoadに設定
 *
 * @return なし
 ****************************************************************/
function menuDropDownChange(){
	// 要素取得
	// 画面のプルダウンリストのObject
	var $screen = $('.small');
	// 最大状態の退避
	var originalScreen = $screen.html();

	$('.middle').change(function() {

		// 選択されたメニューのvalueを取得し変数に入れる
		var val1 = $(this).val();

		// 削除された要素をもとに戻すため.html(original)を入れておく
		$screen.html(originalScreen).find('option').each(function() {
			//data-valの値を取得
			var val2 = $(this).data('val');

			//valueと異なるdata-valを持つ要素を削除
			if (val1 != val2) {
				$(this).not(':first-child').remove();
			}

		});
	});
}
/****************************************************************
 * @name プルダウン初期化処理
 *
 * @description
 * プルダウンの初期化処理を行う
 * OnLoadに設定
 *
 * @return なし
 ****************************************************************/
function initDropDown(){
	// 要素取得
	// メニューのプルダウンリストのObject
	var $menu = $('.middle');
	// 最大状態の退避
	var originalMenu = $menu.html();
	// 画面のプルダウンリストのObject
	var $screen = $('.small');
	// 最大状態の退避
	var originalScreen = $screen.html();


	//カテゴリのvalueを取得し変数に入れる
	var large = $('.large').val();

	//削除された要素をもとに戻すため.html(original)を入れておく
	$menu.html(originalMenu).find('option').each(function() {
		 //data-valの値を取得
		var val2 = $(this).data('val');

		// valueと異なるdata-valを持つ要素を削除
		if (large != val2) {
			$(this).not(':first-child').remove();
		}
	});

	//カテゴリのvalueを取得し変数に入れる
	var middle = $('.middle').val();

	//削除された要素をもとに戻すため.html(original)を入れておく
	$screen.html(originalScreen).find('option').each(function() {
		 //data-valの値を取得
		var val2 = $(this).data('val');

		// valueと異なるdata-valを持つ要素を削除
		if (middle != val2) {
			$(this).not(':first-child').remove();
		}
	});
}
/****************************************************************
 * @name OnLoad処理
 *
 * @description
 * OnLoad処理を以下に記載する
 *
 * @param なし
 * @return なし
 ****************************************************************/
$(function () {

	// カテゴリプルダウン監視処理
	categoryDropDownChange();

	// メニュープルダウン監視処理
	menuDropDownChange();

	// プルダウンの初期化処理
	initDropDown();

	// 画面項目変更検知
	discoverChangeForm();

});
