/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) acssi01.js
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
/****************************************************************
 * @name 検索エリア自動設定処理
 *
 * @description
 * 自動で検索エリアの高さを設定する
 * OnLoadに設定
 *
 * @param formName サブミット対象Form名
 * @param action サブミットアクション名
 * @return なし
 ****************************************************************/
// Gridサイズ調整処理
function gridRezize(){
	// ボタンエリアの位置
	var btnAreaPos = $('#childrenBtnAreaId').offset();
	if(btnAreaPos === undefined){
		return;
	}
	// テーブルエリアの位置
	var tableAreaPos = $('#childrenTableAreaId').offset();
	if(tableAreaPos === undefined){
		return;
	}

	// テーブルの高さ
	var tableHeight = btnAreaPos.top - tableAreaPos.top;

	// 対象のCSSを書き換え
	$('.table-children-area').css('height',tableHeight);

}
/****************************************************************
 * @name OnLoad処理
 *
 * @description
 * OnLoad処理を以下に記載する
 *
 * @param なし
 * @return なし
 ****************************************************************/
$(function () {
	// 検索条件エリア変更時イベント処理
	$("#searchform").exResize(function() {
		gridRezize();
	});
	// 初期表示設定
	gridRezize();
});
