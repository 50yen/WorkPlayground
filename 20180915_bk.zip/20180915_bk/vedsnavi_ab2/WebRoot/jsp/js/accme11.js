/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) accme11.js
 *
 * ----------------------------------------------------
 * 2018.08.21 新規作成
 * ----------------------------------------------------
 */
/*******************************************************************************
 * @name 枚数入力処理
 *
 * @description 枚数が入力された（変更された）際の処理を以下に記載する
 *
 * @param なし
 * @return なし
 ******************************************************************************/
function categoryDropDownChange() {
	$('.inputPiece').on('change', function() {

		// 入力値
		var val = $(this).val();

		// 個別金額計算
		var id = $(this).attr("id");
		var prefix = id.replace('dispMoneyNum', '');

		// 金種ID取得
		var denomiId = 'denomi' + prefix;
		// 金種取得
		var denomiData = Number($('#' + denomiId).val());
		// 枚数hidden値セット
		var moneyNumId = 'moneyNum' + prefix;
		$('#' + moneyNumId).val(val);

		// 入力値数値判断
		var result = $.isNumeric(val);
		if (!result) {
			// エラーの場合リターン
			return;
		}
		;

		// 計算
		var total = denomiData * val;
		// 表示用金額
		var dispMoneyTotal = 'dispMoneyTotal' + prefix;
		$('#' + dispMoneyTotal).html(total.toLocaleString() + "円");
		// 金額（hidden）
		var moneyTotal = 'moneyTotal' + prefix;
		$('#' + moneyTotal).val(total);

		// 合計金額計算
		var allTotal = 0;
		$('.moneyTotal').each(function(index, elm) {
			allTotal = allTotal + Number($(elm).val());
		});
		// 表示用合計金額
		$('#dispAutoSpccmt').html(allTotal.toLocaleString() + "円");

		// 比較用合計金額hidden値
		$('#autoSpccmt').val(allTotal);
	});
}
/*******************************************************************************
 * @name クリア処理
 *
 * @description クリアボタン押下時の処理を以下に記載する
 *
 * @param なし
 * @return なし
 ******************************************************************************/
function inputClear() {
	$("#clearBtn").click(function() {
		// 入力
		$(".inputPiece").val("");
		$("#dispSpccmt").val("");
		$(".hiddenNumberNum").val("");

		// 自動計算
		$(".dispMoneyTotal").html("0円");
		$(".moneyTotal").val("0");
		$('#dispAutoSpccmt').html("0円");
	});
}

/*******************************************************************************
 * @name OnLoad処理
 *
 * @description OnLoad処理を以下に記載する
 *
 * @param なし
 * @return なし
 ******************************************************************************/
$(function() {

	// 枚数変更監視処理
	categoryDropDownChange();

	// 入力項目の初期化処理
	inputClear();

	// 画面項目変更検知
	discoverChangeForm("Mapw003");

});