/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) acech31.js
 *
 * ----------------------------------------------------
 * 2018.08.21 新規作成
 * ----------------------------------------------------
 */

/****************************************************************
 * @name ページ遷移
 *
 * @description
 * レジ別詳細画面遷移を行う
 *
 * @param beanName
 * @param shopSbno	選択行の店舗枝番
 * @param dispShopSbno	選択行の表示されている店舗枝番
 * @param action
 * @return なし
 * @author Hitachi Document
 ****************************************************************/
function selectLine(beanName, shopSbno, dispShopSbno, action)
{
	document.forms[beanName].shopSbno.value = shopSbno;
	document.forms[beanName].dispShopSbno.value = dispShopSbno;
	amallSubmit(beanName, action);
}