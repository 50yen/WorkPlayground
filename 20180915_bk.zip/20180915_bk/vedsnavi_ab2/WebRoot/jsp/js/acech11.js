/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) acech11.js
 *
 * ----------------------------------------------------
 * 2018.08.21 新規作成
 * ----------------------------------------------------
 */

/****************************************************************
 * @name ページ遷移
 *
 * @description
 * レジ別詳細画面遷移を行う
 *
 * @param beanName
 * @param cld	回収日
 * @param cstCd	お客様コード
 * @param shopCd	店舗コード
 * @param action
 * @return なし
 * @author Hitachi Document
 ****************************************************************/
function selectLine(beanName, cld, cstCd, shopCd, action)
{
	document.forms[beanName].de_cld.value = cld;
	document.forms[beanName].de_cstCd.value = cstCd;
	document.forms[beanName].de_shopCd.value = shopCd;
	amallSubmit(beanName, action);
}