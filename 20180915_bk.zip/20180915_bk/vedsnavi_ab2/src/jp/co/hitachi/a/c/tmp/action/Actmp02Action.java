/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Actmp02Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.tmp.action;

import java.io.File;

import jp.co.hitachi.a.c.tmp.bean.Actmp02DispBean;
import jp.co.hitachi.a.c.tmp.business.Actmp02Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Actmp02Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Actmp02DispBean actmp02DispBean;

	/** TEMP01 */
	private String temp01 = null;
	/** TEMP02 */
	private String temp02 = null;
	/** TEMP03 */
	private String temp03 = null;
	/** プルダウンリスト選択値 */
	private String value1 = null;
	/** プルダウンリスト選択値 */
	private String value2 = null;
	/** プルダウンリスト選択値 */
	private String value3 = null;
	/** プルダウンリスト選択値 */
	private String value4 = null;
	/** プルダウンリスト選択値 */
	private String value5 = null;
	/** プルダウンリスト選択値 */
	private String kokyaku = null;

	/** アップロードファイル受信用 */
	private File upLoadFile = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setActmp02DispBean((Actmp02DispBean)request.getAttribute("Actmp02DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Actmp02Business dao = new Actmp02Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Actmp02DispBean getActmp02DispBean() {
		return actmp02DispBean;
	}

	public void setActmp02DispBean(Actmp02DispBean actmp02DispBean) {
		this.actmp02DispBean = actmp02DispBean;
	}

	public String getTemp01() {
		return temp01;
	}

	public void setTemp01(String temp01) {
		this.temp01 = temp01;
	}

	public String getTemp02() {
		return temp02;
	}

	public void setTemp02(String temp02) {
		this.temp02 = temp02;
	}

	public String getValue1() {
		return value1;
	}

	public void setValue1(String value1) {
		this.value1 = value1;
	}

	public String getValue2() {
		return value2;
	}

	public void setValue2(String value2) {
		this.value2 = value2;
	}

	public String getValue3() {
		return value3;
	}

	public void setValue3(String value3) {
		this.value3 = value3;
	}

	public String getValue4() {
		return value4;
	}

	public void setValue4(String value4) {
		this.value4 = value4;
	}

	public String getValue5() {
		return value5;
	}

	public void setValue5(String value5) {
		this.value5 = value5;
	}

	public File getUpLoadFile() {
		return upLoadFile;
	}

	public void setUpLoadFile(File upLoadFile) {
		this.upLoadFile = upLoadFile;
	}

	public String getTemp03() {
		return temp03;
	}

	public void setTemp03(String temp03) {
		this.temp03 = temp03;
	}

	public String getKokyaku() {
		return kokyaku;
	}

	public void setKokyaku(String kokyaku) {
		this.kokyaku = kokyaku;
	}



}
