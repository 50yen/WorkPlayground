/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallExceptionInfo.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

/*****************************************************************************************
 * 例外情報クラス<br>
 *****************************************************************************************/
public final class AmallExceptionInfo implements java.io.Serializable {

	/** 発生した例外             	*/
	private String exception = null;
	/** 例外が発生したクラス名称     */
	private String className = null;
	/** 例外が発生したメソッド名称   */
	private String methodName = null;
	/** メッセージID             	*/
	private String messageID = null;
	/** メッセージ内容           	*/
	private String message = null;
	/** メッセージ種別           	*/
	private String massageKind = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmallExceptionInfo() {
		clear();
	}

	/*************************************************************************************
	 * クリア
	 * <p>
	 * クリア処理を行う
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		this.exception = null;
		this.className = null;
		this.methodName = null;
		this.messageID = null;
		this.message = null;
		this.massageKind = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public String getMessageID() {
		return messageID;
	}

	public void setMessageID(String messageID) {
		this.messageID = messageID;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMassageKind() {
		return massageKind;
	}

	public void setMassageKind(String massageKind) {
		this.massageKind = massageKind;
	}

}
