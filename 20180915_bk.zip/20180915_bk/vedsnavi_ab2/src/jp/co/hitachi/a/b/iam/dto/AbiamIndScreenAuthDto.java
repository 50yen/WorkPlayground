/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AbiamIndScreenAuthDto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * AbiamIndScreenAuthDtoクラス<br>
 *****************************************************************************************/
public class AbiamIndScreenAuthDto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 画面ID */
	private String screenId = null;
	/** カテゴリ名 */
	private String categoryName = null;
	/** メニュー名 */
	private String menuName = null;
	/** 画面名 */
	private String screenName = null;
	/** 表示 */
	private String dispCd = null;
	/** 画面個別権限Id */
	private Long scrIndAtuhId = null;
	/** 排他キー */
	private Long exclusiveKey = null;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public AbiamIndScreenAuthDto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		screenId = null;
		categoryName = null;
		menuName = null;
		screenName = null;
		dispCd = null;
		scrIndAtuhId = null;
		exclusiveKey = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getScreenId() {
		return screenId;
	}
	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public String getScreenName() {
		return screenName;
	}
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	public String getDispCd() {
		return dispCd;
	}
	public void setDispCd(String dispCd) {
		this.dispCd = dispCd;
	}
	public Long getScrIndAtuhId() {
		return scrIndAtuhId;
	}
	public void setScrIndAtuhId(Long scrIndAtuhId) {
		this.scrIndAtuhId = scrIndAtuhId;
	}
	public Long getExclusiveKey() {
		return exclusiveKey;
	}
	public void setExclusiveKey(Long exclusiveKey) {
		this.exclusiveKey = exclusiveKey;
	}

}
