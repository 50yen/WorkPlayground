/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallLoginControl.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.co.hitachi.a.c.log.business.Aclog01Business;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallConst.LoginFlg;
import jp.co.hitachi.a.m.all.AmallConst.SystemType;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;
import jp.co.hitachi.a.m.dto.AmdtoLoginInfo;

/*****************************************************************************************
 * ログイン制御クラス<br>
 *****************************************************************************************/
public class AmallLoginControl {

	/** メンバ定数 */
	/** 結果ステータス */
	// 正常
	public static final int NORMAL = 0;
	// 異常
	public static final int ERROR = 1;
	// パスワード変更要
	public static final int CHANGE = 2;
	// 楽観的排他エラー
	public static final int OPT_ERROR = 3;

	/** メンバ変数 */
	/** 結果ステータス */
	private int status = NORMAL;

	/** ログイン情報DTO */
	private AmdtoLoginInfo loginInfoDto = null;

	/** エラーメッセージ */
	private List<String> errMessage = null;

	/** エラー対象フォームID */
	private List<String> errFormIdList = null;

	/** クラス名 */
	private String m_ClassName = null;

	/** ユーザーID */
	private String m_UserId = null;

	/** パスワード */
	private String m_Password = null;

	/** ユーザーIDフォームID */
	private String m_UidFormId = null;

	/** パスワードフォームID */
	private String m_PwdFormId = null;

	/** システム種別 */
	private int m_Systemkind = SystemType.CUSTOMER;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param userId ユーザーIDの値
	 * @param password パスワードの値
	 * @param uidFormId ログインIDのフォームにおけるID
	 * @param pwdFormId パスワードのフォームにおけるID
	 * @param systemkind システム種別
	 * @return 無し
	 ************************************************************************************/
	public AmallLoginControl(String userId, String password, String uidFormId, String pwdFormId, int systemkind) {

		// クラス名
		m_ClassName = Aclog01Business.class.getName();

		m_UserId = userId;
		m_Password = password;
		m_UidFormId = uidFormId;
		m_PwdFormId = pwdFormId;
		m_Systemkind = systemkind;

		status = NORMAL;
		loginInfoDto = new AmdtoLoginInfo();
		errMessage = new ArrayList<>();
		errFormIdList = new ArrayList<>();
		;

	}

	/*************************************************************************************
	 * ログイン処理実行
	 * <p>
	 * ログイン処理を行う
	 * </p>
	 * @param db DBアクセサインスタンス
	 * @return なし
	 ************************************************************************************/
	public void exec(AmallDbAccess db) throws AmallException {

		String methodName = "exec()";

		try {

			// 入力値のチェック
			if (!checkInput()) {
				return;
			}

			// ログイン情報取得
			loginInfoDto = getLoginInfoDB(db, m_UserId, m_Systemkind);
			if (loginInfoDto == null) {
				// ログイン情報が取得できない場合
				errMessage.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_LOGIN_COLLECT));
				errFormIdList.add(m_UidFormId);
				errFormIdList.add(m_PwdFormId);
				status = ERROR;
				return;
			}

			// パスワード復帰時間を取得
			AmdtoGeneralMst retPassDto = AmallUtilities.getGeneralMstDataRecord(db, GeneralMstKey.PASWORD_LOCK_RETURN,
					null, null, null);
			// 分表記
			Long retPassData = retPassDto.getNo1();
			// ミリ秒表記
			Long retMilliPass = retPassDto.getNo2();

			// 現在時刻を取得
			Date nowDate = new Date();

			// パスワードの一致チェック
			if (AmallPasswordControl.isSafetyPasswordMatch(m_Password, loginInfoDto.getM_Password(), m_UserId)) {
				// 一致する場合
				// アカウントロックチェック
				if (LoginFlg.LOCK_OUT.equals(loginInfoDto.getM_AccountLock())) {
					errMessage.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_LOGIN_LOCK_OUT));
					status = ERROR;
					return;
				}

				// パスワードロックチェック
				if (LoginFlg.LOCK_OUT.equals(loginInfoDto.getM_LoginLock())) {

					// 復帰時間をチェック
					Date loginLockTime = loginInfoDto.getM_LoginLock_Time();
					if (loginLockTime != null) {

						// ミリ秒で差分を算出
						Long diffTime = nowDate.getTime() - loginLockTime.getTime();

						// 復帰時間を超えていない場合
						if (diffTime < retMilliPass) {
							errMessage.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_PASSWORD_MISS_LOCK_OUT,
									retPassData.toString()));
							status = ERROR;
							return;
						}
					} else {
						// 復帰時間が取得できない場合
						// エラー処理を行う。
						AmallException ee = new AmallException();
						throw ee;
					}

				}

				// 仮パスワードフラグチェック
				if (LoginFlg.PRE_PASS.equals(loginInfoDto.getM_Password_Flg())) {
					status = CHANGE;
					// ログイン情報更新(最終ログイン日時)
					updateLoginManagerData(db, 0);
					// ログイン情報取得
					loginInfoDto = getLoginInfoDB(db, m_UserId, m_Systemkind);
					return;
				}

				// 有効期限切れチェック
				if (!LoginFlg.VALID_LIMIT_OFF.equals(loginInfoDto.getM_Password_Exp_Flg())) {
					// 有効期限があり

					// 有効期限切れチェック
					// 有効期限を取得
					Date passExpTime = loginInfoDto.getM_Password_Exp_Date();
					if (passExpTime != null) {

						// ミリ秒で差分を算出
						long diffExpTime = passExpTime.getTime() - nowDate.getTime();
						if (diffExpTime < 0) {
							// 有効期限切れの場合
							status = CHANGE;
							// ログイン情報更新(最終ログイン日時)
							updateLoginManagerData(db, 0);
							// ログイン情報取得
							loginInfoDto = getLoginInfoDB(db, m_UserId, m_Systemkind);
							return;
						}
					} else {
						// 有効期限が取得できない場合
						// エラー処理を行う。
						AmallException ee = new AmallException();
						throw ee;
					}

				}

				// 通常ログイン
				status = NORMAL;
				// ログイン情報更新(最終ログイン日時)
				updateLoginManagerData(db, 0);
				// ログイン情報取得
				loginInfoDto = getLoginInfoDB(db, m_UserId, m_Systemkind);
				return;

			} else {
				// 一致しない場合
				status = ERROR;

				// ログイン上限を取得
				AmdtoGeneralMst limitDto = AmallUtilities.getGeneralMstDataRecord(db, GeneralMstKey.LOGIN_ERR_COUNT_MAX,
						null, null, null);
				Long limitCnt = limitDto.getNo1();

				// ログイン失敗回数チェック
				if (limitCnt <= loginInfoDto.getM_Access_Error_Count() + 1 ) {
					// 上限超えた場合
					errMessage.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_PASSWORD_MISS_LOCK_OUT,
							retPassData.toString()));
					errFormIdList.add(m_UidFormId);
					errFormIdList.add(m_PwdFormId);
					// ログイン情報更新(ログインロック)
					updateLoginManagerData(db, 2);

					return;
				} else {
					errMessage.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_LOGIN_COLLECT,
							retPassData.toString()));
					errFormIdList.add(m_UidFormId);
					errFormIdList.add(m_PwdFormId);
					// 上限超えていない場合
					// ログイン情報更新(ログイン失敗回数追加)
					updateLoginManagerData(db, 1);
				}

			}

			return;
		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_LOGIN_PROC_ERROR);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		}
	}

	/*************************************************************************************
	 * 入力値チェック処理
	 * <p>
	 * 入力値のチェックを行う
	 * </p>
	 * @param  無し
	 * @return true  : 入力正常
	 *          false : 入力エラー
	 ************************************************************************************/
	private boolean checkInput() {

		// Login ID 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(m_UserId)) {
			errMessage.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
					AmallConst.USER_ID_AREA_NAME));
			errFormIdList.add(m_UidFormId);
			status = ERROR;
			return false;
		}

		// Password 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(m_Password)) {
			errMessage.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
					AmallConst.PASSWORD_AREA_NAME));
			errFormIdList.add(m_PwdFormId);
			status = ERROR;
			return false;
		}

		/* Login ID 半角英数値10文字ﾁｪｯｸ */
		if (!AmallUtilities.consist(m_UserId, AmallUtilities.H_ALP | AmallUtilities.H_NUM) || m_UserId.length() != 10) {
			errMessage.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_LOGIN_COLLECT));
			errFormIdList.add(m_UidFormId);
			errFormIdList.add(m_PwdFormId);
			status = ERROR;
			return false;
		}
		// 正常終了
		return true;
	}

	/*************************************************************************************
	 * ログイン情報取得
	 * <p>
	 * ログイン情報を取得する
	 * </p>
	 * @param db DBアクセサインスタンス
	 * @param userId ユーザーID
	 * @param systemkind システム種別
	 * @return dto ログイン情報(DTO)
	 ************************************************************************************/
	public static AmdtoLoginInfo getLoginInfoDB(AmallDbAccess db, String userId, int systemkind) throws AmallException, Exception {

		String className = AmallLoginControl.class.getName();
		String methodName = "getLoginInfoDB()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		AmdtoLoginInfo retDto = null;

		try {
			// SQL文生成
			sql.append("SELECT");
			sql.append("	*");
			// システム種別に応じてテーブルを変える
			if (systemkind == SystemType.CUSTOMER) {
				sql.append("  FROM N_USER_CST_M");
			} else {
				sql.append("  FROM N_USER_EMP_M");
			}
			sql.append(" WHERE");
			sql.append("	DEL_FLG =  ?");
			sql.append("	AND USER_ID =  ?");

			db.createPreparedStatement(sql.toString());
			// 条件設定
			db.setString(1, AmallConst.DEFAULT_DEL_FLG);
			db.setString(2, userId);
			// SQL実行
			rs = db.executeQuery();

			// 結果取得
			while (rs.next()) {
				retDto = new AmdtoLoginInfo();
				retDto.setM_User_Cd(db.getString(rs, "USER_ID"));
				retDto.setM_User_Nm(db.getString(rs, "USER_NM"));
				retDto.setM_Auth_Grp_Cd(db.getString(rs, "ROLE_GRP_CD"));
				retDto.setM_Customer_Grp_Cd(db.getString(rs, "CST_GRP_CD"));
				retDto.setM_Customer_Cd(db.getString(rs, "CST_CD"));
				retDto.setM_Shop_Cd(db.getString(rs, "SHOP_CD"));
				retDto.setM_Cmt(db.getString(rs, "CMT"));
				retDto.setM_User_Upd_dt(rs.getDate("USER_UPD_DT"));
				retDto.setM_Password(db.getString(rs, "PASSWORD"));
				retDto.setM_OldPassword(db.getString(rs, "PASSWORD_OLD"));
				retDto.setM_LastPassword(db.getString(rs, "PASSWORD_LAST"));
				retDto.setM_Password_Flg(db.getString(rs, "PASSWORD_PRE_FLG"));
				retDto.setM_Password_Exp_Date(rs.getDate("PASSWORD_EXP_DATE"));
				retDto.setM_Password_Exp_Flg(db.getString(rs, "PASSWORD_EXP_FLG"));
				retDto.setM_Password_Valid_Limit(rs.getLong("PASSWORD_VALID_LIMIT"));
				retDto.setM_Password_Chg_Time(rs.getDate("PASSWORD_MODIFIED_DATE"));
				retDto.setM_Last_Access_Date(rs.getDate("LAST_LOGIN_DATE"));
				retDto.setM_Access_Error_Time(rs.getDate("LAST_FAILED_LOGIN_DATE"));
				retDto.setM_Access_Error_Count(rs.getLong("FAILED_LOGIN_ATTEMPTS"));
				retDto.setM_LoginLock(db.getString(rs, "PASSWORD_LOCK"));
				retDto.setM_LoginLock_Time(rs.getDate("PASSWORD_LOCK_DATE"));
				retDto.setM_AccountLock(db.getString(rs, "ACCOUNT_LOCK"));
				retDto.setM_AccountLock_Time(rs.getDate("ACCOUNT_LOCK_DATE"));
				retDto.setM_Exclusive_Key(rs.getLong("EXCLUSIVE_KEY"));
			}

			return retDto;
		} catch (AmallException e) {
			e.addException(className, methodName, AmallMessageConst.MSG_SYS_LOGIN_INFO_GET_ERROR);
			throw e;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(className, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
			sql.delete(0, sql.length());
			sql = null;
		}
	}

	/*************************************************************************************
	 * ログイン管理(DB)更新
	 * <p>
	 * ログイン管理(DB)を更新する
	 * </p>
	 * @param db	DBアクセサインスタンス
	 * @param mode 設定パターン 0：通常 1:失敗 2:ログインロック
	 * @return 無し
	 ************************************************************************************/
	private void updateLoginManagerData(AmallDbAccess db, int mode) throws AmallException {

		String methodName = "updateLoginManagerData()";
		StringBuffer sql = new StringBuffer();

		try {
			sql.append("UPDATE");

			// システム種別に応じてテーブルを変える
			if (m_Systemkind == SystemType.CUSTOMER) {
				sql.append("  ").append(SystemType.CUSTOMER_USER_TABLE_NM);
			} else {
				sql.append("  ").append(SystemType.BUSINESS_USER_TABLE_NM);
			}
			sql.append("   SET");

			// モードに応じて更新先を変更
			if(mode == 0) {
				// 通常
				// 最終ログイン日時
				sql.append("	LAST_LOGIN_DATE = SYSDATE");
				// ログイン失敗回数リセット
				sql.append(",	FAILED_LOGIN_ATTEMPTS = 0");
				// ログインロック時刻
				sql.append(",	PASSWORD_LOCK_DATE = ''");
				// ログインロックOFF
				sql.append(",	PASSWORD_LOCK = '").append(LoginFlg.LOCK_OUT_OFF).append("'");

			} else if(mode == 1) {
				// 失敗
				// 最終ログイン失敗日時
				sql.append("	LAST_FAILED_LOGIN_DATE = SYSDATE");
				// ログイン失敗回数加算
				sql.append(",	FAILED_LOGIN_ATTEMPTS = FAILED_LOGIN_ATTEMPTS + 1");
			} else {
				// パスワードロック
				// ログインロック時刻
				sql.append("	PASSWORD_LOCK_DATE = SYSDATE");
				// ログインロック
				sql.append(",	PASSWORD_LOCK = '").append(LoginFlg.LOCK_OUT).append("'");
			}
			// 共通部分
			sql.append(",	UPD_PGM_ID =  ?");
			sql.append(",	UPD_USER_ID =  ?");
			sql.append(",	UPD_DT =  SYSDATE");
			sql.append(",	EXCLUSIVE_KEY =  EXCLUSIVE_KEY + 1");
			// 条件指定
			sql.append(" WHERE");
			sql.append("	USER_ID =  ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND EXCLUSIVE_KEY = ?");
			// WHERE句のパラメタ設定
			db.createPreparedStatement(sql.toString());

			// 更新プログラムID
			db.setString(1, m_ClassName);
			// 更新ユーザーID
			db.setString(2, m_UserId);
			// ユーザーID
			db.setString(3, loginInfoDto.getM_User_Cd());
			// 削除フラグ
			db.setString(4, AmallConst.DEFAULT_DEL_FLG);
			// 排他キー
			db.setLong(5, loginInfoDto.getM_Exclusive_Key());

			// SQL文実行
			int ret = db.executeUpdateSql();

			// 排他チェック
			if(ret == 0) {
				// 更新対象無し(楽観排他)
				db.rollback();
				errMessage.add(AmallMessage.getMessage(AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST));
				status = OPT_ERROR;
				return;
			}

			// 更新結果判定
			if (ret != 1) {
				db.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_UPDATE_ERROR, "");
				throw ee;
			}
			// コミット処理
			db.commit();

		} catch (AmallException e) {
			db.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_UPDATE_ERROR, "");
			throw e;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
		return;
	}
	/*************************************************************************************
	 * 端末アクセス履歴(DB)登録
	 * <p>
	 * ユーザーエージェントよりブラウザを判定し
	 * 端末アクセス履歴(DB)に登録する
	 * </p>
	 * @param db	DBアクセサインスタンス
	 * @param userAgent ユーザーエージェント
	 * @return 無し
	 ************************************************************************************/
	public void insertTermHistory(AmallDbAccess db, String userAgent) throws AmallException {

		String methodName = "insertTermHistory()";
		StringBuffer sql = new StringBuffer();


		// ユーザーエージェント判定
		String browser = AmallUtilities.getBrowser(db, userAgent, null);


		try {

			// SQL生成
			sql.append("INSERT INTO");
			sql.append("	N_TERM_HIST_DAT (");
			sql.append("   		TERM_HIST_PK");
			sql.append(",  		USER_ID");
			sql.append(",  		ACCESS_BROWSER");
			sql.append(",  		USERAGENT");
			sql.append(",  		ACCESS_DT");
			sql.append(",  		EXCLUSIVE_KEY");
			sql.append(",  		DEL_FLG");
			sql.append(",  		CR_PGM_ID");
			sql.append(",  		CR_USER_ID");
			sql.append(",  		CR_DT");
			sql.append(",  		UPD_PGM_ID");
			sql.append(",  		UPD_USER_ID");
			sql.append(",  		UPD_DT");
			sql.append("	) VALUES (");
			sql.append("		S_TERM_HIST_PK.NEXTVAL");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			// 共通部分
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append("	)");

			// 登録値のパラメタ設定
			db.createPreparedStatement(sql.toString());
			int setCnt = 0;
			// ユーザーID
			db.setString(++setCnt, m_UserId);
			// ブラウザ
			db.setString(++setCnt, browser);
			// ユーザーエージェント
			db.setString(++setCnt, userAgent);

			// 排他キー
			db.setLong(++setCnt, 0);
			// 削除フラグ
			db.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 登録プログラムID
			db.setString(++setCnt, m_ClassName);
			// 登録ユーザーID
			db.setString(++setCnt, m_UserId);
			// 更新プログラムID
			db.setString(++setCnt, m_ClassName);
			// 更新ユーザーID
			db.setString(++setCnt, m_UserId);

			// SQL文実行
			int ret = db.executeUpdateSql();

			// 更新結果判定
			if (ret <= 0) {
				db.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_TERM_HIST_DAT");
				throw ee;
			}
			// コミット処理
			db.commit();

		} catch (AmallException e) {
			db.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_TERM_HIST_DAT");
			throw e;
		} catch (Exception e) {
			db.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}

	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public int getStatus() {
		return status;
	}

	public AmdtoLoginInfo getLoginInfoDto() {
		return loginInfoDto;
	}

	public List<String> getErrMessage() {
		return errMessage;
	}

	public List<String> getErrFormIdList() {
		return errFormIdList;
	}

}
