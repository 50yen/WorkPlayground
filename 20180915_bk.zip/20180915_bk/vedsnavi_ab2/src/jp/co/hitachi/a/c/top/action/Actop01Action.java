/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Actop01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.top.action;

import jp.co.hitachi.a.c.top.bean.Actop01DispBean;
import jp.co.hitachi.a.c.top.business.Actop01Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Actop01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Actop01DispBean actop01DispBean;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setActop01DispBean((Actop01DispBean)request.getAttribute("Actop01DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {

		// ビジネス層の生成
		Actop01Business dao = new Actop01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Actop01DispBean getActop01DispBean() {
		return actop01DispBean;
	}

	public void setActop01DispBean(Actop01DispBean actop01DispBean) {
		this.actop01DispBean = actop01DispBean;
	}
}
