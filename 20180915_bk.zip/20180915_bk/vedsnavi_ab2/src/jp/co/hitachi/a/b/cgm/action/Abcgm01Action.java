/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abcgm01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.cgm.action;

import jp.co.hitachi.a.b.cgm.bean.Abcgm01DispBean;
import jp.co.hitachi.a.b.cgm.business.Abcgm01Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Abcgm01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Abcgm01DispBean abcgm01DispBean;

	/** 顧客CD */
	private String cstCd = null;
	/** 顧客名 */
	private String cstNm = null;
	/** 表示件数 */
	private int dispResults = 0;
	/** ページ番号 */
	private int displayNum = 0;
	/** 顧客グループCD(Hidden) */
	private String cstGrpCdHid = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAbcgm01DispBean((Abcgm01DispBean)request.getAttribute("Abcgm01DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Abcgm01Business dao = new Abcgm01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Abcgm01DispBean getAbcgm01DispBean() {
		return abcgm01DispBean;
	}

	public void setAbcgm01DispBean(Abcgm01DispBean abcgm01DispBean) {
		this.abcgm01DispBean = abcgm01DispBean;
	}

	public String getCstCd() {
		return cstCd;
	}

	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}

	public String getCstNm() {
		return cstNm;
	}

	public void setCstNm(String cstNm) {
		this.cstNm = cstNm;
	}

	public String getCstGrpCdHid() {
		return cstGrpCdHid;
	}

	public void setCstGrpCdHid(String cstGrpCdHid) {
		this.cstGrpCdHid = cstGrpCdHid;
	}

	public int getDisplayNum() {
		return displayNum;
	}

	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}

	public int getDispResults() {
		return dispResults;
	}

	public void setDispResults(int dispResults) {
		this.dispResults = dispResults;
	}



}
