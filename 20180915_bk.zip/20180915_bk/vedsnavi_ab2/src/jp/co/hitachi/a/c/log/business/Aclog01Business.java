/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aclog01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.log.business;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.log.action.Aclog01Action;
import jp.co.hitachi.a.c.log.bean.Aclog01DispBean;
import jp.co.hitachi.a.m.all.AmallConst.MsgCode;
import jp.co.hitachi.a.m.all.AmallConst.MsgLvl;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallLoginControl;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;

/*****************************************************************************************
 * Aclog01Businessクラス<br>
 *****************************************************************************************/
public class Aclog01Business extends AclogBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Aclog01DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** ログイン処理 */
	public static final String FORWARD_LOGIN = "LOGIN";
	/** パスワード変更処理 */
	public static final String FORWARD_CHANGEPWD = "CHANGEPWD";

	/**
	 * 画面項目ID
	 */
	/** ログインID */
	public static final String ITEM_ID_LOGIN = "loginID";
	/** パスワード */
	public static final String ITEM_ID_PASSWOARD = "password";

	/** メンバ変数 */
	/** アクションフォーム */
	private Aclog01Action m_Aclog01Form = null;
	/** 表示用画面Bean */
	private Aclog01DispBean m_Aclog01DispBean = null;


	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Aclog01Business(
			Aclog01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Aclog01Business.class.getName();
		m_Aclog01Form = form;
		m_Aclog01DispBean = new Aclog01DispBean();

		setErrString(gid, m_Aclog01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Aclog01DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Aclog01Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_LOGIN.equals(m_Event)) {
				// ログインボタン押下処理の場合
				forwardStr = login();
			}  else if (FORWARD_CHANGEPWD.equals(m_Event)) {
				// パスワード変更処理の場合
				forwardStr = FORWARD_CHANGEPWD;
			} else {
				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Aclog01DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ログイン処理
	 * <p>
	 * ログイン処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String login() throws AmallException {

		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		// ログインID取得
		String lid = m_Aclog01Form.getLoginID();
		// パスワード取得
		String pwd = m_Aclog01Form.getPassword();

		// ログイン制御クラスを生成
		AmallLoginControl loginCtrl = new AmallLoginControl(lid, pwd, ITEM_ID_LOGIN, ITEM_ID_PASSWOARD, m_systemKind);

		// ログイン処理を実行
		loginCtrl.exec(m_DbAccess);

		// 結果ステータスを取得し、遷移FOWARD値を設定
		switch (loginCtrl.getStatus()) {
			case AmallLoginControl.NORMAL:
				// ログイン処理実施
				forwardStr = FORWARD_LOGIN;

				// ログイン情報を取得してリクエストにセット
				putLoginInfoDTO(loginCtrl.getLoginInfoDto());

				// 端末アクセス履歴に登録
				loginCtrl.insertTermHistory(m_DbAccess, m_Request.getHeader("USER-AGENT"));

				// アクセスログ出力
				writeAccessLogStart(lid, null);
				writeAccessLogEnd(lid, false, MsgLvl.NORMAL);
				break;
			case AmallLoginControl.ERROR:
				// ログイン処理エラー
				forwardStr = FORWARD_DISP;

				// エラー情報を設定
				m_Aclog01DispBean.setMessage(loginCtrl.getErrMessage());
				m_Aclog01DispBean.setMessageType(MsgCode.ERROR);
				List<String> errlist = loginCtrl.getErrFormIdList();
				for (String str : errlist) {
					setError(m_Aclog01DispBean, str);
				}

				break;
			case AmallLoginControl.CHANGE:
				// パスワード変更処理
				forwardStr = FORWARD_CHANGEPWD;

				// ログイン情報を取得してリクエストにセット
				putLoginInfoDTO(loginCtrl.getLoginInfoDto());

				// 端末アクセス履歴に登録
				loginCtrl.insertTermHistory(m_DbAccess, m_Request.getHeader("USER-AGENT"));

				// アクセスログ出力
				writeAccessLogStart(lid, null);
				writeAccessLogEnd(lid, false, MsgLvl.NORMAL);
				break;

			case AmallLoginControl.OPT_ERROR:
				// 楽観排他エラー
				forwardStr = FORWARD_DISP;

				// エラー情報を設定
				m_Aclog01DispBean.setMessage(loginCtrl.getErrMessage());
				m_Aclog01DispBean.setMessageType(MsgCode.ERROR);
				List<String> optlist = loginCtrl.getErrFormIdList();
				for (String str : optlist) {
					setError(m_Aclog01DispBean, str);
				}
				// アクセスログ情報の作成
				AmallExceptionInfo amei = new AmallExceptionInfo();
				amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_UPDATE_OPTIMISTIC_ERROR, lid));
				setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

				break;

			default:
				break;
		}

		return forwardStr;

	}


}