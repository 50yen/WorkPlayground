/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoLoginInfo.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import java.sql.Date;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * ログイン情報DTO <br>
 *****************************************************************************************/
public class AmdtoLoginInfo extends AmclsDtoBase {

	/** メンバ変数 */
	/** ユーザーCD(ログインID) */
	private String m_User_Cd = null;
	/** ユーザー名 */
	private String m_User_Nm = null;
	/** 権限グループCD */
	private String m_Auth_Grp_Cd= null;
	/** 顧客グループCD */
	private String m_Customer_Grp_Cd = null;
	/** 顧客CD */
	private String m_Customer_Cd = null;
	/** 店舗CD */
	private String m_Shop_Cd = null;
	/** コメント */
	private String m_Cmt = null;
	/** ユーザー情報変更日時 */
	private Date m_User_Upd_dt = null;
	/** パスワード */
	private String m_Password = null;
	/** 前回パスワード */
	private String m_OldPassword = null;
	/** 前々回パスワード */
	private String m_LastPassword = null;
	/** 仮パスワードフラグ 1：仮パスワード */
	private String m_Password_Flg = null;
	/** パスワード有効期限 */
	private Date m_Password_Exp_Date = null;
	/** パスワード有効期限フラグ 1:有効期限なし */
	private String m_Password_Exp_Flg = null;
	/** パスワード有効期間(月数) */
	private Long m_Password_Valid_Limit = null;
	/** パスワード変更日時 */
	private Date m_Password_Chg_Time = null;
	/** 最終ログイン日時 */
	private Date m_Last_Access_Date = null;
	/** 最終ログイン失敗日時 */
	private Date m_Access_Error_Time = null;
	/** ログイン失敗回数 */
	private Long m_Access_Error_Count = null;
	/** パスワードロック 1：ロック */
	private String m_LoginLock = null;
	/** パスワードロック日時 */
	private Date m_LoginLock_Time = null;
	/** アカウントロック 1：ロック */
	private String m_AccountLock = null;
	/** アカウントロック日時 */
	private Date m_AccountLock_Time = null;
	/** 排他キー */
	private Long m_Exclusive_Key = null;



	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmdtoLoginInfo() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		m_User_Cd = null;
		m_User_Nm = null;
		m_Auth_Grp_Cd= null;
		m_Customer_Grp_Cd = null;
		m_Customer_Cd = null;
		m_Shop_Cd = null;
		m_Cmt = null;
		m_User_Upd_dt = null;
		m_Password = null;
		m_OldPassword = null;
		m_LastPassword = null;
		m_Password_Flg = null;
		m_Password_Exp_Date = null;
		m_Password_Exp_Flg = null;
		m_Password_Valid_Limit = null;
		m_Password_Chg_Time = null;
		m_Last_Access_Date = null;
		m_Access_Error_Time = null;
		m_Access_Error_Count = null;
		m_LoginLock = null;
		m_LoginLock_Time = null;
		m_AccountLock = null;
		m_AccountLock_Time = null;
		m_Exclusive_Key = null;

	}

	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////


	public String getM_User_Cd() {
		return m_User_Cd;
	}

	public void setM_User_Cd(String m_User_Cd) {
		this.m_User_Cd = m_User_Cd;
	}

	public String getM_User_Nm() {
		return m_User_Nm;
	}

	public void setM_User_Nm(String m_User_Nm) {
		this.m_User_Nm = m_User_Nm;
	}

	public String getM_Auth_Grp_Cd() {
		return m_Auth_Grp_Cd;
	}

	public void setM_Auth_Grp_Cd(String m_Auth_Grp_Cd) {
		this.m_Auth_Grp_Cd = m_Auth_Grp_Cd;
	}

	public String getM_Customer_Grp_Cd() {
		return m_Customer_Grp_Cd;
	}

	public void setM_Customer_Grp_Cd(String m_Customer_Grp_Cd) {
		this.m_Customer_Grp_Cd = m_Customer_Grp_Cd;
	}

	public String getM_Customer_Cd() {
		return m_Customer_Cd;
	}

	public void setM_Customer_Cd(String m_Customer_Cd) {
		this.m_Customer_Cd = m_Customer_Cd;
	}

	public String getM_Shop_Cd() {
		return m_Shop_Cd;
	}

	public void setM_Shop_Cd(String m_Shop_Cd) {
		this.m_Shop_Cd = m_Shop_Cd;
	}

	public String getM_Cmt() {
		return m_Cmt;
	}

	public void setM_Cmt(String m_Cmt) {
		this.m_Cmt = m_Cmt;
	}

	public Date getM_User_Upd_dt() {
		return m_User_Upd_dt;
	}

	public void setM_User_Upd_dt(Date m_User_Upd_dt) {
		this.m_User_Upd_dt = m_User_Upd_dt;
	}

	public String getM_Password() {
		return m_Password;
	}

	public void setM_Password(String m_Password) {
		this.m_Password = m_Password;
	}

	public String getM_OldPassword() {
		return m_OldPassword;
	}

	public void setM_OldPassword(String m_OldPassword) {
		this.m_OldPassword = m_OldPassword;
	}

	public String getM_LastPassword() {
		return m_LastPassword;
	}

	public void setM_LastPassword(String m_LastPassword) {
		this.m_LastPassword = m_LastPassword;
	}

	public String getM_Password_Flg() {
		return m_Password_Flg;
	}

	public void setM_Password_Flg(String m_Password_Flg) {
		this.m_Password_Flg = m_Password_Flg;
	}

	public Date getM_Password_Exp_Date() {
		return m_Password_Exp_Date;
	}

	public void setM_Password_Exp_Date(Date m_Password_Exp_Date) {
		this.m_Password_Exp_Date = m_Password_Exp_Date;
	}

	public String getM_Password_Exp_Flg() {
		return m_Password_Exp_Flg;
	}

	public void setM_Password_Exp_Flg(String m_Password_Exp_Flg) {
		this.m_Password_Exp_Flg = m_Password_Exp_Flg;
	}

	public Long getM_Password_Valid_Limit() {
		return m_Password_Valid_Limit;
	}

	public void setM_Password_Valid_Limit(Long m_Password_Valid_Limit) {
		this.m_Password_Valid_Limit = m_Password_Valid_Limit;
	}

	public Date getM_Password_Chg_Time() {
		return m_Password_Chg_Time;
	}

	public void setM_Password_Chg_Time(Date m_Password_Chg_Time) {
		this.m_Password_Chg_Time = m_Password_Chg_Time;
	}

	public Date getM_Last_Access_Date() {
		return m_Last_Access_Date;
	}

	public void setM_Last_Access_Date(Date m_Last_Access_Date) {
		this.m_Last_Access_Date = m_Last_Access_Date;
	}

	public Date getM_Access_Error_Time() {
		return m_Access_Error_Time;
	}

	public void setM_Access_Error_Time(Date m_Access_Error_Time) {
		this.m_Access_Error_Time = m_Access_Error_Time;
	}

	public Long getM_Access_Error_Count() {
		return m_Access_Error_Count;
	}

	public void setM_Access_Error_Count(Long m_Access_Error_Count) {
		this.m_Access_Error_Count = m_Access_Error_Count;
	}

	public String getM_LoginLock() {
		return m_LoginLock;
	}

	public void setM_LoginLock(String m_LoginLock) {
		this.m_LoginLock = m_LoginLock;
	}

	public Date getM_LoginLock_Time() {
		return m_LoginLock_Time;
	}

	public void setM_LoginLock_Time(Date m_LoginLock_Time) {
		this.m_LoginLock_Time = m_LoginLock_Time;
	}

	public String getM_AccountLock() {
		return m_AccountLock;
	}

	public void setM_AccountLock(String m_AccountLock) {
		this.m_AccountLock = m_AccountLock;
	}

	public Date getM_AccountLock_Time() {
		return m_AccountLock_Time;
	}

	public void setM_AccountLock_Time(Date m_AccountLock_Time) {
		this.m_AccountLock_Time = m_AccountLock_Time;
	}

	public Long getM_Exclusive_Key() {
		return m_Exclusive_Key;
	}

	public void setM_Exclusive_Key(Long m_Exclusive_Key) {
		this.m_Exclusive_Key = m_Exclusive_Key;
	}

}
