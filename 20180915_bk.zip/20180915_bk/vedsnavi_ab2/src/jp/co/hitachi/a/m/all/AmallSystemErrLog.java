/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallSystemErrLog.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.hitachi.a.m.all.AmallConst.SystemType;

/*****************************************************************************************
 * システムエラーログファイル作成クラス<br>
 ****************************************************************************************/
public final class AmallSystemErrLog {

	/*************************************************************************************
	 * システムエラーログファイル作成
	 * <p>
	 * システムエラーログファイルを作成する
	 * </p>
	 * @param	systemKind	int	システム種類
	 * @param	e	AmallException	例外情報
	 * @param	request	HttpServletRequest リクエストインスタンス
	 * @return 無し
	 ************************************************************************************/
	public static void createSystemErrLog(int systemKind, AmallException e, HttpServletRequest request) {
		StringBuffer logbuf = null;
		String item1 = AmallMessageConst.ERR_LOG_H_DATE;
		String item2 = AmallMessageConst.ERR_LOG_H_LOGIN_ID;
		String item3 = AmallMessageConst.ERR_LOG_H_KBN;
		String item4 = AmallMessageConst.ERR_LOG_H_GYOMU_NM;
		String item5 = AmallMessageConst.ERR_LOG_H_LOG_HEAD;
		String item6 = AmallMessageConst.ERR_LOG_H_LOG_INFO;
		String item7 = AmallMessageConst.ERR_LOG_H_EXCEPTION;
		String item8 = AmallMessageConst.ERR_LOG_H_CLASS_NM;
		String item9 = AmallMessageConst.ERR_LOG_H_METHOD_NM;
		String item10 = AmallMessageConst.ERR_LOG_H_MESSAGE_ID;
		String item11 = AmallMessageConst.ERR_LOG_H_MESSAGE;
		String item12 = AmallMessageConst.ERR_LOG_H_MESSAGE_KIND;
		String space = "  ";
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

		String log = "";
		switch (systemKind) {
		case SystemType.CUSTOMER: // 顧客OL
			log = "SystemErr_assvedsnavi.Logging";
			break;
		case SystemType.BUSINESS: // 業務支援
			log = "SystemErr_gyoumu.Logging";
		default:
			// 上記以外は共通定義を使用する
			log = "SystemErr.Logging";
			break;
		}

		//log4j設定
		Logger logger = LogManager.getLogger(log); //システムエラー用

		//1行目(発生日時)
		logbuf = new StringBuffer();
		logbuf.append(item1);
		if (e.getM_GTime() != null) { //発生日付有？
			logbuf.append(fmt.format(e.getM_GTime())); //フォーマット変換
		}
		logger.error(logbuf.toString());

		//2行目(ログインID)
		logbuf = new StringBuffer();
		logbuf.append(item2);
		logbuf.append(e.getM_LoginID());
		logger.error(logbuf.toString());

		//3行目(区分)
		logbuf = new StringBuffer();
		logbuf.append(item3);
		logbuf.append(e.getM_Kind());
		logger.error(logbuf.toString());

		//4行目(業務名)
		logbuf = new StringBuffer();
		logbuf.append(item4);
		logbuf.append(e.getM_BusinessName());
		logger.error(logbuf.toString());

		//5行目(ログ情報ヘッダ)
		logbuf = new StringBuffer();
		logbuf.append(item5);
		logbuf.append(e.getM_LogInfoHeader());
		logger.error(logbuf.toString());

		//6行目(ログ情報)
		logbuf = new StringBuffer();
		logbuf.append(item6);
		logger.error(logbuf.toString());

		logger.error("URL:" + request.getRequestURL());
		logger.error("QUERY_STRING:" + request.getQueryString());
		logger.error("REMOTE_ADDRESS:" + request.getRemoteAddr());

		//7行目(ログ情報)
		List<AmallExceptionInfo> list = e.getM_AmallExceptionInfoList();
		if (list != null) {
			for (int i = 0; i < list.size(); i++) {
				AmallExceptionInfo info = list.get(i);
				StringBuffer sb = new StringBuffer();
				sb.append(space);
				sb.append(item7);
				sb.append(info.getException()); //発生した例外
				sb.append("\n");
				sb.append(space);
				sb.append(item8);
				sb.append(info.getClassName()); //例外が発生したクラス名称
				sb.append("\n");
				sb.append(space);
				sb.append(item9);
				sb.append(info.getMethodName()); //例外が発生したメソッド名称
				sb.append("\n");
				sb.append(space);
				sb.append(item10);
				sb.append(info.getMessageID()); //メッセージID
				sb.append("\n");
				sb.append(space);
				sb.append(item11);
				sb.append(info.getMessage()); //メッセージ内容
				sb.append("\n");
				sb.append(space);
				sb.append(item12);
				sb.append(info.getMassageKind()); //メッセージ種別
				logger.error(sb.toString());
			}
		}

		// 追加のエラー情報
		logger.error(space);
		logbuf = new StringBuffer();
		logbuf.append(space);
		logbuf.append(e.getMessage());
		logger.error(logbuf.toString());
		StackTraceElement ste[] = e.getStackTrace(); //スタックトレース取得
		for (int i = 0; i < ste.length; i++) { //スタックトレース分
			logbuf = new StringBuffer();
			logbuf.append("  ");
			logbuf.append(ste[i].getClassName()); //クラス名
			logbuf.append(".");
			logbuf.append(ste[i].getMethodName()); //メソッド名
			logbuf.append("  ");
			logbuf.append(ste[i].getFileName()); //ファイル名
			logbuf.append(":");
			logbuf.append(ste[i].getLineNumber()); //行番号
			logger.error(logbuf.toString()); //ログ出力
		}

		//最終行
		logger.error("");
	}
}