/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abiam03Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.action;

import java.util.List;

import jp.co.hitachi.a.b.iam.bean.Abiam03DispBean;
import jp.co.hitachi.a.b.iam.business.Abiam03Business;
import jp.co.hitachi.a.b.iam.dto.AbiamIndScreenAuthDto;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Abiam03Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Abiam03DispBean abiam03DispBean;

	/** 分類プルダウン選択値 */
	private String selectedClsCd = null;
	/** 顧客入力値 */
	private String inputedCstCd = null;
	/** 店舗入力値 */
	private String inputedShopCd = null;
	/** ユーザー入力値 */
	private String inputedUserCd = null;

	/** カテゴリプルダウン選択値 */
	private String selectedCategoryCd = null;
	/** メニュープルダウン選択値 */
	private String selectedMenuCd = null;
	/** 画面名プルダウン選択値 */
	private String selectedScreenCd = null;


	/** 顧客名称 */
	private String dispCstNm = null;
	/** 店舗名称 */
	private String dispShopNm = null;
	/** ユーザー名称 */
	private String dispUserNm = null;


	/** 分類プルダウン保存値 */
	private String savedClsCd = null;
	/** 顧客保存値 */
	private String savedCstCd = null;
	/** 店舗保存値 */
	private String savedShopCd = null;
	/** ユーザー保存値 */
	private String savedUserCd = null;

	/** カテゴリプルダウン選択値(検索ボタン押下保存値) */
	private String savedCategoryCd = null;
	/** メニューロールプルダウン選択値(検索ボタン押下保存値) */
	private String savedMenuCd = null;
	/** 画面名プルダウン選択値(検索ボタン押下保存値) */
	private String savedScreenCd = null;

	/** 一覧表示用データ */
	private List<AbiamIndScreenAuthDto> indScreenDispList = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAbiam03DispBean((Abiam03DispBean)request.getAttribute("Abiam03DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Abiam03Business dao = new Abiam03Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Abiam03DispBean getAbiam03DispBean() {
		return abiam03DispBean;
	}

	public void setAbiam03DispBean(Abiam03DispBean abiam03DispBean) {
		this.abiam03DispBean = abiam03DispBean;
	}

	public String getSelectedClsCd() {
		return selectedClsCd;
	}

	public void setSelectedClsCd(String selectedClsCd) {
		this.selectedClsCd = selectedClsCd;
	}

	public String getInputedCstCd() {
		return inputedCstCd;
	}

	public void setInputedCstCd(String inputedCstCd) {
		this.inputedCstCd = inputedCstCd;
	}

	public String getInputedShopCd() {
		return inputedShopCd;
	}

	public void setInputedShopCd(String inputedShopCd) {
		this.inputedShopCd = inputedShopCd;
	}

	public String getInputedUserCd() {
		return inputedUserCd;
	}

	public void setInputedUserCd(String inputedUserCd) {
		this.inputedUserCd = inputedUserCd;
	}

	public String getSelectedCategoryCd() {
		return selectedCategoryCd;
	}

	public void setSelectedCategoryCd(String selectedCategoryCd) {
		this.selectedCategoryCd = selectedCategoryCd;
	}

	public String getSelectedMenuCd() {
		return selectedMenuCd;
	}

	public void setSelectedMenuCd(String selectedMenuCd) {
		this.selectedMenuCd = selectedMenuCd;
	}

	public String getSelectedScreenCd() {
		return selectedScreenCd;
	}

	public void setSelectedScreenCd(String selectedScreenCd) {
		this.selectedScreenCd = selectedScreenCd;
	}

	public String getDispCstNm() {
		return dispCstNm;
	}

	public void setDispCstNm(String dispCstNm) {
		this.dispCstNm = dispCstNm;
	}

	public String getDispShopNm() {
		return dispShopNm;
	}

	public void setDispShopNm(String dispShopNm) {
		this.dispShopNm = dispShopNm;
	}

	public String getDispUserNm() {
		return dispUserNm;
	}

	public void setDispUserNm(String dispUserNm) {
		this.dispUserNm = dispUserNm;
	}

	public String getSavedClsCd() {
		return savedClsCd;
	}

	public void setSavedClsCd(String savedClsCd) {
		this.savedClsCd = savedClsCd;
	}

	public String getSavedCstCd() {
		return savedCstCd;
	}

	public void setSavedCstCd(String savedCstCd) {
		this.savedCstCd = savedCstCd;
	}

	public String getSavedShopCd() {
		return savedShopCd;
	}

	public void setSavedShopCd(String savedShopCd) {
		this.savedShopCd = savedShopCd;
	}

	public String getSavedUserCd() {
		return savedUserCd;
	}

	public void setSavedUserCd(String savedUserCd) {
		this.savedUserCd = savedUserCd;
	}

	public String getSavedCategoryCd() {
		return savedCategoryCd;
	}

	public void setSavedCategoryCd(String savedCategoryCd) {
		this.savedCategoryCd = savedCategoryCd;
	}

	public String getSavedMenuCd() {
		return savedMenuCd;
	}

	public void setSavedMenuCd(String savedMenuCd) {
		this.savedMenuCd = savedMenuCd;
	}

	public String getSavedScreenCd() {
		return savedScreenCd;
	}

	public void setSavedScreenCd(String savedScreenCd) {
		this.savedScreenCd = savedScreenCd;
	}

	public List<AbiamIndScreenAuthDto> getIndScreenDispList() {
		return indScreenDispList;
	}

	public void setIndScreenDispList(List<AbiamIndScreenAuthDto> indScreenDispList) {
		this.indScreenDispList = indScreenDispList;
	}



}
