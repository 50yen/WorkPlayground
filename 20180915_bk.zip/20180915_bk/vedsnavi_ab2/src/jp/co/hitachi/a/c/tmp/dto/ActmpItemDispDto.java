/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Actmp02Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.tmp.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * ActmpItemDispDtoクラス<br>
 *****************************************************************************************/
public class ActmpItemDispDto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 項目ID */
	private String itemId = null;
	/** 項目表示名 */
	private String itemDispName = null;
	/** 項目タイプ */
	private String itemType = null;
	/** 表示 */
	private String dispCd = null;
	/** 編集 */
	private String enableCd = null;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public ActmpItemDispDto(){
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getItemDispName() {
		return itemDispName;
	}
	public void setItemDispName(String itemDispName) {
		this.itemDispName = itemDispName;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getDispCd() {
		return dispCd;
	}
	public void setDispCd(String dispCd) {
		this.dispCd = dispCd;
	}
	public String getEnableCd() {
		return enableCd;
	}
	public void setEnableCd(String enableCd) {
		this.enableCd = enableCd;
	}
}
