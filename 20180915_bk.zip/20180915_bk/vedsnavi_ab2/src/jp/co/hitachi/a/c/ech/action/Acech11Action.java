/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech11Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.action;

import jp.co.hitachi.a.c.ech.bean.Acech11DispBean;
import jp.co.hitachi.a.c.ech.business.Acech11Business;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Acech11Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Acech11DispBean acech11DispBean;

	/** 店舗CD */
	private String searchShopCd = null;
	/** 店舗名 */
	private String searchShopNm = null;
	/** 回収FROM */
	private String cldFrom = null;
	/** 回収TO */
	private String cldTo = null;
	/** 誤差フラグ */
	private boolean defFlg = false;

	/** プルダウンリスト選択値 */
	private int dispResults = 0;

	/** ページ遷移用情報 */
	/** 顧客CD */
	private String de_cstCd = null;
	/** 回収日 */
	private String de_cld = null;
	/** 店舗CD */
	private String de_shopCd = null;



	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAcech11DispBean((Acech11DispBean)request.getAttribute("Acech11DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Acech11Business dao = new Acech11Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Acech11DispBean getAcech11DispBean() {
		return acech11DispBean;
	}

	public void setAcech11DispBean(Acech11DispBean acech11DispBean) {
		this.acech11DispBean = acech11DispBean;
	}

	public String getSearchShopCd() {
		return searchShopCd;
	}

	public void setSearchShopCd(String searchShopCd) {
		this.searchShopCd = searchShopCd;
	}

	public String getSearchShopNm() {
		return searchShopNm;
	}

	public void setSearchShopNm(String searchShopNm) {
		this.searchShopNm = searchShopNm;
	}

	public String getCldFrom() {
		return cldFrom;
	}

	public void setCldFrom(String cldFrom) {
		this.cldFrom = cldFrom;
	}

	public String getCldTo() {
		return cldTo;
	}

	public void setCldTo(String cldTo) {
		this.cldTo = cldTo;
	}

	public boolean getDefFlg() {
		return defFlg;
	}

	public void setDefFlg(boolean defFlg) {
		this.defFlg = defFlg;
	}

	public int getDispResults() {
		return dispResults;
	}

	public void setDispResults(int dispResults) {
		this.dispResults = dispResults;
	}

	public String getDe_cstCd() {
		return de_cstCd;
	}

	public void setDe_cstCd(String de_cstCd) {
		this.de_cstCd = de_cstCd;
	}

	public String getDe_cld() {
		return de_cld;
	}

	public void setDe_cld(String de_cld) {
		this.de_cld = de_cld;
	}

	public String getDe_shopCd() {
		return de_shopCd;
	}

	public void setDe_shopCd(String de_shopCd) {
		this.de_shopCd = de_shopCd;
	}





}
