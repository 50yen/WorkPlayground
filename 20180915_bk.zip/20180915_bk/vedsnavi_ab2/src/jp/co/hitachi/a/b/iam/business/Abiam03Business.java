/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abiam03DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.business;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.b.iam.action.Abiam03Action;
import jp.co.hitachi.a.b.iam.bean.Abiam03DispBean;
import jp.co.hitachi.a.b.iam.dto.Abiam03Dto;
import jp.co.hitachi.a.b.iam.dto.AbiamIndScreenAuthDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallConst.ScrExp;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;

/*****************************************************************************************
 * Abiam03Businessクラス<br>
 *****************************************************************************************/
public class Abiam03Business extends AbiamBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Abiam03DispBean";
	/** 内部記憶用DTO名 */
	private static final String DTO_ABIAM03 = "DTO_ABIAM03";
	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 検索 */
	public static final String FORWARD_SEARCH = "SEARCH";
	/** 登録 */
	public static final String FORWARD_REGIST = "REGIST";

	/**
	 * 画面項目ID
	 */
	/** 分類プルダウン */
	public static final String ITEM_ID_CLASS_DD = "classDropDown";
	/** お客様入力 */
	public static final String ITEM_ID_CST_IN = "customerSearchNm";
	/** 店舗入力 */
	public static final String ITEM_ID_SHOP_IN = "shopSearchNm";
	/** ユーザー入力 */
	public static final String ITEM_ID_USER_IN = "userSearchNm";
	/** お客様検索ボタン */
	public static final String ITEM_ID_CST_SEARCH = "customerSearchChildBtn";
	/** 店舗検索ボタン */
	public static final String ITEM_ID_SHOP_SEARCH = "shopSearchChildBtn";
	/** ユーザー検索ボタン */
	public static final String ITEM_ID_USER_SEARCH = "userSearchChildBtn";
	/** カテゴリプルダウン */
	public static final String ITEM_ID_CATEGORY_DD = "categoryDropDown";
	/** メニュープルダウン */
	public static final String ITEM_ID_MENU_DD = "menuDropDown";
	/** 画面名プルダウン */
	public static final String ITEM_ID_SCREEN_DD = "screenDropDown";
	/** 一覧表示可否プルダウン */
	public static final String ITEM_ID_DISP_DD = "dispDropDownList";

	/** メンバ変数 */
	/** アクションフォーム */
	private Abiam03Action m_Abiam03Form = null;
	/** 表示用画面Bean */
	private Abiam03DispBean m_Abiam03DispBean = null;
	/** 内部記憶用DTO */
	private Abiam03Dto m_Abiam03Dto = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Abiam03Business(
			Abiam03Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Abiam03Business.class.getName();
		m_Abiam03Form = form;
		m_Abiam03DispBean = new Abiam03DispBean();
		setErrString(gid, m_Abiam03Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}
			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Abiam03DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Abiam03Form.getM_systemKind());
			m_DbAccess.initDB();

			// 共通処理
			getDropDownListData();

			// 内部記憶情報の生成
			m_Abiam03Dto = (Abiam03Dto) getSpecifiedDTO(m_Gid, DTO_ABIAM03);
			if (m_Abiam03Dto == null) {
				m_Abiam03Dto = new Abiam03Dto();
				putSpecifiedDTO(m_Gid, DTO_ABIAM03, m_Abiam03Dto);
			}

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_SEARCH.equals(m_Event)) {
				// 検索処理の場合

				// 検索結果を初期化
				List<AbiamIndScreenAuthDto> emptylist = new ArrayList<>();
				m_Abiam03Form.setIndScreenDispList(emptylist);

				// 検索実行
				forwardStr = search();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				forwardStr = regist();
			} else {
				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Abiam03DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 検索処理
	 * <p>
	 * 検索処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String search() throws AmallException, Exception {

		// 分類コード取得
		String clsCd = m_Abiam03Form.getSelectedClsCd();
		// 顧客コード取得
		String cstCd = m_Abiam03Form.getInputedCstCd();
		// 店舗コード取得
		String shopCd = m_Abiam03Form.getInputedShopCd();
		// ユーザーコード取得
		String userCd = m_Abiam03Form.getInputedUserCd();

		// カテゴリコード取得
		String categoryCd = m_Abiam03Form.getSelectedCategoryCd();
		// メニューコード取得
		String menuCd = m_Abiam03Form.getSelectedMenuCd();
		// 画面コード取得
		String screenCd = m_Abiam03Form.getSelectedScreenCd();



		// 入力値チェック
		if (!inputCheck(clsCd, cstCd, shopCd, userCd, categoryCd, menuCd, screenCd)) {
			// エラーの場合
			return FORWARD_DISP;
		}

		// 画面DTO一覧検索
		List<AbiamIndScreenAuthDto> indScreenList = getScreenGrpMst(categoryCd, menuCd, screenCd);

		// 結果チェック
		if (indScreenList.size() == 0) {
			// 0件だった場合
			setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_INF_SEARCH_CON_NO_DATA);
			return FORWARD_DISP;
		}

		// 画面個別権限データ
		List<AbiamIndScreenAuthDto> authDataList = getIndScreenRoleMst(clsCd, cstCd, shopCd, userCd);

		// データマージ処理
		List<AbiamIndScreenAuthDto> dispDataList = getMergeDataList(indScreenList, authDataList);


		// 関連画面データ作成
		getChainDataList(authDataList);


		// 一覧表示データセット
		m_Abiam03Form.setIndScreenDispList(dispDataList);
		// 検索ボタン押下時検索条件保存
		m_Abiam03Form.setSavedClsCd(clsCd);
		m_Abiam03Form.setSavedCstCd(cstCd);
		m_Abiam03Form.setSavedShopCd(shopCd);
		m_Abiam03Form.setSavedUserCd(userCd);
		m_Abiam03Form.setSavedCategoryCd(categoryCd);
		m_Abiam03Form.setSavedMenuCd(menuCd);
		m_Abiam03Form.setSavedScreenCd(screenCd);

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 入力値チェック
	 * <p>
	 * 入力値チェックを実施する
	 * </p>
	 * @param  clsCd 分類コード
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @param  userCd ユーザーコード
	 * @param  cateCd カテゴリコード
	 * @param  menuCd メニューコード
	 * @param  scrCd 画面コード
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheck(String clsCd, String cstCd, String shopCd, String userCd, String cateCd, String menuCd, String scrCd) throws AmallException, Exception {

		// 返却フラグ
		boolean ret = true;


		// 分類コード 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(clsCd)) {
			setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_CLASS_DD, m_Abiam03DispBean));
			setError(m_Abiam03DispBean, ITEM_ID_CLASS_DD);
			ret = false;
		}

		// 分類コードによるチェック分岐
		if (ScrExp.EXP_TYPE_CUSTOMER.equals(clsCd)) {
			// 顧客
			if (!AmallUtilities.isHalfWidthCharacterKind(cstCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CST_IN, m_Abiam03DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Abiam03DispBean, ITEM_ID_CST_IN);

				ret = false;
			} else if (AmallUtilities.getLengthAsHalf(cstCd) != InputNum.CST_CD) {
				// 10桁より多い数字が設定されている
				setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CST_IN, m_Abiam03DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Abiam03DispBean, ITEM_ID_CST_IN);

				ret = false;
			}

			if(ret) {
				// ユニークチェック
				if (!chkUniqCst(cstCd)) {
					// 特定できない場合
					setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_CAN_NOT_IDENTIFY_DATA,
							getItemDispName(ITEM_ID_CST_IN, m_Abiam03DispBean), getItemDispName(ITEM_ID_CST_SEARCH, m_Abiam03DispBean));
					setError(m_Abiam03DispBean, ITEM_ID_CST_IN);
					ret = false;
				}
			}

		} else 	if (ScrExp.EXP_TYPE_SHOP.equals(clsCd)) {
			// 店舗
			// 顧客コード
			if (!AmallUtilities.isHalfWidthCharacterKind(cstCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CST_IN, m_Abiam03DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Abiam03DispBean, ITEM_ID_CST_IN);

				ret = false;
			} else if (AmallUtilities.getLengthAsHalf(cstCd) != InputNum.CST_CD) {
				// 10桁より多い数字が設定されている
				setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CST_IN, m_Abiam03DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Abiam03DispBean, ITEM_ID_CST_IN);

				ret = false;
			}

			// 店舗コード
			if (!AmallUtilities.isHalfWidthCharacterKind(shopCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
						getItemDispName(ITEM_ID_SHOP_IN, m_Abiam03DispBean), String.valueOf(InputNum.SHOP_CD));
				setError(m_Abiam03DispBean, ITEM_ID_SHOP_IN);

				ret = false;
			} else if (AmallUtilities.getLengthAsHalf(shopCd) > InputNum.SHOP_CD) {
				// 10桁より多い数字が設定されている
				setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
						getItemDispName(ITEM_ID_SHOP_IN, m_Abiam03DispBean), String.valueOf(InputNum.SHOP_CD));
				setError(m_Abiam03DispBean, ITEM_ID_SHOP_IN);

				ret = false;
			}
			if(ret) {
				// ユニークチェック
				if (!chkUniqShop(cstCd, shopCd)) {
					// 特定できない場合
					setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_CAN_NOT_IDENTIFY_DATA,
							getItemDispName(ITEM_ID_SHOP_IN, m_Abiam03DispBean), getItemDispName(ITEM_ID_SHOP_SEARCH, m_Abiam03DispBean));
					setError(m_Abiam03DispBean, ITEM_ID_SHOP_IN);
					ret = false;
				}
			}


		} else 	if (ScrExp.EXP_TYPE_USER.equals(clsCd)) {
			// ユーザー
			// 入力値が存在する場合
			if (!AmallUtilities.isHalfWidthCharacterKind(userCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_USER_IN, m_Abiam03DispBean), String.valueOf(InputNum.USER_ID));
				setError(m_Abiam03DispBean, ITEM_ID_USER_IN);

				ret = false;
			} else if (AmallUtilities.getLengthAsHalf(userCd) != InputNum.USER_ID) {
				// 10桁より多い英数字が設定されている
				setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_USER_IN, m_Abiam03DispBean), String.valueOf(InputNum.USER_ID));
				setError(m_Abiam03DispBean, ITEM_ID_USER_IN);

				ret = false;
			}

			if(ret) {
				// ユニークチェック
				if (!chkUniqUser(userCd)) {
					// 特定できない場合
					setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_CAN_NOT_IDENTIFY_DATA,
							getItemDispName(ITEM_ID_USER_IN, m_Abiam03DispBean), getItemDispName(ITEM_ID_USER_SEARCH, m_Abiam03DispBean));
					setError(m_Abiam03DispBean, ITEM_ID_USER_IN);
					ret = false;
				}
			}


		}

		if (!AmallUtilities.isEmpty(menuCd) && AmallUtilities.isEmpty(cateCd)) {
			// メニューコード指定時のカテゴリコード 必須ﾁｪｯｸ
			setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_SPEC_NOT_COMBI, getItemDispName(ITEM_ID_CATEGORY_DD, m_Abiam03DispBean),getItemDispName(ITEM_ID_MENU_DD, m_Abiam03DispBean));
			setError(m_Abiam03DispBean, ITEM_ID_CATEGORY_DD);
			setError(m_Abiam03DispBean, ITEM_ID_MENU_DD);
			ret = false;
		} else if (!AmallUtilities.isEmpty(scrCd) && AmallUtilities.isEmpty(cateCd)) {
			// 画面コード指定時のカテゴリコード 必須ﾁｪｯｸ
			setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_SPEC_NOT_COMBI, getItemDispName(ITEM_ID_CATEGORY_DD, m_Abiam03DispBean),getItemDispName(ITEM_ID_SCREEN_DD, m_Abiam03DispBean));
			setError(m_Abiam03DispBean, ITEM_ID_CATEGORY_DD);
			setError(m_Abiam03DispBean, ITEM_ID_SCREEN_DD);
			ret = false;
		} else if (!AmallUtilities.isEmpty(scrCd) && AmallUtilities.isEmpty(menuCd)) {
			// 画面コード指定時のメニューコード 必須ﾁｪｯｸ
			setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_SPEC_NOT_COMBI, getItemDispName(ITEM_ID_MENU_DD, m_Abiam03DispBean),getItemDispName(ITEM_ID_SCREEN_DD, m_Abiam03DispBean));
			setError(m_Abiam03DispBean, ITEM_ID_MENU_DD);
			setError(m_Abiam03DispBean, ITEM_ID_SCREEN_DD);
			ret = false;
		}


		return ret;
	}

	/*************************************************************************************
	 * 登録処理
	 * <p>
	 * 登録処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException, Exception {

		boolean registFlg = true;

		// == 検索条件・更新データ取得 ==
		// 分類コード取得
		String clsCd = m_Abiam03Form.getSavedClsCd();
		// 顧客コード取得
		String cstCd = m_Abiam03Form.getSavedCstCd();
		// 店舗コード取得
		String shopCd = m_Abiam03Form.getSavedShopCd();
		// ユーザーコード取得
		String userCd = m_Abiam03Form.getSavedUserCd();


		// 今回対象画面データリストを取得

		// 入力データ取得
		List<AbiamIndScreenAuthDto> dataList = m_Abiam03Form.getIndScreenDispList();
		// 関連用Map(更新対象)
		Map<String, AbiamIndScreenAuthDto> dataInUpMap = new ConcurrentHashMap<>();
		// 関連用Map(削除対象)
		Map<String, AbiamIndScreenAuthDto> dataDelMap = new ConcurrentHashMap<>();

		for (AbiamIndScreenAuthDto authDto : dataList) {


			// 登録データ判定
			if (authDto.getScrIndAtuhId() == null && !ScrExp.DISPLAY_UNDEFF.equals(authDto.getDispCd())) {
				// IDがないデータが未設定以外の表示コードになっている場合

				// 登録処理
				registFlg = insertIndScrRoleMst(authDto.getScreenId(), clsCd, cstCd, shopCd, userCd, authDto.getDispCd());
				if (registFlg) {
					// マップに格納
					dataInUpMap.put(authDto.getScreenId(), authDto);
					continue;
				} else {
					break;
				}
			}

			// 更新データ判定
			if (authDto.getScrIndAtuhId() != null && !ScrExp.DISPLAY_UNDEFF.equals(authDto.getDispCd())) {
				// IDのあるデータが未設定以外の表示コードになっている場合

				// 更新処理
				registFlg = updateIndScrRoleMst(authDto.getScrIndAtuhId(), authDto.getDispCd(), authDto.getExclusiveKey());
				if (registFlg) {
					// マップに格納
					dataInUpMap.put(authDto.getScreenId(), authDto);
					continue;
				} else {
					break;
				}
			}

			// 削除データ判定
			if (authDto.getScrIndAtuhId() != null && ScrExp.DISPLAY_UNDEFF.equals(authDto.getDispCd())) {
				// IDのあるデータが未設定の表示コードになっている場合

				// 削除処理
				registFlg = deleteIndScrRoleMst(authDto.getScrIndAtuhId(), authDto.getExclusiveKey());
				if (registFlg) {
					// マップに格納
					dataDelMap.put(authDto.getScreenId(), authDto);
					continue;
				} else {
					break;
				}
			}

		}


		// 関連更新情報を取得
		// 汎用マスタから関連画面を取得
		List<AmdtoGeneralMst> generalMsts = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.RELATED_SCREEN, null, null, m_Abiam03DispBean.getServiceDate());
		// 内部保存値からデータを取り出す
		Map<String, AbiamIndScreenAuthDto> chainDataMap = m_Abiam03Dto.getUpdateChainDataMap();

		if (registFlg) {

			// 汎用マスタ取得データを繰り返す
			for (AmdtoGeneralMst mst : generalMsts) {

				if (dataInUpMap.containsKey(mst.getGeneralCd1())) {
					AbiamIndScreenAuthDto orgDto = dataInUpMap.get(mst.getGeneralCd1());

					// 登録用データに存在していた場合
					if (chainDataMap.containsKey(mst.getGeneralCd2())) {
						// 関連データに存在していた場合
						AbiamIndScreenAuthDto compDto = chainDataMap.get(mst.getGeneralCd2());

						// 登録処理判定
						if (compDto.getScrIndAtuhId() == null) {
							// 登録処理
							registFlg = insertIndScrRoleMst(compDto.getScreenId(), clsCd, cstCd, shopCd, userCd,
									orgDto.getDispCd());
							if (!registFlg) {
								break;
							}
						}

						// 更新処理判定
						if (compDto.getScrIndAtuhId() != null) {
							registFlg = updateIndScrRoleMst(compDto.getScrIndAtuhId(), orgDto.getDispCd(),
									compDto.getExclusiveKey());
							if (!registFlg) {
								break;
							}
						}

					}
					continue;
				}
				if (dataDelMap.containsKey(mst.getGeneralCd1())) {
					// 削除用データに存在していた場合
					if (chainDataMap.containsKey(mst.getGeneralCd2())) {
						// 関連データに存在していた場合
						AbiamIndScreenAuthDto compDto = chainDataMap.get(mst.getGeneralCd2());

						// 削除処理
						registFlg = deleteIndScrRoleMst(compDto.getScrIndAtuhId(), compDto.getExclusiveKey());
						if (!registFlg) {
							break;
						}
					}

				}
				continue;
			}

		}

		// DB処理正常判定
		if (registFlg) {
			// コミット処理
			m_DbAccess.commit();
			// 正常完了処理メッセージ
			setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_INF_NML_REGIST_END_RELOGIN);

			// 再検索処理
			m_Abiam03Form.setSelectedClsCd(m_Abiam03Form.getSavedClsCd());
			m_Abiam03Form.setInputedCstCd(m_Abiam03Form.getSavedCstCd());
			m_Abiam03Form.setInputedShopCd(m_Abiam03Form.getSavedShopCd());
			m_Abiam03Form.setInputedUserCd(m_Abiam03Form.getSavedUserCd());
			m_Abiam03Form.setSelectedCategoryCd(m_Abiam03Form.getSavedCategoryCd());
			m_Abiam03Form.setSelectedMenuCd(m_Abiam03Form.getSavedMenuCd());
			m_Abiam03Form.setSelectedScreenCd(m_Abiam03Form.getSavedScreenCd());

			search();
		}


		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * プルダウンリスト取得処理
	 * <p>
	 * 画面に表示するプルダウンリストの値を取得する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private void getDropDownListData() throws AmallException, Exception {

		// カテゴリ一覧を取得する
		m_Abiam03DispBean.setCategoryDropDownList(getMenuGrpList(true));

		// メニュー一覧を取得する
		m_Abiam03DispBean.setMenuDropDownList(getMenuGrpList(false));

		// 画面(メニュー)一覧を取得する
		m_Abiam03DispBean.setScreenDropDownList(getScreenMenuList());

		// 表示可否一覧を取得する
		m_Abiam03DispBean.setDispDropDownList(getIndDispProprietyList(m_Abiam03DispBean.getServiceDate()));

		// 分類一覧を取得する
		m_Abiam03DispBean.setClsDropDownList(getClsProprietyList(m_Abiam03DispBean.getServiceDate()));

	}
	/*************************************************************************************
	 * データマージ処理
	 * <p>
	 * 2種類のリストをマージしてデータを作成する
	 * </p>
	 * @param  screenList 画面DTOリスト
	 * @param  authList 個別権限リスト
	 * @return List<AbiamIndScreenAuthDto> マージ後リスト
	 ************************************************************************************/
	private List<AbiamIndScreenAuthDto> getMergeDataList(List<AbiamIndScreenAuthDto> screenList, List<AbiamIndScreenAuthDto> authList) {

		// 返却リスト
		List<AbiamIndScreenAuthDto> retList = new ArrayList<>();

		// 画面DTOリストを繰り返す
		for (AbiamIndScreenAuthDto scrDto : screenList) {

			// DTOを生成
			AbiamIndScreenAuthDto dto = new AbiamIndScreenAuthDto();
			// 画面コード
			dto.setScreenId(scrDto.getScreenId());
			// カテゴリ名
			dto.setCategoryName(scrDto.getCategoryName());
			// メニュー名
			dto.setMenuName(scrDto.getMenuName());
			// 画面名
			dto.setScreenName(scrDto.getScreenName());
			// 表示可否を初期化
			dto.setDispCd(ScrExp.DISPLAY_UNDEFF);

			// 個別権限リストを繰り返す
			for (AbiamIndScreenAuthDto authDto : authList) {

				if(authDto.getScreenId().equals(scrDto.getScreenId())) {
					// 画面IDが一致した場合
					// 表示可否
					dto.setDispCd(authDto.getDispCd());
					// 画面個別権限Id
					dto.setScrIndAtuhId(authDto.getScrIndAtuhId());
					// 排他キー
					dto.setExclusiveKey(authDto.getExclusiveKey());
					break;
				}
			}

			retList.add(dto);
		}
		return retList;

	}
	/*************************************************************************************
	 * 関連画面データ作成処理
	 * <p>
	 * 汎用マスタから関連画面を取得し，メニューに出てこない画面で
	 * 別の画面が制限された場合にともに制限を設定する必要のある画面用データを作成し
	 * 内部記憶にセットする。
	 * </p>
	 * @param  authList 画面権限リスト
	 * @return List<AbiamIndScreenAuthDto> 画面DTOリスト
	 ************************************************************************************/
	private void getChainDataList( List<AbiamIndScreenAuthDto> authList) throws AmallException, Exception {

		// 返却リスト
		Map<String, AbiamIndScreenAuthDto> retMap = new ConcurrentHashMap<>();

		// 汎用マスタから関連画面を取得
		List<AmdtoGeneralMst> generalMsts = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.RELATED_SCREEN, null, null, m_Abiam03DispBean.getServiceDate());

		// 取得データを繰り返す
		for (AmdtoGeneralMst mst : generalMsts) {
			// DTOを生成
			AbiamIndScreenAuthDto dto = new AbiamIndScreenAuthDto();

			// 画面コード
			dto.setScreenId(mst.getGeneralCd2());
			// 画面名
			dto.setScreenName(mst.getGeneralNm2());
			// 表示可否を初期化
			dto.setDispCd(ScrExp.DISPLAY_UNDEFF);

			// 個別権限リストを繰り返す
			for (AbiamIndScreenAuthDto authDto : authList) {

				if(authDto.getScreenId().equals(dto.getScreenId())) {
					// 画面IDが一致した場合
					// 表示可否
					dto.setDispCd(authDto.getDispCd());
					// 画面個別権限Id
					dto.setScrIndAtuhId(authDto.getScrIndAtuhId());
					// 排他キー
					dto.setExclusiveKey(authDto.getExclusiveKey());
					break;
				}
			}

			// マップに設定
			retMap.put(dto.getScreenId(), dto);
		}
		// 生成したデータを内部記憶に設定
		m_Abiam03Dto.setUpdateChainDataMap(retMap);

	}
	/*************************************************************************************
	 * 画面メニューグループマスタ(DB)取得
	 * <p>
	 * 画面メニューグループマスタ(DB)からデータを取得する
	 * 画面の検索条件と合致する画面DTOの一覧を取得する、取得されるデータはメニュー表示可否ONの画面のみ
	 * </p>
	 * @param  categoryCd 画面グループコード(カテゴリ)
	 * @param  menuCd 画面グループコード(メニュー)
	 * @param  screenCd 画面コード
	 * @return List<AbiamIndScreenAuthDto> 画面DTOリスト
	 ************************************************************************************/
	private List<AbiamIndScreenAuthDto> getScreenGrpMst(String categoryCd, String menuCd, String screenCd) throws AmallException, Exception {

		String methodName = "getScreenGrpMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<AbiamIndScreenAuthDto> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	C.SCREEN_CD");
			sql.append(",	D.MENU_GRP_NM AS CATEGORY_NM");
			sql.append(",	C.MENU_GRP_NM AS MENU_NM");
			sql.append(",	C.MENU_NM AS SCREEN_NM");
			sql.append("  FROM");
			sql.append("	(");
			sql.append("		SELECT");
			sql.append("			B.PARENT_MENU_GRP_CD");
			sql.append("			,B.MENU_GRP_CD");
			sql.append("			,B.MENU_GRP_NM");
			sql.append("			,A.SCREEN_CD");
			sql.append("			,A.MENU_NM");
			sql.append("		  FROM");
			sql.append("			(");
			sql.append("				SELECT");
			sql.append("					MENU_GRP_CD");
			sql.append("					,SCREEN_CD");
			sql.append("					,MENU_NM");
			sql.append("				  FROM");
			sql.append("					N_MENU_M");
			sql.append("				 WHERE");
			sql.append("					VISIBLE = ?");
			sql.append("					AND DEL_FLG = ?");
			sql.append("			) A,");
			sql.append("			N_MENU_GRP_M B");
			sql.append("		 WHERE");
			sql.append("			B.MENU_GRP_CD = A.MENU_GRP_CD");
			sql.append("			AND B.DEL_FLG = ?");
			sql.append("	) C,");
			sql.append("	N_MENU_GRP_M D");
			sql.append(" WHERE");
			sql.append("	D.MENU_GRP_CD = C.PARENT_MENU_GRP_CD");
			sql.append("	AND D.DEL_FLG = ?");
			// カテゴリコード
			if (!AmallUtilities.isEmpty(categoryCd)) {
				sql.append("	AND D.MENU_GRP_CD = ?");
				// メニューコード
				if (!AmallUtilities.isEmpty(menuCd)) {
					sql.append("	AND C.MENU_GRP_CD = ?");
					// 画面コード
					if (!AmallUtilities.isEmpty(screenCd)) {
						sql.append("	AND C.SCREEN_CD = ?");
					}
				}
			}
			sql.append(" ORDER BY");
			sql.append("	D.MENU_GRP_CD");
			sql.append(",	C.MENU_GRP_CD");
			sql.append(",	C.SCREEN_CD");
			m_DbAccess.createPreparedStatement(sql.toString());

			// 条件設定
			int setCnt = 0;
			// 表示可否
			m_DbAccess.setString(++setCnt, ScrExp.DISPLAY_ON);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// カテゴリコード
			if (!AmallUtilities.isEmpty(categoryCd)) {
				m_DbAccess.setString(++setCnt, categoryCd);
				// メニューコード
				if (!AmallUtilities.isEmpty(menuCd)) {
					m_DbAccess.setString(++setCnt, menuCd);
					// 画面コード
					if (!AmallUtilities.isEmpty(screenCd)) {
						m_DbAccess.setString(++setCnt, screenCd);
					}
				}
			}
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				AbiamIndScreenAuthDto dto = new AbiamIndScreenAuthDto();
				// 画面コード
				dto.setScreenId(m_DbAccess.getString(rs, "SCREEN_CD"));
				// カテゴリ名
				dto.setCategoryName(m_DbAccess.getString(rs, "CATEGORY_NM"));
				// メニュー名
				dto.setMenuName(m_DbAccess.getString(rs, "MENU_NM"));
				// 画面名
				dto.setScreenName(m_DbAccess.getString(rs, "SCREEN_NM"));

				// リストに追加
				retList.add(dto);

			}
			return retList;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_MENU_M,N_MENU_GRP_M,N_MENU_GRP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 画面個別権限マスタ(DB)取得
	 * <p>
	 * 画面権限マスタ(DB)からデータを取得する
	 * </p>
	 * @param  clsCd 分類コード
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @param  userCd ユーザーコード
	 * @return List<AbiamIndScreenAuthDto> 表示項目リスト
	 ************************************************************************************/
	private List<AbiamIndScreenAuthDto> getIndScreenRoleMst(String clsCd, String cstCd, String shopCd, String userCd) throws AmallException, Exception {

		String methodName = "getIndScreenRoleMst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用リスト
		List<AbiamIndScreenAuthDto> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	SCREEN_EXP_AUTH_ID");
			sql.append(",	SCREEN_CD");
			sql.append(",	VISIBLE");
			sql.append(",	EXCLUSIVE_KEY");
			sql.append("  FROM");
			sql.append("	N_SCREEN_EXP_AUTH_M");
			sql.append(" WHERE");
			sql.append("	EXP_TYPE = ?");
			sql.append("	AND EXP_CD = ?");
			sql.append("	AND DEL_FLG = ?");

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 分類
			m_DbAccess.setString(++setCnt, clsCd);

			// 分類コードによるチェック分岐
			if (ScrExp.EXP_TYPE_CUSTOMER.equals(clsCd)) {
				// 顧客
				m_DbAccess.setString(++setCnt, cstCd);
			} else 	if (ScrExp.EXP_TYPE_SHOP.equals(clsCd)) {
				// 店舗
				m_DbAccess.setString(++setCnt, cstCd + shopCd);
			} else 	if (ScrExp.EXP_TYPE_USER.equals(clsCd)) {
				// ユーザー
				m_DbAccess.setString(++setCnt, userCd);
			}

			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				// DTOの生成
				AbiamIndScreenAuthDto dto = new AbiamIndScreenAuthDto();
				// 画面コード
				dto.setScreenId(m_DbAccess.getString(rs, "SCREEN_CD"));
				// 画面個別権限ID
				dto.setScrIndAtuhId(rs.getLong("SCREEN_EXP_AUTH_ID"));
				// 表示可否
				dto.setDispCd(m_DbAccess.getString(rs, "VISIBLE"));
				// 排他キー
				Long key = rs.getLong("EXCLUSIVE_KEY");
				if (rs.wasNull()) {
					dto.setExclusiveKey(null);
				} else {
					dto.setExclusiveKey(key);
				}

				// リストに追加
				retList.add(dto);
			}

			return retList;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_ROLE_GRP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 顧客マスタ(DB)ユニークチェック
	 * <p>
	 * 顧客マスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できる場合はActionFormに値を設定し，
	 * 特定できない場合はfalseで返却する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @return boolean true:正常 false:異常
	 ************************************************************************************/
	private boolean chkUniqCst(String cstCd) throws AmallException, Exception {

		String methodName = "chkUniqCst()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用チェックリスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	CST_NM");
			sql.append("  FROM");
			sql.append("	N_CST_M");
			sql.append(" WHERE");
			sql.append("	DEL_FLG = ?");
			sql.append("	AND CST_CD = ?");
			// 顧客範囲設定
			// 全顧客判定
			if (!m_Abiam03DispBean.isCustomerCdAllFlg()) {
				// 全顧客ではない場合
				sql.append("	AND CST_CD IN (");
				for (String appCustomer : m_Abiam03DispBean.getCustomerCdList()) {
					sql.append("'").append(appCustomer).append("',");
				}
				sql.append("'')");
			}

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				// 店舗名
				String name = m_DbAccess.getString(rs, "CST_NM");

				// リストに追加
				retList.add(name);
			}

			// 結果チェック
			if(retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}

			// 値を設定
			m_Abiam03Form.setDispCstNm(retList.get(0));

			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_CST_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}

	/*************************************************************************************
	 * 店舗マスタ(DB)ユニークチェック
	 * <p>
	 * 店舗マスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できる場合はActionFormに値を設定し，
	 * 特定できない場合はfalseで返却する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @return boolean true:正常 false:異常
	 ************************************************************************************/
	private boolean chkUniqShop(String cstCd, String shopCd) throws AmallException, Exception {

		String methodName = "chkUniqShop()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用チェックリスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	ncm.CST_CD");
			sql.append(",	ncm.CST_NM");
			sql.append(",	nsm.SHOP_NM");
			sql.append(",	TRIM(nscm.COMPANY_SHOP_NM) AS COMPANY_SHOP_NM");
			sql.append("  FROM");
			sql.append("  	N_SHOP_M nsm");
			sql.append("	LEFT JOIN");
			sql.append("		N_CST_M ncm");
			sql.append("	  ON");
			sql.append("		nsm.CST_CD = ncm.CST_CD");
			sql.append("		AND ncm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_CNV_M nscm");
			sql.append("	  ON");
			sql.append("		nsm.CST_CD = nscm.CST_CD");
			sql.append("		AND nsm.SHOP_CD = nscm.SHOP_CD");
			sql.append("		AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
			sql.append("		AND nscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append(" WHERE");
			sql.append("	nsm.DEL_FLG = ?");
			sql.append("	AND ? BETWEEN nsm.EFST_DY AND nsm.EFED_DY");
			sql.append("	AND nsm.CST_CD = ?");
			sql.append("	AND (");
			sql.append("			nsm.SHOP_CD = ?");
			sql.append("			OR");
			sql.append("			TRIM(nscm.COMPANY_SHOP_CD) = ?");
			sql.append("		)");
			// 店舗範囲設定
			// 全店舗判定
			if (!m_Abiam03DispBean.isShopCdAllFlg()) {
				// 全顧客・全店舗ではない場合
				sql.append("	AND (");
				boolean first = true;
				for (Entry<String, List<String>> entry : m_Abiam03DispBean.getShopCdListMap().entrySet()) {

					String appCstCd = entry.getKey();
					for (String appShop : entry.getValue()) {
						if (first) {
							sql.append("		");
							first = false;
						} else {
							sql.append("		OR");
						}
						sql.append("		(");
						sql.append("			nsm.CST_CD = '").append(appCstCd).append("'");
						sql.append("			AND");
						sql.append("			nsm.SHOP_CD = '").append(appShop).append("'");
						sql.append("		)");
					}
				}
				sql.append("	)");
			}


			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 有効期限
			m_DbAccess.setString(++setCnt, m_Abiam03DispBean.getServiceDate());
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, m_Abiam03DispBean.getServiceDate());
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);
			// 店舗コード
			m_DbAccess.setString(++setCnt, shopCd);
			// 店舗コード
			m_DbAccess.setString(++setCnt, shopCd);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			String cstCdData = "";
			String cstNmData = "";
			while (rs.next()) {

				// 店舗名
				String name = m_DbAccess.getString(rs, "SHOP_NM");
				// 店舗名(企業)
				String comapany = m_DbAccess.getString(rs, "COMPANY_SHOP_NM");

				// 企業店舗コード判定
				if (AmallUtilities.isEmpty(comapany)) {
					// リストに追加
					retList.add(name);
				} else {
					// 企業店舗コードがある場合は企業店舗を優先
					// リストに追加
					retList.add(comapany);
				}

				// 顧客コード
				cstCdData = m_DbAccess.getString(rs, "CST_CD");
				// 顧客名
				cstNmData = m_DbAccess.getString(rs, "CST_NM");

			}

			// 結果チェック
			if(retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}

			// 値を設定
			m_Abiam03Form.setDispShopNm(retList.get(0));
			m_Abiam03Form.setInputedCstCd(cstCdData);
			m_Abiam03Form.setSavedCstCd(cstCdData);
			m_Abiam03Form.setDispCstNm(cstNmData);

			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_SHOP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}

	/*************************************************************************************
	 * ユーザーマスタ(DB)ユニークチェック
	 * <p>
	 * ユーザーマスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できない場合はnullで返却する
	 * </p>
	 * @param  userCd ユーザーコード
	 * @return String ユーザー名(異常時はnull)
	 ************************************************************************************/
	private boolean chkUniqUser(String userCd) throws AmallException, Exception {

		String methodName = "chkUniqUser()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用チェックリスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	nucm.USER_NM");
			sql.append("  FROM");
			sql.append("	(");
			sql.append("		SELECT");
			sql.append("			USER_ID");
			sql.append(",			USER_NM");
			sql.append(",			DEL_FLG");
			sql.append("		 FROM");
			sql.append("			N_USER_CST_M");
			sql.append("		UNION ALL");
			sql.append("		SELECT");
			sql.append("			USER_ID");
			sql.append(",			USER_NM");
			sql.append(",			DEL_FLG");
			sql.append("		 FROM");
			sql.append("			N_USER_EMP_M");
			sql.append("	) nucm");
			sql.append(" WHERE");
			sql.append("	nucm.USER_ID = ?");
			sql.append("	AND nucm.DEL_FLG = ?");

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;

			// ユーザー
			m_DbAccess.setString(++setCnt, userCd);

			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				String name = m_DbAccess.getString(rs, "USER_NM");
				// リストに追加
				retList.add(name);
			}

			// 結果チェック
			if(retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}
			// 値を設定
			m_Abiam03Form.setDispUserNm(retList.get(0));

			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_USER_CST_M,N_USER_EMP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}

	/*************************************************************************************
	 * 画面個別権限マスタ(DB)更新
	 * <p>
	 * 画面個別権限マスタ(DBを更新する
	 * </p>
	 * @param authPkey 画面個別権限ID
	 * @param dispCd 入力表示可否
	 * @param exKey 排他キー
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	public boolean updateIndScrRoleMst(Long authPkey, String dispCd, Long exKey) throws AmallException {

		String methodName = "updateScrRoleMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// SQL生成
			sql.append("UPDATE");
			sql.append("	N_SCREEN_EXP_AUTH_M");
			sql.append("   SET");
			// 表示可否
			sql.append("	VISIBLE = ?");
			// 共通部分
			sql.append(",	UPD_PGM_ID =  ?");
			sql.append(",	UPD_USER_ID =  ?");
			sql.append(",	UPD_DT =  SYSDATE");
			sql.append(",	EXCLUSIVE_KEY =  EXCLUSIVE_KEY + 1");

			// 条件指定
			sql.append(" WHERE");
			sql.append("	SCREEN_EXP_AUTH_ID =  ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND EXCLUSIVE_KEY = ?");


			// 更新値のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;
			// 表示可否
			m_DbAccess.setString(++setCnt, dispCd);
			// 更新プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 更新ユーザーID
			m_DbAccess.setString(++setCnt, m_Abiam03DispBean.getH_loginId());


			// WHERE句のパラメタ設定
			// 権画面個別権限ID
			m_DbAccess.setLong(++setCnt, authPkey);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 排他キー
			m_DbAccess.setLong(++setCnt, exKey);

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 排他チェック
			if(ret == 0) {
				// 更新対象無し(楽観排他)
				m_DbAccess.rollback();

				// エラー情報を設定
				setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST);

				// アクセスログ情報の作成
				AmallExceptionInfo amei = new AmallExceptionInfo();
				amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_ACS_OPT_ERROR, "N_SCREEN_EXP_AUTH_M"));
				setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

				return false;
			}

			// 更新結果判定
			if (ret != 1) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_SCREEN_EXP_AUTH_M");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_SCREEN_EXP_AUTH_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}
	/*************************************************************************************
	 * 画面個別権限マスタ(DB)登録
	 * <p>
	 * 画面個別権限マスタ(DB)にレコードを登録する
	 * </p>
	 * @param screenId 画面ID
	 * @param clsCd 分類コード
	 * @param cstCd 顧客コード
	 * @param shopCd 店舗コード
	 * @param userCd ユーザーコード
	 * @param dispCd 入力表示可否
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	public boolean insertIndScrRoleMst(String screenId, String clsCd, String cstCd, String shopCd, String userCd, String dispCd) throws AmallException {

		String methodName = "insertIndScrRoleMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// SQL生成
			sql.append("INSERT INTO");
			sql.append("	N_SCREEN_EXP_AUTH_M (");
			sql.append("   		SCREEN_EXP_AUTH_ID");
			sql.append(",  		SCREEN_CD");
			sql.append(",  		EXP_TYPE");
			sql.append(",  		EXP_CD");
			sql.append(",  		VISIBLE");
			sql.append(",  		EXCLUSIVE_KEY");
			sql.append(",  		DEL_FLG");
			sql.append(",  		CR_PGM_ID");
			sql.append(",  		CR_USER_ID");
			sql.append(",  		CR_DT");
			sql.append(",  		UPD_PGM_ID");
			sql.append(",  		UPD_USER_ID");
			sql.append(",  		UPD_DT");
			sql.append("	) VALUES (");
			sql.append("		S_SCREEN_EXP_AUTH_ID.NEXTVAL");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			// 共通部分
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append(",		?");
			sql.append(",		?");
			sql.append(",		SYSDATE");
			sql.append("	)");

			// 登録値のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;

			// 画面コード
			m_DbAccess.setString(++setCnt, screenId);

			// 分類
			m_DbAccess.setString(++setCnt, clsCd);

			// 分類コードによる値分岐
			if (ScrExp.EXP_TYPE_CUSTOMER.equals(clsCd)) {
				// 顧客
				m_DbAccess.setString(++setCnt, cstCd);
			} else 	if (ScrExp.EXP_TYPE_SHOP.equals(clsCd)) {
				// 店舗
				m_DbAccess.setString(++setCnt, cstCd + shopCd);
			} else 	if (ScrExp.EXP_TYPE_USER.equals(clsCd)) {
				// ユーザー
				m_DbAccess.setString(++setCnt, userCd);
			}
			// 表示可否
			m_DbAccess.setString(++setCnt, dispCd);

			// 排他キー
			m_DbAccess.setLong(++setCnt, 0);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 登録プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 登録ユーザーID
			m_DbAccess.setString(++setCnt, m_Abiam03DispBean.getH_loginId());
			// 更新プログラムID
			m_DbAccess.setString(++setCnt, m_ClassName);
			// 更新ユーザーID
			m_DbAccess.setString(++setCnt, m_Abiam03DispBean.getH_loginId());

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 更新結果判定
			if (ret <= 0) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_SCREEN_EXP_AUTH_M");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_SCREEN_EXP_AUTH_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}
	/*************************************************************************************
	 * 画面個別権限マスタ(DB)削除
	 * <p>
	 * 画面個別権限マスタ(DBを削除する
	 * </p>
	 * @param authPkey 画面個別権限ID
	 * @param exKey 排他キー
	 * @return true:正常 false:更新エラー(楽観排他エラー)
	 ************************************************************************************/
	public boolean deleteIndScrRoleMst(Long authPkey, Long exKey) throws AmallException {

		String methodName = "deleteIndScrRoleMst()";
		StringBuffer sql = new StringBuffer();

		try {

			// SQL生成
			sql.append("DELETE FROM");
			sql.append("	N_SCREEN_EXP_AUTH_M");
			// 条件指定
			sql.append(" WHERE");
			sql.append("	SCREEN_EXP_AUTH_ID = ?");
			sql.append("	AND DEL_FLG = ?");
			sql.append("	AND EXCLUSIVE_KEY = ?");


			// パラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString());
			int setCnt = 0;

			// WHERE句のパラメタ設定
			// 画面個別権限ID
			m_DbAccess.setLong(++setCnt, authPkey);
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 排他キー
			m_DbAccess.setLong(++setCnt, exKey);

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 排他チェック
			if(ret == 0) {
				// 更新対象無し(楽観排他)
				m_DbAccess.rollback();

				// エラー情報を設定
				setMessageInfo(m_Abiam03DispBean, AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST);

				// アクセスログ情報の作成
				AmallExceptionInfo amei = new AmallExceptionInfo();
				amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_ACS_OPT_ERROR, "N_SCREEN_EXP_AUTH_M"));
				setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

				return false;
			}

			// 更新結果判定
			if (ret != 1) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_SCREEN_EXP_AUTH_M");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_SCREEN_EXP_AUTH_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}

}