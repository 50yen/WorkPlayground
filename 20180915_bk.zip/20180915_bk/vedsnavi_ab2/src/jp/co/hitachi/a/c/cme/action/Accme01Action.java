/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Accme01Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cme.action;

import java.util.List;

import jp.co.hitachi.a.c.cme.bean.Accme01DispBean;
import jp.co.hitachi.a.c.cme.business.Accme01Business;
import jp.co.hitachi.a.c.cme.dto.AccmeItemDispDto;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Accme01Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Accme01DispBean accme01DispBean;

	/** 顧客CD */
	private String searchCstCd = null;
	/** 顧客名 */
	private String searchCstNm = null;
	/** 店舗CD */
	private String searchShopCd = null;
	/** 店舗名 */
	private String searchShopNm = null;
	/** 店舗枝番 */
	private String searchSbnoCd = null;
	/** 店舗枝番名 */
	private String searchSbnoNm = null;
	/** 売上日From */
	private String sldFrom = null;
	/** 売上日To */
	private String sldTo = null;

	/** プルダウンリスト選択値 */
	private int dispResults = 0;

	/** 選択リスト */
	private List<AccmeItemDispDto> itemDispList = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAccme01DispBean((Accme01DispBean)request.getAttribute("Accme01DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Accme01Business dao = new Accme01Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Accme01DispBean getAccme01DispBean() {
		return accme01DispBean;
	}

	public void setAccme01DispBean(Accme01DispBean accme01DispBean) {
		this.accme01DispBean = accme01DispBean;
	}

	public String getSearchCstCd() {
		return searchCstCd;
	}

	public void setSearchCstCd(String searchCstCd) {
		this.searchCstCd = searchCstCd;
	}

	public String getSearchCstNm() {
		return searchCstNm;
	}

	public void setSearchCstNm(String searchCstNm) {
		this.searchCstNm = searchCstNm;
	}

	public String getSearchShopCd() {
		return searchShopCd;
	}

	public void setSearchShopCd(String searchShopCd) {
		this.searchShopCd = searchShopCd;
	}

	public String getSearchShopNm() {
		return searchShopNm;
	}

	public void setSearchShopNm(String searchShopNm) {
		this.searchShopNm = searchShopNm;
	}

	public String getSearchSbnoCd() {
		return searchSbnoCd;
	}

	public void setSearchSbnoCd(String searchSbnoCd) {
		this.searchSbnoCd = searchSbnoCd;
	}

	public String getSearchSbnoNm() {
		return searchSbnoNm;
	}

	public void setSearchSbnoNm(String searchSbnoNm) {
		this.searchSbnoNm = searchSbnoNm;
	}

	public String getSldFrom() {
		return sldFrom;
	}

	public void setSldFrom(String sldFrom) {
		this.sldFrom = sldFrom;
	}

	public String getSldTo() {
		return sldTo;
	}

	public void setSldTo(String sldTo) {
		this.sldTo = sldTo;
	}

	public int getDispResults() {
		return dispResults;
	}

	public void setDispResults(int dispResults) {
		this.dispResults = dispResults;
	}

	public List<AccmeItemDispDto> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<AccmeItemDispDto> itemDispList) {
		this.itemDispList = itemDispList;
	}



}
