/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Actmp02Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * ActmpItemDispDtoクラス<br>
 *****************************************************************************************/
public class AcechItemDispDto extends AmclsDtoBase {

	/** メンバ変数 */
	/** 顧客CD */
	private String cstCd = null;
	/** 顧客名 */
	private String cstNm = null;
	/** 店舗CD */
	private String shopCd = null;
	/** 店舗名 */
	private String shopNm = null;
	/** 店舗枝番 */
	private String shopSbno = null;
	/** 店舗枝番名称 */
	private String mcdSchNm = null;
	/** 回収日 */
	private String cld = null;
	/** 売上日 */
	private String sld = null;
	/** 差額 */
	private String spccDfemt = null;
	/** 金種表登録合計 */
	private String spccmTotal = null;
	/** 精査金額計 */
	private String srmTotal = null;
	/** 差額フラグ */
	private String defFlg = null;
	/** レジ別詳細 */
	private String registerDtl = null;
	/** 店舗CD(遷移用) */
	private String shopCdsp = null;
	/** 店舗枝番(遷移用) */
	private String shopSbnosp = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AcechItemDispDto() {
		clear();
	}

	/*************************************************************************************
	 * クリア
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		cstCd = null;
		cstNm = null;
		shopCd = null;
		shopNm = null;
		shopSbno = null;
		mcdSchNm = null;
		cld = null;
		sld = null;
		spccDfemt = null;
		spccmTotal = null;
		srmTotal = null;
		defFlg = null;
		registerDtl = null;
		shopCdsp = null;
		shopSbnosp = null;
	}

	public String getCstCd() {
		return cstCd;
	}

	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}

	public String getCstNm() {
		return cstNm;
	}

	public void setCstNm(String cstNm) {
		this.cstNm = cstNm;
	}

	public String getShopCd() {
		return shopCd;
	}

	public void setShopCd(String shopCd) {
		this.shopCd = shopCd;
	}

	public String getShopNm() {
		return shopNm;
	}

	public void setShopNm(String shopNm) {
		this.shopNm = shopNm;
	}

	public String getShopSbno() {
		return shopSbno;
	}

	public void setShopSbno(String shopSbno) {
		this.shopSbno = shopSbno;
	}

	public String getMcdSchNm() {
		return mcdSchNm;
	}

	public void setMcdSchNm(String mcdSchNm) {
		this.mcdSchNm = mcdSchNm;
	}

	public String getCld() {
		return cld;
	}

	public void setCld(String cld) {
		this.cld = cld;
	}

	public String getSld() {
		return sld;
	}

	public void setSld(String sld) {
		this.sld = sld;
	}

	public String getSpccDfemt() {
		return spccDfemt;
	}

	public void setSpccDfemt(String spccDfemt) {
		this.spccDfemt = spccDfemt;
	}

	public String getSpccmTotal() {
		return spccmTotal;
	}

	public void setSpccmTotal(String spccmTotal) {
		this.spccmTotal = spccmTotal;
	}

	public String getSrmTotal() {
		return srmTotal;
	}

	public void setSrmTotal(String srmTotal) {
		this.srmTotal = srmTotal;
	}

	public String getDefFlg() {
		return defFlg;
	}

	public void setDefFlg(String defFlg) {
		this.defFlg = defFlg;
	}

	public String getRegisterDtl() {
		return registerDtl;
	}

	public void setRegisterDtl(String registerDtl) {
		this.registerDtl = registerDtl;
	}

	public String getShopCdsp() {
		return shopCdsp;
	}

	public void setShopCdsp(String shopCdsp) {
		this.shopCdsp = shopCdsp;
	}

	public String getShopSbnosp() {
		return shopSbnosp;
	}

	public void setShopSbnosp(String shopSbnosp) {
		this.shopSbnosp = shopSbnosp;
	}

}
