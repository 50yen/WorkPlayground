/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech41DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.bean;

import jp.co.hitachi.a.m.cls.AmclsBeanBase;

/*****************************************************************************************
 * Acech41DispBeanクラス<br>
 *****************************************************************************************/
public class Acech41DispBean extends AmclsBeanBase {

	/** メンバ変数 */
	/** 回収日 */
	private String cld = null;
	/** 顧客名 */
	private String customerNm = null;
	/** 店舗名 */
	private String storeNm = null;
	/** 店舗枝番 */
	private String shopSbno = null;
	/** 誤差コメント */
	private String dferpNote = null;

	/** 紙幣 */
	/** 10000円　ラベル */
	private String tenThousandYen = null;
	/** 10000円枚数　過不足 */
	private String dfemt10000bills = null;
	/** 10000円金額　過不足 */
	private String dfemt10000yen = null;
	/** 10000円　過不足フラグ */
	private String defFlg10000 = null;
	/** 10000円枚数　お客様勘定明細 */
	private String spcc10000bills = null;
	/** 10000円金額　お客様勘定明細 */
	private String spcc10000yen = null;
	/** 10000円枚数　精査実績 */
	private String scr10000bills = null;
	/** 10000円金額　精査実績 */
	private String scr10000yen = null;

	/** 5000円　ラベル */
	private String fiveThousandYen = null;
	/** 5000円枚数　過不足 */
	private String dfemt5000bills = null;
	/** 5000円金額　過不足 */
	private String dfemt5000yen = null;
	/** 5000円　過不足フラグ */
	private String defFlg5000 = null;
	/** 5000円枚数　お客様勘定明細 */
	private String spcc5000bills = null;
	/** 5000円金額　お客様勘定明細 */
	private String spcc5000yen = null;
	/** 5000円枚数　精査実績 */
	private String scr5000bills = null;
	/** 5000円金額　精査実績 */
	private String scr5000yen = null;

	/** 2000円　ラベル */
	private String twoThousandYen = null;
	/** 2000円枚数　過不足 */
	private String dfemt2000bills = null;
	/** 2000円金額　過不足 */
	private String dfemt2000yen = null;
	/** 2000円　過不足フラグ */
	private String defFlg2000 = null;
	/** 2000円枚数　お客様勘定明細 */
	private String spcc2000bills = null;
	/** 2000円金額　お客様勘定明細 */
	private String spcc2000yen = null;
	/** 2000円枚数　精査実績 */
	private String scr2000bills = null;
	/** 2000円金額　精査実績 */
	private String scr2000yen = null;

	/** 1000円　ラベル */
	private String oneThousandYen = null;
	/** 1000円枚数　過不足 */
	private String dfemt1000bills = null;
	/** 1000円金額　過不足 */
	private String dfemt1000yen = null;
	/** 1000円　過不足フラグ */
	private String defFlg1000 = null;
	/** 1000円枚数　お客様勘定明細 */
	private String spcc1000bills = null;
	/** 1000円金額　お客様勘定明細 */
	private String spcc1000yen = null;
	/** 1000円枚数　精査実績 */
	private String scr1000bills = null;
	/** 1000円金額　精査実績 */
	private String scr1000yen = null;

	/** 過不足　紙幣合計 */
	private String dfemtBillTotal = null;
	/** お客様勘定明細　紙幣合計 */
	private String spccBillTotal = null;
	/** 精査実績　紙幣合計 */
	private String scrBillTotal = null;
	/** 紙幣　過不足フラグ */
	private String defFlgBills = null;

	/** 硬貨 */
	/** 500円　ラベル */
	private String fiveHundredYen = null;
	/** 500円枚数　過不足 */
	private String dfemt500coins = null;
	/** 500円金額　過不足 */
	private String dfemt500yen = null;
	/** 500円　過不足フラグ */
	private String defFlg500 = null;
	/** 500円枚数　お客様勘定明細 */
	private String spcc500coins = null;
	/** 500円金額　お客様勘定明細 */
	private String spcc500yen = null;
	/** 500円枚数　精査実績 */
	private String scr500coins = null;
	/** 500円金額　精査実績 */
	private String scr500yen = null;

	/** 100円　ラベル */
	private String oneHundredYen = null;
	/** 100円枚数　過不足 */
	private String dfemt100coins = null;
	/** 100円金額　過不足 */
	private String dfemt100yen = null;
	/** 100円　過不足フラグ */
	private String defFlg100 = null;
	/** 100円枚数　お客様勘定明細 */
	private String spcc100coins = null;
	/** 100円金額　お客様勘定明細 */
	private String spcc100yen = null;
	/** 100円枚数　精査実績 */
	private String scr100coins = null;
	/** 100円金額　精査実績 */
	private String scr100yen = null;

	/** 50円　ラベル */
	private String fiftyYen = null;
	/** 50円枚数　過不足 */
	private String dfemt50coins = null;
	/** 50円金額　過不足 */
	private String dfemt50yen = null;
	/** 50円　過不足フラグ */
	private String defFlg50 = null;
	/** 50円枚数　お客様勘定明細 */
	private String spcc50coins = null;
	/** 50円金額　お客様勘定明細 */
	private String spcc50yen = null;
	/** 50円枚数　精査実績 */
	private String scr50coins = null;
	/** 50円金額　精査実績 */
	private String scr50yen = null;

	/** 10円　ラベル */
	private String tenYen = null;
	/** 10円枚数　過不足 */
	private String dfemt10coins = null;
	/** 10円金額　過不足 */
	private String dfemt10yen = null;
	/** 10円　過不足フラグ */
	private String defFlg10 = null;
	/** 10円枚数　お客様勘定明細 */
	private String spcc10coins = null;
	/** 10円金額　お客様勘定明細 */
	private String spcc10yen = null;
	/** 10円枚数　精査実績 */
	private String scr10coins = null;
	/** 10円金額　精査実績 */
	private String scr10yen = null;

	/** 5円　ラベル */
	private String fiveYen = null;
	/** 5円枚数　過不足 */
	private String dfemt5coins = null;
	/** 5円金額　過不足 */
	private String dfemt5yen = null;
	/** 5円　過不足フラグ */
	private String defFlg5 = null;
	/** 5円枚数　お客様勘定明細 */
	private String spcc5coins = null;
	/** 5円金額　お客様勘定明細 */
	private String spcc5yen = null;
	/** 5円枚数　精査実績 */
	private String scr5coins = null;
	/** 5円金額　精査実績 */
	private String scr5yen = null;

	/** 1円　ラベル */
	private String oneYen = null;
	/** 1円枚数　過不足 */
	private String dfemt1coins = null;
	/** 1円金額　過不足 */
	private String dfemt1yen = null;
	/** 1円　過不足フラグ */
	private String defFlg1 = null;
	/** 1円枚数　お客様勘定明細 */
	private String spcc1coins = null;
	/** 1円金額　お客様勘定明細 */
	private String spcc1yen = null;
	/** 1円枚数　精査実績 */
	private String scr1coins = null;
	/** 1円金額　精査実績 */
	private String scr1yen = null;

	/** 過不足　硬貨合計 */
	private String DfemtCoinTotal = null;
	/** お客様勘定明細　硬貨合計 */
	private String spccCoinTotal = null;
	/** 精査実績　硬貨合計 */
	private String scrCoinTotal = null;
	/** 硬貨　過不足フラグ */
	private String defFlgCoins = null;

	/** 差額 */
	private String spccDfemt = null;
	/** お客様勘定明細合計 */
	private String spccmTotal = null;
	/** 精査金額計 */
	private String srmTotal = null;
	/** 差額フラグ */
	private String defFlg = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Acech41DispBean() {
		super();
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		super.clear();
		cld = null;
		customerNm = null;
		storeNm = null;
		shopSbno = null;
		dferpNote = null;
		tenThousandYen = null;
		dfemt10000bills = null;
		dfemt10000yen = null;
		defFlg10000 = null;
		spcc10000bills = null;
		spcc10000yen = null;
		scr10000bills = null;
		scr10000yen = null;
		fiveThousandYen = null;
		dfemt5000bills = null;
		dfemt5000yen = null;
		defFlg5000 = null;
		spcc5000bills = null;
		spcc5000yen = null;
		scr5000bills = null;
		scr5000yen = null;
		twoThousandYen = null;
		dfemt2000bills = null;
		dfemt2000yen = null;
		defFlg2000 = null;
		spcc2000bills = null;
		spcc2000yen = null;
		scr2000bills = null;
		scr2000yen = null;
		oneThousandYen = null;
		dfemt1000bills = null;
		dfemt1000yen = null;
		defFlg1000 = null;
		spcc1000bills = null;
		spcc1000yen = null;
		scr1000bills = null;
		scr1000yen = null;
		dfemtBillTotal = null;
		spccBillTotal = null;
		scrBillTotal = null;
		defFlgBills = null;
		fiveHundredYen = null;
		dfemt500coins = null;
		dfemt500yen = null;
		defFlg500 = null;
		spcc500coins = null;
		spcc500yen = null;
		scr500coins = null;
		scr500yen = null;
		oneHundredYen = null;
		dfemt100coins = null;
		dfemt100yen = null;
		defFlg100 = null;
		spcc100coins = null;
		spcc100yen = null;
		scr100coins = null;
		scr100yen = null;
		fiftyYen = null;
		dfemt50coins = null;
		dfemt50yen = null;
		defFlg50 = null;
		spcc50coins = null;
		spcc50yen = null;
		scr50coins = null;
		scr50yen = null;
		tenYen = null;
		dfemt10coins = null;
		dfemt10yen = null;
		defFlg10 = null;
		spcc10coins = null;
		spcc10yen = null;
		scr10coins = null;
		scr10yen = null;
		fiveYen = null;
		dfemt5coins = null;
		dfemt5yen = null;
		defFlg5 = null;
		spcc5coins = null;
		spcc5yen = null;
		scr5coins = null;
		scr5yen = null;
		oneYen = null;
		dfemt1coins = null;
		dfemt1yen = null;
		defFlg1 = null;
		spcc1coins = null;
		spcc1yen = null;
		scr1coins = null;
		scr1yen = null;
		DfemtCoinTotal = null;
		spccCoinTotal = null;
		scrCoinTotal = null;
		defFlgCoins = null;

		spccDfemt = null;
		spccmTotal = null;
		srmTotal = null;
		defFlg = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getCld() {
		return cld;
	}

	public void setCld(String cld) {
		this.cld = cld;
	}

	public String getCustomerNm() {
		return customerNm;
	}

	public void setCustomerNm(String customerNm) {
		this.customerNm = customerNm;
	}

	public String getStoreNm() {
		return storeNm;
	}

	public void setStoreNm(String storeNm) {
		this.storeNm = storeNm;
	}

	public String getShopSbno() {
		return shopSbno;
	}

	public void setShopSbno(String shopSbno) {
		this.shopSbno = shopSbno;
	}

	public String getDferpNote() {
		return dferpNote;
	}

	public void setDferpNote(String dferpNote) {
		this.dferpNote = dferpNote;
	}

	public String getTenThousandYen() {
		return tenThousandYen;
	}

	public void setTenThousandYen(String tenThousandYen) {
		this.tenThousandYen = tenThousandYen;
	}

	public String getDfemt10000bills() {
		return dfemt10000bills;
	}

	public void setDfemt10000bills(String dfemt10000bills) {
		this.dfemt10000bills = dfemt10000bills;
	}

	public String getDfemt10000yen() {
		return dfemt10000yen;
	}

	public void setDfemt10000yen(String dfemt10000yen) {
		this.dfemt10000yen = dfemt10000yen;
	}

	public String getSpcc10000bills() {
		return spcc10000bills;
	}

	public void setSpcc10000bills(String spcc10000bills) {
		this.spcc10000bills = spcc10000bills;
	}

	public String getSpcc10000yen() {
		return spcc10000yen;
	}

	public void setSpcc10000yen(String spcc10000yen) {
		this.spcc10000yen = spcc10000yen;
	}

	public String getScr10000bills() {
		return scr10000bills;
	}

	public void setScr10000bills(String scr10000bills) {
		this.scr10000bills = scr10000bills;
	}

	public String getScr10000yen() {
		return scr10000yen;
	}

	public void setScr10000yen(String scr10000yen) {
		this.scr10000yen = scr10000yen;
	}

	public String getFiveThousandYen() {
		return fiveThousandYen;
	}

	public void setFiveThousandYen(String fiveThousandYen) {
		this.fiveThousandYen = fiveThousandYen;
	}

	public String getDfemt5000bills() {
		return dfemt5000bills;
	}

	public void setDfemt5000bills(String dfemt5000bills) {
		this.dfemt5000bills = dfemt5000bills;
	}

	public String getDfemt5000yen() {
		return dfemt5000yen;
	}

	public void setDfemt5000yen(String dfemt5000yen) {
		this.dfemt5000yen = dfemt5000yen;
	}

	public String getSpcc5000bills() {
		return spcc5000bills;
	}

	public void setSpcc5000bills(String spcc5000bills) {
		this.spcc5000bills = spcc5000bills;
	}

	public String getSpcc5000yen() {
		return spcc5000yen;
	}

	public void setSpcc5000yen(String spcc5000yen) {
		this.spcc5000yen = spcc5000yen;
	}

	public String getScr5000bills() {
		return scr5000bills;
	}

	public void setScr5000bills(String scr5000bills) {
		this.scr5000bills = scr5000bills;
	}

	public String getScr5000yen() {
		return scr5000yen;
	}

	public void setScr5000yen(String scr5000yen) {
		this.scr5000yen = scr5000yen;
	}

	public String getTwoThousandYen() {
		return twoThousandYen;
	}

	public void setTwoThousandYen(String twoThousandYen) {
		this.twoThousandYen = twoThousandYen;
	}

	public String getDfemt2000bills() {
		return dfemt2000bills;
	}

	public void setDfemt2000bills(String dfemt2000bills) {
		this.dfemt2000bills = dfemt2000bills;
	}

	public String getDfemt2000yen() {
		return dfemt2000yen;
	}

	public void setDfemt2000yen(String dfemt2000yen) {
		this.dfemt2000yen = dfemt2000yen;
	}

	public String getSpcc2000bills() {
		return spcc2000bills;
	}

	public void setSpcc2000bills(String spcc2000bills) {
		this.spcc2000bills = spcc2000bills;
	}

	public String getSpcc2000yen() {
		return spcc2000yen;
	}

	public void setSpcc2000yen(String spcc2000yen) {
		this.spcc2000yen = spcc2000yen;
	}

	public String getScr2000bills() {
		return scr2000bills;
	}

	public void setScr2000bills(String scr2000bills) {
		this.scr2000bills = scr2000bills;
	}

	public String getScr2000yen() {
		return scr2000yen;
	}

	public void setScr2000yen(String scr2000yen) {
		this.scr2000yen = scr2000yen;
	}

	public String getOneThousandYen() {
		return oneThousandYen;
	}

	public void setOneThousandYen(String oneThousandYen) {
		this.oneThousandYen = oneThousandYen;
	}

	public String getDfemt1000bills() {
		return dfemt1000bills;
	}

	public void setDfemt1000bills(String dfemt1000bills) {
		this.dfemt1000bills = dfemt1000bills;
	}

	public String getDfemt1000yen() {
		return dfemt1000yen;
	}

	public void setDfemt1000yen(String dfemt1000yen) {
		this.dfemt1000yen = dfemt1000yen;
	}

	public String getSpcc1000bills() {
		return spcc1000bills;
	}

	public void setSpcc1000bills(String spcc1000bills) {
		this.spcc1000bills = spcc1000bills;
	}

	public String getSpcc1000yen() {
		return spcc1000yen;
	}

	public void setSpcc1000yen(String spcc1000yen) {
		this.spcc1000yen = spcc1000yen;
	}

	public String getScr1000bills() {
		return scr1000bills;
	}

	public void setScr1000bills(String scr1000bills) {
		this.scr1000bills = scr1000bills;
	}

	public String getScr1000yen() {
		return scr1000yen;
	}

	public void setScr1000yen(String scr1000yen) {
		this.scr1000yen = scr1000yen;
	}

	public String getDfemtBillTotal() {
		return dfemtBillTotal;
	}

	public void setDfemtBillTotal(String dfemtBillTotal) {
		this.dfemtBillTotal = dfemtBillTotal;
	}

	public String getSpccBillTotal() {
		return spccBillTotal;
	}

	public void setSpccBillTotal(String spccBillTotal) {
		this.spccBillTotal = spccBillTotal;
	}

	public String getScrBillTotal() {
		return scrBillTotal;
	}

	public void setScrBillTotal(String scrBillTotal) {
		this.scrBillTotal = scrBillTotal;
	}

	public String getFiveHundredYen() {
		return fiveHundredYen;
	}

	public void setFiveHundredYen(String fiveHundredYen) {
		this.fiveHundredYen = fiveHundredYen;
	}

	public String getDfemt500coins() {
		return dfemt500coins;
	}

	public void setDfemt500coins(String dfemt500coins) {
		this.dfemt500coins = dfemt500coins;
	}

	public String getDfemt500yen() {
		return dfemt500yen;
	}

	public void setDfemt500yen(String dfemt500yen) {
		this.dfemt500yen = dfemt500yen;
	}

	public String getSpcc500coins() {
		return spcc500coins;
	}

	public void setSpcc500coins(String spcc500coins) {
		this.spcc500coins = spcc500coins;
	}

	public String getSpcc500yen() {
		return spcc500yen;
	}

	public void setSpcc500yen(String spcc500yen) {
		this.spcc500yen = spcc500yen;
	}

	public String getScr500coins() {
		return scr500coins;
	}

	public void setScr500coins(String scr500coins) {
		this.scr500coins = scr500coins;
	}

	public String getScr500yen() {
		return scr500yen;
	}

	public void setScr500yen(String scr500yen) {
		this.scr500yen = scr500yen;
	}

	public String getOneHundredYen() {
		return oneHundredYen;
	}

	public void setOneHundredYen(String oneHundredYen) {
		this.oneHundredYen = oneHundredYen;
	}

	public String getDfemt100coins() {
		return dfemt100coins;
	}

	public void setDfemt100coins(String dfemt100coins) {
		this.dfemt100coins = dfemt100coins;
	}

	public String getDfemt100yen() {
		return dfemt100yen;
	}

	public void setDfemt100yen(String dfemt100yen) {
		this.dfemt100yen = dfemt100yen;
	}

	public String getSpcc100coins() {
		return spcc100coins;
	}

	public void setSpcc100coins(String spcc100coins) {
		this.spcc100coins = spcc100coins;
	}

	public String getSpcc100yen() {
		return spcc100yen;
	}

	public void setSpcc100yen(String spcc100yen) {
		this.spcc100yen = spcc100yen;
	}

	public String getScr100coins() {
		return scr100coins;
	}

	public void setScr100coins(String scr100coins) {
		this.scr100coins = scr100coins;
	}

	public String getScr100yen() {
		return scr100yen;
	}

	public void setScr100yen(String scr100yen) {
		this.scr100yen = scr100yen;
	}

	public String getFiftyYen() {
		return fiftyYen;
	}

	public void setFiftyYen(String fiftyYen) {
		this.fiftyYen = fiftyYen;
	}

	public String getDfemt50coins() {
		return dfemt50coins;
	}

	public void setDfemt50coins(String dfemt50coins) {
		this.dfemt50coins = dfemt50coins;
	}

	public String getDfemt50yen() {
		return dfemt50yen;
	}

	public void setDfemt50yen(String dfemt50yen) {
		this.dfemt50yen = dfemt50yen;
	}

	public String getSpcc50coins() {
		return spcc50coins;
	}

	public void setSpcc50coins(String spcc50coins) {
		this.spcc50coins = spcc50coins;
	}

	public String getSpcc50yen() {
		return spcc50yen;
	}

	public void setSpcc50yen(String spcc50yen) {
		this.spcc50yen = spcc50yen;
	}

	public String getScr50coins() {
		return scr50coins;
	}

	public void setScr50coins(String scr50coins) {
		this.scr50coins = scr50coins;
	}

	public String getScr50yen() {
		return scr50yen;
	}

	public void setScr50yen(String scr50yen) {
		this.scr50yen = scr50yen;
	}

	public String getTenYen() {
		return tenYen;
	}

	public void setTenYen(String tenYen) {
		this.tenYen = tenYen;
	}

	public String getDfemt10coins() {
		return dfemt10coins;
	}

	public void setDfemt10coins(String dfemt10coins) {
		this.dfemt10coins = dfemt10coins;
	}

	public String getDfemt10yen() {
		return dfemt10yen;
	}

	public void setDfemt10yen(String dfemt10yen) {
		this.dfemt10yen = dfemt10yen;
	}

	public String getSpcc10coins() {
		return spcc10coins;
	}

	public void setSpcc10coins(String spcc10coins) {
		this.spcc10coins = spcc10coins;
	}

	public String getSpcc10yen() {
		return spcc10yen;
	}

	public void setSpcc10yen(String spcc10yen) {
		this.spcc10yen = spcc10yen;
	}

	public String getScr10coins() {
		return scr10coins;
	}

	public void setScr10coins(String scr10coins) {
		this.scr10coins = scr10coins;
	}

	public String getScr10yen() {
		return scr10yen;
	}

	public void setScr10yen(String scr10yen) {
		this.scr10yen = scr10yen;
	}

	public String getFiveYen() {
		return fiveYen;
	}

	public void setFiveYen(String fiveYen) {
		this.fiveYen = fiveYen;
	}

	public String getDfemt5coins() {
		return dfemt5coins;
	}

	public void setDfemt5coins(String dfemt5coins) {
		this.dfemt5coins = dfemt5coins;
	}

	public String getDfemt5yen() {
		return dfemt5yen;
	}

	public void setDfemt5yen(String dfemt5yen) {
		this.dfemt5yen = dfemt5yen;
	}

	public String getSpcc5coins() {
		return spcc5coins;
	}

	public void setSpcc5coins(String spcc5coins) {
		this.spcc5coins = spcc5coins;
	}

	public String getSpcc5yen() {
		return spcc5yen;
	}

	public void setSpcc5yen(String spcc5yen) {
		this.spcc5yen = spcc5yen;
	}

	public String getScr5coins() {
		return scr5coins;
	}

	public void setScr5coins(String scr5coins) {
		this.scr5coins = scr5coins;
	}

	public String getScr5yen() {
		return scr5yen;
	}

	public void setScr5yen(String scr5yen) {
		this.scr5yen = scr5yen;
	}

	public String getOneYen() {
		return oneYen;
	}

	public void setOneYen(String oneYen) {
		this.oneYen = oneYen;
	}

	public String getDfemt1coins() {
		return dfemt1coins;
	}

	public void setDfemt1coins(String dfemt1coins) {
		this.dfemt1coins = dfemt1coins;
	}

	public String getDfemt1yen() {
		return dfemt1yen;
	}

	public void setDfemt1yen(String dfemt1yen) {
		this.dfemt1yen = dfemt1yen;
	}

	public String getSpcc1coins() {
		return spcc1coins;
	}

	public void setSpcc1coins(String spcc1coins) {
		this.spcc1coins = spcc1coins;
	}

	public String getSpcc1yen() {
		return spcc1yen;
	}

	public void setSpcc1yen(String spcc1yen) {
		this.spcc1yen = spcc1yen;
	}

	public String getScr1coins() {
		return scr1coins;
	}

	public void setScr1coins(String scr1coins) {
		this.scr1coins = scr1coins;
	}

	public String getScr1yen() {
		return scr1yen;
	}

	public void setScr1yen(String scr1yen) {
		this.scr1yen = scr1yen;
	}

	public String getDfemtCoinTotal() {
		return DfemtCoinTotal;
	}

	public void setDfemtCoinTotal(String dfemtCoinTotal) {
		DfemtCoinTotal = dfemtCoinTotal;
	}

	public String getSpccCoinTotal() {
		return spccCoinTotal;
	}

	public void setSpccCoinTotal(String spccCoinTotal) {
		this.spccCoinTotal = spccCoinTotal;
	}

	public String getScrCoinTotal() {
		return scrCoinTotal;
	}

	public void setScrCoinTotal(String scrCoinTotal) {
		this.scrCoinTotal = scrCoinTotal;
	}

	public String getSpccDfemt() {
		return spccDfemt;
	}

	public void setSpccDfemt(String spccDfemt) {
		this.spccDfemt = spccDfemt;
	}

	public String getSpccmTotal() {
		return spccmTotal;
	}

	public void setSpccmTotal(String spccmTotal) {
		this.spccmTotal = spccmTotal;
	}

	public String getSrmTotal() {
		return srmTotal;
	}

	public void setSrmTotal(String srmTotal) {
		this.srmTotal = srmTotal;
	}

	public String getDefFlg10000() {
		return defFlg10000;
	}

	public void setDefFlg10000(String defFlg10000) {
		this.defFlg10000 = defFlg10000;
	}

	public String getDefFlg5000() {
		return defFlg5000;
	}

	public void setDefFlg5000(String defFlg5000) {
		this.defFlg5000 = defFlg5000;
	}

	public String getDefFlg2000() {
		return defFlg2000;
	}

	public void setDefFlg2000(String defFlg2000) {
		this.defFlg2000 = defFlg2000;
	}

	public String getDefFlg1000() {
		return defFlg1000;
	}

	public void setDefFlg1000(String defFlg1000) {
		this.defFlg1000 = defFlg1000;
	}

	public String getDefFlg500() {
		return defFlg500;
	}

	public void setDefFlg500(String defFlg500) {
		this.defFlg500 = defFlg500;
	}

	public String getDefFlg100() {
		return defFlg100;
	}

	public void setDefFlg100(String defFlg100) {
		this.defFlg100 = defFlg100;
	}

	public String getDefFlg50() {
		return defFlg50;
	}

	public void setDefFlg50(String defFlg50) {
		this.defFlg50 = defFlg50;
	}

	public String getDefFlg10() {
		return defFlg10;
	}

	public void setDefFlg10(String defFlg10) {
		this.defFlg10 = defFlg10;
	}

	public String getDefFlg5() {
		return defFlg5;
	}

	public void setDefFlg5(String defFlg5) {
		this.defFlg5 = defFlg5;
	}

	public String getDefFlg1() {
		return defFlg1;
	}

	public void setDefFlg1(String defFlg1) {
		this.defFlg1 = defFlg1;
	}

	public String getDefFlg() {
		return defFlg;
	}

	public void setDefFlg(String defFlg) {
		this.defFlg = defFlg;
	}

	public String getDefFlgBills() {
		return defFlgBills;
	}

	public void setDefFlgBills(String defFlgBills) {
		this.defFlgBills = defFlgBills;
	}

	public String getDefFlgCoins() {
		return defFlgCoins;
	}

	public void setDefFlgCoins(String defFlgCoins) {
		this.defFlgCoins = defFlgCoins;
	}

}
