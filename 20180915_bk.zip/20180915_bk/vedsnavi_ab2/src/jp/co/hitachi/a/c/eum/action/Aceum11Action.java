/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aceum11Action.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.action;

import java.util.List;

import jp.co.hitachi.a.c.eum.bean.Aceum11DispBean;
import jp.co.hitachi.a.c.eum.business.Aceum11Business;
import jp.co.hitachi.a.c.eum.dto.AceumShopGrpDto;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Aceum11Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Aceum11DispBean aceum11DispBean;
	/** 表示モード 0:新規 1:更新 */
	private int dispMode = 0;
	/**
	 * 入力項目
	 */
	/** ユーザーID表示部(新規の時は前方5桁) */
	private String dispUserId = null;

	/** ユーザーID入力値(前方) */
	private String inputedUserIdHead = null;

	/** ユーザーID入力値(後方) */
	private String inputedUserIdBack = null;

	/** チェック結果 */
	private String userIdCheckResult = null;

	/** ユーザー名 */
	private String inputedUserNm = null;

	/** 権限ロールプルダウン選択値 */
	private String selectedRoleCd = null;

	/** 顧客グループコード */
	private String inputedCstGrpCd = null;

	/** 顧客グループ名称 */
	private String dispCstGrpNm = null;

	/** 顧客コード */
	private String inputedCstCd = null;

	/** 顧客名称 */
	private String dispCstNm = null;

	/** 店舗グループリスト */
	private List<AceumShopGrpDto> shopGrpList = null;

	/** 店舗コード */
	private String inputedShopCd = null;

	/** 店舗名称 */
	private String dispShopNm = null;

	/** コメント */
	private String inputedCmt = null;

	/** ユーザー情報更新日時 */
	private String userUpdateDate = null;

	/** パスワード */
	private String password = null;

	/** 再パスワード */
	private String rePassword = null;

	/** パスワード有効期限 */
	private String inputedPasswordExp = null;

	/** パスワード有効期限なしフラグ */
	private boolean checkPwdExpFlg = false;

	/** パスワード有効期間 */
	private String inputedPasswordValid = null;

	/** パスワードロック選択ラジオボタン */
	private String selectedPwdLockRadio = null;

	/** パスワード更新日時 */
	private String pwdUpdateDate = null;


	/** アカウントロック選択ラジオボタン */
	private String selectedActLockRadio = null;


	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAceum11DispBean((Aceum11DispBean)request.getAttribute("Aceum11DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Aceum11Business dao = new Aceum11Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Aceum11DispBean getAceum11DispBean() {
		return aceum11DispBean;
	}

	public void setAceum11DispBean(Aceum11DispBean aceum11DispBean) {
		this.aceum11DispBean = aceum11DispBean;
	}

	public int getDispMode() {
		return dispMode;
	}

	public void setDispMode(int dispMode) {
		this.dispMode = dispMode;
	}

	public String getDispUserId() {
		return dispUserId;
	}

	public void setDispUserId(String dispUserId) {
		this.dispUserId = dispUserId;
	}

	public String getInputedUserIdHead() {
		return inputedUserIdHead;
	}

	public void setInputedUserIdHead(String inputedUserIdHead) {
		this.inputedUserIdHead = inputedUserIdHead;
	}

	public String getInputedUserIdBack() {
		return inputedUserIdBack;
	}

	public void setInputedUserIdBack(String inputedUserIdBack) {
		this.inputedUserIdBack = inputedUserIdBack;
	}

	public String getUserIdCheckResult() {
		return userIdCheckResult;
	}

	public void setUserIdCheckResult(String userIdCheckResult) {
		this.userIdCheckResult = userIdCheckResult;
	}

	public String getInputedUserNm() {
		return inputedUserNm;
	}

	public void setInputedUserNm(String inputedUserNm) {
		this.inputedUserNm = inputedUserNm;
	}

	public String getSelectedRoleCd() {
		return selectedRoleCd;
	}

	public void setSelectedRoleCd(String selectedRoleCd) {
		this.selectedRoleCd = selectedRoleCd;
	}

	public String getInputedCstGrpCd() {
		return inputedCstGrpCd;
	}

	public void setInputedCstGrpCd(String inputedCstGrpCd) {
		this.inputedCstGrpCd = inputedCstGrpCd;
	}

	public String getDispCstGrpNm() {
		return dispCstGrpNm;
	}

	public void setDispCstGrpNm(String dispCstGrpNm) {
		this.dispCstGrpNm = dispCstGrpNm;
	}

	public String getInputedCstCd() {
		return inputedCstCd;
	}

	public void setInputedCstCd(String inputedCstCd) {
		this.inputedCstCd = inputedCstCd;
	}

	public String getDispCstNm() {
		return dispCstNm;
	}

	public void setDispCstNm(String dispCstNm) {
		this.dispCstNm = dispCstNm;
	}

	public List<AceumShopGrpDto> getShopGrpList() {
		return shopGrpList;
	}

	public void setShopGrpList(List<AceumShopGrpDto> shopGrpList) {
		this.shopGrpList = shopGrpList;
	}

	public String getInputedShopCd() {
		return inputedShopCd;
	}

	public void setInputedShopCd(String inputedShopCd) {
		this.inputedShopCd = inputedShopCd;
	}

	public String getDispShopNm() {
		return dispShopNm;
	}

	public void setDispShopNm(String dispShopNm) {
		this.dispShopNm = dispShopNm;
	}

	public String getInputedCmt() {
		return inputedCmt;
	}

	public void setInputedCmt(String inputedCmt) {
		this.inputedCmt = inputedCmt;
	}

	public String getUserUpdateDate() {
		return userUpdateDate;
	}

	public void setUserUpdateDate(String userUpdateDate) {
		this.userUpdateDate = userUpdateDate;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRePassword() {
		return rePassword;
	}

	public void setRePassword(String rePassword) {
		this.rePassword = rePassword;
	}

	public String getInputedPasswordExp() {
		return inputedPasswordExp;
	}

	public void setInputedPasswordExp(String inputedPasswordExp) {
		this.inputedPasswordExp = inputedPasswordExp;
	}

	public boolean isCheckPwdExpFlg() {
		return checkPwdExpFlg;
	}

	public void setCheckPwdExpFlg(boolean checkPwdExpFlg) {
		this.checkPwdExpFlg = checkPwdExpFlg;
	}

	public String getInputedPasswordValid() {
		return inputedPasswordValid;
	}

	public void setInputedPasswordValid(String inputedPasswordValid) {
		this.inputedPasswordValid = inputedPasswordValid;
	}

	public String getSelectedPwdLockRadio() {
		return selectedPwdLockRadio;
	}

	public void setSelectedPwdLockRadio(String selectedPwdLockRadio) {
		this.selectedPwdLockRadio = selectedPwdLockRadio;
	}

	public String getPwdUpdateDate() {
		return pwdUpdateDate;
	}

	public void setPwdUpdateDate(String pwdUpdateDate) {
		this.pwdUpdateDate = pwdUpdateDate;
	}

	public String getSelectedActLockRadio() {
		return selectedActLockRadio;
	}

	public void setSelectedActLockRadio(String selectedActLockRadio) {
		this.selectedActLockRadio = selectedActLockRadio;
	}


}
