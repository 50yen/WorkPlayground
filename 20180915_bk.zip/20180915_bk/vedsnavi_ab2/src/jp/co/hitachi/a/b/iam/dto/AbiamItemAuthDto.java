/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AbiamItemAuthDto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * AbiamItemAuthDtoクラス<br>
 *****************************************************************************************/
public class AbiamItemAuthDto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 項目ID */
	private String itemId = null;
	/** 項目表示名 */
	private String itemDispName = null;
	/** 項目タイプコード */
	private String itemTypeCd = null;
	/** 項目タイプ */
	private String itemType = null;
	/** 表示 */
	private String dispCd = null;
	/** 編集必須フラグ */
	private String enableReqFlg = null;
	/** 編集 */
	private String enableCd = null;
	/** 排他キー */
	private Long exclusiveKey = null;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public AbiamItemAuthDto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		itemId = null;
		itemDispName = null;
		itemType = null;
		itemTypeCd = null;
		dispCd = null;
		enableReqFlg = null;
		enableCd = null;
		exclusiveKey = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getItemDispName() {
		return itemDispName;
	}
	public void setItemDispName(String itemDispName) {
		this.itemDispName = itemDispName;
	}
	public String getItemTypeCd() {
		return itemTypeCd;
	}
	public void setItemTypeCd(String itemTypeCd) {
		this.itemTypeCd = itemTypeCd;
	}
	public String getItemType() {
		return itemType;
	}
	public void setItemType(String itemType) {
		this.itemType = itemType;
	}
	public String getDispCd() {
		return dispCd;
	}
	public void setDispCd(String dispCd) {
		this.dispCd = dispCd;
	}
	public String getEnableReqFlg() {
		return enableReqFlg;
	}
	public void setEnableReqFlg(String enableReqFlg) {
		this.enableReqFlg = enableReqFlg;
	}
	public String getEnableCd() {
		return enableCd;
	}
	public void setEnableCd(String enableCd) {
		this.enableCd = enableCd;
	}
	public Long getExclusiveKey() {
		return exclusiveKey;
	}
	public void setExclusiveKey(Long exclusiveKey) {
		this.exclusiveKey = exclusiveKey;
	}
}
