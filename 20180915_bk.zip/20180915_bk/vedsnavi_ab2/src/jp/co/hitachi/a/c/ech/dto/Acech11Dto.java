/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech11Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Acech11Dtoクラス<br>
 *****************************************************************************************/
public class Acech11Dto extends AmclsDtoBase {

	/** メンバ変数 */

	/** 店舗CD */
	private String shopCd = null;
	/** 店舗名 */
	private String shopNm = null;
	/** 回収FROM */
	private String cldFrom = null;
	/** 回収TO */
	private String cldTo = null;
	/** 誤差フラグ */
	private boolean defFlg = false;
	/** ページ表示No */
	private int displayNum = 1;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Acech11Dto() {
		clear();
	}

	/*************************************************************************************
	 * クリア
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		shopCd = null;
		shopNm = null;
		cldFrom = null;
		cldTo = null;
		defFlg = false;
		displayNum = 1;
	}

	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public String getShopCd() {
		return shopCd;
	}

	public void setShopCd(String shopCd) {
		this.shopCd = shopCd;
	}

	public String getShopNm() {
		return shopNm;
	}

	public void setShopNm(String shopNm) {
		this.shopNm = shopNm;
	}

	public String getCldFrom() {
		return cldFrom;
	}

	public void setCldFrom(String cldFrom) {
		this.cldFrom = cldFrom;
	}

	public String getCldTo() {
		return cldTo;
	}

	public void setCldTo(String cldTo) {
		this.cldTo = cldTo;
	}

	public boolean isDefFlg() {
		return defFlg;
	}

	public void setDefFlg(boolean defFlg) {
		this.defFlg = defFlg;
	}

	public int getDisplayNum() {
		return displayNum;
	}

	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}
}
