/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AccmeItemDispDto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cme.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * AccmeItemInsertDtoクラス<br>
 *****************************************************************************************/
public class AccmeItemInsertDto extends AmclsDtoBase {

	/** メンバ変数 */
	/** 主管センターコード */
	private String centerCd = null;
	/** SR顧客コード */
	private String srCstCd = null;
	/** SR店舗コード */
	private String srShopCd = null;
	/** SRコード */
	private String srCd = null;
	/** 売上日データフラグ */
	private String sldFlg = null;
	/** 入力締め日時間 */
	private String entFinDt = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AccmeItemInsertDto() {
		clear();
	}

	/*************************************************************************************
	 * クリア
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		centerCd = null;
		srCstCd = null;
		srShopCd = null;
		srCd = null;
		sldFlg = null;
		entFinDt = null;
	}

	public String getCenterCd() {
		return centerCd;
	}

	public void setCenterCd(String centerCd) {
		this.centerCd = centerCd;
	}

	public String getSrCstCd() {
		return srCstCd;
	}

	public void setSrCstCd(String srCstCd) {
		this.srCstCd = srCstCd;
	}

	public String getSrShopCd() {
		return srShopCd;
	}

	public void setSrShopCd(String srShopCd) {
		this.srShopCd = srShopCd;
	}

	public String getSrCd() {
		return srCd;
	}

	public void setSrCd(String srCd) {
		this.srCd = srCd;
	}

	public String getSldFlg() {
		return sldFlg;
	}

	public void setSldFlg(String sldFlg) {
		this.sldFlg = sldFlg;
	}

	public String getEntFinDt() {
		return entFinDt;
	}

	public void setEntFinDt(String entFinDt) {
		this.entFinDt = entFinDt;
	}

}
