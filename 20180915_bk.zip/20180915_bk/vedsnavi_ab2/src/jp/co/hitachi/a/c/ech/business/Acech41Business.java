/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acech41DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.ech.business;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.ech.action.Acech41Action;
import jp.co.hitachi.a.c.ech.bean.Acech41DispBean;
import jp.co.hitachi.a.c.ech.dto.AcechItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;

/*****************************************************************************************
 * Acech41Businessクラス<br>
 *****************************************************************************************/
public class Acech41Business extends AcechBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Acech41DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 戻るボタン押下 */
	private static final String FORWARD_RETURNPAGE = "RETURNPAGE";

	/**
	 * 画面項目ID
	 */
	/** 画面名 */
	public static final String DISP_NM = "レジ別回収金精査実績";
	/** 遷移元ボタン名称 */
	private String SBNO_NM = "店舗枝番";

	/** メンバ変数 */
	/** アクションフォーム */
	private Acech41Action m_Acech41Form = null;
	/** 表示用画面Bean */
	private Acech41DispBean m_Acech41DispBean = null;
	/** 遷移先画面キー */
	public static final String ACECH_INFO_KEY = "AcechInfo";
	/** 遷移DTO */
	AcechItemDispDto acechInfoDto;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Acech41Business(
			Acech41Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Acech41Business.class.getName();
		m_Acech41Form = form;
		m_Acech41DispBean = new Acech41DispBean();
		setErrString(gid, m_Acech41Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}
			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Acech41DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Acech41Form.getM_systemKind());
			m_DbAccess.initDB();

			// ヘッダー（顧客）情報の取得
			acechInfoDto = (AcechItemDispDto) getSpecifiedDTO(ACECH_INFO_KEY);
			if (acechInfoDto != null) {
				m_Acech41DispBean.setCld(AmallUtilities.changeFormat(acechInfoDto.getCld()));
				m_Acech41DispBean.setCustomerNm(acechInfoDto.getCstNm());
				m_Acech41DispBean.setStoreNm(acechInfoDto.getShopNm());
				m_Acech41DispBean.setShopSbno(AmallUtilities.changeFormatSbNo(acechInfoDto.getShopSbno()));

				// DTO削除
				delSpecifiedDTO(ACECH_INFO_KEY);
			}

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (m_Event.equals(FORWARD_RETURNPAGE)) {
				// 戻るボタン押下処理の場合
				forwardStr = returnPage();
			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Acech41DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException, Exception {

		// 遷移元情報が存在しない場合
		if (acechInfoDto == null) {
			setMessageInfo(m_Acech41DispBean, AmallMessageConst.MSG_ERR_SELECT_CON_NO_DATA, SBNO_NM);
			return FORWARD_DISP;
		}

		// レジ別回収金精査実績の取得
		search();
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 戻るボタン押下処理実行
	 * <p>
	 * 戻る変更押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String returnPage() throws AmallException {

		// 画面DTO削除
		deleteSpecifiedDTO(m_Gid);

		return FORWARD_RETURNPAGE;
	}

	/*************************************************************************************
	 * 検索処理実行
	 * <p>
	 * 検索処理を実行する
	 * </p>
	 * @param  なし
	 * @return なし
	 ************************************************************************************/
	public void search() throws AmallException, Exception {
		// methodName
		String methodName = "search()";
		//
		ResultSet rs = null;

		try {

			// SQL作成
			makeSearchSql();

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 正常
			List<Map<String, String>> retList = new ArrayList<>();
			// 実行結果チェック
			ResultSetMetaData metaData = null;
			int maxCol = 0;
			while (rs.next()) {
				//検索正常の時
				if (metaData == null) {
					// メタデータの取得
					metaData = rs.getMetaData();
					maxCol = metaData.getColumnCount();
				}
				Map<String, String> field = new ConcurrentHashMap<String, String>();
				for (int i = 1; i <= maxCol; i++) {//カラム数分ループ
					//フィールドデータ取得
					field.put(metaData.getColumnName(i), m_DbAccess.getString(rs, metaData.getColumnName(i)));
				}
				//1レコード追加
				retList.add(field);
			}

			// レコードが存在しなかった場合
			if (retList.size() == 0) {
				// エラーメッセージセット
				setMessageInfo(m_Acech41DispBean, AmallMessageConst.MSG_ERR_SELECT_CON_NO_DATA, SBNO_NM);
				return;
			}

			// 明細部リスト作成
			makeDetailList(retList);

		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_CLASS_CREATE_ERROR, DISP_NM);
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	/*************************************************************************************
	 * SQL作成処理
	 * <p>
	 * SQLを作成する処理を行う
	 * </p>
	 * @param なし
	 * @return
	 ************************************************************************************/
	protected void makeSearchSql() throws AmallException {
		String methodName = "makeSearchSql()";

		// システム日付取得
		String systemDt = m_Acech41DispBean.getServiceDate();
		// 検索条件
		String cstCd = acechInfoDto.getCstCd();
		String shopCd = acechInfoDto.getShopCd();
		String shopSbno = acechInfoDto.getShopSbnosp();
		String cld = acechInfoDto.getCld();

		try {

			// SQL作成
			StringBuffer sql = new StringBuffer();
			List<String> bindParam = new ArrayList<String>();
			sql.append("SELECT");
			sql.append("	ncd.DFERP_NOTE AS DFERP_NOTE");
			sql.append(",	NVL(ncd.SPCCMT_10000Y_MAI, 0) AS SPCCMT_10000Y_MAI");
			sql.append(",	NVL(ncd.SCR_10000Y_MAI, 0) AS SCR_10000Y_MAI");
			sql.append(",	NVL(ncd.SPCCMT_5000Y_MAI, 0) AS SPCCMT_5000Y_MAI");
			sql.append(",	NVL(ncd.SCR_5000Y_MAI, 0) AS SCR_5000Y_MAI");
			sql.append(",	NVL(ncd.SPCCMT_2000Y_MAI, 0) AS SPCCMT_2000Y_MAI");
			sql.append(",	NVL(ncd.SCR_2000Y_MAI, 0) AS SCR_2000Y_MAI");
			sql.append(",	NVL(ncd.SPCCMT_1000Y_MAI, 0) AS SPCCMT_1000Y_MAI");
			sql.append(",	NVL(ncd.SCR_1000Y_MAI, 0) AS SCR_1000Y_MAI");
			sql.append(",	NVL(ncd.SPCCMT_500Y_MAI, 0) AS SPCCMT_500Y_MAI");
			sql.append(",	NVL(ncd.SCR_500Y_MAI, 0) AS SCR_500Y_MAI");
			sql.append(",	NVL(ncd.SPCCMT_100Y_MAI, 0) AS SPCCMT_100Y_MAI");
			sql.append(",	NVL(ncd.SCR_100Y_MAI, 0) AS SCR_100Y_MAI");
			sql.append(",	NVL(ncd.SPCCMT_50Y_MAI, 0) AS SPCCMT_50Y_MAI");
			sql.append(",	NVL(ncd.SCR_50Y_MAI, 0) AS SCR_50Y_MAI");
			sql.append(",	NVL(ncd.SPCCMT_10Y_MAI, 0) AS SPCCMT_10Y_MAI");
			sql.append(",	NVL(ncd.SCR_10Y_MAI, 0) AS SCR_10Y_MAI");
			sql.append(",	NVL(ncd.SPCCMT_5Y_MAI, 0) AS SPCCMT_5Y_MAI");
			sql.append(",	NVL(ncd.SCR_5Y_MAI, 0) AS SCR_5Y_MAI");
			sql.append(",	NVL(ncd.SPCCMT_1Y_MAI, 0) AS SPCCMT_1Y_MAI");
			sql.append(",	NVL(ncd.SCR_1Y_MAI, 0) AS SCR_1Y_MAI");
			sql.append(",	NVL(ncd.SPCC_DFEMT, 0) AS SPCC_DFEMT");
			sql.append(",	NVL(ncd.SRMT, 0) AS SRMT");
			sql.append(",	NVL(ncd.SPCCMT, 0) AS SPCCMT");
			sql.append(" FROM");
			sql.append("	N_CLMY_DAT ncd");
			sql.append(" LEFT JOIN");
			sql.append(" 	N_SHOP_SB_M nssm");
			sql.append(" 	ON ncd.CST_CD = nssm.CST_CD");
			sql.append(" 	AND ncd.SHOP_CD = nssm.SHOP_CD");
			sql.append(" 	AND ncd.SHOP_SBNO = nssm.SHOP_SBNO");
			sql.append(" 	AND nssm.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" 	AND nssm.EFST_DY <= ?");
			bindParam.add(systemDt);
			sql.append(" 	AND ? <= nssm.EFED_DY");
			bindParam.add(systemDt);
			sql.append(" WHERE");
			sql.append(" ncd.CST_CD = ?");
			bindParam.add(cstCd);
			sql.append(" AND ncd.SHOP_CD = ?");
			bindParam.add(shopCd);
			sql.append(" AND ncd.SHOP_SBNO = ?");
			bindParam.add(shopSbno);
			sql.append(" AND ncd.CLD = ?");
			bindParam.add(cld);
			sql.append(" AND ncd.DEL_FLG = " + AmallConst.DEFAULT_DEL_FLG);
			sql.append(" ORDER BY ncd.SHOP_SBNO");

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < bindParam.size(); i++) {
				m_DbAccess.setString(i + 1, bindParam.get(i));
			}

			/* StringBuffer 開放  */
			sql.delete(0, sql.length());
			sql = null;

			/* List<String> 開放  */
			bindParam.clear();
			bindParam = null;

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 明細リスト作成処理
	 * <p>
	 * 明細リスト作成処理を実行する
	 * </p>
	 * @param	registerData	取得データ
	 * @return 明細ArrayList
	 ************************************************************************************/
	public void makeDetailList(List<Map<String, String>> registerData)
			throws AmallException {
		String methodName = "makeDetailList()";
		try {

			// List<String> moneyType = new ArrayList<>();
			Map<String, String> moneyType = new ConcurrentHashMap<>();
			List<AmdtoGeneralMst> typeList = AmallUtilities.getGeneralMstDataList(m_DbAccess,
					GeneralMstKey.MONEY_TYPE, null, null, m_Acech41DispBean.getServiceDate());
			for (AmdtoGeneralMst mst : typeList) {
				moneyType.put(mst.getGeneralCd1(), mst.getGeneralNm1());
			}

			// 1円
			m_Acech41DispBean.setOneYen(moneyType.get("01"));
			// 5円
			m_Acech41DispBean.setFiveYen(moneyType.get("02"));
			// 10円
			m_Acech41DispBean.setTenYen(moneyType.get("03"));
			// 50円
			m_Acech41DispBean.setFiftyYen(moneyType.get("04"));
			// 100円
			m_Acech41DispBean.setOneHundredYen(moneyType.get("05"));
			// 500円
			m_Acech41DispBean.setFiveHundredYen(moneyType.get("06"));
			// 1000円
			m_Acech41DispBean.setOneThousandYen(moneyType.get("07"));
			// 2000円
			m_Acech41DispBean.setTwoThousandYen(moneyType.get("08"));
			// 5000円
			m_Acech41DispBean.setFiveThousandYen(moneyType.get("09"));
			// 10000円
			m_Acech41DispBean.setTenThousandYen(moneyType.get("10"));

			// ページ情報をリストに追加
			for (Map<String, String> map : registerData) {
				// 誤差コメント
				m_Acech41DispBean.setDferpNote(map.get("DFERP_NOTE"));

				// 10000円枚数　精査実績
				int scr10000bills = Integer.parseInt(map.get("SCR_10000Y_MAI"));
				m_Acech41DispBean
						.setScr10000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr10000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 10000円金額　精査実績
				int scr10000yen = scr10000bills * 10000;
				m_Acech41DispBean.setScr10000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr10000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 10000円枚数　お客様勘定明細
				int spcc10000bills = Integer.parseInt(map.get("SPCCMT_10000Y_MAI"));
				m_Acech41DispBean
						.setSpcc10000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc10000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 10000円金額　お客様勘定明細
				int spcc10000yen = spcc10000bills * 10000;
				m_Acech41DispBean.setSpcc10000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc10000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 10000円枚数　過不足
				int dfemt10000bills = scr10000bills - spcc10000bills;
				m_Acech41DispBean
						.setDfemt10000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt10000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 10000円金額　過不足
				int dfemt10000yen = dfemt10000bills * 10000;
				m_Acech41DispBean.setDfemt10000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt10000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 10000円　過不足フラグ
				if (dfemt10000yen != 0) {
					m_Acech41DispBean.setDefFlg10000(AmallConst.GeneralFlg.ON);
				}

				// 5000円枚数　精査実績
				int scr5000bills = Integer.parseInt(map.get("SCR_5000Y_MAI"));
				m_Acech41DispBean
						.setScr5000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr5000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 5000円金額　精査実績
				int scr5000yen = scr5000bills * 5000;
				m_Acech41DispBean.setScr5000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr5000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 5000円枚数　お客様勘定明細
				int spcc5000bills = Integer.parseInt(map.get("SPCCMT_5000Y_MAI"));
				m_Acech41DispBean
						.setSpcc5000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc5000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 5000円金額　お客様勘定明細
				int spcc5000yen = spcc5000bills * 5000;
				m_Acech41DispBean.setSpcc5000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc5000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 5000円枚数　過不足
				int dfemt5000bills = scr5000bills - spcc5000bills;
				m_Acech41DispBean
						.setDfemt5000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt5000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 5000円金額　過不足
				int dfemt5000yen = dfemt5000bills * 5000;
				m_Acech41DispBean.setDfemt5000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt5000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 5000円　過不足フラグ
				if (dfemt5000yen != 0) {
					m_Acech41DispBean.setDefFlg5000(AmallConst.GeneralFlg.ON);
				}

				// 2000円枚数　精査実績
				int scr2000bills = Integer.parseInt(map.get("SCR_2000Y_MAI"));
				m_Acech41DispBean
						.setScr2000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr2000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 2000円金額　精査実績
				int scr2000yen = scr2000bills * 2000;
				m_Acech41DispBean.setScr2000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr2000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 2000円枚数　お客様勘定明細
				int spcc2000bills = Integer.parseInt(map.get("SPCCMT_2000Y_MAI"));
				m_Acech41DispBean
						.setSpcc2000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc2000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 2000円金額　お客様勘定明細
				int spcc2000yen = spcc2000bills * 2000;
				m_Acech41DispBean.setSpcc2000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc2000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 2000円枚数　過不足
				int dfemt2000bills = scr2000bills - spcc2000bills;
				m_Acech41DispBean
						.setDfemt2000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt2000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 2000円金額　過不足
				int dfemt2000yen = dfemt2000bills * 2000;
				m_Acech41DispBean.setDfemt2000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt2000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 2000円　過不足フラグ
				if (dfemt2000bills != 0) {
					m_Acech41DispBean.setDefFlg2000(AmallConst.GeneralFlg.ON);
				}

				// 1000円枚数　精査実績
				int scr1000bills = Integer.parseInt(map.get("SCR_1000Y_MAI"));
				m_Acech41DispBean
						.setScr1000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr1000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 1000円金額　精査実績
				int scr1000yen = scr1000bills * 1000;
				m_Acech41DispBean.setScr1000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr1000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 1000円枚数　お客様勘定明細
				int spcc1000bills = Integer.parseInt(map.get("SPCCMT_1000Y_MAI"));
				m_Acech41DispBean
						.setSpcc1000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc1000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 1000円金額　お客様勘定明細
				int spcc1000yen = spcc1000bills * 1000;
				m_Acech41DispBean.setSpcc1000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc1000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 1000円枚数　過不足
				int dfemt1000bills = scr1000bills - spcc1000bills;
				m_Acech41DispBean
						.setDfemt1000bills(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt1000bills)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 1000円金額　過不足
				int dfemt1000yen = dfemt1000bills * 1000;
				m_Acech41DispBean.setDfemt1000yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt1000yen) + AmallConst.DEFAULT_MONEY_JA);
				// 1000円　過不足フラグ
				if (dfemt1000yen != 0) {
					m_Acech41DispBean.setDefFlg1000(AmallConst.GeneralFlg.ON);
				}

				// 紙幣合計　精査実績
				int scrBillTotal = scr10000yen + scr5000yen + scr2000yen + scr1000yen;
				m_Acech41DispBean.setScrBillTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scrBillTotal) + AmallConst.DEFAULT_MONEY_JA);
				// 紙幣合計　お客様勘定明細
				int spccBillTotal = spcc10000yen + spcc5000yen + spcc2000yen + spcc1000yen;
				m_Acech41DispBean.setSpccBillTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spccBillTotal) + AmallConst.DEFAULT_MONEY_JA);
				// 紙幣合計　過不足
				int dfemtBillTotal = scrBillTotal - spccBillTotal;
				m_Acech41DispBean.setDfemtBillTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemtBillTotal) + AmallConst.DEFAULT_MONEY_JA);
				// 紙幣　過不足フラグ
				if (dfemtBillTotal != 0) {
					m_Acech41DispBean.setDefFlgBills(AmallConst.GeneralFlg.ON);
				}

				// 500円枚数　精査実績
				int scr500coins = Integer.parseInt(map.get("SCR_500Y_MAI"));
				m_Acech41DispBean
						.setScr500coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr500coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 500円金額　精査実績
				int scr500yen = scr500coins * 500;
				m_Acech41DispBean.setScr500yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr500yen) + AmallConst.DEFAULT_MONEY_JA);
				// 500円枚数　お客様勘定明細
				int spcc500coins = Integer.parseInt(map.get("SPCCMT_500Y_MAI"));
				m_Acech41DispBean
						.setSpcc500coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc500coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 500円金額　お客様勘定明細
				int spcc500yen = spcc500coins * 500;
				m_Acech41DispBean.setSpcc500yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc500yen) + AmallConst.DEFAULT_MONEY_JA);
				// 500円枚数　過不足
				int dfemt500coins = scr500coins - spcc500coins;
				m_Acech41DispBean
						.setDfemt500coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt500coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 500円金額　過不足
				int dfemt500yen = dfemt500coins * 500;
				m_Acech41DispBean.setDfemt500yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt500yen) + AmallConst.DEFAULT_MONEY_JA);
				// 500円　過不足フラグ
				if (dfemt500yen != 0) {
					m_Acech41DispBean.setDefFlg500(AmallConst.GeneralFlg.ON);
				}

				// 100円枚数　精査実績
				int scr100coins = Integer.parseInt(map.get("SCR_100Y_MAI"));
				m_Acech41DispBean
						.setScr100coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr100coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 100円金額　精査実績
				int scr100yen = scr100coins * 100;
				m_Acech41DispBean.setScr100yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr100yen) + AmallConst.DEFAULT_MONEY_JA);
				// 100円枚数　お客様勘定明細
				int spcc100coins = Integer.parseInt(map.get("SPCCMT_100Y_MAI"));
				m_Acech41DispBean
						.setSpcc100coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc100coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 100円金額　お客様勘定明細
				int spcc100yen = spcc100coins * 100;
				m_Acech41DispBean.setSpcc100yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc100yen) + AmallConst.DEFAULT_MONEY_JA);
				// 100円枚数　過不足
				int dfemt100coins = scr100coins - spcc100coins;
				m_Acech41DispBean
						.setDfemt100coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt100coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 100円金額　過不足
				int dfemt100yen = dfemt100coins * 100;
				m_Acech41DispBean.setDfemt100yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt100yen) + AmallConst.DEFAULT_MONEY_JA);
				// 100円　過不足フラグ
				if (dfemt100yen != 0) {
					m_Acech41DispBean.setDefFlg100(AmallConst.GeneralFlg.ON);
				}

				// 50円枚数　精査実績
				int scr50coins = Integer.parseInt(map.get("SCR_50Y_MAI"));
				m_Acech41DispBean.setScr50coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr50coins)
						+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 50円金額　精査実績
				int scr50yen = scr50coins * 50;
				m_Acech41DispBean.setScr50yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr50yen) + AmallConst.DEFAULT_MONEY_JA);
				// 50円枚数　お客様勘定明細
				int spcc50coins = Integer.parseInt(map.get("SPCCMT_50Y_MAI"));
				m_Acech41DispBean
						.setSpcc50coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc50coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 50円金額　お客様勘定明細
				int spcc50yen = spcc50coins * 50;
				m_Acech41DispBean.setSpcc50yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc50yen) + AmallConst.DEFAULT_MONEY_JA);
				// 50円枚数　過不足
				int dfemt50coins = scr50coins - spcc50coins;
				m_Acech41DispBean
						.setDfemt50coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt50coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 50円金額　過不足
				int dfemt50yen = dfemt50coins * 50;
				m_Acech41DispBean.setDfemt50yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt50yen) + AmallConst.DEFAULT_MONEY_JA);
				// 50円　過不足フラグ
				if (dfemt50yen != 0) {
					m_Acech41DispBean.setDefFlg50(AmallConst.GeneralFlg.ON);
				}

				// 10円枚数　精査実績
				int scr10coins = Integer.parseInt(map.get("SCR_10Y_MAI"));
				m_Acech41DispBean.setScr10coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr10coins)
						+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 10円金額　精査実績
				int scr10yen = scr10coins * 10;
				m_Acech41DispBean.setScr10yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr10yen) + AmallConst.DEFAULT_MONEY_JA);
				// 10円枚数　お客様勘定明細
				int spcc10coins = Integer.parseInt(map.get("SPCCMT_10Y_MAI"));
				m_Acech41DispBean
						.setSpcc10coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc10coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 10円金額　お客様勘定明細
				int spcc10yen = spcc10coins * 10;
				m_Acech41DispBean.setSpcc10yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc10yen) + AmallConst.DEFAULT_MONEY_JA);
				// 10円枚数　過不足
				int dfemt10coins = scr10coins - spcc10coins;
				m_Acech41DispBean
						.setDfemt10coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt10coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 10円金額　過不足
				int dfemt10yen = dfemt10coins * 10;
				m_Acech41DispBean.setDfemt10yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt10yen) + AmallConst.DEFAULT_MONEY_JA);
				// 10円　過不足フラグ
				if (dfemt10yen != 0) {
					m_Acech41DispBean.setDefFlg10(AmallConst.GeneralFlg.ON);
				}

				// 5円枚数　精査実績
				int scr5coins = Integer.parseInt(map.get("SCR_5Y_MAI"));
				m_Acech41DispBean.setScr5coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr5coins)
						+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 5円金額　精査実績
				int scr5yen = scr5coins * 5;
				m_Acech41DispBean.setScr5yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr5yen) + AmallConst.DEFAULT_MONEY_JA);
				// 5円枚数　お客様勘定明細
				int spcc5coins = Integer.parseInt(map.get("SPCCMT_5Y_MAI"));
				m_Acech41DispBean.setSpcc5coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc5coins)
						+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 5円金額　お客様勘定明細
				int spcc5yen = spcc5coins * 5;
				m_Acech41DispBean.setSpcc5yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc5yen) + AmallConst.DEFAULT_MONEY_JA);
				// 5円枚数　過不足
				int dfemt5coins = scr5coins - spcc5coins;
				m_Acech41DispBean
						.setDfemt5coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt5coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 5円金額　過不足
				int dfemt5yen = dfemt5coins * 5;
				m_Acech41DispBean.setDfemt5yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt5yen) + AmallConst.DEFAULT_MONEY_JA);
				// 5円　過不足フラグ
				if (dfemt5yen != 0) {
					m_Acech41DispBean.setDefFlg5(AmallConst.GeneralFlg.ON);
				}

				// 1円枚数　精査実績
				int scr1coins = Integer.parseInt(map.get("SCR_1Y_MAI"));
				m_Acech41DispBean.setScr1coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr1coins)
						+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 1円金額　精査実績
				int scr1yen = scr1coins * 1;
				m_Acech41DispBean.setScr1yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scr1yen) + AmallConst.DEFAULT_MONEY_JA);
				// 1円枚数　お客様勘定明細
				int spcc1coins = Integer.parseInt(map.get("SPCCMT_1Y_MAI"));
				m_Acech41DispBean.setSpcc1coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc1coins)
						+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 1円金額　お客様勘定明細
				int spcc1yen = spcc1coins * 1;
				m_Acech41DispBean.setSpcc1yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spcc1yen) + AmallConst.DEFAULT_MONEY_JA);
				// 1円枚数　過不足
				int dfemt1coins = scr1coins - spcc1coins;
				m_Acech41DispBean
						.setDfemt1coins(String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt1coins)
								+ AmallConst.DEFAULT_MONEY_AMOUNT_JA);
				// 1円金額　過不足
				int dfemt1yen = dfemt1coins * 1;
				m_Acech41DispBean.setDfemt1yen(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemt1yen) + AmallConst.DEFAULT_MONEY_JA);
				// 1円　過不足フラグ
				if (dfemt1yen != 0) {
					m_Acech41DispBean.setDefFlg1(AmallConst.GeneralFlg.ON);
				}

				// 硬貨合計　精査実績
				int scrCoinTotal = scr500yen + scr100yen + scr50yen + scr10yen + scr5yen + scr1yen;
				m_Acech41DispBean.setScrCoinTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, scrCoinTotal) + AmallConst.DEFAULT_MONEY_JA);
				// 硬貨合計　お客様勘定明細
				int spccCoinTotal = spcc500yen + spcc100yen + spcc50yen + spcc10yen + spcc5yen + spcc1yen;
				m_Acech41DispBean.setSpccCoinTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, spccCoinTotal) + AmallConst.DEFAULT_MONEY_JA);
				// 硬貨合計　過不足
				int dfemtCoinTotal = scrCoinTotal - spccCoinTotal;
				m_Acech41DispBean.setDfemtCoinTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, dfemtCoinTotal) + AmallConst.DEFAULT_MONEY_JA);
				// 硬貨　過不足フラグ
				if (dfemtCoinTotal != 0) {
					m_Acech41DispBean.setDefFlgCoins(AmallConst.GeneralFlg.ON);
				}

				// 過不足
				m_Acech41DispBean.setSpccDfemt(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, Integer.parseInt(map.get("SPCC_DFEMT")))
								+ AmallConst.DEFAULT_MONEY_JA);
				// 金種票登録合計
				m_Acech41DispBean.setSrmTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, Integer.parseInt(map.get("SRMT")))
								+ AmallConst.DEFAULT_MONEY_JA);
				// 精査金額計
				m_Acech41DispBean.setSpccmTotal(
						String.format(AmallConst.THREE_SEPARATOR_FORMAT, Integer.parseInt(map.get("SPCCMT")))
								+ AmallConst.DEFAULT_MONEY_JA);
				// 過不足フラグ
				if (Integer.parseInt(map.get("SPCC_DFEMT")) != 0) {
					m_Acech41DispBean.setDefFlg(AmallConst.GeneralFlg.ON);
				}

			}

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

	}

}