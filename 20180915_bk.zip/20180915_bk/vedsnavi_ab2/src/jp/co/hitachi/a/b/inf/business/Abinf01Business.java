/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abinf01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.inf.business;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.b.inf.action.Abinf01Action;
import jp.co.hitachi.a.b.inf.bean.Abinf01DispBean;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;

/*****************************************************************************************
 * Abinf01Businessクラス<br>
 *****************************************************************************************/
public class Abinf01Business extends AbinfBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Abinf01DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 登録 */
	public static final String FORWARD_REGIST = "REGIST";

	/**
	 * 画面項目ID
	 */
	/** 告知入力 */
	public static final String ITEM_ID_NOTICEINPUT = "noticeInput";

	/** メンバ変数 */
	/** アクションフォーム */
	private Abinf01Action m_Abinf01Form = null;
	/** 表示用画面Bean */
	private Abinf01DispBean m_Abinf01DispBean = null;

	/** 最大文字数 */
    private static final int MAX_STRINGS  		= 20000 ;
    /** 列文字数 */
    private static final int CLM_STRINGS  		= 2000 ;
    /** 列数 */
    private static final int CLM_NUM     		= 10 ;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Abinf01Business(
			Abinf01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Abinf01Business.class.getName();
		m_Abinf01Form = form;
		m_Abinf01DispBean = new Abinf01DispBean();
		setErrString(gid, m_Abinf01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Abinf01DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Abinf01Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				forwardStr = regist();

			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Abinf01DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException, Exception {

		//検索処理 from設定処理
		search();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 登録処理
	 * <p>
	 * 登録処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException,Exception {

		// 入力データ取得
		String input = m_Abinf01Form.getNoticeData();

		// == 入力チェック ==

		//入力不可能文字チェック
		if(AmallUtilities.isSurrogate(input)) {
			setMessageInfo(m_Abinf01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_INVALID_STRING
					,getItemDispName(ITEM_ID_NOTICEINPUT, m_Abinf01DispBean));
			setError(m_Abinf01DispBean, ITEM_ID_NOTICEINPUT);
		}

		//文字数チェック
		if (!AmallUtilities.isEmpty(input)) {
			if(input.getBytes(AmallConst.Encode.UTF8).length > MAX_STRINGS) {
				setMessageInfo(m_Abinf01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_MAX_STR);
				setError(m_Abinf01DispBean, ITEM_ID_NOTICEINPUT);
				return FORWARD_DISP;
			}
		}

		boolean ret = false;
		if(m_Abinf01Form.getInfoId() == null) {
			//登録処理
			 ret = insert();

		}else {
			//更新処理
			 ret =update();
		}
		// DB処理正常判定
		if (ret) {
			// コミット処理
			m_DbAccess.commit();
			// 正常完了処理メッセージ
			setMessageInfo(m_Abinf01DispBean, AmallMessageConst.MSG_INF_NML_REGIST_END);

			// 再検索処理
			search();
		}

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 検索処理実行
	 * <p>
	 * 検索処理を実行する
	 * </p>
	 * @param  なし
	 * @return なし
	 ************************************************************************************/
	public void search() throws AmallException, Exception {

		String methodName = "search()";

		ResultSet rs = null;

		List<String> bindParam = new ArrayList<String>();

		//日付取得
		String systemDt = m_Abinf01DispBean.getServiceDate();

		// SQL作成
		StringBuffer sql = new StringBuffer();
		try {
			sql.append(" select ");
			sql.append("   inf.INFO_ID");
			sql.append("  ,inf.EFST_DY");
			sql.append("  ,inf.EFED_DY");
			sql.append("  ,inf.INFO_DATA_01");
			sql.append("  ,inf.INFO_DATA_02");
			sql.append("  ,inf.INFO_DATA_03");
			sql.append("  ,inf.INFO_DATA_04");
			sql.append("  ,inf.INFO_DATA_05");
			sql.append("  ,inf.INFO_DATA_06");
			sql.append("  ,inf.INFO_DATA_07");
			sql.append("  ,inf.INFO_DATA_08");
			sql.append("  ,inf.INFO_DATA_09");
			sql.append("  ,inf.INFO_DATA_10");
			sql.append("  ,inf.EXCLUSIVE_KEY");
			sql.append("  ,inf.DEL_FLG");
			sql.append(" from N_INF_M inf");
			sql.append(" where inf.DEL_FLG = ").append(AmallConst.DEFAULT_DEL_FLG);
			bindParam.add(systemDt);
			sql.append("  and inf.EFST_DY <= ?");
			bindParam.add(systemDt);
			sql.append("  and inf.EFED_DY >= ?");
			sql.append(" order by INFO_ID desc");

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < bindParam.size(); i++) {
				m_DbAccess.setString(i + 1, bindParam.get(i));
			}

			// SQL実行
			rs = m_DbAccess.executeQuery();

			while (rs.next()) {

				//formに設定
				//告知ID
				m_Abinf01Form.setInfoId(rs.getLong("INFO_ID"));
				//排他キー
				m_Abinf01Form.setExclusiveKey(rs.getLong("EXCLUSIVE_KEY"));

				StringBuffer sbNotice = new StringBuffer();
				sbNotice.append(m_DbAccess.getString(rs, "INFO_DATA_01"));
				sbNotice.append(m_DbAccess.getString(rs, "INFO_DATA_02"));
				sbNotice.append(m_DbAccess.getString(rs, "INFO_DATA_03"));
				sbNotice.append(m_DbAccess.getString(rs, "INFO_DATA_04"));
				sbNotice.append(m_DbAccess.getString(rs, "INFO_DATA_05"));
				sbNotice.append(m_DbAccess.getString(rs, "INFO_DATA_06"));
				sbNotice.append(m_DbAccess.getString(rs, "INFO_DATA_07"));
				sbNotice.append(m_DbAccess.getString(rs, "INFO_DATA_08"));
				sbNotice.append(m_DbAccess.getString(rs, "INFO_DATA_09"));
				sbNotice.append(m_DbAccess.getString(rs, "INFO_DATA_10"));
				//告知
				m_Abinf01Form.setNoticeData(sbNotice.toString());
				break;
			}

		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_INF_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}
    /*************************************************************************************
     * 告知マスタデータ追加処理
     * <p>
     * 告知マスタデータに画面情報を追加登録する
     * </p>
     * @param 無し
     * @return 結果　正常=true/異常=false
     * @exception AmallException
     ************************************************************************************/
	private boolean insert() throws AmallException {
		String methodName = "execsqlInsAINFOMT()";
		StringBuffer sql = new StringBuffer();

		try {
			String str = m_Abinf01Form.getNoticeData();

			/* 画面項目分割 */
			List<String> data = getSplitList(str);

			/* SQL 作成 */
			sql.append("INSERT INTO N_INF_M ( ");
			sql.append("  INFO_ID");
			sql.append(", EFST_DY");
			sql.append(", EFED_DY");
			sql.append(", INFO_DATA_01");
			sql.append(", INFO_DATA_02");
			sql.append(", INFO_DATA_03");
			sql.append(", INFO_DATA_04");
			sql.append(", INFO_DATA_05");
			sql.append(", INFO_DATA_06");
			sql.append(", INFO_DATA_07");
			sql.append(", INFO_DATA_08");
			sql.append(", INFO_DATA_09");
			sql.append(", INFO_DATA_10");
			// 共通部分
			sql.append(", EXCLUSIVE_KEY");
			sql.append(", DEL_FLG");
			sql.append(", CR_PGM_ID");
			sql.append(", CR_USER_ID");
			sql.append(", CR_DT");
			sql.append(", UPD_PGM_ID");
			sql.append(", UPD_USER_ID");
			sql.append(", UPD_DT");
			sql.append(") VALUES ( ");
			sql.append(" S_INFO_ID_PK.NEXTVAL");
			sql.append(", ").append(AmallConst.EFST_DY_DEFAULT);
			sql.append(", ").append(AmallConst.EFED_DY_DEFAULT);
			sql.append(", ?");	//INFO_DATA_01
			sql.append(", ?");	//INFO_DATA_02
			sql.append(", ?");	//INFO_DATA_03
			sql.append(", ?");	//INFO_DATA_04
			sql.append(", ?");	//INFO_DATA_05
			sql.append(", ?");	//INFO_DATA_06
			sql.append(", ?");	//INFO_DATA_07
			sql.append(", ?");	//INFO_DATA_08
			sql.append(", ?");	//INFO_DATA_09
			sql.append(", ?");	//INFO_DATA_10
			// 共通部分
			sql.append(", 0");
			sql.append(", ").append(AmallConst.DEFAULT_DEL_FLG);
			sql.append(", '").append(m_ClassName).append("'");
			sql.append(", '").append(m_Abinf01DispBean.getH_loginId()).append("'");
			sql.append(", SYSDATE");
			sql.append(", '").append(m_ClassName).append("'");
			sql.append(", '").append(m_Abinf01DispBean.getH_loginId()).append("'");
			sql.append(", SYSDATE");
			sql.append(" )");

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			int setCnt = 0;
			for (int i = 0; i < CLM_NUM; i++) {
				if (i < data.size()) {
					this.m_DbAccess.setString(++setCnt, data.get(i));
				} else {
					this.m_DbAccess.setString(++setCnt, "");
				}
			}

			/* DB 更新 */
			int outParam = this.m_DbAccess.executeUpdateSql();
			if (outParam <= 0) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_INF_M");
				throw ee;
			}
			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_INF_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
    }
    /*************************************************************************************
     * 告知マスタデータ更新処理
     * <p>
     * 告知マスタデータに画面情報を更新登録する
     * </p>
     * @param 無し
     * @return 結果　正常=true/異常=false
     * @exception AmallException
     ************************************************************************************/
	private boolean update() throws AmallException {
		String methodName = "execsqlUpdAINFOMT()";
		StringBuffer sql = new StringBuffer();

		try {

			String str = m_Abinf01Form.getNoticeData();

			/* 画面項目分割 */
			List<String> data = getSplitList(str);

			/* SQL 作成 */
			sql.append(" UPDATE N_INF_M SET ");
			sql.append("    INFO_DATA_01 = ? ");
			sql.append("  , INFO_DATA_02 = ? ");
			sql.append("  , INFO_DATA_03 = ? ");
			sql.append("  , INFO_DATA_04 = ? ");
			sql.append("  , INFO_DATA_05 = ? ");
			sql.append("  , INFO_DATA_06 = ? ");
			sql.append("  , INFO_DATA_07 = ? ");
			sql.append("  , INFO_DATA_08 = ? ");
			sql.append("  , INFO_DATA_09 = ? ");
			sql.append("  , INFO_DATA_10 = ? ");
			sql.append("  , EXCLUSIVE_KEY =  EXCLUSIVE_KEY + 1 ");
			sql.append("  , UPD_PGM_ID = '").append(m_ClassName).append("'");
			sql.append("  , UPD_USER_ID = '").append(m_Abinf01DispBean.getH_loginId()).append("'");
			sql.append("  , UPD_DT =  SYSDATE");
			sql.append(" WHERE ");
			sql.append("      INFO_ID = ? ");
			sql.append("  AND DEL_FLG = ").append(AmallConst.DEFAULT_DEL_FLG);
			sql.append("  AND EXCLUSIVE_KEY = ? ");

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			int setCnt = 0;
			for (int i = 0; i < CLM_NUM; i++) {
				if (i < data.size()) {
					this.m_DbAccess.setString(++setCnt, data.get(i));
				} else {
					this.m_DbAccess.setString(++setCnt, "");
				}
			}
			this.m_DbAccess.setLong(++setCnt, m_Abinf01Form.getInfoId());
			this.m_DbAccess.setLong(++setCnt, m_Abinf01Form.getExclusiveKey());

			/* DB 更新 */
			int outParam = this.m_DbAccess.executeUpdateSql();
			// 排他チェック
			if(outParam == 0) {
				// 更新対象無し(楽観排他)
				m_DbAccess.rollback();

				// エラー情報を設定
				setMessageInfo(m_Abinf01DispBean, AmallMessageConst.MSG_ERR_OPT_EXCLUSION_NOT_REGIST);

				// アクセスログ情報の作成
				AmallExceptionInfo amei = new AmallExceptionInfo();
				amei.setMessage(AmallMessage.getMessage(AmallMessageConst.MSG_SYS_DB_ACS_OPT_ERROR, "N_INF_M"));
				setReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO, amei);

				return false;
			}

			// 更新結果判定
			if (outParam != 1) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_INF_M");
				throw ee;
			}

			return true;

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_UPDATE_ERROR, "N_INF_M");
			throw e;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
	}
    /*************************************************************************************
     * 文字列分割処理
     * <p>
     * 文字列を指定のbyte単位で分割する。
     * </p>
     * @param String
     * @return
     * @exception AmallException
     ************************************************************************************/
	private List<String> getSplitList(String str) throws Exception{

		List<String> rtnlst = new ArrayList<String>();

		StringBuffer sb = new StringBuffer();
		int cnt = 0;

		for (int i = 0; i < str.length(); i++) {
			//一文字単位でbyte数を取得し、カウント判定する。
			String tmpStr = str.substring(i, i + 1);
			byte[] b = tmpStr.getBytes(AmallConst.Encode.UTF8);
			if (cnt + b.length > CLM_STRINGS) {
				rtnlst.add(sb.toString());
				cnt = 0;
				sb = new StringBuffer();
				sb.append(tmpStr);
				cnt += b.length;
			} else {
				sb.append(tmpStr);
				cnt += b.length;
			}
		}
		if (sb.length() != 0) {
			rtnlst.add(sb.toString());
		}

		return rtnlst;
	}
}