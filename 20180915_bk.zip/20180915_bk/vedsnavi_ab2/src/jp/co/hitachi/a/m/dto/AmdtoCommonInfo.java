/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoCommonInfo.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * 共通情報DTO <br>
 *****************************************************************************************/
public class AmdtoCommonInfo extends AmclsDtoBase {

	/** メンバ変数 */
	/** 業務日付 */
	private String m_BusinessDate = null;
	/** アクセスログ(DB)有無 */
	private String m_AccessLogEnable = null;
	/** JavaScript用メッセージマップ */
	private Map<String, String> m_JsMessageMap = null;
	/** 表示件数プルダウンリスト */
	private List<String> m_DispCountList = null;
	/** 表示件数プルダウンリスト初期値 */
	private String m_DispCountDefault = null;
	/** 表示件数プルダウンリスト(子画面)初期値 */
	private String m_DispCountChildDefault = null;

	/** 画面分類情報 画面グループID(カテゴリ) -> 画面グループID(メニュー) -> 画面ID*/
	private List<AmdtoScreenCategory> m_ScreenList = null;
	/** 画面情報リスト 画面ID -> 画面情報/ */
	private Map<String, AmdtoScreen> m_ScreenInfoMap = null;
	/** 項目権限  画面ID -> 項目ID -> 項目名/編集*/
	private Map<String, Map<String, Map<String, String>>> m_ItemDispAuth = null;

	/** 顧客全社フラグ true: 全顧客(顧客コードリストなし) false:顧客コードリストあり */
	private boolean m_CustomerCdAllFlg = false;
	/** 顧客コードリスト */
	private List<String> m_CustomerCdList = null;
	/** 制限顧客コード情報 画面ID -> 顧客コードリスト */
	private Map<String, List<String>> m_LimitCustomerMap = null;
	/** 店舗全店フラグ true: 全店舗(店舗コードリストなし) false:店舗コードリストあり */
	private boolean m_ShopCdAllFlg = false;
	/** 店舗コードリストマップ */
	private Map<String, List<String>> m_ShopCdListMap = null;
	/** 制限店舗コード情報 画面ID -> 店舗コードリスト */
	private Map<String, Map<String, List<String>>> m_LimitShopMap = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmdtoCommonInfo() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		m_BusinessDate = null;
		m_AccessLogEnable = null;
		m_JsMessageMap = new ConcurrentHashMap<>();
		m_DispCountList = new ArrayList<>();
		m_DispCountDefault = null;
		m_ScreenList = new ArrayList<>();
		m_ScreenInfoMap =  new ConcurrentHashMap<>();
		m_ItemDispAuth =  new ConcurrentHashMap<>();
		m_CustomerCdAllFlg = false;
		m_CustomerCdList =  new ArrayList<>();
		m_LimitCustomerMap =  new ConcurrentHashMap<>();
		m_ShopCdAllFlg = false;
		m_ShopCdListMap =  new ConcurrentHashMap<>();
		m_LimitShopMap =  new ConcurrentHashMap<>();

	}

	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getM_BusinessDate() {
		return m_BusinessDate;
	}

	public void setM_BusinessDate(String m_BusinessDate) {
		this.m_BusinessDate = m_BusinessDate;
	}

	public String getM_AccessLogEnable() {
		return m_AccessLogEnable;
	}

	public void setM_AccessLogEnable(String m_AccessLogEnable) {
		this.m_AccessLogEnable = m_AccessLogEnable;
	}

	public Map<String, String> getM_JsMessageMap() {
		return m_JsMessageMap;
	}

	public void setM_JsMessageMap(Map<String, String> m_JsMessageMap) {
		this.m_JsMessageMap = m_JsMessageMap;
	}

	public List<String> getM_DispCountList() {
		return m_DispCountList;
	}

	public void setM_DispCountList(List<String> m_DispCountList) {
		this.m_DispCountList = m_DispCountList;
	}

	public String getM_DispCountDefault() {
		return m_DispCountDefault;
	}

	public void setM_DispCountDefault(String m_DispCountDefault) {
		this.m_DispCountDefault = m_DispCountDefault;
	}

	public String getM_DispCountChildDefault() {
		return m_DispCountChildDefault;
	}

	public void setM_DispCountChildDefault(String m_DispCountChildDefault) {
		this.m_DispCountChildDefault = m_DispCountChildDefault;
	}

	public List<AmdtoScreenCategory> getM_ScreenList() {
		return m_ScreenList;
	}

	public void setM_ScreenList(List<AmdtoScreenCategory> m_ScreenList) {
		this.m_ScreenList = m_ScreenList;
	}

	public Map<String, AmdtoScreen> getM_ScreenInfoMap() {
		return m_ScreenInfoMap;
	}

	public void setM_ScreenInfoMap(Map<String, AmdtoScreen> m_ScreenInfoMap) {
		this.m_ScreenInfoMap = m_ScreenInfoMap;
	}

	public Map<String, Map<String, Map<String, String>>> getM_ItemDispAuth() {
		return m_ItemDispAuth;
	}

	public void setM_ItemDispAuth(Map<String, Map<String, Map<String, String>>> m_ItemDispAuth) {
		this.m_ItemDispAuth = m_ItemDispAuth;
	}

	public boolean isM_CustomerCdAllFlg() {
		return m_CustomerCdAllFlg;
	}

	public void setM_CustomerCdAllFlg(boolean m_CustomerCdAllFlg) {
		this.m_CustomerCdAllFlg = m_CustomerCdAllFlg;
	}

	public List<String> getM_CustomerCdList() {
		return m_CustomerCdList;
	}

	public void setM_CustomerCdList(List<String> m_CustomerCdList) {
		this.m_CustomerCdList = m_CustomerCdList;
	}

	public Map<String, List<String>> getM_LimitCustomerMap() {
		return m_LimitCustomerMap;
	}

	public void setM_LimitCustomerMap(Map<String, List<String>> m_LimitCustomerMap) {
		this.m_LimitCustomerMap = m_LimitCustomerMap;
	}

	public boolean isM_ShopCdAllFlg() {
		return m_ShopCdAllFlg;
	}

	public void setM_ShopCdAllFlg(boolean m_ShopCdAllFlg) {
		this.m_ShopCdAllFlg = m_ShopCdAllFlg;
	}

	public Map<String, List<String>> getM_ShopCdListMap() {
		return m_ShopCdListMap;
	}

	public void setM_ShopCdListMap(Map<String, List<String>> m_ShopCdListMap) {
		this.m_ShopCdListMap = m_ShopCdListMap;
	}

	public Map<String, Map<String, List<String>>> getM_LimitShopMap() {
		return m_LimitShopMap;
	}

	public void setM_LimitShopMap(Map<String, Map<String, List<String>>> m_LimitShopMap) {
		this.m_LimitShopMap = m_LimitShopMap;
	}

}
