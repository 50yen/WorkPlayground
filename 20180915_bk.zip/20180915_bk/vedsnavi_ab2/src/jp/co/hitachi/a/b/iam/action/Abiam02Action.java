/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abiam02Action.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.action;

import java.util.List;

import jp.co.hitachi.a.b.iam.bean.Abiam02DispBean;
import jp.co.hitachi.a.b.iam.business.Abiam02Business;
import jp.co.hitachi.a.b.iam.dto.AbiamItemAuthDto;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsActionPcBase;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public class Abiam02Action extends AmclsActionPcBase {

	/** メンバ変数 */
	/** 画面表示Bean */
	private Abiam02DispBean abiam02DispBean;

	/** 画面名プルダウン選択値 */
	private String selectedScreenCd = null;
	/** 権限ロールプルダウン選択値 */
	private String selectedRoleCd = null;

	/** 画面名プルダウン選択値(検索ボタン押下保存値) */
	private String savedScreenCd = null;
	/** 権限ロールプルダウン選択値(検索ボタン押下保存値) */
	private String savedRoleCd = null;

	/** 一覧表示用データ */
	private List<AbiamItemAuthDto> itemDispList = null;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {

		// セッションやトークンのチェック等を実行し、callexecute処理を呼び出す
    	String forwardName = super.execute();
    	// 実行結果を画面表示Beanに登録
    	setAbiam02DispBean((Abiam02DispBean)request.getAttribute("Abiam02DispBean"));
    	return forwardName;

	}

	/*************************************************************************************
	 * callexecute処理
	 * <p>
	 * callexecute実行
	 * </p>
	 * @return ActionForward
	 ************************************************************************************/
	public String callexecute() throws AmallException {
		// ビジネス層の生成
		Abiam02Business dao = new Abiam02Business(this, request, response, getGid(), getEvent());

		// ビジネス層の実行
		return dao.executeProc();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Abiam02DispBean getAbiam02DispBean() {
		return abiam02DispBean;
	}

	public void setAbiam02DispBean(Abiam02DispBean abiam02DispBean) {
		this.abiam02DispBean = abiam02DispBean;
	}

	public String getSelectedScreenCd() {
		return selectedScreenCd;
	}

	public void setSelectedScreenCd(String selectedScreenCd) {
		this.selectedScreenCd = selectedScreenCd;
	}

	public String getSelectedRoleCd() {
		return selectedRoleCd;
	}

	public void setSelectedRoleCd(String selectedRoleCd) {
		this.selectedRoleCd = selectedRoleCd;
	}

	public String getSavedScreenCd() {
		return savedScreenCd;
	}

	public void setSavedScreenCd(String savedScreenCd) {
		this.savedScreenCd = savedScreenCd;
	}

	public String getSavedRoleCd() {
		return savedRoleCd;
	}

	public void setSavedRoleCd(String savedRoleCd) {
		this.savedRoleCd = savedRoleCd;
	}

	public List<AbiamItemAuthDto> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<AbiamItemAuthDto> itemDispList) {
		this.itemDispList = itemDispList;
	}
}
