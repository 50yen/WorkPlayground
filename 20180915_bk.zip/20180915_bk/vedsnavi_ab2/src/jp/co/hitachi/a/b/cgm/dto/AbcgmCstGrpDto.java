/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abcgm02Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.cgm.dto;

import java.sql.Date;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * AbcgmItemDispDtoクラス<br>
 *****************************************************************************************/
public class AbcgmCstGrpDto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 顧客グループCD */
	private String cstGrpCd = null;
	/** 顧客グループ名 */
	private String cstGrpNm = null;
	/** 顧客CD */
	private String cstCd = null;
	/** 顧客名 */
	private String cstNm = null;
	/** 更新日時 */
	private String upDate = null;
	/** 更新者 */
	private String upDateUser = null;
	/** 登録日時 */
	private Date createDate = null;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public AbcgmCstGrpDto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		cstCd = "";
		cstNm = "";
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public synchronized String getCstGrpCd() {
		return cstGrpCd;
	}
	public synchronized void setCstGrpCd(String cstGrpCd) {
		this.cstGrpCd = cstGrpCd;
	}
	public synchronized String getCstGrpNm() {
		return cstGrpNm;
	}
	public synchronized void setCstGrpNm(String cstGrpNm) {
		this.cstGrpNm = cstGrpNm;
	}
	public synchronized String getCstCd() {
		return cstCd;
	}
	public synchronized void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}
	public synchronized String getCstNm() {
		return cstNm;
	}
	public synchronized void setCstNm(String cstNm) {
		this.cstNm = cstNm;
	}
	public synchronized String getUpDate() {
		return upDate;
	}
	public synchronized void setUpDate(String upDate) {
		this.upDate = upDate;
	}
	public synchronized String getUpDateUser() {
		return upDateUser;
	}
	public synchronized void setUpDateUser(String upDateUser) {
		this.upDateUser = upDateUser;
	}
	public synchronized Date getCreateDate() {
		return createDate;
	}
	public synchronized void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}



}
