/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aceum11DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.business;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.eum.action.Aceum11Action;
import jp.co.hitachi.a.c.eum.bean.Aceum11DispBean;
import jp.co.hitachi.a.c.eum.dto.Aceum11Dto;
import jp.co.hitachi.a.c.eum.dto.AceumItemDispDto;
import jp.co.hitachi.a.c.eum.dto.AceumShopGrpDto;
import jp.co.hitachi.a.m.all.AmallConst.GeneralFlg;
import jp.co.hitachi.a.m.all.AmallConst.GeneralMstKey;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallConst.MsgCode;
import jp.co.hitachi.a.m.all.AmallConst.SystemType;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallPage;
import jp.co.hitachi.a.m.all.AmallPasswordControl;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoDropDownList;
import jp.co.hitachi.a.m.dto.AmdtoGeneralMst;
import jp.co.hitachi.a.m.dto.AmdtoLoginInfo;
import jp.co.hitachi.a.m.dto.AmdtoPagingSql;
import jp.co.hitachi.a.m.dto.AmdtoRadioList;

/*****************************************************************************************
 * Aceum11Businessクラス<br>
 *****************************************************************************************/
public class Aceum11Business extends AceumBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Aceum11DispBean";
	/** 表示モード:新規 */
	private static final int MODE_NEW = 0;
	/** 表示モード:更新 */
	private static final int MODE_UPDATE = 1;


	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	private static final String FORWARD_DISP = "DISP";
	/** ユーザーIDチェック */
	private static final String FORWARD_IDCHECK = "IDCHECK";
	/** 店舗グループ追加 */
	private static final String FORWARD_ADDSHOPGRP = "ADDSHOPGRP";
	/** 登録 */
	private static final String FORWARD_REGIST = "REGIST";
	/** 削除 */
	private static final String FORWARD_DELETE = "DELETE";
	/** 戻る */
	private static final String FORWARD_BACK = "RETURNPAGE";


	/**
	 * 画面項目ID
	 */
	/** ユーザーID */
	private static final String ITEM_ID_USER_ID = "userIdInput";
	/** ユーザー名 */
	private static final String ITEM_ID_USER_NM = "userNmInput";
	/** 顧客コード */
	private static final String ITEM_ID_CST_CD = "customerSearchNm";
	/** 店舗コード */
	private static final String ITEM_ID_SHOP_CD = "shopSearchNm";
	/** コメント */
	private static final String ITEM_ID_CMT = "cmtInput";
	/** パスワード */
	public static final String ITEM_ID_PASS = "passwordInput";
	/** 再パスワード */
	public static final String ITEM_ID_RE_PASS = "rePasswordInput";
	/** パスワード有効期限 */
	public static final String ITEM_ID_PASSEXP = "passwordExpDate";
	/** パスワード有効期間 */
	public static final String ITEM_ID_PASSVALID = "passwordValidDate";
	/** パスワードロック */
	public static final String ITEM_ID_PASS_LOCK = "passwordLock";
	/** アカウントロック */
	public static final String ITEM_ID_ACT_LOCK = "accountLock";



	/** DTOキー名 */
	private static final String DTO_KEY = "DTO_ACEUM11";


	/** メンバ変数 */
	/** アクションフォーム */
	private Aceum11Action m_Aceum11Form = null;
	/** 表示用画面Bean */
	private Aceum11DispBean m_Aceum11DispBean = null;
	/** ページング処理用 */
	private AmallPage m_Page = null;
	/** SQL作成用 */
	private AmdtoPagingSql m_Page_Sql = null;
	/** 画面DTO */
	private Aceum11Dto m_Aceum11Dto;
	/** 特殊権限ロール */
	List<AmdtoGeneralMst> m_RoleGeneralMstList = new ArrayList<>();

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Aceum11Business(
			Aceum11Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Aceum11Business.class.getName();
		m_Aceum11Form = form;
		m_Aceum11DispBean = new Aceum11DispBean();
		m_Aceum11Dto = new Aceum11Dto();
		m_Page = new AmallPage();
		m_Page_Sql = new AmdtoPagingSql();
		setErrString(gid, m_Aceum11Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Aceum11DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Aceum11Form.getM_systemKind());
			m_DbAccess.initDB();

			/* 内部記憶情報の生成 */
			m_Aceum11Dto = (Aceum11Dto) getSpecifiedDTO(m_Gid, DTO_KEY);
			if (m_Aceum11Dto == null || FORWARD_DISP.equals(m_Event)) {
				m_Aceum11Dto = new Aceum11Dto();
				putSpecifiedDTO(m_Gid, DTO_KEY, m_Aceum11Dto);
			}

			// 遷移元情報取得
			aceumInfoDto = (AceumItemDispDto) getSpecifiedDTO(ACEUM_INFO_KEY);
			if (aceumInfoDto != null) {
				m_Aceum11Dto.setUserId(aceumInfoDto.getUserId());
				m_Aceum11Dto.setSystemKind(aceumInfoDto.getSystemKind());
				// DTO削除
				delSpecifiedDTO(ACEUM_INFO_KEY);
			}


			// 共通処理
			getDropDownListData();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_IDCHECK.equals(m_Event)) {
				// チェックボタン押下の場合
				forwardStr = idCheck();
			} else if (FORWARD_ADDSHOPGRP.equals(m_Event)) {
				// 店舗グループ追加ボタン押下の場合
				forwardStr = addShopGrp();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				// 登録ボタン押下の場合
				forwardStr = regist();
			} else if (FORWARD_DELETE.equals(m_Event)) {
				// 削除ボタン押下の場合
				forwardStr = delete();
			} else if (FORWARD_BACK.equals(m_Event)) {
				// 戻るボタン押下の場合
				forwardStr = back();
			} else {
				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {

			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Aceum11DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * 入力値が存在する場合は初期検索を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		// 新規更新判定
		if (AmallUtilities.isEmpty(m_Aceum11Dto.getUserId())) {
			// ユーザーIDがない場合は新規モードにする
			m_Aceum11Form.setDispMode(MODE_NEW);
			m_Aceum11Dto.setDispMode(MODE_NEW);
		} else {
			// ユーザーIDがある場合は更新モードにする
			m_Aceum11Form.setDispMode(MODE_UPDATE);
			m_Aceum11Dto.setDispMode(MODE_UPDATE);
		}

		// 初期検索

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * プルダウンリスト取得処理
	 * <p>
	 * 画面に表示するプルダウンリストの値を取得する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private void getDropDownListData() throws AmallException, Exception {

		// 権限一覧を取得する
		List<AmdtoDropDownList> roleList =  getAuthRoleList(m_Aceum11Form.getM_systemKind());

		// 汎用マスタ取得(特殊権限ロール)
		m_RoleGeneralMstList = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.PASSWORD_LOCK_RADIO, null, null, m_Aceum11DispBean.getServiceDate());

		// システム種別が顧客OLの場合は特殊権限ロールを排除する
		if (SystemType.CUSTOMER == m_Aceum11Form.getM_systemKind()) {
			for (AmdtoDropDownList downData : roleList) {
				for (AmdtoGeneralMst removeData : m_RoleGeneralMstList) {
					// 削除対象権限か確認
					if (removeData.getGeneralCd1().equals(downData.getId())) {
						// 一致した場合 リストから削除
						roleList.remove(roleList.indexOf(downData));
					}
				}
			}
		}

		// 権限一覧の設定
		m_Aceum11DispBean.setRoleDropDownList(roleList);


		// 汎用マスタ取得(パスワードロックラジオボタン)
		List<AmdtoGeneralMst> pwdGeneralMstList = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.PASSWORD_LOCK_RADIO, null, null, m_Aceum11DispBean.getServiceDate());

		// 設定用リスト生成
		List<AmdtoRadioList> pwdList = new ArrayList<>();
		// 取得データ繰り返し
		for (AmdtoGeneralMst pwdMst : pwdGeneralMstList) {
			AmdtoRadioList dto = new AmdtoRadioList();
			// コード値
			dto.setId(pwdMst.getGeneralCd1());
			// 表示
			dto.setName(pwdMst.getGeneralNm1());

			// デフォルト区分
			if(GeneralFlg.ON.equals(pwdMst.getDefaultFlg())) {
				// 初期値
				if (m_Aceum11Form.getSelectedPwdLockRadio() == null) {
					m_Aceum11Form.setSelectedPwdLockRadio(pwdMst.getGeneralCd1());

				}
			}
			// リストに設定
			pwdList.add(dto);
		}
		// Beanに設定
		m_Aceum11DispBean.setRadioPwdLockList(pwdList);


		// 汎用マスタ取得(アカウントロックラジオボタン)
		List<AmdtoGeneralMst> actGeneralMstList = AmallUtilities.getGeneralMstDataList(m_DbAccess, GeneralMstKey.ACCOUNT_LOCK_RADIO, null, null, m_Aceum11DispBean.getServiceDate());

		// 設定用リスト生成
		List<AmdtoRadioList> actList = new ArrayList<>();
		for (AmdtoGeneralMst actMst : actGeneralMstList) {
			AmdtoRadioList dto = new AmdtoRadioList();
			// コード値
			dto.setId(actMst.getGeneralCd1());
			// 表示
			dto.setName(actMst.getGeneralNm1());

			// デフォルト区分
			if(GeneralFlg.ON.equals(actMst.getDefaultFlg())) {
				// 初期値
				if (m_Aceum11Form.getSelectedActLockRadio() == null) {
					m_Aceum11Form.setSelectedActLockRadio(actMst.getGeneralCd1());
				}
			}
			// リストに設定
			actList.add(dto);
		}
		// Beanに設定
		m_Aceum11DispBean.setRadioActLockList(actList);

		// 店舗グループ初期時のみ空データ設定
		if(m_Aceum11Form.getShopGrpList() == null) {

			List<AceumShopGrpDto> emptyList = new ArrayList<>();

			AceumShopGrpDto dto = new AceumShopGrpDto();
			dto.setShopGrpCd("");
			dto.setShopGrpNm("");
			emptyList.add(dto);

			// 空データを設定
			m_Aceum11Form.setShopGrpList(emptyList);
		}

	}
	/*************************************************************************************
	 * チェックボタン押下処理実行
	 * <p>
	 * チェックボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String idCheck() throws AmallException {

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 店舗グループ追加ボタン押下処理実行
	 * <p>
	 * 店舗グループ追加ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String addShopGrp() throws AmallException {

		List<AceumShopGrpDto> grplist = m_Aceum11Form.getShopGrpList();
		AceumShopGrpDto grpdto = new AceumShopGrpDto();
		grpdto.setShopGrpCd("");
		grpdto.setShopGrpNm("");
		grplist.add(grpdto);
		 m_Aceum11Form.setShopGrpList(grplist);

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 登録ボタン押下処理実行
	 * <p>
	 * 登録ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException, Exception {

		// 入力値チェック
		if (!inputCheck()) {
			return FORWARD_DISP;
		}

		return FORWARD_DISP;
	}
	/*************************************************************************************
	 * 削除ボタン押下処理実行
	 * <p>
	 * 削除ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String delete() throws AmallException {

		return FORWARD_BACK;
	}
	/*************************************************************************************
	 * 戻るボタン押下処理実行
	 * <p>
	 * 戻るボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String back() throws AmallException {

		return FORWARD_BACK;
	}
	/*************************************************************************************
	 * 入力値チェック
	 * <p>
	 * 入力値チェックを実施する
	 * </p>
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheck() throws AmallException, Exception {

		// 返却フラグ
		boolean ret = true;

		// 権限チェック(必須)

		// 顧客コードチェック(必須)



		// == ユーザー情報エリア ==
		// ユーザーIDチェック
		if (m_Aceum11Dto.getDispMode() == MODE_NEW) {
			// 新規モードのみ
			// ユーザーID(前半)
			String userIdHead = m_Aceum11Form.getInputedUserIdHead();

			// ユーザーID(後半)
			String userIdBack = m_Aceum11Form.getInputedUserIdBack();

			if(!inputCheckUserId(userIdHead, userIdBack, m_Aceum11Form.getM_systemKind())) {
				ret = false;
			}

		}



		// 自由記載エリアチェック
		// ユーザー名
		String userName = m_Aceum11Form.getInputedUserNm();
		// コメント
		String userCmt = m_Aceum11Form.getInputedCmt();

		if(!inputCheckFree(userName, userCmt)) {
			ret = false;
		}


		// == パスワード情報エリア ==
		// パスワードチェック
		// パスワード
		String pass = m_Aceum11Form.getPassword();
		// 再パスワード
		String rePass = m_Aceum11Form.getRePassword();

		if(!inputCheckPass(pass, rePass)) {
			ret = false;
		}


		// パスワード(期間)チェック
		// 有効期限なしフラグがONの場合はチェックなし
		if(!m_Aceum11Form.isCheckPwdExpFlg()) {
			// 有効期限
			String expDate = m_Aceum11Form.getInputedPasswordExp();
			// 有効期間
			String valid = m_Aceum11Form.getInputedPasswordValid();

			if(!inputCheckPassPeriod(expDate, valid)) {
				ret = false;
			}
		}

		// == その他 ==
		// パスワードロック ラジオボタンチェック
		String pLock = m_Aceum11Form.getSelectedPwdLockRadio();
		if(AmallUtilities.isEmpty(pLock)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_PASS_LOCK, m_Aceum11DispBean));
			ret = false;
		}

		// パスワードロック ラジオボタンチェック
		String actLock = m_Aceum11Form.getSelectedPwdLockRadio();
		if(AmallUtilities.isEmpty(actLock)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_ACT_LOCK, m_Aceum11DispBean));
			ret = false;
		}

		return ret;
	}
	/*************************************************************************************
	 * 入力値チェック(ユーザーID)
	 * <p>
	 * ユーザーIDの入力値チェックを実施する
	 * </p>
	 * @param  userIdhead	ユーザーID(前半)
	 * @param  userIdback	ユーザーID(後半)
	 * @param  cstCd	顧客コード
	 * @param  systemKind	システム種別
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheckUserId(String userIdhead, String userIdback, int systemKind) throws AmallException {

		// 返却フラグ
		boolean retFlg = true;



		// 処理終了
		return retFlg;

	}

	/*************************************************************************************
	 * 入力値チェック(自由入力)
	 * <p>
	 * 自由入力の入力値チェックを実施する
	 * </p>
	 * @param  userNm	ユーザー名
	 * @param  cmt	コメント
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheckFree(String userNm, String cmt) throws AmallException {

		// 返却フラグ
		boolean retFlg = true;


		// 入力値チェック(ユーザー名)
		if (!AmallUtilities.isEmpty(userNm)) {
			// 入力値が存在する場合
			if (AmallUtilities.getLengthAsHalf(userNm) > (InputNum.USER_NM * 2)) {
				// 60文字より多い数字が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_STR_WTN,
						getItemDispName(ITEM_ID_USER_NM, m_Aceum11DispBean), String.valueOf(InputNum.USER_NM));
				setError(m_Aceum11DispBean, ITEM_ID_USER_NM);

				retFlg = false;
			}
		}

		// 入力値チェック(コメント)
		if (!AmallUtilities.isEmpty(cmt)) {
			// 入力値が存在する場合
			if (AmallUtilities.getLengthAsHalf(cmt) > (InputNum.USER_CMT * 2)) {
				// 60文字より多い数字が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_STR_WTN,
						getItemDispName(ITEM_ID_CMT, m_Aceum11DispBean), String.valueOf(InputNum.USER_CMT));
				setError(m_Aceum11DispBean, ITEM_ID_CMT);

				retFlg = false;
			}
		}

		// 処理終了
		return retFlg;

	}
	/*************************************************************************************
	 * 入力値チェック(パスワード)
	 * <p>
	 * パスワードの入力値チェックを実施する
	 * </p>
	 * @param  pwd		パスワード
	 * @param  rePwd	再パスワード
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheckPass(String pwd, String rePwd) throws AmallException {

		// 返却フラグ
		boolean retFlg = true;

		// 入力なし
		if (AmallUtilities.isEmpty(pwd) && AmallUtilities.isEmpty(rePwd)){
			// チェックなし
			return true;
		}

		// 必須入力チェック
		// Password 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(pwd)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_PASS, m_Aceum11DispBean));
			setError(m_Aceum11DispBean, ITEM_ID_PASS);
			setError(m_Aceum11DispBean, ITEM_ID_RE_PASS);
			retFlg = false;
		}

		// 再Password 必須ﾁｪｯｸ
		if (AmallUtilities.isEmpty(rePwd)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_RE_PASS, m_Aceum11DispBean));
			setError(m_Aceum11DispBean, ITEM_ID_PASS);
			setError(m_Aceum11DispBean, ITEM_ID_RE_PASS);
			retFlg = false;
		}

		// パスワード・再パスワードの一致
		if (retFlg == true && !pwd.equals(rePwd)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_PASSWORD_NOT_SAME);
			setError(m_Aceum11DispBean, ITEM_ID_PASS);
			setError(m_Aceum11DispBean, ITEM_ID_RE_PASS);
			retFlg = false;
		}

		// パスワードの内容チェック
		if(retFlg) {
			// ログイン情報の取得
			AmdtoLoginInfo loginInfo = getLoginInfoDTO();

			// ログイン情報存在チェック
			if(loginInfo == null) {
				// 例外を投げる
				AmallException e = new AmallException();
				e.addException(this.m_ClassName, "inputCheckPass()", AmallMessageConst.MSG_SYS_DTO_MNG_DATA_GET_ERROR,
						"m_loginInfo");
				throw e;
			}

			List<String> msglist = AmallPasswordControl.passwordValidateCheck(pwd, loginInfo, m_DbAccess);
			if (msglist.size() > 0) {
				// メッセージを設定
				m_Aceum11DispBean.setMessage(msglist);
				m_Aceum11DispBean.setMessageType(MsgCode.ERROR);
				// 欄を赤く
				setError(m_Aceum11DispBean, ITEM_ID_PASS);
				setError(m_Aceum11DispBean, ITEM_ID_RE_PASS);
				retFlg = false;

			}
		}

		// 処理終了
		return retFlg;

	}

	/*************************************************************************************
	 * 入力値チェック(パスワード期間)
	 * <p>
	 * パスワード(期間)の入力値チェックを実施する
	 * </p>
	 * @param  expDate	有効期限日(YYYY/MM/DD形式)
	 * @param  valdMonth	有効期間(月数)
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheckPassPeriod(String expDate, String valdMonth) throws AmallException, Exception {

		// 返却フラグ
		boolean retFlg = true;


		// 必須入力チェック
		if (AmallUtilities.isEmpty(expDate)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_PASSEXP, m_Aceum11DispBean));
			setError(m_Aceum11DispBean, ITEM_ID_PASSEXP);
			retFlg = false;
		} else {

			// 日付妥当性チェック
			if (expDate.length() != 10) {
				if (expDate.length() == 8) {
					// 「/」が含まれていない日付の場合挿入
					expDate = AmallUtilities.changeFormat(expDate);
				} else {
					setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_DATE_ERROR);
					setError(m_Aceum11DispBean, ITEM_ID_PASSEXP);
					retFlg = false;
				}
			}
			if(retFlg) {
				if (!AmallUtilities.checkExistDate(expDate)) {
					// 正しい日付か
					setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_NOT_EXIST_DATE,	getItemDispName(ITEM_ID_PASSEXP, m_Aceum11DispBean));
					setError(m_Aceum11DispBean, ITEM_ID_PASSEXP);
					retFlg = false;
				}
			}
		}

		// 必須入力チェック
		if (AmallUtilities.isEmpty(valdMonth)) {
			setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD, getItemDispName(ITEM_ID_PASSVALID, m_Aceum11DispBean));
			setError(m_Aceum11DispBean, ITEM_ID_PASSVALID);
			retFlg = false;
		} else {
			if (!AmallUtilities.isHalfWidthCharacterKind(valdMonth, AmallUtilities.H_NUM)) {
				// 半角数字以外が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_NUM_WTN,
						getItemDispName(ITEM_ID_PASSVALID, m_Aceum11DispBean), String.valueOf(InputNum.PASS_VALID));
				setError(m_Aceum11DispBean, ITEM_ID_PASSVALID);

				retFlg = false;
			} else if (AmallUtilities.getLengthAsHalf(valdMonth) > InputNum.PASS_VALID) {
				// 3桁以上の数字が設定されている
				setMessageInfo(m_Aceum11DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_NUM_WTN,
						getItemDispName(ITEM_ID_PASSVALID, m_Aceum11DispBean), String.valueOf(InputNum.PASS_VALID));
				setError(m_Aceum11DispBean, ITEM_ID_PASSVALID);

				retFlg = false;
			}
		}

		// 正常終了
		return retFlg;

	}
	/*************************************************************************************
	 * 顧客マスタ(DB)ユニークチェック
	 * <p>
	 * 顧客マスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できる場合はActionFormに値を設定し，
	 * 特定できない場合はfalseで返却する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @return boolean true:正常 false:異常
	 ************************************************************************************/
//	private boolean chkUniqCst(String cstCd) throws AmallException, Exception {
//
//		String methodName = "chkUniqCst()";
//
//		ResultSet rs = null;
//		StringBuffer sql = new StringBuffer();
//		// 返却用チェックリスト
//		List<String> retList = new ArrayList<>();
//
//		try {
//			// SQLの生成
//			sql.append("SELECT");
//			sql.append("	CST_NM");
//			sql.append("  FROM");
//			sql.append("	N_CST_M");
//			sql.append(" WHERE");
//			sql.append("	DEL_FLG = ?");
//			sql.append("	AND CST_CD = ?");
//			// 顧客範囲設定
//			// 全顧客判定
//			if (!m_Aceum11DispBean.isCustomerCdAllFlg()) {
//				// 全顧客ではない場合
//				sql.append("	AND CST_CD IN (");
//				for (String appCustomer : m_Aceum11DispBean.getCustomerCdList()) {
//					sql.append("'").append(appCustomer).append("',");
//				}
//				sql.append("'')");
//			}
//
//			m_DbAccess.createPreparedStatement(sql.toString());
//			// 条件設定
//			int setCnt = 0;
//			// 削除フラグ
//			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
//			// 顧客コード
//			m_DbAccess.setString(++setCnt, cstCd);
//
//			// SQL実行
//			rs = m_DbAccess.executeQuery();
//
//			// 結果取得
//			while (rs.next()) {
//
//				// 店舗名
//				String name = m_DbAccess.getString(rs, "CST_NM");
//
//				// リストに追加
//				retList.add(name);
//			}
//
//			// 結果チェック
//			if(retList.size() != 1) {
//				// 1件以外の取得結果の場合
//				return false;
//			}
//
//			// 値を設定
//			m_Aceum11Form.setDispCstNm(retList.get(0));
//			m_Aceum11Dto.setSavedCustomerNm(retList.get(0));
//
//			return true;
//		} catch (AmallException ame) {
//			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_CST_M");
//			throw ame;
//		} catch (SQLException e) {
//			AmallException ee = new AmallException();
//			ee.addException(m_ClassName, methodName, e);
//			throw ee;
//		} finally {
//			if (rs != null) {
//				rs.close();
//				rs = null;
//			}
//		}
//
//	}

	/*************************************************************************************
	 * 店舗マスタ(DB)ユニークチェック
	 * <p>
	 * 店舗マスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できる場合はActionFormに値を設定し，
	 * 特定できない場合はfalseで返却する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @return boolean true:正常 false:異常
	 ************************************************************************************/
//	private boolean chkUniqShop(String cstCd, String shopCd) throws AmallException, Exception {
//
//		String methodName = "chkUniqShop()";
//
//		ResultSet rs = null;
//		StringBuffer sql = new StringBuffer();
//		// 返却用チェックリスト
//		List<String> retList = new ArrayList<>();
//
//		try {
//			// SQLの生成
//			sql.append("SELECT");
//			sql.append("	ncm.CST_CD");
//			sql.append(",	ncm.CST_NM");
//			sql.append(",	nsm.SHOP_NM");
//			sql.append(",	TRIM(nscm.COMPANY_SHOP_NM) AS COMPANY_SHOP_NM");
//			sql.append("  FROM");
//			sql.append("  	N_SHOP_M nsm");
//			sql.append("	LEFT JOIN");
//			sql.append("		N_CST_M ncm");
//			sql.append("	  ON");
//			sql.append("		nsm.CST_CD = ncm.CST_CD");
//			sql.append("		AND ncm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
//			sql.append("	LEFT JOIN");
//			sql.append("		N_SHOP_CNV_M nscm");
//			sql.append("	  ON");
//			sql.append("		nsm.CST_CD = nscm.CST_CD");
//			sql.append("		AND nsm.SHOP_CD = nscm.SHOP_CD");
//			sql.append("		AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
//			sql.append("		AND nscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
//			sql.append(" WHERE");
//			sql.append("	nsm.DEL_FLG = ?");
//			sql.append("	AND ? BETWEEN nsm.EFST_DY AND nsm.EFED_DY");
//			sql.append("	AND nsm.CST_CD = ?");
//			sql.append("	AND (");
//			sql.append("			nsm.SHOP_CD = ?");
//			sql.append("			OR");
//			sql.append("			TRIM(nscm.COMPANY_SHOP_CD) = ?");
//			sql.append("		)");
//			// 店舗範囲設定
//			// 全店舗判定
//			if (!m_Aceum11DispBean.isShopCdAllFlg()) {
//				// 全顧客・全店舗ではない場合
//				sql.append("	AND (");
//				boolean first = true;
//				for (Entry<String, List<String>> entry : m_Aceum11DispBean.getShopCdListMap().entrySet()) {
//
//					String appCstCd = entry.getKey();
//					for (String appShop : entry.getValue()) {
//						if (first) {
//							sql.append("		");
//							first = false;
//						} else {
//							sql.append("		OR");
//						}
//						sql.append("		(");
//						sql.append("			nsm.CST_CD = '").append(appCstCd).append("'");
//						sql.append("			AND");
//						sql.append("			nsm.SHOP_CD = '").append(appShop).append("'");
//						sql.append("		)");
//					}
//				}
//				sql.append("	)");
//			}
//
//
//			m_DbAccess.createPreparedStatement(sql.toString());
//			// 条件設定
//			int setCnt = 0;
//			// 有効期限
//			m_DbAccess.setString(++setCnt, m_Aceum11DispBean.getServiceDate());
//			// 削除フラグ
//			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
//			// 有効期限
//			m_DbAccess.setString(++setCnt, m_Aceum11DispBean.getServiceDate());
//			// 顧客コード
//			m_DbAccess.setString(++setCnt, cstCd);
//			// 店舗コード
//			m_DbAccess.setString(++setCnt, shopCd);
//			// 店舗コード
//			m_DbAccess.setString(++setCnt, shopCd);
//
//			// SQL実行
//			rs = m_DbAccess.executeQuery();
//
//			// 結果取得
//			String cstNmData = "";
//			while (rs.next()) {
//
//				// 店舗名
//				String name = m_DbAccess.getString(rs, "SHOP_NM");
//				// 店舗名(企業)
//				String comapany = m_DbAccess.getString(rs, "COMPANY_SHOP_NM");
//
//				// 企業店舗コード判定
//				if (AmallUtilities.isEmpty(comapany)) {
//					// リストに追加
//					retList.add(name);
//				} else {
//					// 企業店舗コードがある場合は企業店舗を優先
//					// リストに追加
//					retList.add(comapany);
//				}
//
//				// 顧客名
//				cstNmData = m_DbAccess.getString(rs, "CST_NM");
//
//			}
//
//			// 結果チェック
//			if(retList.size() != 1) {
//				// 1件以外の取得結果の場合
//				return false;
//			}
//
//			// 値を設定
//			m_Aceum11Form.setDispShopNm(retList.get(0));
//			m_Aceum11Dto.setSavedShopNm(retList.get(0));
//			m_Aceum11Form.setDispCstNm(cstNmData);
//			m_Aceum11Dto.setSavedCustomerNm(cstNmData);
//
//
//			return true;
//		} catch (AmallException ame) {
//			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_SHOP_M");
//			throw ame;
//		} catch (SQLException e) {
//			AmallException ee = new AmallException();
//			ee.addException(m_ClassName, methodName, e);
//			throw ee;
//		} finally {
//			if (rs != null) {
//				rs.close();
//				rs = null;
//			}
//		}
//
//	}


}