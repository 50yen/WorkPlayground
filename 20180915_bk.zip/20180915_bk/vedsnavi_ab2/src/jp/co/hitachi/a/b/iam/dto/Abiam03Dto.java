/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abiam03Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.dto;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Abiam03Dtoクラス<br>
 *****************************************************************************************/
public class Abiam03Dto extends AmclsDtoBase{

	/** メンバ変数 */
	/** 関連更新対象データ */
	private Map<String, AbiamIndScreenAuthDto> updateChainDataMap = null;

	/*************************************************************************************
     * コンストラクタ
     * <p>
     * コンストラクタ
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public Abiam03Dto(){
		clear();
	}
	/*************************************************************************************
     * クリア
     * <p>
     * クリア
     * </p>
     * @param  無し
     * @return 無し
     ************************************************************************************/
	public void clear(){
		updateChainDataMap =  new ConcurrentHashMap<>();
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////
	public Map<String, AbiamIndScreenAuthDto> getUpdateChainDataMap() {
		return updateChainDataMap;
	}
	public void setUpdateChainDataMap(Map<String, AbiamIndScreenAuthDto> updateChainDataMap) {
		this.updateChainDataMap = updateChainDataMap;
	}



}
