/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aceum11DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.20 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.eum.bean;

import java.util.List;

import jp.co.hitachi.a.m.cls.AmclsBeanBase;
import jp.co.hitachi.a.m.dto.AmdtoDropDownList;
import jp.co.hitachi.a.m.dto.AmdtoRadioList;

/*****************************************************************************************
 * Aceum11DispBeanクラス<br>
 *****************************************************************************************/
public class Aceum11DispBean extends AmclsBeanBase {

	/** メンバ変数 */
	/** 権限ロールプルダウンリスト */
	private List<AmdtoDropDownList> roleDropDownList = null;

	/** パスワードロックラジオボタンリスト */
	private List<AmdtoRadioList> radioPwdLockList = null;

	/** アカウントロックラジオボタンリスト */
	private List<AmdtoRadioList> radioActLockList = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Aceum11DispBean() {
		super();
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		super.clear();
		roleDropDownList = null;
	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public List<AmdtoDropDownList> getRoleDropDownList() {
		return roleDropDownList;
	}

	public void setRoleDropDownList(List<AmdtoDropDownList> roleDropDownList) {
		this.roleDropDownList = roleDropDownList;
	}

	public List<AmdtoRadioList> getRadioPwdLockList() {
		return radioPwdLockList;
	}

	public void setRadioPwdLockList(List<AmdtoRadioList> radioPwdLockList) {
		this.radioPwdLockList = radioPwdLockList;
	}

	public List<AmdtoRadioList> getRadioActLockList() {
		return radioActLockList;
	}

	public void setRadioActLockList(List<AmdtoRadioList> radioActLockList) {
		this.radioActLockList = radioActLockList;
	}

}
