/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Actmp02DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.tmp.business;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.tmp.action.Actmp02Action;
import jp.co.hitachi.a.c.tmp.bean.Actmp02DispBean;
import jp.co.hitachi.a.c.tmp.dto.ActmpItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst.Encode;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoCalender;
import jp.co.hitachi.a.m.dto.AmdtoDropDownList;

/*****************************************************************************************
 * Actmp02Businessクラス<br>
 *****************************************************************************************/
public class Actmp02Business extends ActmpBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Actmp02DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** ダウンロード処理 */
	public static final String FORWARD_DOWNLOAD = "DOWNLOAD";
	/** アップロード処理 */
	public static final String FORWARD_UPLOAD = "UPLOAD";

	/**
	 * 画面項目ID
	 */
	/** TEMP01 */
	public static final String ITEM_ID_TEMP01 = "temp01";
	/** TEMP01 */
	public static final String ITEM_ID_TEMP02 = "temp02";

	/** メンバ変数 */
	/** アクションフォーム */
	private Actmp02Action m_Actmp02Form = null;
	/** 表示用画面Bean */
	private Actmp02DispBean m_Actmp02DispBean = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Actmp02Business(
			Actmp02Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Actmp02Business.class.getName();
		m_Actmp02Form = form;
		m_Actmp02DispBean = new Actmp02DispBean();

		setErrString(gid, m_Actmp02Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Actmp02DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Actmp02Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_DOWNLOAD.equals(m_Event)) {
				// ダウンロード処理の場合
				forwardStr = download();
			} else if (FORWARD_UPLOAD.equals(m_Event)) {
				// アップロード処理の場合
				disp();
				forwardStr = upload();

			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Actmp02DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		// エラーメッセージの設定
		setMessageInfo(m_Actmp02DispBean, "Mapw001");

		// 情報表示エリアの表示文字1
		m_Actmp02DispBean.setDivDispData1("情報表示エリア1　※センターの更新状況などを表示します。");

		// 情報表示エリアの表示文字2
		m_Actmp02DispBean.setDivDispData2("情報表示エリア2　※センターの更新状況などを表示します。");

		// カレンダーデータの作成
		List<List<AmdtoCalender>> calender = AmallUtilities.getCalenderDispData("201807", m_DbAccess);

		// 内容データの設定
		AmallUtilities.setCalenderContentsData("20180710", AmdtoCalender.CON_TYPE_ERROR, "回収実績有", "誤差発生", calender);
		AmallUtilities.setCalenderContentsData("20180726", AmdtoCalender.CON_TYPE_ON, "回収実績有", "", calender);

		m_Actmp02DispBean.setCalDataList(calender);

		// ドロップダウンリストの中身作成
		List<AmdtoDropDownList> list = new ArrayList<>();

		AmdtoDropDownList dto = new AmdtoDropDownList();

		dto.setId("10");
		dto.setName("ASS管理者");
		list.add(dto);

		dto = new AmdtoDropDownList();
		dto.setId("20");
		dto.setName("ASS管制");
		list.add(dto);

		dto = new AmdtoDropDownList();
		dto.setId("30");
		dto.setName("ASS企業担当");
		list.add(dto);

		m_Actmp02DispBean.setDownlist(list);

		// 入力エリア青
		m_Actmp02DispBean.setInputLbl1("（株）アサヒ商事");
		m_Actmp02DispBean.setInputLbl2("海岸店");
		m_Actmp02DispBean.setInputLbl3("20181年7月20日");
		m_Actmp02DispBean.setInputLbl4("123-55-66");
		m_Actmp02DispBean.setInputLbl5("鑑定券(1000円) あいうえおかきくけこ");

		// 一覧表示データ
		List<ActmpItemDispDto> itiran = new ArrayList<>();
		ActmpItemDispDto listdto = new ActmpItemDispDto();
		listdto.setItemId("customerName");
		listdto.setItemDispName("顧客名");
		listdto.setItemType("Label");
		listdto.setDispCd("1");
		listdto.setEnableCd("0");

		itiran.add(listdto);

		listdto = new ActmpItemDispDto();
		listdto.setItemId("shopName");
		listdto.setItemDispName("店舗名");
		listdto.setItemType("Label");
		listdto.setDispCd("0");
		listdto.setEnableCd("0");

		itiran.add(listdto);

		listdto = new ActmpItemDispDto();
		listdto.setItemId("shopButton");
		listdto.setItemDispName("検索ボタン");
		listdto.setItemType("Button");
		listdto.setDispCd("1");
		listdto.setEnableCd("1");

		itiran.add(listdto);

		// 日付
		m_Actmp02Form.setTemp03("2018/09/05");

		m_Actmp02DispBean.setItemDispList(itiran);

		if (m_DbAccess != null) {
			m_DbAccess.exitDB();
		}
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ダウンロード処理
	 * <p>
	 * ダウンロード処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String download() throws AmallException {

		// ファイルデータ作成
		List<String> data = new ArrayList<>();
		data.add("1行目");
		data.add("2行目,3行目");

		// ファイルデータ出力
		m_Actmp02Form.setDownloadFileData(data, "download.csv", Encode.SHIFT_JIS);

		return FORWARD_DOWNLOAD;
	}

	/*************************************************************************************
	 * アップロード処理
	 * <p>
	 * アップロード処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String upload() throws AmallException {

		// ファイルデータ取得
		File infile = m_Actmp02Form.getUpLoadFile();
		try {
			//FileReaderクラスのオブジェクトを生成する
			FileReader filereader = new FileReader(infile);

			//filereaderクラスのreadメソッドでファイルを1文字ずつ読み込む
			int data;
			while ((data = filereader.read()) != -1) {
				System.out.print((char) data);
			}

			//ファイルクローズ
			filereader.close();
		} catch (Exception e) {

		}

		return FORWARD_DISP;
	}

}