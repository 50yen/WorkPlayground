/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Acsgm01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.sgm.business;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.sgm.action.Acsgm01Action;
import jp.co.hitachi.a.c.sgm.bean.Acsgm01DispBean;
import jp.co.hitachi.a.c.sgm.dto.Acsgm01Dto;
import jp.co.hitachi.a.c.sgm.dto.AcsgmItemDispDto;
import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.InputNum;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallPage;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoPagingSql;

/*****************************************************************************************
 * Acsgm01Businessクラス<br>
 *****************************************************************************************/
public class Acsgm01Business extends AcsgmBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Acsgm01DispBean";
	/** 内部記憶用DTO名 */
	private static final String DTO_ACSGM01 = "DTO_ACSGM01";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	private static final String FORWARD_DISP = "DISP";
	/** 画面遷移 */
	private static final String FORWARD_DETAIL = "DETAIL";
	/** 検索 */
	private static final String FORWARD_SEARCH = "SEARCH";
	/** 登録 */
	private static final String FORWARD_REGIST = "REGIST";
	/** 先頭頁処理 */
	private static final String FORWARD_PAGEFIRST = "PAGEFIRST";
	/** 前頁 */
	private static final String FORWARD_PAGEPREV = "PAGEPREV";
	/** 次頁 */
	private static final String FORWARD_PAGENEXT = "PAGENEXT";
	/** 最終頁 */
	private static final String FORWARD_PAGELAST = "PAGELAST";
	/** 件数変更 */
	private static final String FORWARD_DISPRESULTS = "DISPRESULTS";
	/** 編集ボタン */
	private static final String FORWARD_EDIT = "EDIT";
	/** コピーボタン */
	private static final String FORWARD_COPY = "COPY";
	/** 戻る処理 */
	private static final String FORWARD_REDISP = "REDISP";

	/**
	 * 画面項目ID
	 */
	// 画面のフォームのIDを設定する(エラー状態時のキー値用)
	/** お客様コード */
	private static final String ITEM_ID_CST_SEARCH_NM = "customerSearchNm";

	/** 店舗コード */
	private static final String ITEM_ID_SHOP_SEARCH_NM = "shopSearchNm";

	/** お客様グループコード */
	private static final String ITEM_ID_SHOP_GRP_CD = "shopGroupCd";

	/** メンバ変数 */
	// フォームとBeanの変数をメンバ変数で定義 フォームから画面上の入力値が取得可能
	/** アクションフォーム */
	private Acsgm01Action m_Acsgm01Form = null;
	/** 表示用画面Bean */
	private Acsgm01DispBean m_Acsgm01DispBean = null;
	/** ページング処理用 */
	private AmallPage m_Page = null;
	/** SQL作成用 */
	private AmdtoPagingSql m_Page_Sql = null;
	/** 画面DTO */
	private Acsgm01Dto m_Acsgm01Dto = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Acsgm01Business(
			Acsgm01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Acsgm01Business.class.getName();
		m_Acsgm01Form = form;
		m_Acsgm01DispBean = new Acsgm01DispBean();
		m_Page = new AmallPage();
		m_Page_Sql = new AmdtoPagingSql();
		m_Acsgm01Dto = new Acsgm01Dto();
		setErrString(gid, m_Acsgm01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}
			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Acsgm01DispBean);

			/* 内部記憶情報の生成 */
			m_Acsgm01Dto = (Acsgm01Dto) getSpecifiedDTO(m_Gid, DTO_ACSGM01);
			if (m_Acsgm01Dto == null || FORWARD_DISP.equals(m_Event)) {
				m_Acsgm01Dto = new Acsgm01Dto();
				putSpecifiedDTO(m_Gid, DTO_ACSGM01, m_Acsgm01Dto);
			}

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Acsgm01Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_SEARCH.equals(m_Event)) {
				// 検索ボタン押下の場合
				forwardStr = search();
			} else if (FORWARD_REGIST.equals(m_Event)) {
				// 登録ボタン押下の場合
				forwardStr = regist();
			} else if (FORWARD_PAGEFIRST.equals(m_Event)) {
				// "<<"ボタン押下の場合
				forwardStr = pageFirst();
			} else if (FORWARD_PAGEPREV.equals(m_Event)) {
				// "<"ボタン押下の場合
				forwardStr = pagePrev();
			} else if (FORWARD_PAGENEXT.equals(m_Event)) {
				// ">"ボタン押下の場合
				forwardStr = pageNext();
			} else if (FORWARD_PAGELAST.equals(m_Event)) {
				// ">>"ボタン押下の場合
				forwardStr = pageLast();
			} else if (FORWARD_DISPRESULTS.equals(m_Event)) {
				// 表示件数変更の場合
				forwardStr = changeDispRslts();
			} else if (FORWARD_EDIT.equals(m_Event)) {
				// 編集ボタン押下処理の場合
				forwardStr = edit();
			}else if (FORWARD_COPY.equals(m_Event)) {
				// コピーボタン押下処理の場合
				forwardStr = copy();
			}else if (FORWARD_REDISP.equals(m_Event)) {
				// 戻るボタン押下処理の場合
				forwardStr = redisp();

			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Acsgm01DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 検索ボタン押下処理実行
	 * <p>
	 * 検索ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String search() throws AmallException, Exception {

		// 入力値チェック
		if (!inputCheck()) {
			// エラーの場合
			return FORWARD_DISP;
		}

		// 検索処理を呼ぶ
		searchProc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * "<"ボタン押下処理実行
	 * <p>
	 * "<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pagePrev() throws AmallException {

		// 検索処理を呼ぶ
		searchProc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * "<<"ボタン押下処理実行
	 * <p>
	 * "<<"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageFirst() throws AmallException {

		// 検索処理を呼ぶ
		searchProc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ">"ボタン押下処理実行
	 * <p>
	 * ">"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageNext() throws AmallException {

		// 検索処理を呼ぶ
		searchProc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ">>"ボタン押下処理実行
	 * <p>
	 * ">>"ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String pageLast() throws AmallException {

		// 検索処理を呼ぶ
		searchProc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 表示件数変更処理実行
	 * <p>
	 * 表示件数変更処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String changeDispRslts() throws AmallException {

		// 検索処理を呼ぶ
		searchProc();

		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * 登録処理
	 * <p>
	 * 登録処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String regist() throws AmallException {

		AcsgmItemDispDto dto = new AcsgmItemDispDto();
		putSpecifiedDTO(ACSGM_INFO_KEY, dto);

		return FORWARD_DETAIL;
	}
	/*************************************************************************************
	 * 編集ボタン押下処理
	 * <p>
	 * 編集ボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String edit() throws AmallException {

		//編集対象店舗グループコードチェック
		if(AmallUtilities.isEmpty(m_Acsgm01Form.getShopGrpCdHid())) {
			// エラーメッセージセット
			setMessageInfo(m_Acsgm01DispBean, AmallMessageConst.MSG_ERR_SELECT_CON_NO_DATA,
					getItemDispName(ITEM_ID_SHOP_GRP_CD, m_Acsgm01DispBean));
			// 検索処理を呼ぶ
			searchProc();
			return FORWARD_DISP;
		}
		// 店舗グループコードをdtoにセット
		AcsgmItemDispDto dto = new AcsgmItemDispDto();
		dto.setShopGrpCd(m_Acsgm01Form.getShopGrpCdHid());
		putSpecifiedDTO(ACSGM_INFO_KEY, dto);

		return FORWARD_DETAIL;
	}

	/*************************************************************************************
	 * コピーボタン押下処理
	 * <p>
	 * コピーボタン押下処理を実行する
	 * </p>
	 * @param  なし
	 * @return ActionForward名称
	 ************************************************************************************/
	private String copy() throws AmallException {

		boolean ret = false;

		//コピー対象店舗グループコードチェック
		if(AmallUtilities.isEmpty(m_Acsgm01Form.getShopGrpCdHid())) {
			setMessageInfo(m_Acsgm01DispBean, AmallMessageConst.MSG_ERR_FAIL_COPY);
			// 検索処理を呼ぶ
			searchProc();
			return FORWARD_DISP;
		}

		//コピー処理を呼ぶ
		ret = copyProc();

		// DB処理正常判定
		if (ret) {
			// コミット処理
			m_DbAccess.commit();

			// 店舗グループコードをdtoにセット
			AcsgmItemDispDto dto = new AcsgmItemDispDto();
			dto.setShopGrpCd(m_Acsgm01Form.getShopGrpCdHid());
			putSpecifiedDTO(ACSGM_INFO_KEY, dto);

			return FORWARD_DETAIL;
		}else {
			// 検索処理を呼ぶ
			searchProc();
			return FORWARD_DISP;
		}
	}
	/*************************************************************************************
	 * 再表示処理
	 * <p>
	 * 「戻る」ボタンで戻ってきた場合の再表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String redisp() throws AmallException {

		m_Acsgm01Form.setInputedCstCd(m_Acsgm01Dto.getInputedCstCd());
		m_Acsgm01Form.setInputedShopCd(m_Acsgm01Dto.getInputedShopCd());
		m_Acsgm01Form.setDisplayNum(m_Acsgm01Dto.getDisplayNum());
		m_Acsgm01Form.setDispResults(m_Acsgm01Dto.getDispResults());
		// 検索処理
		searchProc();

		return FORWARD_DISP;

	}

	/*************************************************************************************
	 * 検索処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private void searchProc() throws AmallException {
		// methodName
		String methodName = "searchProc()";
		// 明細部用LIST
		List<AcsgmItemDispDto> detailList = new ArrayList<>();

		//検索値
		String searchCst = null;
		String searchshop = null;
		if ( m_Event.equals(FORWARD_SEARCH)) {
			searchCst = m_Acsgm01Form.getInputedCstCd();
			searchshop = m_Acsgm01Form.getInputedShopCd();
			m_Acsgm01Dto.setInputedCstCd(searchCst);
			m_Acsgm01Dto.setInputedShopCd(searchshop);
		}else {
			searchCst = m_Acsgm01Dto.getInputedCstCd();
			searchshop = m_Acsgm01Dto.getInputedShopCd();
			m_Acsgm01Form.setInputedCstCd(searchCst);
			m_Acsgm01Form.setInputedShopCd(searchshop);
		}

		try {
			makeSearchSql(searchCst,searchshop);

			// select句
			String sqlSelect = m_Page_Sql.getSqlSelect();
			// from where 句
			String sqlCondition = m_Page_Sql.getSqlConditinon();
			// order 句
			String sqlOrder = m_Page_Sql.getSqlOrder();
			// param 句
			String[] sqlParam = m_Page_Sql.getSqlParam();
			// 表示件数
			int pageDispCnt = m_Page_Sql.getPageDispCnt();
			// ページ番号
			int pageNo = m_Acsgm01Form.getDisplayNum();

			List<Map<String, String>> pageData;
			if (m_Event.equals(FORWARD_DISP) || m_Event.equals(FORWARD_SEARCH)) { // 初期検索状態
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEFIRST)) { // "<<"ボタン押下時
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGEPREV)) { // "<"ボタン押下時
				pageData = m_Page.getPrevPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGENEXT)) { // ">"ボタン押下時
				pageData = m_Page.getNextPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageNo,
						pageDispCnt);
			} else if (m_Event.equals(FORWARD_PAGELAST)) { // ">>"ボタン押下時
				pageData = m_Page.getLastPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			} else { // 表示件数プル変更時、その他
				pageData = m_Page.getFirstPage(m_DbAccess, sqlSelect, sqlCondition, sqlOrder, sqlParam, pageDispCnt);
			}

			/* 表示頁NOのセット */
			m_Acsgm01DispBean.setDisplayNum(m_Page.getNowPage());
			/* ページ遷移ボタンセット */
			if (!m_Page.isPrevPageExist()) {
				m_Acsgm01DispBean.setPrevPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Acsgm01DispBean.setPrevPageFlg(AmallConst.GeneralFlg.OFF);
			}
			if (!m_Page.isNextPageExist()) {
				m_Acsgm01DispBean.setNextPageFlg(AmallConst.GeneralFlg.ON);
			} else {
				m_Acsgm01DispBean.setNextPageFlg(AmallConst.GeneralFlg.OFF);
			}

			// 件数セット
			m_Acsgm01DispBean.setDispCountDefault(String.valueOf(pageDispCnt));

			// ページ情報がない場合
			if (pageData == null) {
				// エラーメッセージをセット
				setMessageInfo(m_Acsgm01DispBean, AmallMessageConst.MSG_INF_SEARCH_CON_NO_DATA);
				return;

			}

			detailList = makeDetailList(m_Page.getNowPage(), pageData);

			/* 表示Beanに一覧データをセット */
			m_Acsgm01DispBean.setItemDispList(detailList);

			//検索欄名称設定処理
			if (!AmallUtilities.isEmpty(searchCst)) {
				//お客様コードが設定されている場合
				chkUniqCst(searchCst);
				if(!AmallUtilities.isEmpty(searchshop)){
					// 名称取得
					chkUniqShop(searchCst, searchshop);
				}
			}

			//dtoに退避
			m_Acsgm01Dto.setDisplayNum(m_Page.getNowPage());
			m_Acsgm01Dto.setDispResults(pageDispCnt);

		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR,"N_SHOP_GRP_M");
			setAmallException(ame);
			throw ame;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, "", e);
			throw ee;
		}

	}
	/*************************************************************************************
	 * 明細リスト作成処理
	 * <p>
	 * 明細リスト作成処理を実行する
	 * </p>
	 * @param  pageSize	頁数
	 * @param	pageData	頁データ
	 * @return 明細ArrayList
	 ************************************************************************************/
	private List<AcsgmItemDispDto> makeDetailList(int pageSize, List<Map<String, String>> pageData)
			throws AmallException {
		String methodName = "makeDetailList()";

		// 返却リスト
		List<AcsgmItemDispDto> retList = new ArrayList<>();

		try {
			// ページ情報をリストに追加
			for (Map<String, String> map : pageData) {
				AcsgmItemDispDto listdto = new AcsgmItemDispDto();
				//店舗グループコード
				listdto.setShopGrpCd(map.get("SHOP_GRP_CD"));
				//店舗グループ名
				listdto.setShopGrpNm(map.get("SHOP_GRP_NM"));
				//登録店舗件数
				listdto.setShopCount(Long.parseLong(map.get("CNT")));

				// 返却リストに追加
				retList.add(listdto);
			}

			return retList;
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}

	}

	/*************************************************************************************
	 * 入力値チェック
	 * <p>
	 * 入力値チェックを実施する
	 * </p>
 	 * @return boolean true : 正常 false : 異常
	 ************************************************************************************/
	private boolean inputCheck() throws  AmallException, Exception {
		// 返却フラグ
		boolean ret = true;

		String cstCd = m_Acsgm01Form.getInputedCstCd();
		String shopCd = m_Acsgm01Form.getInputedShopCd();

		// 入力値チェック(顧客コード)
		if (!AmallUtilities.isEmpty(cstCd)) {
			// 入力値が存在する場合
			if (!AmallUtilities.isHalfWidthCharacterKind(cstCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Acsgm01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CST_SEARCH_NM, m_Acsgm01DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Acsgm01DispBean, ITEM_ID_CST_SEARCH_NM);

				ret = false;
			} else if (AmallUtilities.getLengthAsHalf(cstCd) != InputNum.CST_CD) {
				// 10桁以外が設定されている
				setMessageInfo(m_Acsgm01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
						getItemDispName(ITEM_ID_CST_SEARCH_NM, m_Acsgm01DispBean), String.valueOf(InputNum.CST_CD));
				setError(m_Acsgm01DispBean, ITEM_ID_CST_SEARCH_NM);

				ret = false;
			}
			if(ret) {
				// 名称取得
				chkUniqCst(cstCd);
			}
		}

		// 入力値チェック(店舗コード)
		if (!AmallUtilities.isEmpty(shopCd)) {
			// 入力値が存在する場合
			// 顧客コード必須チェック

			// 入力値チェック(顧客コード)
			if (!AmallUtilities.isEmpty(cstCd)) {
				// 入力値が存在する場合
				if (!AmallUtilities.isHalfWidthCharacterKind(cstCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
					// 半角英数以外が設定されている
					setMessageInfo(m_Acsgm01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
							getItemDispName(ITEM_ID_CST_SEARCH_NM, m_Acsgm01DispBean), String.valueOf(InputNum.CST_CD));
					setError(m_Acsgm01DispBean, ITEM_ID_CST_SEARCH_NM);

					ret = false;
				} else if (AmallUtilities.getLengthAsHalf(cstCd) != InputNum.CST_CD) {
					// 10桁以外が設定されている
					setMessageInfo(m_Acsgm01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR,
							getItemDispName(ITEM_ID_CST_SEARCH_NM, m_Acsgm01DispBean), String.valueOf(InputNum.CST_CD));
					setError(m_Acsgm01DispBean, ITEM_ID_CST_SEARCH_NM);

					ret = false;
				}
			} else {
				// 入力がない場合
				setMessageInfo(m_Acsgm01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_REQUIRD,
						getItemDispName(ITEM_ID_CST_SEARCH_NM, m_Acsgm01DispBean));
				setError(m_Acsgm01DispBean, ITEM_ID_CST_SEARCH_NM);

				ret = false;
			}


			if (!AmallUtilities.isHalfWidthCharacterKind(shopCd, AmallUtilities.H_NUM|AmallUtilities.H_ALP)) {
				// 半角英数以外が設定されている
				setMessageInfo(m_Acsgm01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
						getItemDispName(ITEM_ID_SHOP_SEARCH_NM, m_Acsgm01DispBean), String.valueOf(InputNum.SHOP_CD));
				setError(m_Acsgm01DispBean, ITEM_ID_SHOP_SEARCH_NM);

				ret = false;
			} else if (AmallUtilities.getLengthAsHalf(shopCd) > InputNum.SHOP_CD) {
				// 10桁より大きい値が設定されている
				setMessageInfo(m_Acsgm01DispBean, AmallMessageConst.MSG_ERR_INPUT_CHK_HALF_STR_WTN,
						getItemDispName(ITEM_ID_SHOP_SEARCH_NM, m_Acsgm01DispBean), String.valueOf(InputNum.SHOP_CD));
				setError(m_Acsgm01DispBean, ITEM_ID_SHOP_SEARCH_NM);

				ret = false;
			}
			if(ret) {
				// 名称取得
				chkUniqShop(cstCd, shopCd);
			}
		}

		return ret;
	}

	/*************************************************************************************
	 * SQL作成
	 * <p>
	 * SQLを作成する
	 * </p>
	 * @param cstCd  顧客CD
	 * @param shopCd 店舗CD
	 * @return SQL
	 ************************************************************************************/
	private void makeSearchSql(String cstCd, String shopCd) throws AmallException, Exception {
		String methodName = "makeSearchSql()";
		StringBuffer sql = new StringBuffer();

		String systemDt = m_Acsgm01DispBean.getServiceDate();

		List<String> list = new ArrayList<>();

		try {
			// 1ページの表示件数
			// 初期検索はデフォルト値を設定する
			if (m_Event.equals(FORWARD_SEARCH)) {
				int dispCnt = m_Acsgm01Form.getDispResults();
				if (dispCnt == 0) {
					m_Page_Sql.setPageDispCnt(Integer.parseInt(m_Acsgm01DispBean.getDispCountDefault()));
				}else {
					m_Page_Sql.setPageDispCnt(dispCnt);
				}
			} else {
				m_Page_Sql.setPageDispCnt(m_Acsgm01Form.getDispResults());
			}

			// SQL SELECT
			sql.delete(0, sql.length());

			sql.append("SELECT");
			sql.append("	sub.SHOP_GRP_CD");
			sql.append(",	sub.SHOP_GRP_NM");
			sql.append(",	sub.CNT");

			String sqlSelect = sql.toString();


			// SQL FROM & WHERE
			sql.delete(0, sql.length());
			sql.append("  FROM ");
			sql.append("  ( select ");
			sql.append("  	    B.SHOP_GRP_CD as SHOP_GRP_CD  ");
			sql.append("  	  	, B.SHOP_GRP_NM as SHOP_GRP_NM  ");
			sql.append("  	 	, COUNT(B.SHOP_CD) as CNT  ");
			sql.append("		from N_SHOP_GRP_M B ");
			sql.append("		where  ");
			sql.append("		B.SHOP_GRP_CD in  ");
			sql.append("		( ");
			sql.append("			SELECT ");
			sql.append("				distinct	nsgm.SHOP_GRP_CD ");
			sql.append(" 			  FROM");
			sql.append("				N_SHOP_GRP_M nsgm");
			sql.append("				LEFT JOIN");
			sql.append("					N_SHOP_CNV_M nscm");
			sql.append("	  			  ON");
			sql.append("					nsgm.CST_CD = nscm.CST_CD");
			sql.append("					AND nsgm.SHOP_CD = nscm.SHOP_CD");
			// 有効期間
			sql.append("					AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
			list.add(systemDt);
			sql.append("					AND nscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("			  WHERE");
			sql.append("				1 = 1 ");

			if(!AmallUtilities.isEmpty(cstCd)) {
				// 顧客コードが存在する場合
				sql.append("			AND nsgm.CST_CD = ? ");
				list.add(cstCd);
			}

			if(!AmallUtilities.isEmpty(shopCd)) {
				// 店舗コードが存在する場合(お客様店舗コードも検索対象)
				sql.append("			AND (");
				sql.append("					nsgm.SHOP_CD = ?");
				sql.append("					OR");
				sql.append("					TRIM(nscm.COMPANY_SHOP_CD) = ?");
				sql.append("				)");
				list.add(shopCd);
				list.add(shopCd);
			}
			// 有効期間
			sql.append("				AND ? BETWEEN nsgm.EFST_DY AND nsgm.EFED_DY");
			list.add(systemDt);

			// 削除フラグ
			sql.append("				AND nsgm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");

			// 店舗グループ検索は範囲設定を特殊に定義する
			// 1.顧客範囲を指定する
			// 2.店舗範囲は店舗範囲の数が1の時のみ指定する
			// 3.店舗範囲は担当の店舗1つだけのグループしか表示できないようにする(本来、店舗担当者は店舗グループを表示できないため)

			// 顧客範囲設定
			// 全顧客判定
			if (!m_Acsgm01DispBean.isCustomerCdAllFlg()) {
				// 全顧客ではない場合
				sql.append("				AND nsgm.CST_CD IN (");
				for (String appCustomer : m_Acsgm01DispBean.getCustomerCdList()) {
					sql.append("'").append(appCustomer).append("',");
				}
				sql.append("'')");
			}

			// 店舗範囲設定
			// 全店舗判定
			if (!m_Acsgm01DispBean.isShopCdAllFlg()) {
				// 全顧客・全店舗ではない場合

				// 店舗範囲の数を判定する
				if (m_Acsgm01DispBean.getShopCdListMap().size() == 1) {

					// 店舗範囲の数が1件のみの場合
					String appCstCd = "";
					String appShopCd = "";
					// 対象の顧客と店舗コードを取得する
					for (Entry<String, List<String>> entry : m_Acsgm01DispBean.getShopCdListMap().entrySet()) {
						appCstCd = entry.getKey();
						for (String appShop : entry.getValue()) {
							appShopCd = appShop;
							break;
						}
					}
					sql.append("				AND nsgm.SHOP_GRP_CD IN (");
					sql.append("											SELECT");
					sql.append("												g1.SHOP_GRP_CD");
					sql.append("											  FROM");
					sql.append("												N_SHOP_GRP_M g1");
					sql.append("											 WHERE");
					sql.append("												g1.CST_CD = ?");
					// 顧客コード
					list.add(appCstCd);
					sql.append("												AND g1.SHOP_CD = ?");
					// 店舗コード
					list.add(appShopCd);
					sql.append("												AND NOT EXISTS (");
					sql.append("																SELECT");
					sql.append("																	*");
					sql.append("																  FROM");
					sql.append("																	N_SHOP_GRP_M g2");
					sql.append("																 WHERE");
					sql.append("																	g1.SHOP_GRP_CD = g2.SHOP_GRP_CD");
					sql.append("																	AND (");
					sql.append("																		g2.CST_CD <> ?");
					// 顧客コード
					list.add(appCstCd);
					sql.append("																		OR (");
					sql.append("																			g2.CST_CD = ?");
					// 顧客コード
					list.add(appCstCd);
					sql.append("																			AND g2.SHOP_CD <> ?");
					// 店舗コード
					list.add(appShopCd);
					sql.append("																		)");
					sql.append("																	)");
					sql.append("												)");
					sql.append("				)");
				}
			}

			sql.append("	) ");
			sql.append("   AND B.DEL_FLG = ").append(AmallConst.DEFAULT_DEL_FLG);
			sql.append("   AND B.EFST_DY <= '").append(systemDt).append("' ");
			sql.append("   AND B.EFED_DY >= '").append(systemDt).append("' ");
			sql.append("  GROUP BY B.SHOP_GRP_CD, B.SHOP_GRP_NM ");
			sql.append(" ) sub");
			String sqlCondition = sql.toString();
			// SQL ORDER
			sql.delete(0, sql.length());
			sql.append(" ORDER BY sub.SHOP_GRP_CD ");
			String sqlOrder = sql.toString();

			// 配列変換
			String[] sqlParam = list.toArray(new String[list.size()]);


			// セット処理
			m_Page_Sql.setSqlSelect(sqlSelect);
			m_Page_Sql.setSqlConditinon(sqlCondition);
			m_Page_Sql.setSqlOrder(sqlOrder);
			m_Page_Sql.setSqlParam(sqlParam);

		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}
	/*************************************************************************************
	 * コピー処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private boolean copyProc() throws AmallException {

		String methodName = "copyProc()";

		StringBuffer sql = new StringBuffer();

		List<String> bindParam = new ArrayList<String>();

		try {
			// 店舗グループコード自動採番処理
			Long nextVal = AmallUtilities.getSequenceNextval("S_SHOP_GRP_CD", m_DbAccess);

			// nullチェック
			if(nextVal == null || nextVal.longValue() == 0) {
				setMessageInfo(m_Acsgm01DispBean, AmallMessageConst.MSG_ERR_DB_ACCESS);
				return false;
			}

			// 0埋めされた店舗グループコードを取得
			String nextShopGrpCd = String.format(AmallConst.SHOP_GRP_CD_FORMAT, nextVal);

			// システム日付を取得
			String systemDt = m_Acsgm01DispBean.getServiceDate();

			//INSERT SELECT用SQLの生成
			sql = new StringBuffer();
			sql.append(" Insert into N_SHOP_GRP_M ( ");
			sql.append("   SHOP_GRP_CD ");
			sql.append(" , CST_CD ");
			sql.append(" , SHOP_CD ");
			sql.append(" , EFST_DY ");
			sql.append(" , EFED_DY ");
			sql.append(" , SHOP_GRP_NM ");
			sql.append(" , VARCHAR_YOBI_01 ");
			sql.append(" , VARCHAR_YOBI_02 ");
			sql.append(" , VARCHAR_YOBI_03 ");
			sql.append(" , VARCHAR_YOBI_04 ");
			sql.append(" , VARCHAR_YOBI_05 ");
			sql.append(" , VARCHAR_YOBI_06 ");
			sql.append(" , VARCHAR_YOBI_07 ");
			sql.append(" , VARCHAR_YOBI_08 ");
			sql.append(" , VARCHAR_YOBI_09 ");
			sql.append(" , VARCHAR_YOBI_10 ");
			sql.append(" , EXCLUSIVE_KEY ");
			sql.append(" , DEL_FLG ");
			sql.append(" , CR_PGM_ID ");
			sql.append(" , CR_USER_ID ");
			sql.append(" , CR_DT ");
			sql.append(" , UPD_PGM_ID ");
			sql.append(" , UPD_USER_ID ");
			sql.append(" , UPD_DT) ");
			sql.append(" SELECT ");
			bindParam.add(nextShopGrpCd);
			sql.append("    ? as SHOP_GRP_CD ");
			sql.append("  , nsgm.CST_CD as CST_CD ");
			sql.append("  , nsgm.SHOP_CD as SHOP_CD ");
			sql.append("  , nsgm.EFST_DY as EFST_DY ");
			sql.append("  , nsgm.EFED_DY as EFED_DY ");
			sql.append("  , nsgm.SHOP_GRP_NM as SHOP_GRP_NM ");
			sql.append("  , nsgm.VARCHAR_YOBI_01 as VARCHAR_YOBI_01 ");
			sql.append("  , nsgm.VARCHAR_YOBI_02 as VARCHAR_YOBI_02 ");
			sql.append("  , nsgm.VARCHAR_YOBI_03 as VARCHAR_YOBI_03 ");
			sql.append("  , nsgm.VARCHAR_YOBI_04 as VARCHAR_YOBI_04 ");
			sql.append("  , nsgm.VARCHAR_YOBI_05 as VARCHAR_YOBI_05 ");
			sql.append("  , nsgm.VARCHAR_YOBI_06 as VARCHAR_YOBI_06 ");
			sql.append("  , nsgm.VARCHAR_YOBI_07 as VARCHAR_YOBI_07 ");
			sql.append("  , nsgm.VARCHAR_YOBI_08 as VARCHAR_YOBI_08 ");
			sql.append("  , nsgm.VARCHAR_YOBI_09 as VARCHAR_YOBI_09 ");
			sql.append("  , nsgm.VARCHAR_YOBI_10 as VARCHAR_YOBI_10 ");
			sql.append("  , 0 as EXCLUSIVE_KEY ");
			sql.append("  , ").append(AmallConst.DEFAULT_DEL_FLG).append(" as DEL_FLG ");
			sql.append("  , '").append(m_ClassName).append("' as CR_PGM_ID ");
			sql.append("  , '").append(m_Acsgm01DispBean.getH_loginId()).append("' as CR_USER_ID ");
			sql.append("  , SYSDATE as CR_DT ");
			sql.append("  , '").append(m_ClassName).append("' as UPD_PGM_ID ");
			sql.append("  , '").append(m_Acsgm01DispBean.getH_loginId()).append("' as UPD_USER_ID ");
			sql.append("  , SYSDATE as UPD_DT ");
			sql.append(" FROM N_SHOP_GRP_M nsgm ");
			bindParam.add(m_Acsgm01Form.getShopGrpCdHid());
			sql.append(" WHERE 				nsgm.SHOP_GRP_CD = ? ");
			sql.append("				AND nsgm.DEL_FLG = ").append(AmallConst.DEFAULT_DEL_FLG);
			sql.append(" 				AND nsgm.EFST_DY <= '").append(systemDt).append("' ");
			sql.append("				AND nsgm.EFED_DY >= '").append(systemDt).append("' ");

			m_DbAccess.createPreparedStatement(sql.toString());

			// バインド変数セット
			for (int i = 0; i < bindParam.size(); i++) {
				m_DbAccess.setString(i + 1, bindParam.get(i));
			}

			// SQL実行
			int ret = m_DbAccess.executeUpdateSql();

			// 更新結果判定
			if (ret <= 0) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_INSERT_ERROR, "N_SHOP_GRP_M");
				throw ee;
			}

			//Hiddenに値を追加
			m_Acsgm01Form.setShopGrpCdHid(nextShopGrpCd);

			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_SHOP_GRP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}
	/*************************************************************************************
	 * 顧客マスタ(DB)ユニーク設定
	 * <p>
	 * 顧客マスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できる場合はActionFormに値を設定し，
	 * 特定できない場合はfalseで返却する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @return boolean true:正常 false:異常
	 ************************************************************************************/
	private boolean chkUniqCst(String cstCd) throws AmallException, Exception {

		String methodName = "chkUniqCstNm()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用チェックリスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	CST_NM");
			sql.append("  FROM");
			sql.append("	N_CST_M");
			sql.append(" WHERE");
			sql.append("	DEL_FLG = ?");
			sql.append("	AND CST_CD = ?");

			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {

				// 店舗名
				String name = m_DbAccess.getString(rs, "CST_NM");

				// リストに追加
				retList.add(name);
			}

			// 結果チェック
			if(retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}

			// 値を設定
			m_Acsgm01Form.setDispCstNm(retList.get(0));

			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_CST_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
	/*************************************************************************************
	 * 店舗マスタ(DB)ユニークチェック
	 * <p>
	 * 店舗マスタ(DB)からデータを取得し、データを特定できるかチェックする
	 * 特定できる場合はActionFormに値を設定し，
	 * 特定できない場合はfalseで返却する
	 * </p>
	 * @param  cstCd 顧客コード
	 * @param  shopCd 店舗コード
	 * @return boolean true:正常 false:異常
	 ************************************************************************************/
	private boolean chkUniqShop(String cstCd, String shopCd) throws AmallException, Exception {

		String methodName = "chkUniqShop()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		// 返却用チェックリスト
		List<String> retList = new ArrayList<>();

		try {
			// SQLの生成
			sql.append("SELECT");
			sql.append("	ncm.CST_CD");
			sql.append(",	ncm.CST_NM");
			sql.append(",	nsm.SHOP_NM");
			sql.append(",	TRIM(nscm.COMPANY_SHOP_NM) AS COMPANY_SHOP_NM");
			sql.append("  FROM");
			sql.append("  	N_SHOP_M nsm");
			sql.append("	LEFT JOIN");
			sql.append("		N_CST_M ncm");
			sql.append("	  ON");
			sql.append("		nsm.CST_CD = ncm.CST_CD");
			sql.append("		AND ncm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append("	LEFT JOIN");
			sql.append("		N_SHOP_CNV_M nscm");
			sql.append("	  ON");
			sql.append("		nsm.CST_CD = nscm.CST_CD");
			sql.append("		AND nsm.SHOP_CD = nscm.SHOP_CD");
			sql.append("		AND ? BETWEEN nscm.EFST_DY AND nscm.EFED_DY");
			sql.append("		AND nscm.DEL_FLG = '").append(AmallConst.DEFAULT_DEL_FLG).append("'");
			sql.append(" WHERE");
			sql.append("	nsm.DEL_FLG = ?");
			sql.append("	AND ? BETWEEN nsm.EFST_DY AND nsm.EFED_DY");
			sql.append("	AND nsm.CST_CD = ?");
			sql.append("	AND (");
			sql.append("			nsm.SHOP_CD = ?");
			sql.append("			OR");
			sql.append("			TRIM(nscm.COMPANY_SHOP_CD) = ?");
			sql.append("		)");
			// 店舗範囲設定
			// 全店舗判定
			if (!m_Acsgm01DispBean.isShopCdAllFlg()) {
				// 全顧客・全店舗ではない場合
				sql.append("	AND (");
				boolean first = true;
				for (Entry<String, List<String>> entry : m_Acsgm01DispBean.getShopCdListMap().entrySet()) {

					String appCstCd = entry.getKey();
					for (String appShop : entry.getValue()) {
						if (first) {
							sql.append("		");
							first = false;
						} else {
							sql.append("		OR");
						}
						sql.append("		(");
						sql.append("			nsm.CST_CD = '").append(appCstCd).append("'");
						sql.append("			AND");
						sql.append("			nsm.SHOP_CD = '").append(appShop).append("'");
						sql.append("		)");
					}
				}
				sql.append("	)");
			}


			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			int setCnt = 0;
			// 有効期限
			m_DbAccess.setString(++setCnt, m_Acsgm01DispBean.getServiceDate());
			// 削除フラグ
			m_DbAccess.setString(++setCnt, AmallConst.DEFAULT_DEL_FLG);
			// 有効期限
			m_DbAccess.setString(++setCnt, m_Acsgm01DispBean.getServiceDate());
			// 顧客コード
			m_DbAccess.setString(++setCnt, cstCd);
			// 店舗コード
			m_DbAccess.setString(++setCnt, shopCd);
			// 店舗コード
			m_DbAccess.setString(++setCnt, shopCd);

			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			String cstNmData = "";
			while (rs.next()) {

				// 店舗名
				String name = m_DbAccess.getString(rs, "SHOP_NM");
				// 店舗名(企業)
				String comapany = m_DbAccess.getString(rs, "COMPANY_SHOP_NM");

				// 企業店舗コード判定
				if (AmallUtilities.isEmpty(comapany)) {
					// リストに追加
					retList.add(name);
				} else {
					// 企業店舗コードがある場合は企業店舗を優先
					// リストに追加
					retList.add(comapany);
				}

				// 顧客名
				cstNmData = m_DbAccess.getString(rs, "CST_NM");

			}

			// 結果チェック
			if(retList.size() != 1) {
				// 1件以外の取得結果の場合
				return false;
			}

			// 値を設定
			m_Acsgm01Form.setDispShopNm(retList.get(0));
			m_Acsgm01Form.setDispCstNm(cstNmData);


			return true;
		} catch (AmallException ame) {
			ame.addException(m_ClassName, methodName, AmallMessageConst.MSG_SYS_DB_ACS_SELECT_ERROR, "N_SHOP_M");
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}

	}
}