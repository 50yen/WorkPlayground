/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Abiam02DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.iam.bean;

import java.util.ArrayList;
import java.util.List;

import jp.co.hitachi.a.b.iam.dto.AbiamItemAuthDto;
import jp.co.hitachi.a.m.cls.AmclsBeanBase;
import jp.co.hitachi.a.m.dto.AmdtoDropDownList;

/*****************************************************************************************
 * Abiam02DispBeanクラス<br>
 *****************************************************************************************/
public class Abiam02DispBean extends AmclsBeanBase {

	/** メンバ変数 */
	/** 画面名プルダウンリスト */
	private List<AmdtoDropDownList> screenDropDownList = null;
	/** 権限ロールプルダウンリスト */
	private List<AmdtoDropDownList> roleDropDownList = null;
	/** 表示プルダウンリスト */
	private List<AmdtoDropDownList> dispDropDownList = null;
	/** 編集可否プルダウンリスト */
	private List<AmdtoDropDownList> editDropDownList = null;
	/** プルダウンリスト(空) */
	private List<AmdtoDropDownList> emptyDropDownList = null;
	/** 一覧表示用データ */
	private List<AbiamItemAuthDto> itemDispList = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Abiam02DispBean() {
		super();
		screenDropDownList = new ArrayList<>();
		roleDropDownList = new ArrayList<>();
		dispDropDownList = new ArrayList<>();
		editDropDownList = new ArrayList<>();
		itemDispList =  new ArrayList<>();
		emptyDropDownList = new ArrayList<>();
		AmdtoDropDownList dto = new AmdtoDropDownList();
		dto.setId(null);
		dto.setName("");
		emptyDropDownList.add(dto);

	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		super.clear();
		screenDropDownList = null;
		roleDropDownList = null;
		dispDropDownList = null;
		editDropDownList = null;
		itemDispList =  null;

	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public List<AmdtoDropDownList> getScreenDropDownList() {
		return screenDropDownList;
	}

	public void setScreenDropDownList(List<AmdtoDropDownList> screenDropDownList) {
		this.screenDropDownList = screenDropDownList;
	}

	public List<AmdtoDropDownList> getRoleDropDownList() {
		return roleDropDownList;
	}

	public void setRoleDropDownList(List<AmdtoDropDownList> roleDropDownList) {
		this.roleDropDownList = roleDropDownList;
	}

	public List<AmdtoDropDownList> getDispDropDownList() {
		return dispDropDownList;
	}

	public void setDispDropDownList(List<AmdtoDropDownList> dispDropDownList) {
		this.dispDropDownList = dispDropDownList;
	}

	public List<AmdtoDropDownList> getEditDropDownList() {
		return editDropDownList;
	}

	public void setEditDropDownList(List<AmdtoDropDownList> editDropDownList) {
		this.editDropDownList = editDropDownList;
	}

	public List<AmdtoDropDownList> getEmptyDropDownList() {
		return emptyDropDownList;
	}

	public void setEmptyDropDownList(List<AmdtoDropDownList> emptyDropDownList) {
		this.emptyDropDownList = emptyDropDownList;
	}

	public List<AbiamItemAuthDto> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<AbiamItemAuthDto> itemDispList) {
		this.itemDispList = itemDispList;
	}



}
