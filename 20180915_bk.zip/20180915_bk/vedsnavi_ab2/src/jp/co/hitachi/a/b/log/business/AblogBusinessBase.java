/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AblogBusinessBase.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.b.log.business;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.cls.AmclsBusinessPcBase;

/*****************************************************************************************
 * AblogBusinessBaseクラス<br>
 *****************************************************************************************/
public abstract class AblogBusinessBase extends AmclsBusinessPcBase {

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  mapping
	 * @param  form
	 * @param  request
	 * @param  response
	 * @param  context
	 * @param  gid
	 * @param  event
	 * @return 無し
	 ************************************************************************************/
	public AblogBusinessBase(HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);
	}
}
