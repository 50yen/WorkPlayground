/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Accme0101Dto.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.cme.dto;

import java.util.List;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * Accme01Dtoクラス<br>
 *****************************************************************************************/
public class Accme01Dto extends AmclsDtoBase {

	/** メンバ変数 */

	/** 確定状況 */
	private String finFlg = null;
	/** 送信状態 */
	private String statusCls = null;
	/** 売上日From */
	private String sldFrom = null;
	/** 売上日To */
	private String sldTo = null;
	/** 顧客Cd */
	private String cstCd = null;
	/** 顧客名 */
	private String cstNm = null;
	/** 店舗Cd */
	private String shopCd = null;
	/** 店舗名 */
	private String shopNm = null;
	/** 店舗枝番（レジNo） */
	private String shopSbno = null;
	/** 店舗枝番名（レジ名） */
	private String shopSbnm = null;

	/** ページ表示No */
	private int displayNum = 1;

	/** 選択リスト */
	private List<AccmeItemDispDto> itemDispList = null;


	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public Accme01Dto() {
		clear();
	}

	/*************************************************************************************
	 * クリア
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		finFlg = null;
		statusCls = null;
		sldFrom = null;
		sldTo = null;
		cstCd = null;
		cstNm = null;
		shopCd = null;
		shopNm = null;
		shopSbno = null;
		shopSbnm = null;

		displayNum = 1;
	}

	public String getFinFlg() {
		return finFlg;
	}

	public void setFinFlg(String finFlg) {
		this.finFlg = finFlg;
	}

	public String getStatusCls() {
		return statusCls;
	}

	public void setStatusCls(String statusCls) {
		this.statusCls = statusCls;
	}

	public String getSldFrom() {
		return sldFrom;
	}

	public void setSldFrom(String sldFrom) {
		this.sldFrom = sldFrom;
	}

	public String getSldTo() {
		return sldTo;
	}

	public void setSldTo(String sldTo) {
		this.sldTo = sldTo;
	}

	public String getCstCd() {
		return cstCd;
	}

	public void setCstCd(String cstCd) {
		this.cstCd = cstCd;
	}

	public String getCstNm() {
		return cstNm;
	}

	public void setCstNm(String cstNm) {
		this.cstNm = cstNm;
	}

	public String getShopCd() {
		return shopCd;
	}

	public void setShopCd(String shopCd) {
		this.shopCd = shopCd;
	}

	public String getShopNm() {
		return shopNm;
	}

	public void setShopNm(String shopNm) {
		this.shopNm = shopNm;
	}

	public String getShopSbno() {
		return shopSbno;
	}

	public void setShopSbno(String shopSbno) {
		this.shopSbno = shopSbno;
	}

	public String getShopSbnm() {
		return shopSbnm;
	}

	public void setShopSbnm(String shopSbnm) {
		this.shopSbnm = shopSbnm;
	}

	public int getDisplayNum() {
		return displayNum;
	}

	public void setDisplayNum(int displayNum) {
		this.displayNum = displayNum;
	}

	public List<AccmeItemDispDto> getItemDispList() {
		return itemDispList;
	}

	public void setItemDispList(List<AccmeItemDispDto> itemDispList) {
		this.itemDispList = itemDispList;
	}

	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////


}
