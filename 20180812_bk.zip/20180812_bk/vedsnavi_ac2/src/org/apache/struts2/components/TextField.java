package org.apache.struts2.components;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;

/*     */ import org.apache.struts2.views.annotations.StrutsTag;
/*     */ import org.apache.struts2.views.annotations.StrutsTagAttribute;

/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */
/*     */ @StrutsTag(
/*     */    name = "textfield",
/*     */    tldTagClass = "org.apache.struts2.views.jsp.ui.TextFieldTag",
/*     */    description = "Render an HTML input field of type text",
/*     */    allowDynamicAttributes = true
/*     */ )
/*     */ public class TextField extends UIBean_Owd {
/*     */    public static final String TEMPLATE = "text";
/*     */    protected String maxlength;
/*     */    protected String readonly;
/*     */    protected String size;
/*     */    protected String type;
/*     */    protected String owdbtnid;
/*     */    protected String btnCssClass;
/*     */    protected String col;
/*     */
/*     */    public TextField(ValueStack stack, HttpServletRequest request, HttpServletResponse response) {
/*  73 */       super(stack, request, response);
/*  74 */    }
/*     */
/*     */    protected String getDefaultTemplate() {
/*  77 */       return "text";
/*     */    }
/*     */
/*     */    protected void evaluateExtraParams() {
/*  81 */       super.evaluateExtraParams();
/*     */
/*  83 */       if(this.size != null) {
/*  84 */          this.addParameter("size", this.findString(this.size));
/*     */       }
/*     */
/*  87 */       if(this.maxlength != null) {
/*  88 */          this.addParameter("maxlength", this.findString(this.maxlength));
/*     */       }
/*     */
/*  91 */       if(this.readonly != null) {
/*  92 */          this.addParameter("readonly", this.findValue(this.readonly, Boolean.class));
/*     */       }
/*     */
/*  95 */       if(this.type != null) {
/*  96 */          this.addParameter("type", this.findString(this.type));
/*     */       }

/*  95 */       if(this.owdbtnid != null) {
/*  96 */          this.addParameter("owdbtnid", this.findString(this.owdbtnid));
/*     */       }
/*  95 */       if(this.btnCssClass != null) {
/*  96 */          this.addParameter("btnCssClass", this.findString(this.btnCssClass));
/*     */       }
/*  95 */       if(this.col != null) {
/*  96 */          this.addParameter("col", this.findString(this.col));
/*     */       }/*     */
/*     */
/*     */
/*  99 */    }
/*     */    @StrutsTagAttribute(      description = "HTML maxlength attribute",      type = "Integer"
/*     */    )
/*     */    public void setMaxlength(String maxlength) {
/* 103 */       this.maxlength = maxlength;
/* 104 */    }
/*     */    @StrutsTagAttribute(      description = "Deprecated. Use maxlength instead.",      type = "Integer"
/*     */    )
/*     */    public void setMaxLength(String maxlength) {
/* 108 */       this.maxlength = maxlength;
/* 109 */    }
/*     */    @StrutsTagAttribute(      description = "Whether the input is readonly",      type = "Boolean",      defaultValue = "false"
/*     */    )
/*     */    public void setReadonly(String readonly) {
/* 113 */       this.readonly = readonly;
/* 114 */    }
/*     */    @StrutsTagAttribute(      description = "HTML size attribute",      type = "Integer"
/*     */    )
/*     */    public void setSize(String size) {
/* 118 */       this.size = size;
/* 119 */    }
/*     */    @StrutsTagAttribute(      description = "Specifies the html5 type element to display. e.g. text, email, url",      defaultValue = "text"
/*     */    )
/*     */    public void setType(String type) {
/* 123 */       this.type = type;
/* 124 */    }
/*     */    @StrutsTagAttribute(      description = "ASS Special Attribute",      defaultValue = "text"
/*     */    )
/*     */    public void setOwdbtnid(String owdbtnid) {
/* 123 */       this.owdbtnid = owdbtnid;
/* 124 */    }
/*     */    @StrutsTagAttribute(      description = "ASS Special Attribute",      defaultValue = "text"
/*     */    )
/*     */    public void setBtnCssClass(String btnCssClass) {
/* 123 */       this.btnCssClass = btnCssClass;
/* 124 */    }
/*     */    @StrutsTagAttribute(      description = "ASS Special Attribute",      defaultValue = "text"
/*     */    )
/*     */    public void setCol(String col) {
/* 123 */       this.col = col;
/* 124 */    }
/*     */ }

/*
	DECOMPILATION REPORT

	Decompiled from: C:\Users\mi.sekiya.it\Documents\as\vedsnavi_ac\WebRoot\WEB-INF\lib\struts2-core-2.5.13.jar
	Total time: 127 ms

	Decompiled with FernFlower.
*/