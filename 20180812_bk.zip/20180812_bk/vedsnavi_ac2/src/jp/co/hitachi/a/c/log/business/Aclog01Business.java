/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Aclog01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.log.business;

import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.log.action.Aclog01Action;
import jp.co.hitachi.a.c.log.bean.Aclog01DispBean;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoLoginInfo;

/*****************************************************************************************
 * Aclog01Businessクラス<br>
 *****************************************************************************************/
public class Aclog01Business extends AclogBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Aclog01DispBean";
	/** 仮パスワードフラグ(パスワードリセット) */
	private static final String PWD_TYPE_RESET = "1";
	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** ログイン処理 */
	public static final String FORWARD_LOGIN = "LOGIN";
	/** パスワード変更処理 */
	public static final String FORWARD_CHANGEPWD = "CHANGEPWD";

	/**
	 * 画面項目ID
	 */
	/** ログインID */
	public static final String ITEM_ID_LOGIN = "loginId";
	/** パスワード */
	public static final String ITEM_ID_PASSWOARD = "password";

	/** メンバ変数 */
	/** アクションフォーム */
	private Aclog01Action m_Aclog01Form = null;
	/** 表示用画面Bean */
	private Aclog01DispBean m_Aclog01DispBean = null;


	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Aclog01Business(
			Aclog01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Aclog01Business.class.getName();
		m_Aclog01Form = form;
		m_Aclog01DispBean = new Aclog01DispBean();

		setErrString(gid, m_Aclog01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_COM_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Aclog01DispBean);

			// DB接続
			m_DbAccess = new AmallDbAccess(m_Aclog01Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_LOGIN.equals(m_Event)) {
				// ログインボタン押下処理の場合
				forwardStr = login();
			}  else if (FORWARD_CHANGEPWD.equals(m_Event)) {
				// TODO プレイグラウンド遷移
				forwardStr = FORWARD_CHANGEPWD;
			} else {
				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_COM_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_COM_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Aclog01DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		if (m_DbAccess != null) {
			m_DbAccess.exitDB();
		}
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ログイン処理
	 * <p>
	 * ログイン処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String login() throws AmallException {

		// ログ用メソッド名
		String methodName = "login()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {
			// 入力値のﾁｪｯｸ
			if (checkInput() != false) {
				// チェック処理が正常の場合
				// ログインID取得
				String lid = m_Aclog01Form.getLoginID();
				// パスワード取得
				String pwd = m_Aclog01Form.getPassword();

				// ログイン情報DTO
				AmdtoLoginInfo loginDto = new AmdtoLoginInfo();

				// ログイン情報取得
				if (getLoginInfoDB(lid, loginDto)) {

					// TODO ログインロック中の処理などログイン処理の仕様
					// TODO 有効期限などのパスワードチェック処理
					// TODO 仮パスワードなどの処理
					// password 一致か
					if (pwd.equals(loginDto.getM_Password())) {
						/* 正規 password ?  */
						if (!PWD_TYPE_RESET.equals(loginDto.getM_Password_Flg())) {
							// 仮パスワードフラグがONでない場合
							// ログイン処理実施
							forwardStr = FORWARD_LOGIN;

							// ログイン管理テーブル更新
							updateLoginManagerData();
						} else {
							forwardStr = FORWARD_CHANGEPWD;
							// ログイン管理テーブル更新
							updateLoginManagerData();
						}
					}
					// 更新後ログイン情報
					getLoginInfoDB(lid, loginDto);
					// ログイン情報のリクエスト保管
					putLoginInfoDTO(loginDto);

					// TODO ログイン正常時はアクセスログに書き込みを行う
					// writeAccessLogStart(lid, null);
					// writeAccessLogEnd(lid, false, MsgLvl.NORMAL);

				} else {
					// ログイン情報の取得エラー
					setMessageInfo(m_Aclog01DispBean, AmallMessageConst.MSG_GYO_LOGIN_COLLECT_ERROR);
					setError(m_Aclog01DispBean, ITEM_ID_LOGIN);
					setError(m_Aclog01DispBean, ITEM_ID_PASSWOARD);
				}
			}
			return forwardStr;
		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_GYO_LOGIN_PROC_ERROR);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {

			if (m_DbAccess != null) {
				m_DbAccess.exitDB();
			}
		}

	}

	/*************************************************************************************
	 * 入力値チェック処理
	 * <p>
	 * 入力値のチェックを行う
	 * </p>
	 * @param  無し
	 * @return true :入力ｴﾗｰ
	 *         false:入力正常
	 ************************************************************************************/
	private boolean checkInput() throws AmallException {
		// ログ用メソッド名
		String methodName = "checkInput()";

		try {
			// ログ用項目名称 ログインID
			String loginDispNmae = getItemDispName(ITEM_ID_LOGIN, m_Aclog01DispBean);
			// ログ用項目名称 パスワード
			String passDispNmae = getItemDispName(ITEM_ID_PASSWOARD, m_Aclog01DispBean);

			// ログインID取得
			String lid = m_Aclog01Form.getLoginID();
			// パスワード取得
			String pwd = m_Aclog01Form.getPassword();

			// Login ID 必須ﾁｪｯｸ
			if (AmallUtilities.isEmpty(lid)) {
				setMessageInfo(m_Aclog01DispBean, AmallMessageConst.MSG_COM_INPUT_CHECK_PROC_ERROR, loginDispNmae);
				setError(m_Aclog01DispBean, "loginID");

				return false;
			}

			// Password 必須ﾁｪｯｸ
			if (AmallUtilities.isEmpty(pwd)) {
				setMessageInfo(m_Aclog01DispBean, AmallMessageConst.MSG_COM_INPUT_CHECK_PROC_ERROR, passDispNmae);
				setError(m_Aclog01DispBean, "password");
				return false;
			}

			// TODO ログイン処理に必要なチェック処理 何文字 文字種別など
			// AmallUtilities.consist(pwd, AmallUtilities.H_ALP | AmallUtilities.H_NUM) &&
			// pwd.length() == 8

			// 正常終了
			return true;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_COM_INPUT_CHECK_PROC_ERROR, "");
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		}
	}

	/*************************************************************************************
	 * ログイン情報取得
	 * <p>
	 * ログイン情報を取得する
	 * </p>
	 * @param loginId ログインID
	 * @param dto ログイン情報(DTO)
	 * @return true :該当データ在り
	 *         false:該当データ無し
	 ************************************************************************************/
	protected boolean getLoginInfoDB(String loginId, AmdtoLoginInfo dto) throws AmallException, Exception {
		String methodName = "getLoginInfoDB()";
		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		boolean rc = false;

		try {
			dto.clear();
			/***************************************
			 * TODO ログイン情報スタブ処理(START)
			 ****************************************/
			dto.setM_User_Cd("1");
			dto.setM_User_Nm("スタブ処理ユーザー");
			dto.setM_Password("1");
			dto.setM_Password_Flg("0");
			rc = true;
			/***************************************
			 * TODO ログイン情報スタブ処理(END)
			 ****************************************/
/** TODO ログイン情報スタブ処理(START)
			// ﾛｸﾞｲﾝ情報の取得
			// TODO SELECT句
			sql.append("SELECT");
			// TODO FROM句
			sql.append("FROM");
			// TODO WHERE句
			sql.append("WHERE");

			// WHERE句のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString(), false);
			// TODO WHERE句 パラメタ内容
			m_DbAccess.setString(1, loginId);
			m_DbAccess.setString(2, "1");

			// SQL文実行
			rs = m_DbAccess.executeQuery();

			while (rs.next()) {
				// TODO 取得内容
				// ログインID
				dto.setM_User_Cd(m_DbAccess.getString(rs, "LOGIN_ID"));
				//  ユーザー名
				dto.setM_User_Nm(m_DbAccess.getString(rs, "CUSTOMER_NAME"));
				//  顧客CD
				dto.setM_User_Nm(m_DbAccess.getString(rs, "CUSTOMER_CD"));
				//  顧客グループCD
				dto.setM_Customer_Grp_Cd(m_DbAccess.getString(rs, "CUSTOMER_CD_SEQ"));
				//  店舗CD
				//  店舗グループCD
				//  パスワード
				dto.setM_Password(m_DbAccess.getString(rs, "PASSWORD"));
				//  パスワードリセット
				dto.setM_Password_Flg(m_DbAccess.getString(rs, "PASSWORD_FLG"));
				//  パスワード変更日時
				//  最終ログイン日時
				//  最終ログイン失敗日時
				//  ログイン失敗回数
				//  ロックアウト
				//  ロックアウト日時
				//  承認権限
				rc = true;
			}

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_GYO_LOGIN_INFO_GET_ERROR);
			throw e;
 TODO ログイン情報スタブ処理(END) **/
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
			sql.delete(0, sql.length());
			sql = null;
		}
		return rc;
	}
	/*************************************************************************************
	 * ログイン管理(DB)更新
	 * <p>
	 * ログイン管理(DB)を更新する
	 * </p>
	 * @param なし
	 * @return 無し
	 ************************************************************************************/
	private void updateLoginManagerData() throws AmallException {

		String methodName = "updateLoginManagerData()";
		StringBuffer sql = new StringBuffer();

		try {
/** TODO ログイン情報スタブ処理(START)
			String lid = m_Aclog01Form.getLoginID();

			// TODO UPDATE句
			sql.append("UPDATE");
			// TODO SET句
			sql.append("SET");
			// TODO WHERE句
			sql.append("WHERE");

			// WHERE句のパラメタ設定
			m_DbAccess.createPreparedStatement(sql.toString(), false);
			// TODO WHERE句 パラメタ内容

			// SQL文実行
			int ret = m_DbAccess.executeUpdateSql();

			// 更新結果判定
			if (ret != 1) {
				m_DbAccess.rollback();
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_GYO_LOGIN_DB_UPDATE_ERROR, "");
				throw ee;
			}
			// コミット処理
			m_DbAccess.commit();

		} catch (AmallException e) {
			m_DbAccess.rollback();
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_GYO_LOGIN_DB_UPDATE_ERROR, "");
			throw e;
 TODO ログイン情報スタブ処理(END) **/
		} catch (Exception e) {
			m_DbAccess.rollback();
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;

		} finally {
			sql.delete(0, sql.length());
			sql = null;
		}
		return;
	}

}