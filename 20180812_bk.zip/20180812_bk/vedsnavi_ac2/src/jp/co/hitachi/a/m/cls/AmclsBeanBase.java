/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmclsBeanBase.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.cls;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import jp.co.hitachi.a.m.all.AmallConst.MsgCode;
import jp.co.hitachi.a.m.dto.AmdtoScreenCategory;

/*****************************************************************************************
 * Beanのスーパークラス<br>
 *****************************************************************************************/
public abstract class AmclsBeanBase implements java.io.Serializable {

	/** メンバ変数 */
	/*************************************************************************************
	 * ヘッダー情報
	 ************************************************************************************/
	/** システム名称 */
	private String h_systemName = null;
	/** システム日付 */
	private String h_systemDate = null;
	/** ログインID */
	private String h_loginId = null;
	/** ログイン表示名 */
	private String h_loginDispName = null;
	/** 画面名 */
	private String h_screenName = null;
	/** 画面名付加情報 */
	private String h_screenNameAddData = null;
	/** 画面照会ID */
	private String h_screenRefId = null;
	/** 画面個別マニュアルパス */
	private String h_screenManualPath = null;
	/** ヘッダー部表示フラグ */
	private boolean h_dispFlg = false;

	/*************************************************************************************
	 * システム情報
	 ************************************************************************************/
	/** 業務日付 */
	private String serviceDate = null;
	/** メッセージ種別 */
	private int messageType;
	/** メッセージ内容 */
	private List<String> message = null;
	/** JavaScript用メッセージマップ */
	private Map<String, String> jsMessageMap = null;
	/** 表示件数プルダウンリスト */
	private List<String> dispCountList = null;
	/** 表示件数プルダウンリスト初期値 */
	private String dispCountDefault = null;

	/** エラースタイル用マップ */
	private Map<String, String> styleMap = null;

	/*************************************************************************************
	 * 権限情報
	 ************************************************************************************/
	/** 権限マップ */
	private Map<String, Map<String, String>> owdRole = null;
	/** 表示対象画面データマップ */
	private List<AmdtoScreenCategory> owdScreenList = null;

	// 以下 検討中 メンバ変数 ===========================
	/** 承認権限 */
	//private boolean appAuthFlg = false;
	/** 店舗コードリスト */
	//private List<String> shopCdList = null;
	/** 顧客コードリスト */
	//private List<String> customerCdList = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmclsBeanBase() {
		this.h_systemName = "";
		this.h_systemDate = "";
		this.h_loginId = "";
		this.h_loginDispName = "";
		this.serviceDate = "";
		this.messageType = MsgCode.NORMAL;
		this.message = new ArrayList<>();
		this.jsMessageMap = new ConcurrentHashMap<>();
		this.dispCountList = new ArrayList<>();
		this.dispCountDefault = "";
		this.styleMap = new ConcurrentHashMap<>();
		this.owdRole = new ConcurrentHashMap<>();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		this.h_systemName = null;
		this.h_systemDate = null;
		this.h_loginId = null;
		this.h_loginDispName = null;
		this.serviceDate = null;
		this.messageType = MsgCode.NORMAL;
		this.message = null;
		this.jsMessageMap = null;
		this.dispCountList = null;
		this.dispCountDefault = null;
		this.styleMap = null;
		this.owdRole = null;
	}

	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getH_systemName() {
		return h_systemName;
	}

	public void setH_systemName(String h_systemName) {
		this.h_systemName = h_systemName;
	}

	public String getH_systemDate() {
		return h_systemDate;
	}

	public void setH_systemDate(String h_systemDate) {
		this.h_systemDate = h_systemDate;
	}

	public String getH_loginId() {
		return h_loginId;
	}

	public void setH_loginId(String h_loginId) {
		this.h_loginId = h_loginId;
	}

	public String getH_loginDispName() {
		return h_loginDispName;
	}

	public void setH_loginDispName(String h_loginDispName) {
		this.h_loginDispName = h_loginDispName;
	}

	public String getH_screenName() {
		return h_screenName;
	}

	public void setH_screenName(String h_screenName) {
		this.h_screenName = h_screenName;
	}

	public String getH_screenNameAddData() {
		return h_screenNameAddData;
	}

	public void setH_screenNameAddData(String h_screenNameAddData) {
		this.h_screenNameAddData = h_screenNameAddData;
	}

	public String getH_screenRefId() {
		return h_screenRefId;
	}

	public void setH_screenRefId(String h_screenRefId) {
		this.h_screenRefId = h_screenRefId;
	}

	public String getH_screenManualPath() {
		return h_screenManualPath;
	}

	public void setH_screenManualPath(String h_screenManualPath) {
		this.h_screenManualPath = h_screenManualPath;
	}

	public boolean isH_dispFlg() {
		return h_dispFlg;
	}

	public void setH_dispFlg(boolean h_dispFlg) {
		this.h_dispFlg = h_dispFlg;
	}

	public String getServiceDate() {
		return serviceDate;
	}

	public void setServiceDate(String serviceDate) {
		this.serviceDate = serviceDate;
	}

	public int getMessageType() {
		return messageType;
	}

	public void setMessageType(int messageType) {
		this.messageType = messageType;
	}

	public List<String> getMessage() {
		return message;
	}

	public void setMessage(List<String> message) {
		this.message = message;
	}

	public Map<String, String> getJsMessageMap() {
		return jsMessageMap;
	}

	public void setJsMessageMap(Map<String, String> jsMessageMap) {
		this.jsMessageMap = jsMessageMap;
	}

	public List<String> getDispCountList() {
		return dispCountList;
	}

	public void setDispCountList(List<String> dispCountList) {
		this.dispCountList = dispCountList;
	}

	public String getDispCountDefault() {
		return dispCountDefault;
	}

	public void setDispCountDefault(String dispCountDefault) {
		this.dispCountDefault = dispCountDefault;
	}

	public Map<String, String> getStyleMap() {
		return styleMap;
	}

	public void setStyleMap(Map<String, String> styleMap) {
		this.styleMap = styleMap;
	}

	public Map<String, Map<String, String>> getOwdRole() {
		return owdRole;
	}

	public void setOwdRole(Map<String, Map<String, String>> owdRole) {
		this.owdRole = owdRole;
	}

	public List<AmdtoScreenCategory> getOwdScreenList() {
		return owdScreenList;
	}

	public void setOwdScreenList(List<AmdtoScreenCategory> owdScreenList) {
		this.owdScreenList = owdScreenList;
	}

}
