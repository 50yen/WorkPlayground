/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoScreenCategory.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import java.util.List;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * 画面カテゴリ情報 <br>
 *****************************************************************************************/
public class AmdtoScreenCategory extends AmclsDtoBase {

	/** メンバ変数 */
	/** グループID(カテゴリ) */
	private String m_CategoryId = null;
	/** 名称 */
	private String m_CategoryName = null;
	/** TOP画面用画像パス */
	private String m_TopImgPath = null;
	/** Side画面用画像パス */
	private String m_SideImgPath = null;
	/** 表示パターン 0:通常 1:サイドメニューのみ(直接) 2:TOP画面のみ */
	private int m_DispPattern = 0;
	/** メニューリスト */
	private List<AmdtoScreenMenu> m_MenuList = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmdtoScreenCategory() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {

	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getM_CategoryId() {
		return m_CategoryId;
	}

	public void setM_CategoryId(String m_CategoryId) {
		this.m_CategoryId = m_CategoryId;
	}

	public String getM_CategoryName() {
		return m_CategoryName;
	}

	public void setM_CategoryName(String m_CategoryName) {
		this.m_CategoryName = m_CategoryName;
	}

	public String getM_TopImgPath() {
		return m_TopImgPath;
	}

	public void setM_TopImgPath(String m_TopImgPath) {
		this.m_TopImgPath = m_TopImgPath;
	}

	public String getM_SideImgPath() {
		return m_SideImgPath;
	}

	public void setM_SideImgPath(String m_SideImgPath) {
		this.m_SideImgPath = m_SideImgPath;
	}

	public int getM_DispPattern() {
		return m_DispPattern;
	}

	public void setM_DispPattern(int m_DispPattern) {
		this.m_DispPattern = m_DispPattern;
	}

	public List<AmdtoScreenMenu> getM_MenuList() {
		return m_MenuList;
	}

	public void setM_MenuList(List<AmdtoScreenMenu> m_MenuList) {
		this.m_MenuList = m_MenuList;
	}

}
