/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoScreen.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * 画面情報 <br>
 *****************************************************************************************/
public class AmdtoScreen extends AmclsDtoBase {

	/** メンバ変数 */
	/** 画面ID */
	private String m_ScreenId = null;
	/** 画面照会ID */
	private String m_ScreenRefId = null;
	/** 名称 */
	private String m_ScreenName = null;
	/** FOWARD値 */
	private String m_FowardData = null;
	/** リンクパス */
	private String m_LinkPath = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmdtoScreen() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {

	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getM_ScreenId() {
		return m_ScreenId;
	}

	public void setM_ScreenId(String m_ScreenId) {
		this.m_ScreenId = m_ScreenId;
	}

	public String getM_ScreenRefId() {
		return m_ScreenRefId;
	}

	public void setM_ScreenRefId(String m_ScreenRefId) {
		this.m_ScreenRefId = m_ScreenRefId;
	}

	public String getM_ScreenName() {
		return m_ScreenName;
	}

	public void setM_ScreenName(String m_ScreenName) {
		this.m_ScreenName = m_ScreenName;
	}

	public String getM_FowardData() {
		return m_FowardData;
	}

	public void setM_FowardData(String m_FowardData) {
		this.m_FowardData = m_FowardData;
	}

	public String getM_LinkPath() {
		return m_LinkPath;
	}

	public void setM_LinkPath(String m_LinkPath) {
		this.m_LinkPath = m_LinkPath;
	}

}
