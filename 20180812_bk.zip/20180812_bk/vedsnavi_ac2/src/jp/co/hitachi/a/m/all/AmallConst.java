/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallConst.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

/*****************************************************************************************
 * 共通定数クラス<br>
 *****************************************************************************************/
public class AmallConst {

	/**
	 * システム名称定義
	 */
	public static class SystemName {
		/** 顧客OL */
		public static final String CUSTOMER = "VEDS navi";
		/** 業務支援 */
		public static final String BUSINESS = "VEDS navi";
	}

	/**
	 * システム種別定義
	 */
	public static class SystemType {
		/** 顧客OL コード値 */
		public static final int CUSTOMER = 1;
		/** 顧客OL 名称 */
		public static final String CUSTOMER_NM = "顧客ＯＬ";
		/** 業務支援 コード値 */
		public static final int BUSINESS = 2;
		/** 業務支援 名称 */
		public static final String BUSINESS_NM = "業務支援";
	}

	/**
	 * セッション・リクエストパラメタ取得キーワード
	 */
	public static class ParamKey {
		/** トランザクション キーワード */
		public static final String TRANS_TOKEN = "TRANS_TOKEN_OWD";
		/** クッキー キーワード */
		public static final String ASS_COOKIE_ID = "ASS_COOKIE_ID_OWD";
		/** システム種別 キーワード */
		public static final String SYSTEM_KIND = "SYSTEM_KIND_OWD";
		/** 楽観的排他 キーワード */
		public static final String OPTIMISTIC_EXCLU_INFO = "OPTIMISTIC_EXCLU_INFO_OWD";

		/** DTO 取得キー */
		public final static String DTO = "DTO_OWD";
		/** 画面DTO 取得キー */
		public final static String DTO_SCREEN = "DTO_SCREEN_OWD";
		/** ログイン情報DTO 取得キー */
		public final static String DTO_LOGININFO = "DTO_LOGININFO_OWD";
		/** 共通情報DTO 取得キー */
		public final static String DTO_COMMONINFO = "DTO_COMMONINFO_OWD";
		/** 画面遷移履歴DTO 取得キー */
		public final static String DTO_TRANSHISTORY = "DTO_TRANSHISTORY_OWD";
		/** アクセス権限DTO 取得キー */
		public final static String DTO_ACCESS_AUTH = "DTO_ACCESS_AUTH_OWD";

		/** 画面ID リクエストパラメタ */
		public final static String GID = "gid";
		/** 画面イベント リクエストパラメタ */
		public final static String EVENT = "event";

	}
	/**
	 * 項目権限マップパラメタ取得キーワード
	 */
	public static class ItemMapKey {
		/** 名称 */
		public final static String NAME = "name";
		/** 表示 */
		public final static String DISP = "disp";
		/** 編集 */
		public final static String ENABLE = "enable";
		/** 画像パス */
		public final static String IMG = "img";
		/** 画面名称 */
		public final static String SCREEN_NAME = "ScreenName";
		/** 画面名称付加情報 */
		public final static String SCREEN_NAME_ADD = "ScreenNameAddData";

	}

	/**
	 * メッセージ種別定義
	 */
	public static class MsgCode {
		/** メッセージ種別(正常) */
		public static final int NORMAL = 0;
		/** メッセージ種別(エラー) */
		public static final int ERROR = 1;
		/** メッセージ種別(警告) */
		public static final int WARNING = 2;
		/** メッセージ種別(情報) */
		public static final int INFO = 9;
	}

	/**
	 * メッセージレベル定義
	 */
	public static class MsgLvl {
		/** メッセージレベル(正常) */
		public static final String NORMAL = "0";
		/** メッセージレベル(業務系) */
		public static final String ERROR = "1";
		/** メッセージレベル(例外) */
		public static final String EXCEPTION = "2";
		/** メッセージレベル(APLトレース) */
		public static final String APLTRACE = "9";
	}

	/**
	 * エラーログ種別定義
	 */
	public static class LogType {
		/** メッセージ種別(エラー) */
		public static final String ERROR = "ERROR";
		/** メッセージ種別(警告) */
		public static final String WARNING = "WARNING";
		/** メッセージ種別(警告) */
		public static final String WARN = "WARN";
		/** メッセージ種別(情報) */
		public static final String INFO = "INFO";
	}

	/**
	 * ログテーブル定義
	 */
	public static class LogTable {
		/** ログテーブル定義 アクセスログ */
		public static final String CUSTOMER = "AACSLHT";
		/** ログテーブル定義 社員ログ */
		public static final String BUSINESS = "ASTFLHT";
	}

	/**
	 * ログ 出力有無
	 */
	public static class LogDbOut {
		/** ログ出力有無 ON */
		public static final String ON = "1";
		/** ログ出力有無 OFF */
		public static final String OFF = "0";
	}

	/**
	 * ログ アペンダー名称定義
	 */
	public static class LoggerName {
		/** ログ アペンダー名称定義 顧客OL */
		public static final String CUSTOMER = "AccessLog_assvedsnavi.Logging";
		/** ログ アペンダー名称定義 業務支援 */
		public static final String BUSINESS = "AccessLog_assvedsnavi.Logging";
	}

	/**
	 * 共通FOWARD定義
	 */
	public static class FowardCom {
		/** 共通FOWARD定義 ログイン画面 */
		public static final String LOGIN = "TOLOGIN";
	}

	/**
	 *  共通スタイルシート定義
	 */
	public static class CssStyleCom {
		/** 正常時の背景色(CSS名) */
		public final static String NORMAL = "NormalStyle";
		/** 異常時の背景色(CSS名) */
		public final static String ERROR = "ErrorStyle";
		/** 警告時の背景色(CSS名) */
		public final static String WARNING = "WarningStyle";

		/** カレンダーの祝日(CSS名) */
		public final static String HOLIDAY = "day holiday";
		/** カレンダーの平日(CSS名) */
		public final static String WEEKDAY = "day";
	}

	/**
	 * 日付フォーマット定義
	 */
	public static class DateFormatCom {
		/** 日時フォーマット */
		public final static String YYYYMMDD24HMISS = "yyyy/MM/dd HH:mm:ss";
	}
	/**
	 * 文字コード定義
	 */
	public static class Encode {
		/** シフトJIS */
		public final static String SHIFT_JIS = "Shift_JIS";
		/** UTF-8 */
		public final static String UTF8 = "UTF-8";
	}


	/**
	 * 固定文字列定義
	 */
	/** 半角スラッシュ */
	public static final String CS_HF_SLASH = "/";
	/** 全角スラッシュ */
	public static final String CS_FL_SLASH = "／";
	/** 通過文字列マイナス値(黒三角) */
	public static final String CS_MINUS_CURRENCY = "▲";
	/** マスタ登録なしデータ */
	public static final String CS_NOT_FOUND_MASTER = "マスタ未登録";
	/** 改行コード */
	public static final String LINE_SEPARATOR = System.getProperty("line.separator");
	/** CSVセパレータ */
	public static final String CSV_SEP = ",";
	/** ログイン表示名称末尾 */
	public static final String USER_NAME_SUFFIX = "様";

}
