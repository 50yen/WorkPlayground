/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) DbAccess.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

/*****************************************************************************************
 * JSP制御クラス<br>
 *****************************************************************************************/
public class AmallJspControl {

	/*************************************************************************************
	 * ファイル更新日時 クエリ追加(個別JSファイル)
	 * <p>
	 * 指定のJSフォルダの画面IDに対応したJSファイル名の更新日時をPathにクエリとして付加する
	 * </p>
	 * @param  path フォルダパス
 	 * @return	String クエリ付個別JSファイルパス
	 ************************************************************************************/
	public static String appendFileUpdateDt_ScreenUniqJs(String path, HttpServletRequest request) {
		return appendFileUpdateDt_ScreenUniq(path, "js", request);
	}
	/*************************************************************************************
	 * ファイル更新日時 クエリ追加(個別CSSファイル)
	 * <p>
	 * 指定のCSSフォルダの画面IDに対応したCSSファイル名の更新日時をPathにクエリとして付加する
	 * </p>
	 * @param  path フォルダパス
 	 * @return	String クエリ付個別JSファイルパス
	 ************************************************************************************/
	public static String appendFileUpdateDt_ScreenUniqCss(String path, HttpServletRequest request) {
		return appendFileUpdateDt_ScreenUniq(path, "css", request);
	}
	/*************************************************************************************
	 * ファイル更新日時 クエリ追加(個別ファイル)
	 * <p>
	 * 指定のフォルダの画面IDに対応した(引数拡張子)ファイル名の更新日時をPathにクエリとして付加する
	 * </p>
	 * @param  path フォルダパス
 	 * @param  type 拡張子
	 * @return	String クエリ付個別JSファイルパス
	 ************************************************************************************/
	private static String appendFileUpdateDt_ScreenUniq(String path, String type, HttpServletRequest request) {

		// JSPパスを取得
		String jspPath = request.getServletPath();

		// 末尾から"/"まで取得
		String JspName = jspPath.substring(jspPath.lastIndexOf("/"), jspPath.length());

		// 取得したJSP名からJSP拡張子を削除し、引数の拡張子にする
		String fileName = JspName.replaceAll("jsp$", type);

		// ファイル名が存在するかチェック
		if(fileName.length() < 0) {
			return "";
		}

		// サーバーパス取得
		String contextPath = request.getServletContext().getRealPath("/");

		// サーバーパスからファイル位置取得
		File file = new File(contextPath + "/" + path + fileName.toLowerCase());

		if (file.exists()) {
			// ファイルが存在する場合
			// 対象ファイルの更新日時取得
			Date lastModified = new Date(file.lastModified());

			// 日時フォーマット(秒まで)
			SimpleDateFormat fmt = new java.text.SimpleDateFormat("yyyyMMddHHmmss");

			// 元のパスにクエリ付加
			return path + fileName.toLowerCase() + "?" + fmt.format(lastModified);
		} else {
			// ファイルが存在しないときは読み込み対象無し
			return "";
		}

	}

	/*************************************************************************************
	 * ファイル更新日時 クエリ追加
	 * <p>
	 * 指定のファイル名の更新日時をPathにクエリとして付加する
	 * </p>
	 * @param  path ファイルパス
	 * @return	String クエリ付ファイルパス
	 ************************************************************************************/
	public static String appendFileUpdateDt(String path, HttpServletRequest request) {

		// サーバーパス取得
		String contextPath = request.getServletContext().getRealPath("/");

		// サーバーパスからファイル位置取得
		File file = new File(contextPath + "/" + path);

		// 対象ファイルの更新日時取得
		Date lastModified = new Date(file.lastModified());

		// 日時フォーマット(秒まで)
		SimpleDateFormat fmt = new java.text.SimpleDateFormat("yyyyMMddHHmmss");

		// 元のパスにクエリ付加
		return path + "?" + fmt.format(lastModified);
	}

}
