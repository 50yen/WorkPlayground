/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoCommonInfo.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import java.util.Date;
import java.util.List;
import java.util.Map;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * 共通情報DTO <br>
 *****************************************************************************************/
public class AmdtoCommonInfo extends AmclsDtoBase {

	/** メンバ変数 */
	/** 業務日付 */
	private Date m_BusinessDate = null;
	/** アクセスログ(DB)有無 */
	private String m_AccessLogEnable = null;
	/** JavaScript用メッセージマップ */
	private Map<String, String> m_JsMessageMap = null;
	/** 表示件数プルダウンリスト */
	private List<String> m_DispCountList = null;
	/** 表示件数プルダウンリスト初期値 */
	private String m_DispCountDefault = null;

	/** 画面分類情報 画面グループID(カテゴリ) -> 画面グループID(メニュー) -> 画面ID*/
	private List<AmdtoScreenCategory> m_ScreenList = null;
	/** 画面情報リスト 画面ID -> 画面情報/ */
	private Map<String, AmdtoScreen> m_ScreenInfoMap = null;
	/** 項目権限  画面ID -> 項目ID -> 項目名/編集*/
	private Map<String, Map<String, Map<String, String>>> m_ItemDispAuth = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmdtoCommonInfo() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {
		// TODO
		m_BusinessDate = null;
		m_AccessLogEnable = null;
	}

	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public Date getM_BusinessDate() {
		return m_BusinessDate;
	}

	public void setM_BusinessDate(Date m_BusinessDate) {
		this.m_BusinessDate = m_BusinessDate;
	}

	public String getM_AccessLogEnable() {
		return m_AccessLogEnable;
	}

	public void setM_AccessLogEnable(String m_AccessLogEnable) {
		this.m_AccessLogEnable = m_AccessLogEnable;
	}

	public Map<String, String> getM_JsMessageMap() {
		return m_JsMessageMap;
	}

	public void setM_JsMessageMap(Map<String, String> m_JsMessageMap) {
		this.m_JsMessageMap = m_JsMessageMap;
	}

	public List<String> getM_DispCountList() {
		return m_DispCountList;
	}

	public void setM_DispCountList(List<String> m_DispCountList) {
		this.m_DispCountList = m_DispCountList;
	}

	public String getM_DispCountDefault() {
		return m_DispCountDefault;
	}

	public void setM_DispCountDefault(String m_DispCountDefault) {
		this.m_DispCountDefault = m_DispCountDefault;
	}

	public List<AmdtoScreenCategory> getM_ScreenList() {
		return m_ScreenList;
	}

	public void setM_ScreenList(List<AmdtoScreenCategory> m_ScreenList) {
		this.m_ScreenList = m_ScreenList;
	}

	public Map<String, AmdtoScreen> getM_ScreenInfoMap() {
		return m_ScreenInfoMap;
	}

	public void setM_ScreenInfoMap(Map<String, AmdtoScreen> m_ScreenInfoMap) {
		this.m_ScreenInfoMap = m_ScreenInfoMap;
	}

	public Map<String, Map<String, Map<String, String>>> getM_ItemDispAuth() {
		return m_ItemDispAuth;
	}

	public void setM_ItemDispAuth(Map<String, Map<String, Map<String, String>>> m_ItemDispAuth) {
		this.m_ItemDispAuth = m_ItemDispAuth;
	}

}
