/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmclsBusinessBase.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.cls;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.hitachi.a.m.all.AmallConst;
import jp.co.hitachi.a.m.all.AmallConst.CssStyleCom;
import jp.co.hitachi.a.m.all.AmallConst.DateFormatCom;
import jp.co.hitachi.a.m.all.AmallConst.FowardCom;
import jp.co.hitachi.a.m.all.AmallConst.ItemMapKey;
import jp.co.hitachi.a.m.all.AmallConst.LogDbOut;
import jp.co.hitachi.a.m.all.AmallConst.LogTable;
import jp.co.hitachi.a.m.all.AmallConst.LogType;
import jp.co.hitachi.a.m.all.AmallConst.MsgLvl;
import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallConst.SystemName;
import jp.co.hitachi.a.m.all.AmallConst.SystemType;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallExceptionInfo;
import jp.co.hitachi.a.m.all.AmallMessage;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.dto.AmdtoCommonInfo;
import jp.co.hitachi.a.m.dto.AmdtoLoginInfo;
import jp.co.hitachi.a.m.dto.AmdtoScreen;
import jp.co.hitachi.a.m.dto.AmdtoScreenCategory;
import jp.co.hitachi.a.m.dto.AmdtoScreenInfo;
import jp.co.hitachi.a.m.dto.AmdtoScreenMenu;
import jp.co.hitachi.cocktail.jxpand.util.JXDateFormat;

/*****************************************************************************************
 * Businessのスーパークラス<br>
 *****************************************************************************************/
public abstract class AmclsBusinessBase implements java.io.Serializable {

	/** メンバ定数 */
	/** アクセスログ定義初期表示フラグ ON */
	private static final String INIT_FLG_ON = "1";

	/** メンバ変数 */
	/** GIDパラメータ */
	protected String m_Gid = null;
	/** EVENTパラメータ */
	protected String m_Event = null;

	/** HttpServletRequest */
	protected HttpServletRequest m_Request = null;
	/** HttpServletResponse */
	protected HttpServletResponse m_Response = null;

	/** クラス名称 */
	protected String m_ClassName = null;
	/** システム種別 */
	protected int m_systemKind = 0;
	/** アクセスログ出力可否 */
	protected boolean m_AccessLogDisp = true;

	/** DTO管理データ */
	protected Map<String, Object> m_DtoHashtable = null;
	/** DBアクセスクラス */
	protected AmallDbAccess m_DbAccess = null;

	/**
	 * エラー情報
	 */
	/** ログインID */
	protected String m_eLoginID = null;
	/** 区分  */
	protected String m_eKind = null;
	/** 業務情報 */
	protected String m_eBusinessName = null;
	/** ログ情報ヘッダ */
	protected String m_eLogInfoHeader = null;

	//必ずオーバライドすること
	/*************************************************************************************
	 * execute処理呼び出し(抽象メソッド)
	 * <p>
	 * execute処理を呼び出すDAOを定義する。
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public abstract String execute() throws AmallException;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmclsBusinessBase() {
		this.m_Request = null;
		this.m_Response = null;
		this.m_DbAccess = null;
		this.m_Gid = "";
		this.m_Event = "";
		this.m_DtoHashtable = null;
		this.m_eLoginID = "";
		this.m_eKind = "";
		this.m_eBusinessName = "";
		this.m_eLogInfoHeader = "";
		this.m_AccessLogDisp = true;
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  mapping
	 * @param  form
	 * @param  request
	 * @param  response
	 * @param  context
	 * @return 無し
	 ************************************************************************************/
	public AmclsBusinessBase(HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event) throws AmallException {
		this.m_Request = request;
		this.m_Response = response;
		this.m_DbAccess = null;
		this.m_Gid = gid;
		this.m_Event = event;
		getDTO();
		this.m_AccessLogDisp = true;
	}

	/*************************************************************************************
	 * 業務処理呼び出し処理
	 * <p>
	 * ・DBインスタンスの生成
	 * ・アクセスログ出力（開始、終了、エラー）
	 * ・業務処理の呼び出し
	 * </p>
	 * @param  無し
	 * @return フォワード名
	 ************************************************************************************/
	public String executeProc() throws AmallException {
		String methodName = "executeProc";
		String forwardStr = "";
		String accessMsglvl = "";
		String loginId = "";

		boolean isSystemStopFlg = false;
		try {

			// ログイン情報DTO取得
			AmdtoLoginInfo loginInfo = getLoginInfoDTO();
			if (loginInfo != null) {
				loginId = loginInfo.getM_User_Cd();
			}

			// DBインスタンス生成
			m_DbAccess = new AmallDbAccess(m_systemKind);
			// DB接続
			if (m_DbAccess != null) {
				m_DbAccess.initDB();
			}

			// 共通情報DTOの取得
			AmdtoCommonInfo commonInfo = getCommonInfoDTO();
			if (commonInfo == null) {
				// TODO トップ画面時は動かないようにする
				commonInfo = new AmdtoCommonInfo();
				// 共通DTOをDBから取得
				getCommonInfoDB(commonInfo);
				// 取得DTOをセット
				putSpecifiedDTO(ParamKey.DTO_COMMONINFO, commonInfo);
			}

			//業務支援の時
			if (m_systemKind == SystemType.BUSINESS) {
				// ログテーブルを指定
				m_DbAccess.setLogTable(LogTable.BUSINESS);
			}
			// アクセスログ開始判定処理
			writeAccessLogStart(loginId, commonInfo);

			// 業務処理呼び出し
			forwardStr = execute();

			// メッセージレベルを正常にセット
			accessMsglvl = MsgLvl.NORMAL;

			// 楽観的排他の判定
			AmallExceptionInfo amei = (AmallExceptionInfo) getReqScopeAttribute(ParamKey.OPTIMISTIC_EXCLU_INFO);

			// アクセスログ可否判定
			if (isM_AccessLogDisp()) {
				if (amei != null) { // 楽観的排他異常あり？
					// アクセスログ（エラー）出力処理
					accessMsglvl = MsgLvl.ERROR;
					m_DbAccess.putErrorLog(amei.getMessage());
				}
			}
		} catch (AmallException ame) {
			setAmallException(ame);
			/*
			 * アクセスログ可否判定
			 */
			if (isM_AccessLogDisp()) {
				/*
				 * 例外発生時に以下を作成する
				 * ・アクセスログ（例外用）
				 * ・アクセスログ（終了）
				 */
				accessMsglvl = MsgLvl.EXCEPTION;
				m_DbAccess.putErrorLog(ame.getMessage());
			}
			// 例外をスローする
			throw ame;
		} catch (Exception e) {
			// ここで例外が発生したら障害情報の出力のみとする
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, LogType.ERROR, e);
			setAmallException(ee);
			throw ee;
		} finally {
			// アクセスログ終了判定処理
			writeAccessLogEnd(loginId, isSystemStopFlg, accessMsglvl);
			/*
			 * DB切断
			 * コミットされてない場合はrollbackする
			 */
			if (m_DbAccess != null) {
				try {
					m_DbAccess.rollback();
				} catch (AmallException ame) {

				} catch (Exception e) {

				} finally {
					try {
						m_DbAccess.exitDB();
					} catch (AmallException ame) {

					} catch (Exception e) {

					}
				}
			}
		}
		return forwardStr;
	}

	/*************************************************************************************
	* アクセスログ開始書き込み処理
	* <p>
	* アクセスログの開始を書き込む
	* </p>
	* @param  loginId ログインID
	* @return commonInfo　共通情報DTO
	************************************************************************************/
	protected void writeAccessLogStart(String loginId, AmdtoCommonInfo commonInfo) {
		String accessMsglvl = "";
		try {
			// アクセスログ可否判定
			if (isM_AccessLogDisp()) {

				// ログインIDが指定されたときはログ出力を有効にする
				if (loginId == null) {
					// アクセスログ（開始）出力処理
					AmdtoLoginInfo loginInfo = getLoginInfoDTO();
					if (loginInfo == null || loginInfo.getM_User_Cd() == null
							|| getLoginInfoDTO().getM_User_Cd().length() == 0)
						m_DbAccess.setLogOutput(false);
					else {
						m_DbAccess.setLogOutput(true);
						loginId = loginInfo.getM_User_Cd();
					}
				} else {
					m_DbAccess.setLogOutput(true);
				}

				// 共通情報が存在する場合は、アクセスログ有無をセットする
				if (commonInfo != null) {
					boolean logFlg = true;
					if (LogDbOut.OFF.equals(commonInfo.getM_AccessLogEnable())) {
						logFlg = false;
					}
					m_DbAccess.setLogOutput(logFlg);
				}
				// アクセスログ定義を取得する
				String[] property = getAccessProperty(m_Gid, m_Event, AmallMessageConst.ERR_LOG_STATUS_START, "");
				if (INIT_FLG_ON.equals(property[2])) {
					// 初期表示の場合
					accessMsglvl = MsgLvl.APLTRACE;
				} else {
					accessMsglvl = MsgLvl.NORMAL;
				}
				// 開始ログをDBへ出力する
				m_DbAccess.putEventStartLog(loginId, property[4], accessMsglvl, m_Gid, property[1], property[0],
						loginId);

				// 障害時情報のセット
				if (m_systemKind == SystemType.CUSTOMER) {
					m_eKind = SystemType.CUSTOMER_NM;
				} else if (m_systemKind == SystemType.BUSINESS) {
					m_eKind = SystemType.BUSINESS_NM;
				}
				m_eBusinessName = m_Gid;
				m_eLogInfoHeader = property[1];
			}
		} catch (Exception e) {
		}
	}

	/*************************************************************************************
	* アクセスログ終了書き込み処理
	* <p>
	* アクセスログの終了を書き込む
	* </p>
	* @param  loginId ログインID
	* @return isSystemStopFlg　システム停止フラグ
	************************************************************************************/
	protected void writeAccessLogEnd(String loginId, boolean isSystemStopFlg, String accessMsglvl) {
		try {
			/*
			 * アクセスログ可否判定
			 */
			if (isM_AccessLogDisp()) {
				if (isSystemStopFlg == false && m_DbAccess != null) {

					// アクセスログ（終了）
					String[] property = getAccessProperty(m_Gid, m_Event, AmallMessageConst.ERR_LOG_STATUS_END,
							accessMsglvl);
					m_DbAccess.putEventStartLog(loginId, property[4], accessMsglvl, m_Gid, property[1], property[0],
							loginId);
				}
			}
		} catch (Exception e) {
		}
	}

	/*************************************************************************************
	 * アクセスログプロパティ取得処理
	 * <p>
	 * プロパティファイルからアクセスログ用の該当画面に対するプロパティを取得する
	 * </p>
	 * @param  画面Id
	 * @param　　イベント
	 * @param  開始・終了ステータス
	 * @param  メッセージレベル
	 * @return フォワード名
	 ************************************************************************************/
	protected String[] getAccessProperty(String gid //画面ID
			, String event //イベント
			, String status //開始/終了
			, String msglvl //メッセージレベル
	) throws AmallException, Exception {
		String logInfo = ""; //ログ情報
		boolean ret = true;
		String[] property = new String[5];

		// 引数チェック
		if (gid == null || event == null) {
			return property;
		}
		// アクセスログ定義取得
		property = getAccessLogDefineDB(gid, event);

		if (INIT_FLG_ON.equals(property[2])) { // 初期表示フラグのチェック
			if (AmallMessageConst.ERR_LOG_STATUS_START.equals(status)) {
				ret = true;
			} else {
				ret = false;
			}
		} else {
			ret = false;
		}

		if (ret) {
			logInfo = new String(property[0] + ":" + AmallMessageConst.ERR_LOG_STATUS_START);
		} else {
			if (MsgLvl.ERROR.equals(msglvl))
				logInfo = property[0] + ":" + property[3] + ":" + status;
			else
				logInfo = property[0] + ":" + property[3] + ":" + status;
		}
		property[0] = logInfo;

		return property;
	}

	/*************************************************************************************
	 * エラー情報作成
	 * <p>
	 * リクエストスコープの変数を登録する(Bean専用それ以外は、禁止)
	 * </p>
	 * @param  str キー
	 * @param  obj 登録値
	 * @return 無し
	 ************************************************************************************/
	protected void setAmallException(AmallException e) {
		e.setM_GTime(new Date());
		e.setM_LoginID(m_eLoginID);
		e.setM_Kind(m_eKind);
		e.setM_BusinessName(m_eBusinessName);
		e.setM_LogInfoHeader(m_eLogInfoHeader);
		e.setM_SessionID(getSessionID());
		return;
	}

	/*************************************************************************************
	 * セッションＩＤ取得
	 * <p>
	 * セッションＩＤを取得する
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	protected String getSessionID() {
		String id = "";
		HttpSession session = this.m_Request.getSession(false);
		if (session != null) {
			id = session.getId();
		}
		return id;
	}

	/*************************************************************************************
	 * リクエストスコープ変数登録
	 * <p>
	 * リクエストスコープの変数を登録する(Bean専用それ以外は、禁止)
	 * </p>
	 * @param  str キー
	 * @param  obj 登録値
	 * @return 無し
	 ************************************************************************************/
	protected void setReqScopeAttribute(String str, Object obj) {
		this.m_Request.setAttribute(str, obj);
		return;
	}

	/*************************************************************************************
	 * リクエストスコープ変数取得
	 * <p>
	 * リクエストスコープの変数を取得する(Bean専用それ以外は、禁止)
	 * </p>
	 * @param  str キー
	 * @return 取得値
	 ************************************************************************************/
	protected Object getReqScopeAttribute(String str) {
		Object obj = null;
		obj = this.m_Request.getAttribute(str);
		return obj;
	}

	/*************************************************************************************
	 * セッションスコープ変数取得
	 * <p>
	 * セッションスコープの変数を取得する(DTO専用それ以外は、禁止)
	 * </p>
	 * @param  str キー
	 * @return 取得値
	 ************************************************************************************/
	private Object getSesScopeAttribute(String str) throws AmallException {
		String methodName = "getSesScopeAttribute()";
		Object obj = null;
		HttpSession session = this.m_Request.getSession(false);
		if (session != null) {
			obj = session.getAttribute(str);
		} else {
			AmallException ee = new AmallException();
			ee.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_COM_SESSION_GET_ERROR);
			throw ee;
		}
		return obj;
	}

	/*************************************************************************************
	 * DTO管理データ取得処理
	 * <p>
	 * DTO管理データを取得し、メンバ変数(m_DtoHashtable)にセットする
	 * </p>
	 * @param  str キー
	 * @return 無し
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	private void getDTO() throws AmallException {
		String methodName = "getDTO()";
		try {
			this.m_DtoHashtable = (Map<String, Object>) getSesScopeAttribute(ParamKey.DTO);
			if (this.m_DtoHashtable == null) {
				AmallException e = new AmallException();
				e.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_COM_DTO_MNG_DATA_GET_ERROR,
						"m_DtoHashtable(null)");
				throw e;
			}
		} catch (AmallException e) {
			e.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_COM_DTO_MNG_DATA_GET_ERROR, "");
			throw e;
		}
	}

	/*************************************************************************************
	 * DTO管理データクリア処理
	 * <p>
	 * DTO管理データを全てクリアする
	 * </p>
	 * @return 無し
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	private void clearDTO() throws AmallException {
		String methodName = "clearDTO()";
		try {
			Map<String, Object> dto = (Map<String, Object>) getSesScopeAttribute(ParamKey.DTO);
			if (dto != null) {
				boolean loop = true;
				while (loop) {
					Set set = dto.keySet();
					Iterator iterator = set.iterator();
					if (!iterator.hasNext())
						break;
					while (iterator.hasNext()) {
						String gid = (String) iterator.next();
						try {
							AmclsDtoBase dtoCls = (AmclsDtoBase) dto.get(gid);
							dtoCls.clear();
						} catch (Exception e) {
						}
						iterator.remove();
						break;
					}
				}
			}

		} catch (AmallException ame) {
			throw ame;
		} catch (Exception e) {
			AmallException ame = new AmallException();
			ame.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_COM_MNG_DATA_CLEAR_ERROR);
			throw ame;
		}
	}

	/*************************************************************************************
	 * 指定DTO判定処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)に指定したDTOが存在するか否か
	 * </p>
	 * @param  str キー
	 * @return 判定結果
	 *          true :有り
	 *          false:無し
	 ************************************************************************************/
	protected boolean isSpecifiedDTO(String str) {
		if (this.m_DtoHashtable.get(str) == null) {
			return false;
		}
		return true;
	}

	/*************************************************************************************
	 * 指定DTO取得処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)から指定したDTOを取得する
	 * </p>
	 * @param  str キー
	 * @return 指定DTO
	 ************************************************************************************/
	protected Object getSpecifiedDTO(String str) {
		return this.m_DtoHashtable.get(str);
	}

	/*************************************************************************************
	 * 指定DTO追加処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)に指定したDTOを追加する
	 * </p>
	 * @param  str キー
	 * @param  obj 登録値
	 * @return 無し
	 ************************************************************************************/
	protected void putSpecifiedDTO(String str, Object obj) {
		this.m_DtoHashtable.put(str, obj);
		return;
	}

	/*************************************************************************************
	 * 指定DTO削除処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)から指定したDTOを削除する
	 * </p>
	 * @param  str キー
	 * @return 指定DTO
	 ************************************************************************************/
	protected void delSpecifiedDTO(String str) {
		if (isSpecifiedDTO(str)) {
			this.m_DtoHashtable.remove(str);
		}
		return;
	}

	/*************************************************************************************
	 * 指定画面DTO追加処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)に指定した画面DTOを追加する
	 * </p>
	 * @param  gid 画面ID
	 * @param  str キー
	 * @param  obj 登録値
	 * @return 無し
	 * @throws AmallException
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	protected void putSpecifiedDTO(String gid, String str, Object obj) throws AmallException {

		Map<String, ArrayList> hmsal = null;
		if (isSpecifiedDTO(ParamKey.DTO_SCREEN)) {
			//画面DTO有
			hmsal = (Map<String, ArrayList>) this.m_DtoHashtable.get(ParamKey.DTO_SCREEN);
		} else {
			hmsal = new ConcurrentHashMap<String, ArrayList>();
		}
		// 指定画面情報取得
		ArrayList<AmdtoScreenInfo> alo = (ArrayList<AmdtoScreenInfo>) hmsal.get(gid);

		if (alo == null) {
			//指定画面情報なし
			alo = new ArrayList<AmdtoScreenInfo>(); //指定画面情報生成
		}
		AmdtoScreenInfo scrInfo = new AmdtoScreenInfo(); //要素生成
		scrInfo.setM_DtoName(str);
		scrInfo.setM_Dto(obj);
		alo.add(scrInfo); //要素追加
		hmsal.put(gid, alo);
		this.m_DtoHashtable.put(ParamKey.DTO_SCREEN, hmsal);
		return;
	}

	/*************************************************************************************
	 * 指定DTO取得処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)から指定したDTOを取得する
	 * </p>
	 * @param  str キー
	 * @return 指定DTO
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	protected Object getSpecifiedDTO(String gid, String str) {

		if (!isSpecifiedDTO(ParamKey.DTO_SCREEN)) {
			//画面DTOなし
			return null;
		}

		Map<String, ArrayList> hmsal = (Map<String, ArrayList>) this.m_DtoHashtable.get(ParamKey.DTO_SCREEN);

		//指定画面情報取得
		ArrayList<AmdtoScreenInfo> alo = (ArrayList<AmdtoScreenInfo>) hmsal.get(gid);
		if (alo == null) {
			//指定画面情報なし
			return null;
		}

		Object obj = null;
		for (int i = 0; i < alo.size(); i++) {
			AmdtoScreenInfo scrInfo = alo.get(i);
			// DTO名から判別
			if (str.equals(scrInfo.getM_DtoName())) {
				obj = scrInfo.getM_Dto();
				break;
			}
		}
		return obj;
	}

	/*************************************************************************************
	 * 指定画面DTO削除処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)に指定した画面DTOを削除する
	 * </p>
	 * @param  gid 画面ID
	 * @return 無し
	 * @throws AmallException
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	protected void deleteSpecifiedDTO(String gid) throws AmallException {
		if (isSpecifiedDTO(ParamKey.DTO_SCREEN)) {
			// 画面DTO登録あり
			Map<String, ArrayList> hmsal = (Map<String, ArrayList>) this.m_DtoHashtable
					.get(ParamKey.DTO_SCREEN);
			// 指定画面情報取得
			ArrayList<AmdtoScreenInfo> alo = (ArrayList<AmdtoScreenInfo>) hmsal.get(gid);
			if (alo != null) {
				//指定画面情報あり
				for (int i = alo.size() - 1; i >= 0; i--) { //登録数分ループ
					AmdtoScreenInfo scrInfo = (AmdtoScreenInfo) alo.get(i); //要素取得
					AmclsDtoBase dto = (AmclsDtoBase) scrInfo.getM_Dto();//DTOオブジェクト取得
					if (dto != null) {
						dto.clear(); //DTO削除
						dto = null;
					}
					scrInfo.clear();
					scrInfo = null;
					alo.remove(i);
				} //
				alo.clear(); //要素配列クリア
				hmsal.remove(gid); //指定画面情報クリア
			}
		}
		return;
	}

	/*************************************************************************************
	 * 指定画面DTO削除処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)からすべての画面DTOを削除する
	 * </p>
	 * @param  gid 画面ID
	 * @return 無し
	 * @throws AmallException
	 ************************************************************************************/
	@SuppressWarnings("unchecked")
	protected void deleteSpecifiedDTO() throws AmallException {
		if (isSpecifiedDTO(ParamKey.DTO_SCREEN)) {
			// 画面DTO登録あり
			Map<String, ArrayList> hmsal = (Map<String, ArrayList>) this.m_DtoHashtable
					.get(ParamKey.DTO_SCREEN);
			Set set = hmsal.keySet();
			Iterator iterator = set.iterator();
			while (iterator.hasNext()) {
				String gid = (String) iterator.next();
				ArrayList<AmdtoScreenInfo> alo = (ArrayList<AmdtoScreenInfo>) hmsal.get(gid); //指定画面情報取得
				for (int i = alo.size() - 1; i >= 0; i--) { //登録数分ループ
					AmdtoScreenInfo scrInfo = (AmdtoScreenInfo) alo.get(i); //要素取得
					AmclsDtoBase dto = (AmclsDtoBase) scrInfo.getM_Dto();//DTOオブジェクト取得
					if (dto != null) {
						dto.clear(); //DTO削除
						dto = null;
					}
					scrInfo.clear();
					scrInfo = null;
					alo.remove(i);
				} //
				alo.clear(); //要素配列クリア
			}
			hmsal.clear(); //指定画面情報クリア
		}
		return;
	}

	/*************************************************************************************
	 * ログイン情報(DTO)取得処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)からログイン情報(DTO)を取得する
	 * </p>
	 * @param  str キー
	 * @return 無し
	 ************************************************************************************/
	protected AmdtoLoginInfo getLoginInfoDTO() {
		AmdtoLoginInfo dto = (AmdtoLoginInfo) getSpecifiedDTO(ParamKey.DTO_LOGININFO);
		if (dto != null) {
			m_eLoginID = dto.getM_User_Cd();
		} else {
			m_eLoginID = "";
		}
		return dto;
	}

	/*************************************************************************************
	 * ログイン情報(DTO)追加処理
	 * <p>
	 * ログイン情報(DTO)をDTO管理データ(m_DtoHashtable)に追加する
	 * </p>
	 * @param  obj ログイン情報
	 * @return 無し
	 ************************************************************************************/
	protected void putLoginInfoDTO(AmdtoLoginInfo obj) {
		putSpecifiedDTO(ParamKey.DTO_LOGININFO, obj);
	}

	/*************************************************************************************
	 * 共通情報(DTO)取得処理
	 * <p>
	 * DTO管理データ(m_DtoHashtable)から共通情報(DTO)を取得する
	 * </p>
	 * @param  無し
	 * @return obj 共通情報
	 ************************************************************************************/
	protected AmdtoCommonInfo getCommonInfoDTO() {
		return (AmdtoCommonInfo) getSpecifiedDTO(ParamKey.DTO_COMMONINFO);
	}

	/*************************************************************************************
	 * 共通情報(DTO)追加処理
	 * <p>
	 * 共通情報(DTO)をDTO管理データ(m_DtoHashtable)に追加する
	 * </p>
	 * @param  obj 共通情報
	 * @return 無し
	 ************************************************************************************/
	protected void putVariousCodesDTO(AmdtoCommonInfo obj) {
		putSpecifiedDTO(ParamKey.DTO_COMMONINFO, obj);
	}

	/*************************************************************************************
	 * 画面メッセージセット処理
	 * <p>
	 * 画面に表示するメッセージをセットする
	 * </p>
	 * @param  obj AmclsBeanBase
	 * @return 無し
	 ************************************************************************************/
	protected void setMessageInfo(AmclsBeanBase bean, String mid, String... val) {

		// 既存のメッセージ/メッセージ種別を取得
		List<String> preMsg = bean.getMessage();
		int preType = bean.getMessageType();

		// メッセージの取得
		if (val == null) {
			preMsg.add(AmallMessage.getMessage(mid));
		} else {
			preMsg.add(AmallMessage.getMessage(mid, val));
		}
		bean.setMessage(preMsg);

		// メッセージタイプの取得
		int ctg = AmallMessage.getMessageType(mid);
		if (preType == 0 || preType > ctg) {
			// 正常か今回のメッセージが強い場合
			bean.setMessageType(ctg);
		}

	}

	/*************************************************************************************
	 * システム共通情報作成
	 * <p>
	 * システム共通情報を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @return 無し
	 ************************************************************************************/
	protected void createSystemCommonInfo(String gid, AmclsBeanBase obj) throws AmallException {


		// 共通情報(セッション)の取得
		AmdtoCommonInfo comDto = getCommonInfoDTO();
		if (comDto != null) {
			// 画面情報の取得
			createScreenData(obj, comDto);

			// 権限マップ作成
			createEachAuthority(gid, obj, comDto);

			// 顧客範囲データリスト作成
			createCustomerRange(gid, obj, comDto);

			// 店舗範囲データリスト作成
			createShopRange(gid, obj, comDto);

			// ヘッダ情報作成
			createHeader(gid, obj, comDto);

			// Javascript用メッセージ定義作成
			createJSMessageConst(obj, comDto);

			// 表示件数プルダウンリストデータ作成
			createDispCountList(obj, comDto);
		}

	}

	/*************************************************************************************
	 * 画面表示情報作成
	 * <p>
	 * 画面表示情報を作成する
	 * </p>
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createScreenData(AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {

		List<AmdtoScreenCategory> categoryList = comDto.getM_ScreenList();

		// 存在チェック
		if (categoryList != null) {
			obj.setOwdScreenList(categoryList);
		}
	}

	/*************************************************************************************
	 * ヘッダー情報作成
	 * <p>
	 * ヘッダー情報を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createHeader(String gid, AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {

		String methodName = "createHeader()";

		try {
			// システム名称
			if (m_systemKind == SystemType.CUSTOMER) {
				obj.setH_systemName(SystemName.CUSTOMER);
			} else if (m_systemKind == SystemType.BUSINESS) {
				obj.setH_systemName(SystemName.BUSINESS);
			}

			// 権限マップより判定
			Map<String, Map<String, String>> owdMap = obj.getOwdRole();
			if(owdMap != null && owdMap.size() > 0) {
				// 画面名が存在するか
				if(owdMap.containsKey(ItemMapKey.SCREEN_NAME)) {
					// 画面名が存在する場合はヘッダー部表示フラグを設定
					obj.setH_dispFlg(true);

					// 画面名称を取得
					obj.setH_screenName(owdMap.get(ItemMapKey.SCREEN_NAME).get(ItemMapKey.NAME));

					// システム日付
					JXDateFormat jxd = JXDateFormat.getInstance(DateFormatCom.YYYYMMDD24HMISS);
					Calendar cal = Calendar.getInstance();
					Date dt = cal.getTime();
					String systemDate = jxd.format(dt);
					obj.setH_systemDate(systemDate);

				} else {
					// 画面名が存在しない場合はヘッダー部表示しない
					obj.setH_dispFlg(false);
				}

			}

			// 共通情報から取得する
			if(comDto != null) {
				// 画面情報マップを取得する
				Map<String, AmdtoScreen> screenInfoMap = comDto.getM_ScreenInfoMap();
				// 存在チェック
				if(screenInfoMap != null) {
					// 画面IDから対象情報を抜き出す
					if(screenInfoMap.containsKey(gid)) {
						AmdtoScreen infoData = screenInfoMap.get(gid);

						// 画面照会IDを取得
						obj.setH_screenRefId(infoData.getM_ScreenRefId());

						// マニュアル用リンクを取得
						obj.setH_screenManualPath(infoData.getM_LinkPath());

					}
				}

			}
			// ログイン情報から取得する
			AmdtoLoginInfo logDto = getLoginInfoDTO();
			if (logDto != null) {
				// ログインID
				obj.setH_loginId(logDto.getM_User_Cd());

				// ログイン表示名称
				StringBuffer customerInfo = new StringBuffer();
				customerInfo.append(logDto.getM_User_Nm());
				customerInfo.append(AmallConst.USER_NAME_SUFFIX);
				obj.setH_loginDispName(customerInfo.toString());
			}

			return;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 権限情報作成
	 * <p>
	 * 権限情報を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createEachAuthority(String gid, AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {

		Map<String, Map<String, Map<String, String>>> itemMap = comDto.getM_ItemDispAuth();

		// 存在チェック
		if (itemMap != null && itemMap.containsKey(gid)) {
			// 画面IDから対象画面の項目権限を取得し、Beanに登録
			obj.setOwdRole(itemMap.get(gid));
		}
	}

	/*************************************************************************************
	 * 顧客範囲データリスト作成
	 * <p>
	 * 顧客範囲データリスト情報を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createCustomerRange(String gid, AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {
		// TODO 顧客範囲データの生成
	}

	/*************************************************************************************
	 * 店舗範囲データリスト作成
	 * <p>
	 * 店舗範囲データリスト情報を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createShopRange(String gid, AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {
		// TODO 店舗範囲データの生成
	}

	/*************************************************************************************
	 * Javascript用メッセージ定義作成
	 * <p>
	 * Javascript用メッセージ定義を作成する
	 * </p>
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @param  comDto 共通情報DTO
	 * @return 無し
	 ************************************************************************************/
	protected void createJSMessageConst(AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {

		// メッセージ定義設定
		Map<String, String> msgMap = comDto.getM_JsMessageMap();
		// 存在チェック
		if (msgMap != null) {
			// メッセージを設定
			obj.setJsMessageMap(msgMap);
		}
	}

	/*************************************************************************************
	 * 表示件数プルダウンリストデータ作成
	 * <p>
	 * 表示件数プルダウンリストと初期値を作成する
	 * </p>
	 * @param  gid 画面ID
	 * @return 無し
	 ************************************************************************************/
	protected void createDispCountList(AmclsBeanBase obj, AmdtoCommonInfo comDto) throws AmallException {

		// メッセージ定義設定
		List<String> dispList = comDto.getM_DispCountList();
		// 存在チェック
		if (dispList != null && dispList.size() > 0) {
			// メッセージを設定
			obj.setDispCountList(dispList);
			// メッセージ初期値を設定
			obj.setDispCountDefault(comDto.getM_DispCountDefault());
		}
	}

	/*************************************************************************************
	 * 共通情報(DB)取得処理
	 * <p>
	 * 共通情報(DTO)を取得する
	 * </p>
	 * @param  obj 諸コード情報
	 * @return 無し
	 ************************************************************************************/
	protected void getCommonInfoDB(AmdtoCommonInfo obj) throws AmallException, Exception {

		String methodName = "getCommonInfoDB()";
		ResultSet rs = null;

		try {

			// TODO 取得内容の整理
			obj.setM_BusinessDate(new Date());
			//			// 汎用マスタ 業務日付の取得
			//			rs = getGeneralData("0003", "0000", "0000");
			//			// 取得結果の検索
			//			while (rs.next()) {
			//				obj.setM_BusinessDate(rs.getDate("DATE1"));
			//			}
			if (obj.getM_BusinessDate() == null) {
				AmallException e = new AmallException();
				e.addException(this.m_ClassName, methodName, AmallMessageConst.MSG_COM_DTO_MNG_DATA_GET_ERROR,
						"m_CommonInfo");
				throw e;
			}

			// TODO 汎用マスタ アクセスログ有無の取得

			// TODO 画面権限リストの取得
			// TODO 画面情報リストの取得
			Map<String, AmdtoScreen> scnMap = new ConcurrentHashMap<>();

			List<AmdtoScreen> scrList = new ArrayList<>();
			List<AmdtoScreenMenu> mnuList = new ArrayList<>();
			List<AmdtoScreenCategory> catList = new ArrayList<>();

			AmdtoScreen screen = new AmdtoScreen();
			screen.setM_ScreenId("accme01");
			screen.setM_ScreenName("回収金種票店舗一覧");
			screen.setM_FowardData("actop01GOTOTEST");
			screen.setM_ScreenRefId("ace-alp-accme01");
			scrList.add(screen);
			scnMap.put(screen.getM_ScreenId(), screen);

			screen = new AmdtoScreen();
			screen.setM_ScreenId("accme11");
			screen.setM_ScreenName("回収金種票入力");
			screen.setM_FowardData("actop01GOTOACTMP02");
			screen.setM_ScreenRefId("ace-adc-accme11");
			scrList.add(screen);
			scnMap.put(screen.getM_ScreenId(), screen);

			screen = new AmdtoScreen();
			screen.setM_ScreenId("accme12");
			screen.setM_ScreenName("回収金種票アップロード");
			screen.setM_FowardData("actop01GOTOACTMP02");
			screen.setM_ScreenRefId("ace-adc-accme12");
			scrList.add(screen);
			scnMap.put(screen.getM_ScreenId(), screen);

			AmdtoScreenMenu menu = new AmdtoScreenMenu();
			menu.setM_MenuId("alpha");
			menu.setM_MenuName("回収金種票入力");
			menu.setM_ScreenList(scrList);
			mnuList.add(menu);

			scrList = new ArrayList<>();
			screen = new AmdtoScreen();
			screen.setM_ScreenId("actmp02");
			screen.setM_ScreenName("プレイグラウンド");
			screen.setM_FowardData("actop01GOTOACTMP02");
			screen.setM_ScreenRefId("ace-bet-actmp02");
			screen.setM_LinkPath("http://www.gakkai.ne.jp/jses/pdf/pdf.pdf");
			scrList.add(screen);
			scnMap.put(screen.getM_ScreenId(), screen);

			screen = new AmdtoScreen();
			screen.setM_ScreenId("accxx11");
			screen.setM_ScreenName("小分類2");
			screen.setM_FowardData("actop01GOTOACTMP02");
			screen.setM_ScreenRefId("ace-bet-accxx11");
			scrList.add(screen);
			scnMap.put(screen.getM_ScreenId(), screen);

			menu = new AmdtoScreenMenu();
			menu.setM_MenuId("beta");
			menu.setM_MenuName("両替入力");
			menu.setM_ScreenList(scrList);
			mnuList.add(menu);

			AmdtoScreenCategory category = new AmdtoScreenCategory();
			category.setM_CategoryId("a");
			category.setM_CategoryName("入力");
			category.setM_TopImgPath("jsp/images/icon_menu_01.png");
			category.setM_SideImgPath("jsp/images/icon_side_01.png");
			category.setM_MenuList(mnuList);

			catList.add(category);

			scrList = new ArrayList<>();
			mnuList = new ArrayList<>();
			screen = new AmdtoScreen();
			screen.setM_ScreenId("acech01");
			screen.setM_ScreenName("回収金カレンダー");
			screen.setM_FowardData("actop01GOTOACTMP02");
			screen.setM_ScreenRefId("ace-gnm-acech01");
			scrList.add(screen);
			scnMap.put(screen.getM_ScreenId(), screen);

			menu = new AmdtoScreenMenu();
			menu.setM_MenuId("ganma");
			menu.setM_MenuName("回収金精査結果照会");
			menu.setM_ScreenList(scrList);
			mnuList.add(menu);

			category = new AmdtoScreenCategory();
			category.setM_CategoryId("b");
			category.setM_CategoryName("照会");
			category.setM_TopImgPath("jsp/images/icon_menu_02.png");
			category.setM_SideImgPath("jsp/images/icon_side_02.png");
			category.setM_MenuList(mnuList);

			catList.add(category);

			// サイドメニューのみ直接のデータ

			scrList = new ArrayList<>();
			mnuList = new ArrayList<>();
			screen = new AmdtoScreen();
			screen.setM_ScreenId("aclog02");
			screen.setM_ScreenName("パスワード変更");
			screen.setM_FowardData("actop01GOTOACTMP02");
			screen.setM_ScreenRefId("ace-gnm-aclog02");
			scrList.add(screen);
			scnMap.put(screen.getM_ScreenId(), screen);

			menu = new AmdtoScreenMenu();
			menu.setM_MenuId("");
			menu.setM_MenuName("");
			menu.setM_ScreenList(scrList);
			mnuList.add(menu);

			category = new AmdtoScreenCategory();
			category.setM_CategoryId("c");
			category.setM_CategoryName("パスワード変更");
			category.setM_TopImgPath("");
			category.setM_SideImgPath("jsp/images/icon_side_03.png");
			category.setM_DispPattern(1);
			category.setM_MenuList(mnuList);

			catList.add(category);

			scrList = new ArrayList<>();
			mnuList = new ArrayList<>();
			screen = new AmdtoScreen();
			screen.setM_ScreenId("actop03");
			screen.setM_ScreenName("マニュアル");
			screen.setM_FowardData("");
			screen.setM_LinkPath("http://www.gakkai.ne.jp/jses/pdf/pdf.pdf");
			screen.setM_ScreenRefId("ace-gnm-actop03");
			scrList.add(screen);
			scnMap.put(screen.getM_ScreenId(), screen);

			menu = new AmdtoScreenMenu();
			menu.setM_MenuId("");
			menu.setM_MenuName("");
			menu.setM_ScreenList(scrList);
			mnuList.add(menu);

			category = new AmdtoScreenCategory();
			category.setM_CategoryId("c");
			category.setM_CategoryName("マニュアル");
			category.setM_TopImgPath("");
			category.setM_SideImgPath("jsp/images/icon_side_06.png");
			category.setM_DispPattern(1);
			category.setM_MenuList(mnuList);

			catList.add(category);

			// TOP画面のみ
			scrList = new ArrayList<>();
			mnuList = new ArrayList<>();
			screen = new AmdtoScreen();
			screen.setM_ScreenId("actmp01");
			screen.setM_ScreenName("テンプレート");
			screen.setM_FowardData("actop01GOTOACTMP01");
			screen.setM_ScreenRefId("ac-tmp-actmp01");
			scrList.add(screen);
			scnMap.put(screen.getM_ScreenId(), screen);

			screen = new AmdtoScreen();
			screen.setM_ScreenId("actmp02");
			screen.setM_ScreenName("Play Ground");
			screen.setM_FowardData("actop01GOTOACTMP02");
			screen.setM_ScreenRefId("ac-tmp-actmp01");
			screen.setM_LinkPath("http://www.gakkai.ne.jp/jses/pdf/pdf.pdf");
			scrList.add(screen);
			scnMap.put(screen.getM_ScreenId(), screen);

			screen = new AmdtoScreen();
			screen.setM_ScreenId("actmp03");
			screen.setM_ScreenName("Play Sample");
			screen.setM_FowardData("actop01GOTOACTMP03");
			screen.setM_ScreenRefId("ac-tmp-actmp03");
			scrList.add(screen);
			scnMap.put(screen.getM_ScreenId(), screen);

			menu = new AmdtoScreenMenu();
			menu.setM_MenuId("tmp");
			menu.setM_MenuName("Phase1");
			menu.setM_ScreenList(scrList);
			mnuList.add(menu);

			category = new AmdtoScreenCategory();
			category.setM_CategoryId("b");
			category.setM_CategoryName("開発用");
			category.setM_TopImgPath("jsp/images/icon_menu_05.png");
			category.setM_SideImgPath("jsp/images/icon_side_05.png");
			category.setM_DispPattern(2);
			category.setM_MenuList(mnuList);

			catList.add(category);


			obj.setM_ScreenList(catList);
			obj.setM_ScreenInfoMap(scnMap);

			// TODO 権限マップの取得
			Map<String, Map<String, String>> map = new ConcurrentHashMap<>();

			// ボタン系 ID＝itemBtn
			Map<String, String> addMap1_1 = new ConcurrentHashMap<>();
			addMap1_1.put(ItemMapKey.NAME, "プレイグランド");
			addMap1_1.put(ItemMapKey.DISP, "true");
			map.put(ItemMapKey.SCREEN_NAME, addMap1_1);
			Map<String, Map<String, Map<String, String>>> setMap = new ConcurrentHashMap<>();
			setMap.put("actmp02", map);
			obj.setM_ItemDispAuth(setMap);

			// TODO 画面用JavaScriptメッセージの取得(DBを使うかも検討)
			Map<String, String> msgMap = new ConcurrentHashMap<>();
			msgMap.put(AmallMessageConst.MSG_COM_COMPLETE_INFO,
					AmallMessage.getMessage(AmallMessageConst.MSG_COM_COMPLETE_INFO));
			obj.setM_JsMessageMap(msgMap);

			// TODO 表示件数プルダウンリストの内容取得
			List<String> dispCountList = new ArrayList<>();
			dispCountList.add("5");
			dispCountList.add("10");
			dispCountList.add("15");
			dispCountList.add("20");
			dispCountList.add("25");
			dispCountList.add("30");
			dispCountList.add("35");
			dispCountList.add("40");
			dispCountList.add("45");
			dispCountList.add("50");
			obj.setM_DispCountList(dispCountList);

			// TODO 表示件数プルダウンリストのデフォルト値取得
			obj.setM_DispCountDefault("10");

		} catch (AmallException ame) {
			throw ame;
			//		} catch (SQLException e) {
			//			AmallException ee = new AmallException();
			//			ee.addException(m_ClassName, methodName, e);
			//			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
	}

	// TODO 汎用マスタ取得処理
	/*************************************************************************************
	 * 汎用マスタ取得処理
	 * <p>
	 * 汎用マスタに対するデータセットを取得する。
	 * </p>
	 * @param  large 大分類コード
	 * @param  middle 中分類コード
	 * @param  samll 小分類コード
	 * @return データセット
	 ************************************************************************************/
	protected ResultSet getGeneralData(String large, String middle, String small) throws AmallException, Exception {

		String methodName = "getGeneralData()";
		StringBuffer sql = new StringBuffer();

		try {
			// 初期化
			sql.delete(0, sql.length());

			// SQL組み立て
			sql.append("	SELECT");
			sql.append("		*");
			sql.append("	FROM");
			sql.append("		ACNTLCM");
			sql.append("	WHERE");
			sql.append("		LARGE_CODE =  ?");
			sql.append("		AND MIDDLE_CODE = ?");
			sql.append("		AND SMALL_CODE = ?");
			// 検索条件設定
			m_DbAccess.createPreparedStatement(sql.toString());
			m_DbAccess.parameterClear();
			m_DbAccess.setString(1, large);
			m_DbAccess.setString(2, middle);
			m_DbAccess.setString(3, small);

			// SQL実行
			return m_DbAccess.executeQuery();

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		}
	}

	/*************************************************************************************
	 * 権限取得処理
	 * <p>
	 * アクセス権限を取得し、取得した値を返す。
	 * </p>
	 * @param  gid 画面ID
	 * @return アクセス権限
	 ************************************************************************************/
	protected void getAccessAuthority(String gid) throws AmallException {
		// TODO
	}

	/*************************************************************************************
	 * アクセスログ定義(DB)取得処理
	 * <p>
	 * アクセスログ定義(DB)からアクセスログ定義を取得する
	 * </p>
	 * @param  gid 画面ID
	 * @param  event イベントID
	 * @return 無し
	 ************************************************************************************/
	protected String[] getAccessLogDefineDB(String gid, String event) throws AmallException, Exception {

		String methodName = "getAccessLogDefineDB()";

		ResultSet rs = null;
		StringBuffer sql = new StringBuffer();
		String[] property = new String[5];

		try {

			sql.append("SELECT");
			sql.append("	SCREEN_NM");
			sql.append(",	PROGRAM_NM");
			sql.append(",	INIT_FLG");
			sql.append(",	EVENT_NM");
			sql.append(",	CONDITION");
			sql.append("FROM B_ACCESS_LOG");
			sql.append(" WHERE");
			sql.append("	SCREEN_ID =  ?");
			sql.append("	AND EVENT_ID = ?");
			m_DbAccess.createPreparedStatement(sql.toString());
			// 条件設定
			m_DbAccess.setString(1, gid);
			m_DbAccess.setString(2, event);
			// SQL実行
			rs = m_DbAccess.executeQuery();

			// 結果取得
			while (rs.next()) {
				// 画面名称
				property[0] = m_DbAccess.getString(rs, "SCREEN_NM");
				// プログラム日本語名
				property[1] = m_DbAccess.getString(rs, "PROGRAM_NM");
				// 初期表示キーワードフラグ
				property[2] = m_DbAccess.getString(rs, "INIT_FLG");
				// ボタン名称
				property[3] = m_DbAccess.getString(rs, "EVENT_NM");
				// 照会条件
				property[4] = m_DbAccess.getString(rs, "CONDITION");

			}

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			throw ee;
		} finally {
			if (rs != null) {
				rs.close();
				rs = null;
			}
		}
		return property;
	}

	/*************************************************************************************
	 * ログアウト処理
	 * <p>
	 * DTO管理情報に存在するすべてのインスタンスを解放する
	 * </p>
	 * @param  なし
	 * @return ログイン画面へのグローバルフォワード名
	 ************************************************************************************/
	protected String logoutProc() throws AmallException {

		try {
			// 画面DTO削除処理
			deleteSpecifiedDTO();
			// DTO削除
			clearDTO();
		} catch (AmallException ame) {
			throw ame;
		}
		return FowardCom.LOGIN;

	}

	/*************************************************************************************
	 * スタイル設定処理
	 * <p>
	 * 指定されたbeanBaseのインスタンスを使用して該当キーに指定スタイルをセットする
	 * </p>
	 * @param  表示用ビーンインスタンス
	 * @param  項目名
	 * @param  スタイル
	 * @return なし
	 ************************************************************************************/
	protected void setStyle(AmclsBeanBase beanBase, String key, String style) {
		beanBase.getStyleMap().put(key, style);
	}

	/*************************************************************************************
	 * エラースタイル設定処理
	 * <p>
	 * 指定されたbeanBaseのインスタンスを使用して該当キーにエラースタイルをセットする
	 * </p>
	 * @param  表示用ビーンインスタンス
	 * @param  項目名
	 * @return なし
	 ************************************************************************************/
	protected void setError(AmclsBeanBase beanBase, String key) {
		setStyle(beanBase, key, CssStyleCom.ERROR);
	}

	/*************************************************************************************
	 * 警告スタイル設定処理
	 * <p>
	 * 指定されたbeanBaseのインスタンスを使用して該当キーに警告スタイルをセットする
	 * </p>
	 * @param  表示用ビーンインスタンス
	 * @param  項目名
	 * @return なし
	 ************************************************************************************/
	public void setWarning(AmclsBeanBase beanBase, String key) {
		setStyle(beanBase, key, CssStyleCom.WARNING);
	}

	/*************************************************************************************
	 * 正常スタイル設定処理
	 * <p>
	 * 指定されたbeanBaseのインスタンスを使用して該当キーに正常スタイルをセットする
	 * </p>
	 * @param  表示用ビーンインスタンス
	 * @param  項目名
	 * @return なし
	 ************************************************************************************/
	public void setNormal(AmclsBeanBase beanBase, String key) {
		setStyle(beanBase, key, CssStyleCom.NORMAL);
	}

	/*************************************************************************************
	 * システム種別取得処理
	 * <p>
	 * システム種別取得処理を行う
	 * </p>
	 * @param  なし
	 * @return システム種別
	 ************************************************************************************/
	protected int getM_systemKind() {
		return m_systemKind;
	}

	/*************************************************************************************
	 * システム種別設定処理
	 * <p>
	 * システム種別設定処理を行う
	 * </p>
	 * @param  kind システム種別
	 * @return なし
	 ************************************************************************************/
	protected void setM_systemKind(int kind) {
		m_systemKind = kind;
	}

	/*************************************************************************************
	 * アクセスログ可否取得処理
	 * <p>
	 * アクセスログ可否取得処理を行う
	 * </p>
	 * @param  なし
	 * @return アクセスログ可否
	 ************************************************************************************/
	public boolean isM_AccessLogDisp() {
		return m_AccessLogDisp;
	}

	/*************************************************************************************
	 * アクセスログ可否設定処理
	 * <p>
	 * アクセスログ可否設定処理を行う
	 * </p>
	 * @param  アクセスログ可否
	 * @return なし
	 ************************************************************************************/
	public void setM_AccessLogDisp(boolean accessLogDisp) {
		m_AccessLogDisp = accessLogDisp;
	}

	/*************************************************************************************
	* 障害時情報設定処理
	* <p>
	* ・障害時情報を設定する
	* </p>
	* @param  gid	画面ID
	* @param  systemKind システム種類
	* @return なし
	************************************************************************************/
	protected void setErrString(String gid, int systemKind) throws AmallException {

		try {
			// システム種類のセット
			m_systemKind = systemKind;

			// アクセスログ定義を取得する
			String[] property = getAccessProperty(m_Gid, m_Event, AmallMessageConst.ERR_LOG_STATUS_START, "");

			// 障害時情報のセット
			if (m_systemKind == SystemType.CUSTOMER) {
				m_eKind = SystemType.CUSTOMER_NM;
			} else if (m_systemKind == SystemType.BUSINESS) {
				m_eKind = SystemType.BUSINESS_NM;
			}
			m_eBusinessName = m_Gid;
			m_eLogInfoHeader = property[1];
		} catch (Exception e) {

		}
	}

	/*************************************************************************************
	 * 項目名称取得
	 * <p>
	 * 権限情報を元に対象IDの項目表示名称を取得する
	 * </p>
	 * @param  itemId 項目ID
	 * @param  obj beanスーパークラスを継承したクラス(OUT)
	 * @return 項目名称
	 ************************************************************************************/
	protected String getItemDispName(String itemId, AmclsBeanBase obj) throws AmallException {

		// 権限情報マップの取得
		Map<String, Map<String, String>> itemMap = obj.getOwdRole();

		// 存在チェック
		if (itemMap.containsKey(itemId)) {
			// 項目IDから対象項目のデータリストを取得する。
			Map<String, String> itemData = itemMap.get(itemId);

			// 名称キーを取得
			if (itemData.containsKey(ItemMapKey.NAME)) {
				// 名称を返却
				return itemData.get(ItemMapKey.NAME);
			}
		}
		return "";

	}

}