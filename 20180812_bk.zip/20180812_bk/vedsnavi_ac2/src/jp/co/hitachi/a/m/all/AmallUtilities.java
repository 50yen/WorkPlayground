/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallUtilities.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.all;

import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;

import jp.co.hitachi.a.m.all.AmallConst.CssStyleCom;
import jp.co.hitachi.a.m.dto.AmdtoCalender;
import jp.co.hitachi.cocktail.jxpand.util.JXDateFormat;
import jp.co.hitachi.cocktail.jxpand.util.JXNumberFormat;
import jp.co.hitachi.cocktail.jxpand.util.JXString;
import jp.co.hitachi.cocktail.jxpand.util.JXStringUtil;

/*****************************************************************************************
 * Utilitieクラス<br>
 *****************************************************************************************/
public final class AmallUtilities {

	/**
	 * 文字種判定用 引数定数
	 */
	/** 全角英字 */
	public final static int F_ALP = JXStringUtil.F_ALP;
	/** 全角数字 */
	public final static int F_NUM = JXStringUtil.F_NUM;
	/** 全角スペース */
	public final static int F_SPACE = JXStringUtil.F_SPACE;
	/** 全角カナ */
	public final static int F_KTKN = JXStringUtil.F_KTKN;
	/** 全角記号 */
	public final static int F_SIGN = JXStringUtil.F_SIGN;
	/** 全角かな */
	public final static int F_HRGN = JXStringUtil.F_HRGN;
	/** 全角漢字・外字 */
	public final static int F_KJGJ = JXStringUtil.F_KJGJ;
	/** 半角英字 */
	public final static int H_ALP = JXStringUtil.H_ALP;
	/** 半角数字 */
	public final static int H_NUM = JXStringUtil.H_NUM;
	/** 半角スペース */
	public final static int H_SPACE = JXStringUtil.H_SPACE;
	/** 半角カナ */
	public final static int H_KTKN = JXStringUtil.H_KTKN;
	/** 半角記号 */
	public final static int H_SIGN = JXStringUtil.H_SIGN;
	/** タブ */
	public final static int TAB = JXStringUtil.TAB;
	/** リターンコード */
	public final static int RTCD = JXStringUtil.RTCD;
	/** デフォルトの記号を指定した記号指定文字列 */
	public final static String DEFAULT_SYMBOLS = JXNumberFormat.DEFAULT_SYMBOLS;
	/** マイナス記号に( )を使用するための記号指定文字列 */
	public final static String MINUS_PARENTHESIS_SYMBOLS = JXNumberFormat.MINUS_PARENTHESIS_SYMBOLS;
	/** マイナス記号に▲を使用するための記号指定文字列 */
	public final static String MINUS_TRIANGLE_SYMBOLS = JXNumberFormat.MINUS_TRIANGLE_SYMBOLS;

	/**
	 * 曜日文字列変換
	 */
	private final static String[] WeekDay = {
			"", "日", "月", "火", "水", "木", "金", "土"
	};

	/** 月内週最大値 */
	private final static int MAX_WEEK_OF_MANTH = 6;

	/*************************************************************************************
	 * NULL又は空文字列の判定
	 * <p>
	 * NULL又は空文字列の判定する
	 * </p>
	 * @param  str 文字列
	 * @return	true : 文字無し
	 * 			false: 文字有り
	 ************************************************************************************/
	public static boolean isEmpty(String str) {
		if (str == null)
			return true;
		if (str.length() == 0)
			return true;
		else
			return false;
	}

	/*************************************************************************************
	 * 空文字変換処理
	 * <p>
	 * NULLを空文字列に変換する
	 * </p>
	 * @param  str 文字列
	 * @return 変換文字列
	 ************************************************************************************/
	public static String convEmpty(String str) {
		if (str == null)
			return "";
		else
			return str;
	}

	/*************************************************************************************
	 * スペース除去
	 * <p>
	 * 文字列の両端から半角、全角スペースを取り除きます。 エスケープシーケンスは
	 * 除去対象の文字列に含まれません。
	 * </p>
	 * @param  str 文字列
	 * @return	true : 文字無し
	 * 			false: 文字有り
	 ************************************************************************************/
	public static String trim(String str) {
		if (str == null)
			return null;
		if (str.length() == 0)
			return "";

		JXString js = new JXString(str);
		js.trimSpace();

		return js.toString();
	}

	/*************************************************************************************
	 * 文字判定(全角)
	 * <p>
	 *入力された文字列が、指定された文字種で構成されていることをチェックします。
	 *文字種は複数指定が可能です。
	 * </p>
	 * @param  str  チェックされる文字列
	 * @param  kind 文字種の指定(F_ALP,F_NUM,F_SPACE,F_KTKN,F_SIGN,F_HRGN,F_KJGJ,TAB,RTCD)
	 * @return	true : 指定文字種のみで構成
	 * 			false: 指定文字種のみで構成されていない
	 ************************************************************************************/
	public static boolean isFullWidthCharacterKind(String str, int kind) {
		if (str == null)
			return false;
		return JXStringUtil.isFullWidthCharacterKind(str, kind);
	}

	/*************************************************************************************
	 * 文字判定(半角)
	 * <p>
	 * 入力された文字列が、指定された文字種で構成されていることをチェックします。
	 * 文字種は複数指定が可能です
	 * </p>
	 * @param  str  チェックされる文字列
	 * @param  kind 文字種の指定(H_ALP,H_NUM,H_SPACE,H_KTKN,H_SIGN,TAB,RTCD)
	 * @return	true : 指定文字種のみで構成
	 * 			false: 指定文字種のみで構成されていない
	 ************************************************************************************/
	public static boolean isHalfWidthCharacterKind(String str, int kind) {
		if (str == null)
			return false;
		return JXStringUtil.isHalfWidthCharacterKind(str, kind);
	}

	/*************************************************************************************
	 * 文字判定
	 * <p>
	 * 入力された文字列が、指定された文字種で構成されていることをチェックします。
	 * 文字種は複数指定が可能です。
	 * </p>
	 * @param  str  チェックされる文字列
	 * @param  kind 文字種の指定(F_ALP,F_NUM,F_SPACE,F_KTKN,F_SIGN,F_HRGN,H_ALP,H_NUM
	 *              H_SPACE,H_KTKN,H_SIGN,TAB,RTCD)
	 * @return	true : 指定文字種のみで構成
	 * 			false: 指定文字種のみで構成されていない
	 ************************************************************************************/
	public static boolean consist(String str, int kind) {
		if (str == null)
			return false;
		return JXStringUtil.consist(str, kind);
	}

	/*************************************************************************************
	 * 文字判定
	 * <p>
	 * 入力された文字列に、指定された文字種が含まれていることをチェックします。
	 * 文字種は複数指定が可能です。
	 * </p>
	 * @param  str  チェックされる文字列
	 * @param  kind 文字種の指定(F_ALP,F_NUM,F_SPACE,F_KTKN,F_SIGN,F_HRGN,H_ALP,H_NUM
	 *              H_SPACE,H_KTKN,H_SIGN,TAB,RTCD)
	 * @return	true : 指定文字種のみで構成
	 * 			false: 指定文字種のみで構成されていない
	 ************************************************************************************/
	public static boolean contain(String str, int kind) {
		if (str == null)
			return false;
		return JXStringUtil.contain(str, kind);
	}

	/*************************************************************************************
	 * カレンダー表示データ作成
	 * <p>
	 * 対象月のカレンダーデータを画面表示用に加工する
	 * </p>
	 * @param  ym 対象年月
	 * @param  db DBアクセスインスタンス
	 * @return List<List<AmdtoCalender>> カレンダーデータ
	 ************************************************************************************/
	public static List<List<AmdtoCalender>> getCalenderDispData(String ym, AmallDbAccess db) {

		// 返却用リスト
		List<List<AmdtoCalender>> retList = new ArrayList<>();

		// 曜日データを生成する(月曜始まり)
		List<AmdtoCalender> weekDayDataList = new ArrayList<>();
		for (int nWeekDay = Calendar.MONDAY; nWeekDay <= Calendar.SATURDAY; nWeekDay++) {
			AmdtoCalender weekDayDto = new AmdtoCalender();
			// 対象日付
			weekDayDto.setM_KeyDate(String.valueOf(nWeekDay));
			// 表示文字列
			weekDayDto.setM_DispDay(WeekDay[nWeekDay]);
			// データに設定
			weekDayDataList.add(weekDayDto);
		}
		// 日曜日データを設定
		AmdtoCalender weekEndDayDto = new AmdtoCalender();
		// 対象日付
		weekEndDayDto.setM_KeyDate(String.valueOf(Calendar.SUNDAY));
		// 表示文字列
		weekEndDayDto.setM_DispDay(WeekDay[Calendar.SUNDAY]);
		// データに設定
		weekDayDataList.add(weekEndDayDto);

		// 1行目データを作成
		retList.add(weekDayDataList);

		// 登録対象データの初期化を行う
		List<AmdtoCalender> registDataList = new ArrayList<>();

		// 初週から最大週まで初期化する
		for (int nWkMonth = 1; nWkMonth <= MAX_WEEK_OF_MANTH; nWkMonth++) {

			for (int nWeekDay = Calendar.MONDAY; nWeekDay <= Calendar.SATURDAY; nWeekDay++) {
				AmdtoCalender intRegistDataDto = new AmdtoCalender();
				// 週目
				intRegistDataDto.setM_WeekofMonth(nWkMonth);
				// 曜日
				intRegistDataDto.setM_WeekDay(nWeekDay);
				// 表示文字
				intRegistDataDto.setM_DispDay("");
				// 基本CSS
				intRegistDataDto.setM_DispDayClass(CssStyleCom.WEEKDAY);
				// データに設定
				registDataList.add(intRegistDataDto);
			}
			// 日曜日データを設定
			AmdtoCalender intSunDayDto = new AmdtoCalender();
			// 週目
			intSunDayDto.setM_WeekofMonth(nWkMonth);
			// 曜日
			intSunDayDto.setM_WeekDay(Calendar.SUNDAY);
			// 表示文字
			intSunDayDto.setM_DispDay("");
			// 基本CSS
			intSunDayDto.setM_DispDayClass(CssStyleCom.WEEKDAY);
			// データに設定
			registDataList.add(intSunDayDto);
		}

		// 対象年月のカレンダーデータを取得
		List<AmdtoCalender> calenderDataList = getCalenderData(ym, db);

		// 登録対象データを作成する
		for (AmdtoCalender registData : registDataList) {

			// 対象年月データの存在をチェック
			for (AmdtoCalender calenderData : calenderDataList) {
				if (registData.getM_WeekofMonth() == calenderData.getM_WeekofMonth() &&
						registData.getM_WeekDay() == calenderData.getM_WeekDay()) {
					registData.copy2me(calenderData);
					break;
				}
			}
		}

		// 週ごとのデータを分類する
		int weekFlg = 1;
		List<AmdtoCalender> weekData = new ArrayList<>();
		for (AmdtoCalender amdtoCalender : registDataList) {
			if (weekFlg == amdtoCalender.getM_WeekofMonth()) {
				weekData.add(amdtoCalender);
			} else {
				retList.add(weekData);
				weekData = new ArrayList<>();
				weekFlg = amdtoCalender.getM_WeekofMonth();
				weekData.add(amdtoCalender);
			}
		}
		// 最終週のデータ
		if (weekData.size() > 0) {
			// 最終日を取得
			AmdtoCalender lastDay = calenderDataList.get(calenderDataList.size() - 1);
			if (lastDay.getM_WeekofMonth() == MAX_WEEK_OF_MANTH) {
				// 最終日が最大週目の場合のみ登録
				retList.add(weekData);
			}
		}
		return retList;

	}

	/*************************************************************************************
	 * カレンダーデータ取得
	 * <p>
	 * 対象月のカレンダーデータを生成する
	 * </p>
	 * @param  ym 対象年月
	 * @param  db DBアクセスインスタンス
	 * @return YYYYMM形式の文字列(対象月)
	 ************************************************************************************/
	private static List<AmdtoCalender> getCalenderData(String ym, AmallDbAccess db) {

		// 文字列長チェック
		if (ym.length() != 6) {
			return null;
		}
		// 返却データを生成
		List<AmdtoCalender> retList = new ArrayList<>();

		// 1か月分の対象日付を取得
		List<String> dayList = getDayRange(ym + "01");

		// カレンダークラス生成(月曜始まり)
		Calendar cal = Calendar.getInstance();
		cal.setFirstDayOfWeek(Calendar.MONDAY);
		// 取得した1か月分データを生成
		for (String day : dayList) {
			AmdtoCalender dto = new AmdtoCalender();
			// 対象日付
			dto.setM_KeyDate(day);

			// カレンダークラス生成
			int yyyy = Integer.parseInt(day.substring(0, 4));
			int mm = Integer.parseInt(day.substring(4, 6));
			int dd = Integer.parseInt(day.substring(6, 8));
			cal.set(yyyy, mm - 1, dd);

			// 表示日付
			dto.setM_DispDay(String.valueOf(cal.get(Calendar.DATE)));

			// 対象曜日
			int week = cal.get(Calendar.DAY_OF_WEEK);
			dto.setM_WeekDay(week);

			// 対象週
			int weekOfMonth = cal.get(Calendar.WEEK_OF_MONTH);
			dto.setM_WeekofMonth(weekOfMonth);

			// 表示文字CSS
			if (week == Calendar.SUNDAY || week == Calendar.SATURDAY) {
				dto.setM_DispDayClass(CssStyleCom.HOLIDAY);
			} else {
				dto.setM_DispDayClass(CssStyleCom.WEEKDAY);
			}

			// TODO カレンダーマスタへのアクセス

			// データを返却リストに設定
			retList.add(dto);

		}

		return retList;

	}

	/*************************************************************************************
	 * カレンダー表示内容データ作成
	 * <p>
	 * 対象月のカレンダーデータの内容部を設定する
	 * </p>
	 * @param  ymd 対象年月日yyyymmdd
	 * @param  type 内容種別 0:表示なし 1:通常 2:異常
	 * @param  main 内容1
	 * @param  sub 内容2
	 * @param	cal 対象カレンダーデータ
	 * @return なし
	 ************************************************************************************/
	public static void setCalenderContentsData(String ymd, int type, String main, String sub,
			List<List<AmdtoCalender>> cal) {

		// 文字列長チェック
		if (ymd == null || ymd.length() != 8) {
			return;
		}

		// カレンダーデータを繰り返す
		for (List<AmdtoCalender> list : cal) {
			for (AmdtoCalender dayData : list) {
				// 対象日が入っているか
				if(dayData.getM_KeyDate() != null && dayData.getM_KeyDate().length() > 0) {
					if(dayData.getM_KeyDate().equals(ymd)) {
						dayData.setM_ContentsType(type);
						dayData.setM_ContentsMain(main);
						dayData.setM_ContentsSub(sub);
					}
				}
			}
		}
		return;
	}

	/*************************************************************************************
	 * 現在日付取得
	 * <p>
	 * 現在日付を取得する
	 * </p>
	 * @param  無
	 * @return YYYYMMDD形式の文字列
	 ************************************************************************************/
	public static String getYYYYMMDD() {

		Calendar cal = Calendar.getInstance();
		String str = null;

		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		int day = cal.get(Calendar.DATE);

		cal.set(year, month, day);
		Date dt = cal.getTime();

		DateFormat dfm = new SimpleDateFormat("yyyyMMdd");
		str = dfm.format(dt);

		return str;

	}

	/*************************************************************************************
	 * 現在日付-1取得
	 * <p>
	 * 現在日付-1を取得する
	 * </p>
	 * @param  無
	 * @return YYYYMMDD形式の文字列
	 ************************************************************************************/
	public static String getYYYYMMDD_1() {

		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		String str = null;

		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH);
		int day = cal.get(Calendar.DATE);

		cal.set(year, month, day);
		Date dt = cal.getTime();

		DateFormat dfm = new SimpleDateFormat("yyyyMMdd");
		str = dfm.format(dt);

		return str;

	}

	/*************************************************************************************
	 * 日付書式変換
	 * <p>
	 * 日付を書式変換する
	 * </p>
	 * @param  date 日付
	 * @return YYYYMMDD形式の文字列
	 ************************************************************************************/
	public static String getYYYYMMDD(Date dt) {

		if (dt == null)
			return "";

		DateFormat dFm = new SimpleDateFormat("yyyyMMdd");
		String ymd = dFm.format(dt);
		return ymd;
	}

	/*************************************************************************************
	 * ３ヶ月前、１ヵ月後日付取得
	 * <p>
	 * 日付より、３ヶ月前(１日)、１ヵ月後(末日)の日付を取得する
	 * </p>
	 * @param  yyyymmdd 文字列
	 * @return ３ヶ月前、１ヵ月後の日付
	 ************************************************************************************/
	public static String[] getDateRange(String ymd) {
		String[] strDt = { "", "" };

		if (ymd == null)
			return strDt;

		int yyyy = Integer.parseInt(ymd.substring(0, 4));
		int mm = Integer.parseInt(ymd.substring(4, 6));
		DateFormat dFm = new SimpleDateFormat("yyyyMMdd");
		Date d1 = null;
		Date d3 = null;

		/* ３ヶ月前 */
		Calendar cal_3 = Calendar.getInstance();
		cal_3.setLenient(false);
		cal_3.set(yyyy, mm - 1, 1);
		cal_3.add(Calendar.MONTH, -3);
		d3 = cal_3.getTime();
		strDt[0] = dFm.format(d3);

		/* １ヶ月後 */
		Calendar cal_1 = Calendar.getInstance();
		cal_1.setLenient(false);
		cal_1.set(yyyy, mm - 1, 1);
		cal_1.add(Calendar.MONTH, 2);
		cal_1.add(Calendar.DATE, -1);
		d1 = cal_1.getTime();
		strDt[1] = dFm.format(d1);

		return strDt;
	}

	/*************************************************************************************
	 * 日付加算
	 * <p>
	 * 加算した日付を取得する
	 * </p>
	 * @param  yyyymmdd 文字列
	 * @return yyyymmdd 年月日加算した日付
	 ************************************************************************************/
	public static String addDate(String ymd, int add, int mode) {
		String strDt = "";

		if (ymd == null)
			return strDt;

		int yyyy = Integer.parseInt(ymd.substring(0, 4));
		int mm = Integer.parseInt(ymd.substring(4, 6));
		int dd = Integer.parseInt(ymd.substring(6, 8));
		DateFormat dFm = new SimpleDateFormat("yyyyMMdd");
		Date d = null;
		Calendar cal = Calendar.getInstance();

		cal.setLenient(false);
		cal.set(yyyy, mm - 1, dd);
		if (mode == 1) {
			cal.add(Calendar.DATE, add);
		} else if (mode == 2) {
			cal.add(Calendar.MONTH, add);
		} else {
			cal.add(Calendar.YEAR, add);
		}
		d = cal.getTime();
		strDt = dFm.format(d);

		return strDt;
	}

	/*************************************************************************************
	 * 通貨フォーマット変換処理
	 * <p>
	 * 通貨フォーマット変換処理を行う
	 * </p>
	 * @param  fromFmt 	文字列
	 * @param  fromSyms 文字列
	 * @param  toFmt 	文字列
	 * @param  toSyms 	文字列
	 * @param  num 		文字列
	 * @return フォーマット変換した文字列
	 ************************************************************************************/
	public static String changeCurrencyFormat(String fromFmt,
			String fromSyms,
			String toFmt,
			String toSyms,
			String num) {
		if (isEmpty(fromFmt) ||
				isEmpty(toFmt) ||
				isEmpty(fromSyms) ||
				isEmpty(toSyms) ||
				isEmpty(num)) {
			return "";
		}

		try {
			return JXNumberFormat.changeFormat(fromFmt, fromSyms, num, toFmt, toSyms);
		} catch (Exception e) {
			return "";
		}
	}

	/*************************************************************************************
	 * 通貨チェック処理
	 * <p>
	 * 通貨チェック処理を行う
	 * </p>
	 * @param  format 	文字列
	 * @param  num 		文字列
	 * @return true		チェックOK
	 *         false	チェックNG
	 ************************************************************************************/
	public static boolean checkCurrency(String format, String num) {
		if (isEmpty(format) || isEmpty(num)) {
			return false;
		}
		return JXNumberFormat.check(format, num);
	}

	/*************************************************************************************
	 * 日付フォーマット変換処理
	 * <p>
	 * 日付フォーマット変換処理を行う
	 * </p>
	 * @param  fromFmt 	文字列
	 * @param  toFmt 	文字列
	 * @param  date 	文字列
	 * @return フォーマット変換した文字列
	 ************************************************************************************/
	public static String changeDateFormat(String fromFmt, String toFmt, String date) {
		if (isEmpty(fromFmt) || isEmpty(toFmt) || isEmpty(date)) {
			return "";
		}

		return JXDateFormat.changeFormat(fromFmt, date, toFmt);
	}

	/*************************************************************************************
	 * 日付チェック処理
	 * <p>
	 * 日付チェック処理を行う
	 * </p>
	 * @param  format 	文字列
	 * @param  num 		文字列
	 * @return true		チェックOK
	 *         false	チェックNG
	 ************************************************************************************/
	public static boolean checkDate(String format, String date) {
		if (isEmpty(format) || isEmpty(date)) {
			return false;
		}
		return JXDateFormat.check(format, date);
	}

	/*************************************************************************************
	 * 数値チェック処理
	 * <p>
	 * 数値チェック処理を行う
	 * </p>
	 * @param  str	 	文字列
	 * @return true		チェックOK
	 *         false	チェックNG
	 ************************************************************************************/
	public static boolean isNumeric(String str) {
		if (str == null)
			return false;
		try {
			Integer.parseInt(str);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/*************************************************************************************
	 * 通貨文字列チェック処理
	 * <p>
	 * 通貨文字列チェック処理を行う
	 * </p>
	 * @param  str	 	文字列
	 * @return 0		チェックOK(カンマ無し)
	 *         1		チェックOK(カンマ有り)
	 *         -1		チェックNG
	 ************************************************************************************/
	public static int isCurrencyChars(String str) {
		if (isEmpty(str))
			return -1;
		char[] chars = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', ',' };
		try {
			boolean cflg = false;
			for (int i = 0; i < str.length(); i++) {
				boolean flg = false;
				for (int j = 0; j < chars.length; j++) {
					if (str.charAt(i) == chars[j]) {
						flg = true;
						/* ｶﾝﾏ有り ? */
						if (str.charAt(i) == chars[11]) {
							cflg = true;
						}
						break;
					}
				}
				if (!flg)
					return -1;
			}
			if (cflg) {
				return 1;
			} else {
				return 0;
			}
		} catch (Exception e) {
			return -1;
		}
	}

	/*************************************************************************************
	 * 指定日の曜日を取得
	 * <p>
	 * 指定日の曜日を取得する
	 * </p>
	 * @param  yyyymmdd 文字列
	 * @return "日","月","火","水","木","金","土":正常
	 * 			"": 日付異常
	 ************************************************************************************/
	public static String getDayOfWeek(String yyyymmdd) {
		String ret = "";
		int yyyy = 0;
		int mm = 0;
		int dd = 0;
		Calendar cal = Calendar.getInstance();

		if (isEmpty(yyyymmdd)) {
			return ret;
		}

		yyyy = Integer.parseInt(yyyymmdd.substring(0, 4));
		mm = Integer.parseInt(yyyymmdd.substring(4, 6));
		dd = Integer.parseInt(yyyymmdd.substring(6, 8));

		try {
			cal.setLenient(false);
			cal.set(yyyy, mm - 1, dd);
			ret = WeekDay[cal.get(Calendar.DAY_OF_WEEK)];
		} catch (Exception e) {
		}

		return ret;
	}

	/**********************************************************************************************
	 * 日付変換(YYYYMMDD → YYYY/MM/DD)
	 * <p>
	 * 日付変換(YYYYMMDD → YYYY/MM/DD)を行う
	 * </p>
	 * @param  String  変換前日付
	 * @return String  変換後日付
	 *********************************************************************************************/
	public static String changeFormat(String strYmd) {
		if (strYmd == null || strYmd.length() != 8)
			return " ";
		else
			return strYmd.substring(0, 4) + "/" + strYmd.substring(4, 6) + "/" + strYmd.substring(6, 8);
	}

	/*********************************************************************************************
	 * 指定年月の翌月末日取得
	 * <p>
	 * 指定年月の翌月末日を取得する
	 * </p>
	 * @param  String  入力年月 YYYYMM
	 * @return String  指定年月の末日 YYYYMMDD
	 *********************************************************************************************/
	public static String getLastDay(String StartDay) {
		String SysYmd = StartDay;

		int intStartYY = java.lang.Integer.parseInt(SysYmd.substring(0, 4));
		int intStartMM = java.lang.Integer.parseInt(SysYmd.substring(4, 6));
		int intStartDD = 1;

		GregorianCalendar gc = new GregorianCalendar(intStartYY, intStartMM, intStartDD);

		//末日
		int intTodayY = gc.get(GregorianCalendar.YEAR);
		int intTodayM = gc.get(GregorianCalendar.MONTH) + 1;
		int intTodayD = gc.getActualMaximum(GregorianCalendar.DAY_OF_MONTH);

		StringBuffer strSdateDD = new StringBuffer();
		StringBuffer strSdateMM = new StringBuffer();
		StringBuffer nextYmd = new StringBuffer();

		if (intTodayM < 10) {
			strSdateMM.append("0");
		}
		strSdateMM.append(String.valueOf(intTodayM));

		if (intTodayD < 10) {
			strSdateDD.append("0");
		}
		strSdateDD.append(String.valueOf(intTodayD));

		nextYmd.append(String.valueOf(intTodayY));
		nextYmd.append(strSdateMM);
		nextYmd.append(strSdateDD);
		return nextYmd.toString();
	}

	/*********************************************************************************************
	 * 指定された日付のX日後取得
	 * <p>
	 * 指定された日付のX日後を取得する
	 * </p>
	 * @param  String  入力日付 YYYYMMDD
	 * @param  int     指定日   X日
	 * @return String  出力日付 YYYYMMDD
	 *********************************************************************************************/
	public static String getLateDay(String StartDay, int date) {
		int intStartYY = 0;
		int intStartMM = 0;
		int intStartDD = 0;
		if (StartDay.length() == 8) {
			intStartYY = java.lang.Integer.parseInt(StartDay.substring(0, 4));
			intStartMM = java.lang.Integer.parseInt(StartDay.substring(4, 6));
			intStartDD = java.lang.Integer.parseInt(StartDay.substring(6, 8));
		} else if (StartDay.length() == 10) {
			intStartYY = java.lang.Integer.parseInt(StartDay.substring(0, 4));
			intStartMM = java.lang.Integer.parseInt(StartDay.substring(5, 7));
			intStartDD = java.lang.Integer.parseInt(StartDay.substring(8, 10));
		} else {
			return StartDay;
		}
		StringBuffer lateDate = new StringBuffer();
		GregorianCalendar gc = new GregorianCalendar(intStartYY, intStartMM - 1, intStartDD);

		gc.add(GregorianCalendar.DATE, date);
		int intTodayY = gc.get(GregorianCalendar.YEAR);
		int intTodayM = gc.get(GregorianCalendar.MONTH) + 1;
		int intTodayD = gc.get(GregorianCalendar.DAY_OF_MONTH);

		String strSdateYYYY = String.valueOf(intTodayY);

		String strSdateMM;
		if (intTodayM < 10) {
			strSdateMM = "0" + String.valueOf(intTodayM);
		} else {
			strSdateMM = String.valueOf(intTodayM);
		}

		String strSdateDD;
		if (intTodayD < 10) {
			strSdateDD = "0" + String.valueOf(intTodayD);
		} else {
			strSdateDD = String.valueOf(intTodayD);
		}

		if (StartDay.length() == 8) {
			lateDate.append(strSdateYYYY);
			lateDate.append(strSdateMM);
			lateDate.append(strSdateDD);
		} else if (StartDay.length() == 10) {
			lateDate.append(strSdateYYYY);
			lateDate.append(AmallConst.CS_HF_SLASH);
			lateDate.append(strSdateMM);
			lateDate.append(AmallConst.CS_HF_SLASH);
			lateDate.append(strSdateDD);
		}

		return lateDate.toString();
	}

	/**********************************************************************************************
	 * 日付チェック
	 * <p>
	 * 文字列(YYYYMMDD)が日付として有効かチェックする。
	 * </p>
	 * @param  String  入力文字列 YYYYMMDD
	 * @return boolean  有効 true 無効 false
	 **********************************************************************************************/
	public static boolean dateChk(String myDate) {
		//入力文字列が８桁以外の場合エラー
		if (myDate.length() != 8) {
			return false;
		}

		for (int i = 0; i < myDate.length(); i++) {
			char charData = myDate.charAt(i);
			if ((charData < '0') || (charData > '9')) {
				return false;
			}
		}

		int intYear;
		int intMonth;
		int intDay;

		if (myDate.length() > 3) {
			intYear = java.lang.Integer.parseInt(myDate.substring(0, 4));
		} else {
			intYear = 0;
		}
		if (myDate.length() > 5) {
			intMonth = java.lang.Integer.parseInt(myDate.substring(4, 6));
		} else {
			intMonth = 0;
		}
		if (myDate.length() == 8) {
			intDay = java.lang.Integer.parseInt(myDate.substring(6, 8));
		} else {
			intDay = 0;
		}

		Calendar cal = new GregorianCalendar();
		cal.setLenient(false);
		cal.set(intYear, intMonth - 1, intDay);

		return true;
	}

	/**********************************************************************************************
	 * 日付変換(YYYY/MM/DD → YYYYMMDD)
	 * <p>
	 * 日付変換(YYYY/MM/DD → YYYYMMDD)を行う
	 * </p>
	 * @param  String  変換前日付
	 * @return String  変換後日付
	 **********************************************************************************************/
	public static String changeFormat422(String strYmd) {
		if (strYmd == null || strYmd.length() != 10)
			return " ";
		else
			return strYmd.substring(0, 4) + strYmd.substring(5, 7) + strYmd.substring(8, 10);
	}

	/**********************************************************************************************
	 * 日付差取得
	 * <p>
	 * 2つの日付の差（日数）を返す。
	 * </p>
	 * @param  String  入力文字列 YYYYMMDD
	 * @param  String  入力文字列 YYYYMMDD
	 * @return Long 日付差 >=0 / 書式不正 = -1
	 **********************************************************************************************/
	public static Long diffDate(String d1, String d2) {
		Long diff = -1L;
		if (!dateChk(d1) || !dateChk(d2))
			return diff;

		Calendar c1 = Calendar.getInstance();
		Calendar c2 = Calendar.getInstance();
		c1.set(Integer.parseInt(d1.substring(0, 4)), Integer.parseInt(d1.substring(4, 6)) - 1,
				Integer.parseInt(d1.substring(6, 8)));
		c2.set(Integer.parseInt(d2.substring(0, 4)), Integer.parseInt(d2.substring(4, 6)) - 1,
				Integer.parseInt(d2.substring(6, 8)));
		diff = c2.getTimeInMillis() - c1.getTimeInMillis();
		diff = diff / (24 * 60 * 60 * 1000);
		return diff;
	}

	/**********************************************************************************************
	 * サニタイジング
	 * <p>
	 * サニタイジング処理を行う
	 * </p>
	 * @param  String  変換前文字列
	 * @return String  変換後文字列
	 **********************************************************************************************/
	public static String sanitizing(String str) {
		String ret = str;

		if (!isEmpty(ret)) {
			ret = ret.replace("&", "&amp;");
			ret = ret.replace("<", "&lt;");
			ret = ret.replace(">", "&gt;");
			ret = ret.replace("\"", "&quot;");
			ret = ret.replace("'", "&#39;");
		}

		return ret;
	}

	/**********************************************************************************************
	 * 文字データCSV出力
	 * <p>
	 * 文字データCSV出力を行う
	 * </p>
	 * @param  String  変換前文字列
	 * @return String  変換後文字列
	**********************************************************************************************/
	public static String getCsvString(String str) {
		StringBuffer ret = new StringBuffer();

		ret.append("\"");
		if (!isEmpty(str)) {
			ret.append(str.replace("\"", "\"\""));
		}
		ret.append("\"");

		return ret.toString();
	}

	/**********************************************************************************************
	 *  ローカルホスト名取得
	 *  <p>
	 *	ローカルホスト名取得を行う
	 *	</p>
	 *	 @param なし
	 *  @return String  ローカルホスト名
	 **********************************************************************************************/
	public static String getLocalHostName() {
		String host = "";
		try {
			InetAddress inet = InetAddress.getLocalHost();
			host = inet.getHostName();
		} catch (Exception e) {
			host = "";
		}
		return host;
	}

	/*************************************************************************************
	 * 通貨変換
	 * <p>
	 * 文字列を通貨変換文字列に変換する
	 * </p>
	 * @param  num 数値文字列
	 * @return 通貨文字列
	 ************************************************************************************/
	public static String toCurrency(String num) {
		try {
			if (!AmallUtilities.isNumeric(num)) {
				return "";
			} else {
				long l = Long.parseLong(num);
				DecimalFormat df = new DecimalFormat("###,###,###");
				return df.format(l);
			}
		} catch (Exception e) {
			return "";
		}
	}

	/*************************************************************************************
	 * 通貨変換
	 * <p>
	 * 文字列を通貨変換文字列に変換する
	 * </p>
	 * @param  num 数値文字列
	 * @return 通貨文字列
	 ************************************************************************************/
	public static String toCurrency(long num) {
		try {
			DecimalFormat df = new DecimalFormat("###,###,###");

			StringBuffer sb = new StringBuffer();
			if (num < 0) {
				num = Math.abs(num);
				sb.append(AmallConst.CS_MINUS_CURRENCY);
			}
			sb.append(df.format(num));
			return sb.toString();
		} catch (Exception e) {
			return "";
		}
	}

	/*************************************************************************************
	 * 半角文字数返却処理
	 * <p>
	 * 半角文字を１としたときの文字数を返却する
	 * </p>
	 * @param  str 文字列
	 * @return 文字数
	 ************************************************************************************/
	public static Integer getLengthAsHalf(String str) {
		int len = str.length();
		int lenb = 0;
		for (int i = 0; i < len; i++) {
			char c = str.charAt(i);
			int addlen = 0;
			// '08/05/01 SJISのバイト数の判定を変更
			if ((0x0 <= c && c < 0x81) ||
					(0xff61 <= c && c < 0xffa0) ||
					(c == 0xf8f0) ||
					(0xf8f1 <= c && c < 0xf8f4)) {
				addlen = 1;
			} else {
				addlen = 2;
			}
			lenb += addlen;
		}
		return lenb;
	}

	/*************************************************************************************
	 * ランダムパスワード作成(英数字8文字)
	 * <p>
	 * ランダムパスワード作成(英数字8文字)を行う
	 * </p>
	 * @param   なし
	 * @return	パスワード
	 ************************************************************************************/
	public static String getRandomPassword() {
		RandomStringUtils rnd = new RandomStringUtils();
		return rnd.randomAlphanumeric(8);
	}

	/*************************************************************************************
	 * 日付の妥当性チェック
	 * <p>
	 * 指定した日付文字列(yyyy/MM/dd or yyyy-MM-dd)が
	 * カレンダーに存在するかどうかを返します。
	 * </p>
	 * @param strDate チェック対象の文字列
	 * @return 存在する日付の場合true
	 ************************************************************************************/
	public static boolean checkExistDate(String strDate) {
		if (strDate == null || strDate.length() != 10) {
			return false;
		}
		strDate = strDate.replace('-', '/');
		DateFormat format = DateFormat.getDateInstance();
		// 日付/時刻解析を厳密に行うかどうかを設定する。
		format.setLenient(false);
		try {
			format.parse(strDate);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/*************************************************************************************
	 * 1ヵ月後から過去年月取得
	 * <p>
	 * 日付より、1ヵ月後から過去の年月を取得する
	 * </p>
	 * @param  yyyymm 文字列
	 * @param  range  出力月数
	 * @return 1ヵ月後から過去年月
	 ************************************************************************************/
	public static String[] getDateRange(String ymd, int range) {
		if (range < 0) {
			range = 0;
		}

		String[] strDt = new String[range];
		for (int i = 0; i < strDt.length; i++) {
			strDt[i] = "";
		}

		if (ymd == null) {
			return strDt;
		}

		int yyyy = Integer.parseInt(ymd.substring(0, 4)); //年取得
		int mm = Integer.parseInt(ymd.substring(4, 6)); //月取得
		DateFormat dFm = new SimpleDateFormat("yyyyMM"); //出力フォーマット

		/* １ヶ月後を設定 */
		Calendar cal = Calendar.getInstance();
		cal.setLenient(false);
		cal.set(yyyy, mm - 1, 1); //年月を設定
		cal.add(Calendar.MONTH, 1); //1ヶ月後を設定

		for (int i = 0; i < strDt.length; i++) { //出力月分ループ
			Date dt = cal.getTime(); //日付取得
			strDt[i] = dFm.format(dt); //フォーマット変換
			cal.add(Calendar.MONTH, -1); //１ヶ月前に設定
		}

		return strDt;
	}

	/*************************************************************************************
	 * １ヵ月の日付取得
	 * <p>
	 * 日付より、当月(末日)の日付を取得する
	 * </p>
	 * @param  yyyymmdd 文字列
	 * @return １ヵ月分の日付
	 ************************************************************************************/
	public static ArrayList<String> getDayRange(String ymd) {
		ArrayList<String> strDt = new ArrayList<String>();

		if (ymd == null) {
			return strDt;
		}

		int yyyy = Integer.parseInt(ymd.substring(0, 4));
		int mm = Integer.parseInt(ymd.substring(4, 6));
		DateFormat dFm = new SimpleDateFormat("yyyyMMdd");
		Date date = null;

		int month = mm - 1;
		Calendar calendar = Calendar.getInstance();
		calendar.setLenient(false);
		calendar.set(yyyy, month, 1);

		for (;;) {
			if (calendar.get(Calendar.MONTH) != month) {
				break;
			}
			date = calendar.getTime();
			String fmt = dFm.format(date);
			strDt.add(fmt);
			calendar.add(Calendar.DATE, 1);
		}

		return strDt;
	}

	/*************************************************************************************
	 * UNICODE変換処理
	 * <p>
	 * JISのMS932をUNICODEのものに変換する。
	 * </p>
	 * @param sSource 変換対象の文字列
	 * @return MS932のUNICODEに変換した文字列
	 ************************************************************************************/
	public static String toMS932(String sSource) {
		StringBuffer sbDest = new StringBuffer();
		char cDest = 0x0000;

		if (isEmpty(sSource)) {
			return sSource;
		}

		// 文字数分
		for (int iI = 0; iI < sSource.length(); iI++) {
			cDest = sSource.charAt(iI);
			switch (cDest) {
			case 0x301c: // ～ WAVE DASH -> FULLWIDTH TILDE
				cDest = 0xff5e;
				break;
			case 0x2016: // ∥ DOUBLE VERTICAL LINE -> PARALLEL TO
				cDest = 0x2225;
				break;
			case 0x2212: // － MINUS SIGN -> FULLWIDTH HYPHEN-MINUS
				cDest = 0xff0d;
				break;
			case 0x00a2: // ￠ CENT SIGN -> FULLWIDTH CENT SIGN
				cDest = 0xffe0;
				break;
			case 0x00a3: // ￡ POUND SIGN -> FULLWIDTH POUND SIGN
				cDest = 0xffe1;
				break;
			case 0x00ac: // ￢ NOT SIGN -> FULLWIDTH NOT SIGN
				cDest = 0xffe2;
				break;
			//case 0x005c:  // ＼ REVERSE SOLIDUS -> FULLWIDTH REVERSE SOLIDUS
			//cDest = 0xff3c;
			//break;
			}
			sbDest.append(cDest);
		}

		return sbDest.toString();
	}

	/*************************************************************************************
	 * 区切り文字列作成処理
	 * <p>
	 * 区切り文字列作成処理を行う
	 * </p>
	 * @param str 		文字列
	 * @param dmi 		区切り文字
	 * @param bytes 	区切りバイト数
	* @return cnvStr
	 ************************************************************************************/
	public static String delimitByteChar(String str, String dmi, int bytes) {
		/* 空 ?           */
		if (isEmpty(str))
			return "";

		/* 指定ﾊﾞｲﾄ以下 ? */
		if (getLengthAsHalf(str) <= bytes)
			return str;

		String cnvStr = "";
		try {
			String[] array = new String[str.length()];
			int count = 0;
			StringBuffer sbDest = new StringBuffer();

			/* 区切りﾊﾞｲﾄで配列に展開 */
			for (int i = 0; i < str.length(); i++) {
				sbDest.append(str.charAt(i));
				int len = getLengthAsHalf(sbDest.toString());
				if (len > bytes || (str.length() - 1) == i) {
					array[count] = sbDest.toString();
					sbDest.delete(0, sbDest.length());
					count++;
				}
			}

			/* 区切り文字列作成       */
			sbDest.delete(0, sbDest.length());
			for (int i = 0; i < count; i++) {
				sbDest.append(array[i]);
				if (count - 1 != i)
					sbDest.append(dmi);
			}

			cnvStr = sbDest.toString();

		} catch (Exception e) {
			return str;
		}

		return cnvStr;
	}

	/*************************************************************************************
	 * 変換処理(初期値表示)
	 * <p>
	 * 文字列に余分な空白やnull値のみの場合は0または""空文字に変換する。
	 * </p>
	 * @param  str
	 * @param  flg(true:"0" false:"")
	 * @return 無し
	 ************************************************************************************/
	public static String convString(String str, boolean flg) {
		String buf1 = AmallUtilities.convEmpty(str);
		String buf2 = AmallUtilities.trim(buf1);
		if (AmallUtilities.isEmpty(buf2)) {
			if (flg) {
				buf2 = "0";
			} else {
				buf2 = "";
			}
		}
		return buf2;
	}

	/*************************************************************************************
	 * ストリームデータ変換処理
	 * <p>
	 * 文字列データをストリームデータに変換する。
	 * </p>
	 * @param  data	文字列データ
	 * @param  encode	文字コード
	 * @return InputStream
	 ************************************************************************************/
	public static ByteArrayOutputStream getStreamData(List<String> data, String encode) {

		// ファイル出力
		ByteArrayOutputStream stream = null;
		OutputStreamWriter writer = null;

		try {
			stream = new ByteArrayOutputStream();
			writer = new OutputStreamWriter(stream, encode);

			// データ出力
			for (String str : data) {
				// 内容出力
				writer.write(str);
				// 改行コード出力
				writer.write(AmallConst.LINE_SEPARATOR);
			}
			// ファイルクローズ
			writer.close();
			return stream;
		} catch (Exception e) {
			return null;
		}
	}
}
