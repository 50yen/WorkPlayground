/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmclsBusinessBase.java
 *
 * ----------------------------------------------------
 * R0 2007/07/30 AsOne		新規作成　SASAKI
 * R1
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.cls;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.m.all.AmallException;

/*****************************************************************************************
 * Businessのスーパークラス<br>
 *****************************************************************************************/
public abstract class AmclsBusinessPcBase extends AmclsBusinessBase {

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  mapping
	 * @param  form
	 * @param  request
	 * @param  response
	 * @param  context
	 * @return 無し
	 ************************************************************************************/
	public AmclsBusinessPcBase(HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event) throws AmallException {
		super(request, response, gid, event);
	}

	// TODO 要検討 共通取得処理をこのクラスに実装するか否か

}