/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) Actmp02DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.tmp.business;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.tmp.action.Actmp02Action;
import jp.co.hitachi.a.c.tmp.bean.Actmp02DispBean;
import jp.co.hitachi.a.m.all.AmallConst.Encode;
import jp.co.hitachi.a.m.all.AmallConst.ItemMapKey;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallUtilities;
import jp.co.hitachi.a.m.dto.AmdtoCalender;
import jp.co.hitachi.a.m.dto.AmdtoDropDownList;

/*****************************************************************************************
 * Actmp02Businessクラス<br>
 *****************************************************************************************/
public class Actmp02Business extends ActmpBusinessBase {

	/** メンバ定数 */
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Actmp02DispBean";

	/**
	 * FOWARD 定義
	 */
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** ダウンロード処理 */
	public static final String FORWARD_DOWNLOAD = "DOWNLOAD";
	/** 処理02 */
	public static final String FORWARD_TEMP02 = "TEMP02";

	/**
	 * 画面項目ID
	 */
	/** TEMP01 */
	public static final String ITEM_ID_TEMP01 = "temp01";
	/** TEMP01 */
	public static final String ITEM_ID_TEMP02 = "temp02";

	/** メンバ変数 */
	/** アクションフォーム */
	private Actmp02Action m_Actmp02Form = null;
	/** 表示用画面Bean */
	private Actmp02DispBean m_Actmp02DispBean = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	public Actmp02Business(
			Actmp02Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Actmp02Business.class.getName();
		m_Actmp02Form = form;
		m_Actmp02DispBean = new Actmp02DispBean();

		setErrString(gid, m_Actmp02Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_COM_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}

			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Actmp02DispBean);

			// 権限マップ(本来はDBで定義する) ↓↓↓↓↓↓====================================
			Map<String, Map<String, String>> map = new ConcurrentHashMap<>();

			// ボタン系 ID＝itemBtn
			Map<String, String> addMap1_1 = new ConcurrentHashMap<>();
			addMap1_1.put(ItemMapKey.NAME, "検索");
			addMap1_1.put(ItemMapKey.DISP, "true");
			addMap1_1.put(ItemMapKey.ENABLE, "true");
			map.put("itemBtn01-1", addMap1_1);
			Map<String, String> addMap1_2 = new ConcurrentHashMap<>();
			addMap1_2.put(ItemMapKey.NAME, "検索");
			addMap1_2.put(ItemMapKey.DISP, "true");
			addMap1_2.put(ItemMapKey.ENABLE, "false");
			map.put("itemBtn01-2", addMap1_2);
			Map<String, String> addMap1_3 = new ConcurrentHashMap<>();
			addMap1_3.put(ItemMapKey.NAME, "検索");
			addMap1_3.put(ItemMapKey.DISP, "false");
			addMap1_3.put(ItemMapKey.ENABLE, "false");
			map.put("itemBtn01-3", addMap1_3);

			Map<String, String> addMap2_1 = new ConcurrentHashMap<>();
			addMap2_1.put(ItemMapKey.NAME, "登録");
			addMap2_1.put(ItemMapKey.DISP, "true");
			addMap2_1.put(ItemMapKey.ENABLE, "true");
			map.put("itemBtn02-1", addMap2_1);

			Map<String, String> addMap2_2 = new ConcurrentHashMap<>();
			addMap2_2.put(ItemMapKey.NAME, "登録");
			addMap2_2.put(ItemMapKey.DISP, "true");
			addMap2_2.put(ItemMapKey.ENABLE, "false");
			map.put("itemBtn02-2", addMap2_2);

			Map<String, String> addMap2_3 = new ConcurrentHashMap<>();
			addMap2_3.put(ItemMapKey.NAME, "登録");
			addMap2_3.put(ItemMapKey.DISP, "false");
			addMap2_3.put(ItemMapKey.ENABLE, "false");
			map.put("itemBtn02-3", addMap2_3);

			Map<String, String> addMap3_1 = new ConcurrentHashMap<>();
			addMap3_1.put(ItemMapKey.NAME, "更新");
			addMap3_1.put(ItemMapKey.DISP, "true");
			addMap3_1.put(ItemMapKey.ENABLE, "true");
			map.put("itemBtn03-1", addMap3_1);

			Map<String, String> addMap3_2 = new ConcurrentHashMap<>();
			addMap3_2.put(ItemMapKey.NAME, "更新");
			addMap3_2.put(ItemMapKey.DISP, "true");
			addMap3_2.put(ItemMapKey.ENABLE, "false");
			map.put("itemBtn03-2", addMap3_2);

			Map<String, String> addMap3_3 = new ConcurrentHashMap<>();
			addMap3_3.put(ItemMapKey.NAME, "更新");
			addMap3_3.put(ItemMapKey.DISP, "false");
			addMap3_3.put(ItemMapKey.ENABLE, "false");
			map.put("itemBtn03-3", addMap3_3);

			Map<String, String> addMap4_1 = new ConcurrentHashMap<>();
			addMap4_1.put(ItemMapKey.NAME, "一つ戻る");
			addMap4_1.put(ItemMapKey.IMG, "jsp/images/btn_pagerleft01.png");
			addMap4_1.put(ItemMapKey.DISP, "true");
			addMap4_1.put(ItemMapKey.ENABLE, "true");
			map.put("itemBtn04-1", addMap4_1);

			Map<String, String> addMap4_2 = new ConcurrentHashMap<>();
			addMap4_2.put(ItemMapKey.NAME, "一つ戻る");
			addMap4_2.put(ItemMapKey.IMG, "jsp/images/btn_pagerleft01.png");
			addMap4_2.put(ItemMapKey.DISP, "true");
			addMap4_2.put(ItemMapKey.ENABLE, "false");
			map.put("itemBtn04-2", addMap4_2);

			Map<String, String> addMap4_3 = new ConcurrentHashMap<>();
			addMap4_3.put(ItemMapKey.NAME, "一つ戻る");
			addMap4_3.put(ItemMapKey.IMG, "jsp/images/btn_pagerleft01.png");
			addMap4_3.put(ItemMapKey.DISP, "false");
			addMap4_3.put(ItemMapKey.ENABLE, "false");
			map.put("itemBtn04-3", addMap4_3);

			Map<String, String> addMap5_1 = new ConcurrentHashMap<>();
			addMap5_1.put(ItemMapKey.NAME, "最初に戻る");
			addMap5_1.put(ItemMapKey.IMG, "jsp/images/btn_pagerleft02.png");
			addMap5_1.put(ItemMapKey.DISP, "true");
			addMap5_1.put(ItemMapKey.ENABLE, "true");
			map.put("itemBtn05-1", addMap5_1);

			Map<String, String> addMap5_2 = new ConcurrentHashMap<>();
			addMap5_2.put(ItemMapKey.NAME, "一つ戻る");
			addMap5_2.put(ItemMapKey.IMG, "jsp/images/btn_pagerleft01.png");
			addMap5_2.put(ItemMapKey.DISP, "true");
			addMap5_2.put(ItemMapKey.ENABLE, "true");
			map.put("itemBtn05-2", addMap5_2);

			Map<String, String> addMap5_3 = new ConcurrentHashMap<>();
			addMap5_3.put(ItemMapKey.NAME, "一つ進む");
			addMap5_3.put(ItemMapKey.IMG, "jsp/images/btn_pagerright01.png");
			addMap5_3.put(ItemMapKey.DISP, "true");
			addMap5_3.put(ItemMapKey.ENABLE, "true");
			map.put("itemBtn05-3", addMap5_3);

			Map<String, String> addMap5_4 = new ConcurrentHashMap<>();
			addMap5_4.put(ItemMapKey.NAME, "最後に進む");
			addMap5_4.put(ItemMapKey.IMG, "jsp/images/btn_pagerright02.png");
			addMap5_4.put(ItemMapKey.DISP, "true");
			addMap5_4.put(ItemMapKey.ENABLE, "true");
			map.put("itemBtn05-4", addMap5_4);

			// エリア系 ID＝itemArea
			// 検索エリア
			Map<String, String> addMap6_1 = new ConcurrentHashMap<>();
			addMap6_1.put(ItemMapKey.NAME, "検索");
			addMap6_1.put(ItemMapKey.DISP, "true");
			map.put("itemArea01-1", addMap6_1);

			Map<String, String> addMap6_2 = new ConcurrentHashMap<>();
			addMap6_2.put(ItemMapKey.NAME, "検索");
			addMap6_2.put(ItemMapKey.DISP, "false");
			map.put("itemArea01-2", addMap6_2);

			// 情報表示エリア
			Map<String, String> addMap8_1 = new ConcurrentHashMap<>();
			addMap8_1.put(ItemMapKey.DISP, "true");
			map.put("itemArea02-1", addMap8_1);

			Map<String, String> addMap8_2 = new ConcurrentHashMap<>();
			addMap8_2.put(ItemMapKey.DISP, "false");
			map.put("itemArea02-2", addMap8_2);

			// カレンダーエリア
			Map<String, String> addMap9_1 = new ConcurrentHashMap<>();
			addMap9_1.put(ItemMapKey.DISP, "true");
			map.put("itemArea03-1", addMap9_1);

			Map<String, String> addMap9_2 = new ConcurrentHashMap<>();
			addMap9_2.put(ItemMapKey.DISP, "false");
			map.put("itemArea03-2", addMap9_2);

			// そのほか系 ID＝itemEtc
			// 表示件数プルダウンリスト
			Map<String, String> addMap7_1 = new ConcurrentHashMap<>();
			addMap7_1.put(ItemMapKey.NAME, "表示件数");
			addMap7_1.put(ItemMapKey.DISP, "true");
			addMap7_1.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc01-1", addMap7_1);

			Map<String, String> addMap7_2 = new ConcurrentHashMap<>();
			addMap7_2.put(ItemMapKey.NAME, "表示件数");
			addMap7_2.put(ItemMapKey.DISP, "false");
			addMap7_2.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc01-2", addMap7_2);

			// 検索エリア内部表示
			Map<String, String> addMap10_1 = new ConcurrentHashMap<>();
			addMap10_1.put(ItemMapKey.NAME, "検索内部表示");
			addMap10_1.put(ItemMapKey.DISP, "true");
			map.put("itemArea04-1", addMap10_1);

			// 検索エリア内部顧客
			Map<String, String> addMap11_1 = new ConcurrentHashMap<>();
			addMap11_1.put(ItemMapKey.NAME, "顧客名");
			addMap11_1.put(ItemMapKey.DISP, "true");
			addMap11_1.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc02-1", addMap11_1);

			Map<String, String> addMap11_2 = new ConcurrentHashMap<>();
			addMap11_2.put(ItemMapKey.NAME, "顧客検索");
			addMap11_2.put(ItemMapKey.DISP, "true");
			addMap11_2.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc02-2", addMap11_2);

			Map<String, String> addMap11_3 = new ConcurrentHashMap<>();
			addMap11_3.put(ItemMapKey.NAME, "顧客名");
			addMap11_3.put(ItemMapKey.DISP, "true");
			addMap11_3.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc02-3", addMap11_3);

			Map<String, String> addMap11_4 = new ConcurrentHashMap<>();
			addMap11_4.put(ItemMapKey.NAME, "顧客検索");
			addMap11_4.put(ItemMapKey.DISP, "true");
			addMap11_4.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc02-4", addMap11_4);

			Map<String, String> addMap11_5 = new ConcurrentHashMap<>();
			addMap11_5.put(ItemMapKey.NAME, "顧客名");
			addMap11_5.put(ItemMapKey.DISP, "false");
			addMap11_5.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc02-5", addMap11_5);

			Map<String, String> addMap11_6 = new ConcurrentHashMap<>();
			addMap11_6.put(ItemMapKey.NAME, "顧客検索");
			addMap11_6.put(ItemMapKey.DISP, "false");
			addMap11_6.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc02-6", addMap11_6);

			// 検索エリア内部店舗
			Map<String, String> addMap12_1 = new ConcurrentHashMap<>();
			addMap12_1.put(ItemMapKey.NAME, "店舗名");
			addMap12_1.put(ItemMapKey.DISP, "true");
			addMap12_1.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc03-1", addMap12_1);

			Map<String, String> addMap12_2 = new ConcurrentHashMap<>();
			addMap12_2.put(ItemMapKey.NAME, "店舗検索");
			addMap12_2.put(ItemMapKey.DISP, "true");
			addMap12_2.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc03-2", addMap12_2);

			Map<String, String> addMap12_3 = new ConcurrentHashMap<>();
			addMap12_3.put(ItemMapKey.NAME, "店舗名");
			addMap12_3.put(ItemMapKey.DISP, "true");
			addMap12_3.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc03-3", addMap12_3);

			Map<String, String> addMap12_4 = new ConcurrentHashMap<>();
			addMap12_4.put(ItemMapKey.NAME, "店舗検索");
			addMap12_4.put(ItemMapKey.DISP, "true");
			addMap12_4.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc03-4", addMap12_4);

			Map<String, String> addMap12_5 = new ConcurrentHashMap<>();
			addMap12_5.put(ItemMapKey.NAME, "店舗名");
			addMap12_5.put(ItemMapKey.DISP, "false");
			addMap12_5.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc03-5", addMap12_5);

			Map<String, String> addMap12_6 = new ConcurrentHashMap<>();
			addMap12_6.put(ItemMapKey.NAME, "店舗検索");
			addMap12_6.put(ItemMapKey.DISP, "false");
			addMap12_6.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc03-6", addMap12_6);

			// 検索エリア内部ユーザー
			Map<String, String> addMap13_1 = new ConcurrentHashMap<>();
			addMap13_1.put(ItemMapKey.NAME, "ユーザ");
			addMap13_1.put(ItemMapKey.DISP, "true");
			addMap13_1.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc04-1", addMap13_1);

			Map<String, String> addMap13_2 = new ConcurrentHashMap<>();
			addMap13_2.put(ItemMapKey.NAME, "ユーザ検索");
			addMap13_2.put(ItemMapKey.DISP, "true");
			addMap13_2.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc04-2", addMap13_2);

			Map<String, String> addMap13_3 = new ConcurrentHashMap<>();
			addMap13_3.put(ItemMapKey.NAME, "ユーザ");
			addMap13_3.put(ItemMapKey.DISP, "true");
			addMap13_3.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc04-3", addMap13_3);

			Map<String, String> addMap13_4 = new ConcurrentHashMap<>();
			addMap13_4.put(ItemMapKey.NAME, "ユーザ検索");
			addMap13_4.put(ItemMapKey.DISP, "true");
			addMap13_4.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc04-4", addMap13_4);

			Map<String, String> addMap13_5 = new ConcurrentHashMap<>();
			addMap13_5.put(ItemMapKey.NAME, "ユーザ");
			addMap13_5.put(ItemMapKey.DISP, "false");
			addMap13_5.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc04-5", addMap13_5);

			Map<String, String> addMap13_6 = new ConcurrentHashMap<>();
			addMap13_6.put(ItemMapKey.NAME, "ユーザ検索");
			addMap13_6.put(ItemMapKey.DISP, "false");
			addMap13_6.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc04-6", addMap13_6);

			// 回収日From TO
			Map<String, String> addMap14_1 = new ConcurrentHashMap<>();
			addMap14_1.put(ItemMapKey.NAME, "回収FROM");
			addMap14_1.put(ItemMapKey.DISP, "true");
			addMap14_1.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc05-1", addMap14_1);

			Map<String, String> addMap14_2 = new ConcurrentHashMap<>();
			addMap14_2.put(ItemMapKey.NAME, "回収TO");
			addMap14_2.put(ItemMapKey.DISP, "true");
			addMap14_2.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc05-2", addMap14_2);

			Map<String, String> addMap14_3 = new ConcurrentHashMap<>();
			addMap14_3.put(ItemMapKey.NAME, "回収FROM");
			addMap14_3.put(ItemMapKey.DISP, "true");
			addMap14_3.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc05-3", addMap14_3);

			Map<String, String> addMap14_4 = new ConcurrentHashMap<>();
			addMap14_4.put(ItemMapKey.NAME, "回収TO");
			addMap14_4.put(ItemMapKey.DISP, "true");
			addMap14_4.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc05-4", addMap14_4);

			Map<String, String> addMap14_5 = new ConcurrentHashMap<>();
			addMap14_5.put(ItemMapKey.NAME, "回収FROM");
			addMap14_5.put(ItemMapKey.DISP, "false");
			addMap14_5.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc05-5", addMap14_5);

			Map<String, String> addMap14_6 = new ConcurrentHashMap<>();
			addMap14_6.put(ItemMapKey.NAME, "回収TO");
			addMap14_6.put(ItemMapKey.DISP, "false");
			addMap14_6.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc05-6", addMap14_6);

			// プルダウンリスト
			Map<String, String> addMap15_1 = new ConcurrentHashMap<>();
			addMap15_1.put(ItemMapKey.NAME, "分類");
			addMap15_1.put(ItemMapKey.DISP, "true");
			addMap15_1.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc06-1", addMap15_1);

			// プルダウンリスト
			Map<String, String> addMap15_2 = new ConcurrentHashMap<>();
			addMap15_2.put(ItemMapKey.NAME, "分類");
			addMap15_2.put(ItemMapKey.DISP, "true");
			addMap15_2.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc06-2", addMap15_2);

			// プルダウンリスト
			Map<String, String> addMap15_3 = new ConcurrentHashMap<>();
			addMap15_3.put(ItemMapKey.NAME, "分類");
			addMap15_3.put(ItemMapKey.DISP, "false");
			addMap15_3.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc06-3", addMap15_3);



			// 入力エリア青
			Map<String, String> reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "顧客名");
			reUseMap.put(ItemMapKey.DISP, "true");
			map.put("itemEtc07-1", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗名");
			reUseMap.put(ItemMapKey.DISP, "true");
			map.put("itemEtc07-2", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "回収日");
			reUseMap.put(ItemMapKey.DISP, "true");
			map.put("itemEtc07-3", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗枝番<br />(お客様番号)");
			reUseMap.put(ItemMapKey.DISP, "true");
			map.put("itemEtc07-4", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "誤差<br />コメント");
			reUseMap.put(ItemMapKey.DISP, "true");
			map.put("itemEtc07-5", reUseMap);



			// 入力エリア青一部非表示
			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "顧客名");
			reUseMap.put(ItemMapKey.DISP, "false");
			map.put("itemEtc08-1", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗名");
			reUseMap.put(ItemMapKey.DISP, "true");
			map.put("itemEtc08-2", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "回収日");
			reUseMap.put(ItemMapKey.DISP, "true");
			map.put("itemEtc08-3", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗枝番<br />(お客様番号)");
			reUseMap.put(ItemMapKey.DISP, "true");
			map.put("itemEtc08-4", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "誤差<br />コメント");
			reUseMap.put(ItemMapKey.DISP, "true");
			map.put("itemEtc08-5", reUseMap);

			// 入力エリアテキストボックス
			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "顧客名");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc09-1", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗名");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc09-2", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "売上日");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc09-3", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗枝番<br />(お客様番号)");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc09-4", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "金種票<br />店舗名");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc09-5", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "顧客検索");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc09-6", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗検索");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc09-7", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "枝番検索");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc09-8", reUseMap);


			// 入力エリアテキストボックス
			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "顧客名");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc10-1", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗名");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc10-2", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "売上日");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc10-3", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗枝番<br />(お客様番号)");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc10-4", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "金種票<br />店舗名");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc10-5", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "顧客検索");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc10-6", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗検索");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc10-7", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "枝番検索");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc10-8", reUseMap);


			// 入力エリアテキストボックス
			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "顧客名");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc11-1", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗名");
			reUseMap.put(ItemMapKey.DISP, "false");
			reUseMap.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc11-2", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "売上日");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc11-3", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗枝番<br />(お客様番号)");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc11-4", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "金種票<br />店舗名");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc11-5", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "顧客検索");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc11-6", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "店舗検索");
			reUseMap.put(ItemMapKey.DISP, "false");
			reUseMap.put(ItemMapKey.ENABLE, "false");
			map.put("itemEtc11-7", reUseMap);

			reUseMap = new ConcurrentHashMap<>();
			reUseMap.put(ItemMapKey.NAME, "枝番検索");
			reUseMap.put(ItemMapKey.DISP, "true");
			reUseMap.put(ItemMapKey.ENABLE, "true");
			map.put("itemEtc11-8", reUseMap);

			// 権限マップ(本来はDBで定義する) ↑↑↑↑↑↑↑====================================

			m_Actmp02DispBean.setOwdRole(map);
			// DB接続
			m_DbAccess = new AmallDbAccess(m_Actmp02Form.getM_systemKind());
			m_DbAccess.initDB();

			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_DOWNLOAD.equals(m_Event)) {
				// ダウンロード処理の場合
				forwardStr = download();
			} else if (FORWARD_TEMP02.equals(m_Event)) {

			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_COM_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_COM_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Actmp02DispBean);
		}
	}

	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		// エラーメッセージの設定
		setMessageInfo(m_Actmp02DispBean, "Mapw001");

		// 情報表示エリアの表示文字1
		m_Actmp02DispBean.setDivDispData1("情報表示エリア1　※センターの更新状況などを表示します。");

		// 情報表示エリアの表示文字2
		m_Actmp02DispBean.setDivDispData2("情報表示エリア2　※センターの更新状況などを表示します。");

		// カレンダーデータの作成
		List<List<AmdtoCalender>> calender = AmallUtilities.getCalenderDispData("201807", null);

		// 内容データの設定
		AmallUtilities.setCalenderContentsData("20180710", AmdtoCalender.CON_TYPE_ERROR, "回収実績有", "誤差発生", calender);
		AmallUtilities.setCalenderContentsData("20180726", AmdtoCalender.CON_TYPE_ON, "回収実績有", "", calender);

		m_Actmp02DispBean.setCalDataList(calender);

		// ドロップダウンリストの中身作成
		List<AmdtoDropDownList> list = new ArrayList<>();

		AmdtoDropDownList dto = new AmdtoDropDownList();

		dto.setId("10");
		dto.setName("ASS管理者");
		list.add(dto);

		dto = new AmdtoDropDownList();
		dto.setId("20");
		dto.setName("ASS管制");
		list.add(dto);

		dto = new AmdtoDropDownList();
		dto.setId("30");
		dto.setName("ASS企業担当");
		list.add(dto);

		m_Actmp02DispBean.setDownlist(list);

		// 入力エリア青
		m_Actmp02DispBean.setInputLbl1("（株）アサヒ商事");
		m_Actmp02DispBean.setInputLbl2("海岸店");
		m_Actmp02DispBean.setInputLbl3("20181年7月20日");
		m_Actmp02DispBean.setInputLbl4("123-55-66");
		m_Actmp02DispBean.setInputLbl5("鑑定券(1000円) あいうえおかきくけこ");






		if (m_DbAccess != null) {
			m_DbAccess.exitDB();
		}
		return FORWARD_DISP;
	}

	/*************************************************************************************
	 * ダウンロード処理
	 * <p>
	 * ダウンロード処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String download() throws AmallException {

		// ファイルデータ作成
		List<String> data = new ArrayList<>();
		data.add("1行目");
		data.add("2行目,3行目");

		// ファイルデータ出力
		m_Actmp02Form.setDownloadFileData(data, "download.csv", Encode.SHIFT_JIS);

		return FORWARD_DOWNLOAD;
	}

}