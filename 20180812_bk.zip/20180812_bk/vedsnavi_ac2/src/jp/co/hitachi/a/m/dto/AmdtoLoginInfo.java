/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoLoginInfo.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * ログイン情報DTO <br>
 *****************************************************************************************/
public class AmdtoLoginInfo extends AmclsDtoBase {

	/** メンバ変数 */
	/**
	 * ユーザーマスタ
	 */
	/** ユーザーCD(ログインID) */
	private String m_User_Cd = null;
	/** ユーザー名 */
	private String m_User_Nm = null;
	/** 顧客CD */
	private String m_Customer_Cd = null;
	/** 顧客グループCD */
	private String m_Customer_Grp_Cd = null;
	/** 店舗CD */
	private String m_Shop_Cd = null;
	/** 店舗グループCD */
	private String m_Shop_Grp_Cd = null;

	/**
	 * ユーザー認証マスタ
	 */
	/** パスワード */
	private String m_Password = null;
	/** パスワードリセット */
	private String m_Password_Flg = null;
	/** パスワード変更日時 */
	private String m_Password_Chg_Time = null;
	/** 最終ログイン日時 */
	private String m_Last_Access_Date = null;
	/** 最終ログイン失敗日時 */
	private String m_Access_Error_Time = null;
	/** ログイン失敗回数 */
	private String m_Access_Error_Count = null;
	/** ロックアウト */
	private String m_LoginLock = null;
	/** ロックアウト日時 */
	private String m_LoginLock_Time = null;

	/**
	 * ユーザー管理マスタ
	 */
	/** 承認権限 */
	private String m_Approval_Auth_Flg= null;
	/** 権限グループCD */
	private String m_Auth_Grp_Cd= null;


	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/

	public AmdtoLoginInfo() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/

	public void clear() {
		m_User_Cd = null;
		m_User_Nm = "";
		m_Customer_Cd = null;
		m_Customer_Grp_Cd = null;
		m_Shop_Cd = null;
		m_Shop_Grp_Cd = null;
		m_Password = null;
		m_Password_Flg = null;
		m_Password_Chg_Time = null;
		m_Last_Access_Date = null;
		m_Access_Error_Time = null;
		m_Access_Error_Count = null;
		m_LoginLock = null;
		m_LoginLock_Time = null;
		m_Approval_Auth_Flg = null;
		m_Auth_Grp_Cd = null;
	}

	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getM_User_Cd() {
		return m_User_Cd;
	}

	public void setM_User_Cd(String m_User_Cd) {
		this.m_User_Cd = m_User_Cd;
	}

	public String getM_User_Nm() {
		return m_User_Nm;
	}

	public void setM_User_Nm(String m_User_Nm) {
		this.m_User_Nm = m_User_Nm;
	}

	public String getM_Customer_Cd() {
		return m_Customer_Cd;
	}

	public void setM_Customer_Cd(String m_Customer_Cd) {
		this.m_Customer_Cd = m_Customer_Cd;
	}

	public String getM_Customer_Grp_Cd() {
		return m_Customer_Grp_Cd;
	}

	public void setM_Customer_Grp_Cd(String m_Customer_Grp_Cd) {
		this.m_Customer_Grp_Cd = m_Customer_Grp_Cd;
	}

	public String getM_Shop_Cd() {
		return m_Shop_Cd;
	}

	public void setM_Shop_Cd(String m_Shop_Cd) {
		this.m_Shop_Cd = m_Shop_Cd;
	}

	public String getM_Shop_Grp_Cd() {
		return m_Shop_Grp_Cd;
	}

	public void setM_Shop_Grp_Cd(String m_Shop_Grp_Cd) {
		this.m_Shop_Grp_Cd = m_Shop_Grp_Cd;
	}

	public String getM_Password() {
		return m_Password;
	}

	public void setM_Password(String m_Password) {
		this.m_Password = m_Password;
	}

	public String getM_Password_Flg() {
		return m_Password_Flg;
	}

	public void setM_Password_Flg(String m_Password_Flg) {
		this.m_Password_Flg = m_Password_Flg;
	}

	public String getM_Password_Chg_Time() {
		return m_Password_Chg_Time;
	}

	public void setM_Password_Chg_Time(String m_Password_Chg_Time) {
		this.m_Password_Chg_Time = m_Password_Chg_Time;
	}

	public String getM_Last_Access_Date() {
		return m_Last_Access_Date;
	}

	public void setM_Last_Access_Date(String m_Last_Access_Date) {
		this.m_Last_Access_Date = m_Last_Access_Date;
	}

	public String getM_Access_Error_Time() {
		return m_Access_Error_Time;
	}

	public void setM_Access_Error_Time(String m_Access_Error_Time) {
		this.m_Access_Error_Time = m_Access_Error_Time;
	}

	public String getM_Access_Error_Count() {
		return m_Access_Error_Count;
	}

	public void setM_Access_Error_Count(String m_Access_Error_Count) {
		this.m_Access_Error_Count = m_Access_Error_Count;
	}

	public String getM_LoginLock() {
		return m_LoginLock;
	}

	public void setM_LoginLock(String m_LoginLock) {
		this.m_LoginLock = m_LoginLock;
	}

	public String getM_LoginLock_Time() {
		return m_LoginLock_Time;
	}

	public void setM_LoginLock_Time(String m_LoginLock_Time) {
		this.m_LoginLock_Time = m_LoginLock_Time;
	}

	public String getM_Approval_Auth_Flg() {
		return m_Approval_Auth_Flg;
	}

	public void setM_Approval_Auth_Flg(String m_Approval_Auth_Flg) {
		this.m_Approval_Auth_Flg = m_Approval_Auth_Flg;
	}

	public String getM_Auth_Grp_Cd() {
		return m_Auth_Grp_Cd;
	}

	public void setM_Auth_Grp_Cd(String m_Auth_Grp_Cd) {
		this.m_Auth_Grp_Cd = m_Auth_Grp_Cd;
	}

}
