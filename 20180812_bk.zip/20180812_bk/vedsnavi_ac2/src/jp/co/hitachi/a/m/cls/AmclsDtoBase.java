/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmclsDtoBase.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.cls;

import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;

import jp.co.hitachi.a.m.all.AmallException;

/*****************************************************************************************
 * DTOのスーパークラス<br>
 *****************************************************************************************/
public abstract class AmclsDtoBase implements java.io.Serializable {
	//必ずオーバライドすること
	/*************************************************************************************
	 * クリアメソッド
	 * <p>
	 * クリア処理を行う
	 * </p>
	 * @param	無し
	 * @return 	無し
	 ************************************************************************************/
	public abstract void clear() throws AmallException;

	/*************************************************************************************
	 * Dtoに対するコピー処理
	 * <p>
	 * 引数で渡されたBeanと対応するメンバデータをコピーする
	 * コピー:Bean(引数) ⇒ Dto
	 * </p>
	 * @param  copySource
	 * @return 無し
	 ************************************************************************************/
	public void copy2me(Object copySource) {
		try {
			BeanUtils.copyProperties(this, copySource);
		} catch (Exception e) {
		}
	}

	/*************************************************************************************
	 * Dtoからのコピー処理
	 * <p>
	 * 引数で渡されたBeanと対応するメンバデータをコピーする
	 * コピー:Dto ⇒ Bean(引数)
	 * </p>
	 * @param  copyDest
	 * @return 無し
	 ************************************************************************************/
	public void copy4you(Object copyDest) {
		try {
			BeanUtils.copyProperties(copyDest, this);
		} catch (Exception e) {
		}
	}

	/*************************************************************************************
	 * arrayListClear処理
	 * <p>
	 * arrayListClear処理を行う
	 * </p>
	 * @param	object
	 * @return 	無し
	 ************************************************************************************/
	public void arrayListClear(ArrayList object) throws AmallException {
		if (object != null) {
			for (int i = 0; i < object.size(); ++i) {
				Map getData = (Map) object.get(i);
				getData.clear();
				getData = null;
			}
			object.clear();
			object = null;
		}
	}

}
