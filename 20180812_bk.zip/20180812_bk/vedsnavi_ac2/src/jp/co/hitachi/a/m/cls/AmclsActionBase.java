/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmclsActionBase.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.cls;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.dispatcher.SessionMap;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.apache.struts2.interceptor.SessionAware;

import com.opensymphony.xwork2.ActionSupport;

import jp.co.hitachi.a.m.all.AmallConst.ParamKey;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;
import jp.co.hitachi.a.m.all.AmallSystemErrLog;
import jp.co.hitachi.a.m.all.AmallUtilities;

/*****************************************************************************************
 * Actionのスーパークラス<br>
 *****************************************************************************************/
public abstract class AmclsActionBase extends ActionSupport
		implements SessionAware, ServletRequestAware, ServletResponseAware {

	/** メンバ変数 */
	/** セッション */
	private Map<String, Object> session;
	/** リクエスト */
	protected HttpServletRequest request;
	/** レスポンス */
	protected HttpServletResponse response;

	/** トークン */
	private String token;
	/** トランザクション */
	private String trans;
	/** 画面ID */
	private String gid = null;
	/** イベントID */
	private String event = null;
	/** 共通ユーザー例外 */
	private String m_globalError = "";
	/** システム種別 */
	private Integer m_systemKind = 0;

	/** ファイルダウンロード用InputStream */
	private InputStream inputStream;
	/** ダウンロードファイル名 */
	private String fileName;
	/** ダウンロードファイルサイズ */
	private long contentLength;

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * セッションのSetterメソッド
	 * </p>
	 * @param  セッション
	 * @return 無し
	 ************************************************************************************/
	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * リクエストのSetterメソッド
	 * </p>
	 * @param  リクエスト
	 * @return 無し
	 ************************************************************************************/
	public void setServletRequest(HttpServletRequest httpServletRequest) {
		this.request = httpServletRequest;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * レスポンスのSetterメソッド
	 * </p>
	 * @param  レスポンス
	 * @return 無し
	 ************************************************************************************/
	public void setServletResponse(HttpServletResponse httpServletResponse) {
		this.response = httpServletResponse;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * トークンのSetterメソッド
	 * </p>
	 * @param  トークン
	 * @return 無し
	 ************************************************************************************/
	public void setToken(String token) {
		this.token = token;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * トークンのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return トークン
	 ************************************************************************************/
	public String getToken() {
		return token;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * トランザクションのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return トランザクション
	 ************************************************************************************/
	public String getTrans() {
		return trans;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * トランザクションのSetterメソッド
	 * </p>
	 * @param  トランザクション
	 * @return 無し
	 ************************************************************************************/
	public void setTrans(String trans) {
		if ("V".equals(trans)) {
			this.trans = "Verification";
		} else {
			this.trans = trans;
		}
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * 画面IDのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return 画面ID
	 ************************************************************************************/
	public String getGid() {
		if (gid == null) {
			gid = "";
		}
		return gid;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * 画面IDのSetterメソッド
	 * </p>
	 * @param  画面ID
	 * @return 無し
	 ************************************************************************************/
	public void setGid(String gid) {
		this.gid = gid;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * イベントIDのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return イベントID
	 ************************************************************************************/
	public String getEvent() {
		if (event == null) {
			event = "";
		}
		return event;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * イベントIDのSetterメソッド
	 * </p>
	 * @param  イベントID
	 * @return 無し
	 ************************************************************************************/
	public void setEvent(String event) {
		this.event = event;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * ストリームのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return ストリーム
	 ************************************************************************************/
	public InputStream getInputStream() {
		return inputStream;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * ストリームのSetterメソッド
	 * </p>
	 * @param  ストリーム
	 * @return 無し
	 ************************************************************************************/
	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * ファイル名のGetterメソッド
	 * </p>
	 * @param  無し
	 * @return ファイル名
	 ************************************************************************************/
	public String getFileName() {
		return fileName;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * ファイル名のSetterメソッド
	 * </p>
	 * @param  ファイル名
	 * @return 無し
	 ************************************************************************************/
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/*************************************************************************************
	 * Getterメソッド
	 * <p>
	 * ファイルサイズのGetterメソッド
	 * </p>
	 * @param  無し
	 * @return ファイルサイズ
	 ************************************************************************************/
	public long getContentLength() {
		return contentLength;
	}

	/*************************************************************************************
	 * Setterメソッド
	 * <p>
	 * ファイルサイズのSetterメソッド
	 * </p>
	 * @param  ファイルサイズ
	 * @return 無し
	 ************************************************************************************/
	public void setContentLength(long contentLength) {
		this.contentLength = contentLength;
	}

	/*************************************************************************************
	 * グローバルエラー名セット
	 * <p>
	 * グローバルエラー名をセットする
	 * </p>
	 * @param  グローバルエラー名 m_globalError
	 * @return 無し
	 ************************************************************************************/
	public void setM_globalError(String error) {
		m_globalError = error;
	}

	//必ずオーバライドすること
	/*************************************************************************************
	 * execute処理呼び出し(抽象メソッド)
	 * <p>
	 * execute処理を呼び出すDAOを定義する。
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public abstract String callexecute() throws AmallException;

	/*************************************************************************************
	 * execute処理
	 * <p>
	 * execute実行
	 * </p>
	 * @param  mapping  ActionMapping
	 * @param  form     ActionForm
	 * @param  request  HttpServletRequest
	 * @param  response HttpServletResponse
	 * @return ActionForward
	 ************************************************************************************/
	public String execute() throws Exception {
		String forwardName = m_globalError;
		try {
			if (isSessionTimeOut(request)) {
				if (isCookie(request)) {
					int ret = validatorToken(request);
					if (ret == 0) {
						forwardName = callexecute();
					} else {
						AmallException e = new AmallException();
						e.setM_GTime(new Date());
						e.addException("AmclsActionBase", "validatorToken() " + "return=" + ret,
								AmallMessageConst.MSG_COM_SCREEN_MOVE_ACCESS_ERROR);
						// システムエラーログ出力
						AmallSystemErrLog.createSystemErrLog(getM_systemKind(request), e, request);
					}
				} else {
					AmallException e = new AmallException();
					e.setM_GTime(new Date());
					e.addException("AmclsActionBase", "isCookie()", AmallMessageConst.MSG_COM_INVALID_COOKIE_ERROR);
					// システムエラーログ出力
					AmallSystemErrLog.createSystemErrLog(getM_systemKind(request), e, request);
				}
			} else {
				AmallException e = new AmallException();
				e.setM_GTime(new Date());
				e.addException("AmclsActionBase", "isSessionTimeOut()",
						AmallMessageConst.MSG_COM_SESSION_TIMEOUT_ERROR);
				// システムエラーログ出力
				AmallSystemErrLog.createSystemErrLog(getM_systemKind(request), e, request);
			}
		} catch (AmallException e) {
			// システムエラーログ出力
			AmallSystemErrLog.createSystemErrLog(getM_systemKind(request), e, request);
		}
		return forwardName;
	}

	/*************************************************************************************
	 * クッキー有効判定処理
	 * <p>
	 * クッキーが有効かをチェックする
	 * </p>
	 * @param  request HttpServletRequest
	 * @return 判定結果
	 *          True  : OK
	 *          False : NG
	 ************************************************************************************/
	protected boolean isCookie(HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		boolean rc = false;
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				/* 該当 cookie ? */
				if (cookies[i].getName().equals(ParamKey.ASS_COOKIE_ID)) {
					rc = true;
					break;
				}
			}
		}
		return rc;
	}

	/*************************************************************************************
	 * セッションタイムアウトチェック処理
	 * <p>
	 * セッションタイムアウトをチェックする
	 * </p>
	 * @param  request HttpServletRequest
	 * @return 判定結果
	 *          True  : OK
	 *          False : NG
	 ************************************************************************************/
	protected boolean isSessionTimeOut(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session == null) {
			return false;
		} else {
			Object obj = session.getAttribute(ParamKey.DTO);
			if (obj == null) {
				return false;
			}
		}
		return true;
	}

	/*************************************************************************************
	 * クッキー生成処理
	 * <p>
	 * クッキーを生成する
	 * </p>
	 * @param  req HttpServletRequest
	 * @param  res HttpServletResponse
	 * @return 無し
	 ************************************************************************************/
	protected void createCookie(HttpServletRequest req, HttpServletResponse res) {
		Cookie cookie = new Cookie(ParamKey.ASS_COOKIE_ID, getSessionID(req));
		cookie.setMaxAge(60 * 60 * 24 * 1);
		res.addCookie(cookie);
		return;
	}

	/*************************************************************************************
	 * クッキーＩＤ取得
	 * <p>
	 * クッキーＩＤを取得する
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	protected String getSessionID(HttpServletRequest req) {
		String id = "";
		HttpSession session = req.getSession(false);
		if (session != null) {
			id = session.getId();
		}
		return id;
	}

	/*************************************************************************************
	 * セッション(DTO管理データ)作成
	 * <p>
	 * セッション(DTO管理データ)を作成する
	 * </p>
	 * @param  str キー
	 * @return 無し
	 ************************************************************************************/
	protected void createSession(HttpServletRequest request) {
		Hashtable<String, Object> dto = null;

		if (session == null || session.isEmpty()) {
			HttpSession httpSession = request.getSession();
			this.session.put("id", httpSession.getId());
		}
		session.remove(ParamKey.DTO);
		session.remove(ParamKey.TRANS_TOKEN);
		dto = new Hashtable<String, Object>();
		session.put(ParamKey.DTO, dto);
	}

	/*************************************************************************************
	 * セッション無効化
	 * <p>
	 * セッションを無効化し、バインドされていたすべてのオブジェクトをアンバインド
	 * </p>
	 * @param  str キー
	 * @return 無し
	 ************************************************************************************/
	protected void invalidateSession(HttpServletRequest request) {

		if (session != null) {
			((SessionMap<String, Object>) session).invalidate();
		}
	}

	/*************************************************************************************
	 * セッション再作成
	 * <p>
	 * セッションを再作成する
	 * </p>
	 * @param  request HttpServletRequest
	 * @return 無し
	 ************************************************************************************/
	protected void reCreateSession(HttpServletRequest request) {
		if (session != null) {
			String sToken = (String) session.get("struts.tokens.token");
			((SessionMap<String, Object>) session).invalidate();
			HttpSession httpSession = request.getSession();
			session.put("id", httpSession.getId());
			session.put("struts.tokens.token", sToken);
		}
	}

	/*************************************************************************************
	 * トークン検証処理
	 * <p>
	 * トークンを検証する
	 * </p>
	 * @param  request HttpServletRequest
	 * @return 無し
	 ************************************************************************************/
	protected int validatorToken(HttpServletRequest request) {
		try {
			String tVal = getTrans();
			HttpSession session = request.getSession(false);
			if (session == null) {
				return -1;
			}

			String sToken = (String) session.getAttribute("struts.tokens.token");
			String sValToken = (String) session.getAttribute(ParamKey.TRANS_TOKEN);

			if (!AmallUtilities.isEmpty(tVal)) {
				/* ActionからActionの遷移  */
				if (tVal.equals("Verification")) {
					if (sToken != null && sValToken != null) {
						if (sToken.equals(sValToken)) {
						} else {
							return -2;
						}
					} else {
						return -3;
					}
				} else if (tVal.equals("Initialization")) {
				} else {
					return -4;
				}
			} else {
				/* JSPからの遷移          */
				if (sToken != null && sToken.equals(getToken())) {
				} else {
					return -5;
				}
			}

			sToken = (String) session.getAttribute("struts.tokens.token");
			session.setAttribute(ParamKey.TRANS_TOKEN, sToken);

		} catch (Exception e) {
			return -6;
		}

		return 0;
	}

	/*************************************************************************************
	 * トークン作成処理
	 * <p>
	 * トークン作成する
	 * </p>
	 * @param  request HttpServletRequest
	 * @return 無し
	 ************************************************************************************/
	protected void createToken(HttpServletRequest request) throws AmallException {
		String methodName = "createToken()";
		try {
			HttpSession session = request.getSession(false);

			String sToken = (String) session.getAttribute("struts.tokens.token");

			session.setAttribute(ParamKey.TRANS_TOKEN, sToken);
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.setM_GTime(new Date());
			ee.addException("AmclsActionBase", methodName, AmallMessageConst.MSG_COM_TOKEN_CREATE_ERROR);
		}
		return;
	}

	/*************************************************************************************
	 * 画面ID取得
	 * <p>
	 * 画面IDを取得する
	 * </p>
	 * @param  request HttpServletRequest
	 * @return 無し
	 ************************************************************************************/
	protected String getGID(HttpServletRequest request) {
		String gid = request.getParameter(ParamKey.GID);
		if (gid == null) {
			gid = "";
		}
		return gid;
	}

	/*************************************************************************************
	 * 画面イベント取得
	 * <p>
	 * 画面イベントを取得する
	 * </p>
	 * @param  request HttpServletRequest
	 * @return 無し
	 ************************************************************************************/
	protected String getEVENT(HttpServletRequest request) {
		String event = request.getParameter(ParamKey.EVENT);
		if (event == null) {
			event = "";
		}
		return event;
	}

	/*************************************************************************************
	 * システム種類セット
	 * <p>
	 * システム種類をセットする
	 * </p>
	 * @param  システム種類 kind
	 * @return 無し
	 ************************************************************************************/
	public void setM_systemKind(HttpServletRequest req, int kind) {
		try {
			m_systemKind = kind;
			/* セッションインスタンス取得 */
			HttpSession session = req.getSession(false);
			/* セッションに記憶 */
			if (session != null)
				session.setAttribute(ParamKey.SYSTEM_KIND, m_systemKind);
		} catch (Exception e) {
			// NOP
		}
	}

	/*************************************************************************************
	 * システム種類取得(セッション取得)
	 * <p>
	 * システム種類をセッションから取得する
	 * </p>
	 * @param  リクエスト req
	 * @return m_systemKind
	 ************************************************************************************/
	public int getM_systemKind(HttpServletRequest req) {
		m_systemKind = 0;
		try {
			/* セッションインスタンス取得 */
			HttpSession session = req.getSession(false);
			/* セッションから取得 */
			if (session != null)
				m_systemKind = (Integer) session.getAttribute(ParamKey.SYSTEM_KIND);
		} catch (Exception e) {
			// NOP
		}
		if (m_systemKind == null)
			m_systemKind = 0;
		return m_systemKind;
	}

	/*************************************************************************************
	 * システム種類取得
	 * <p>
	 * システム種類を取得する
	 * </p>
	 * @param  なし
	 * @return m_systemKind
	 ************************************************************************************/
	public int getM_systemKind() {
		return m_systemKind;
	}

	/*************************************************************************************
	 * ダウンロードファイル作成処理
	 * <p>
	 * ダウンロードさせるファイルをレスポンスに設定する
	 * </p>
	 * @param  data		ファイル内容データ
	 * @param  fileName	ファイル名
	 * @param  encode		文字コード
	 * @return なし
	 ************************************************************************************/
	public void setDownloadFileData(List<String> data, String fileName,String encode) {

		String methodName = "setDownloadFileData";

		try {
			// ストリームデータの作成
			ByteArrayOutputStream stream = AmallUtilities.getStreamData(data, encode);

			// ブラウザへのレスポンス処理
			// ファイル名をセット
			this.setFileName(fileName);
			// ファイルサイズをフィールドに格納
			this.setContentLength(stream.toByteArray().length);
			// ファイルストリームをフィールドに格納
			this.setInputStream(new ByteArrayInputStream(stream.toByteArray()));

			return;
		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.setM_GTime(new Date());
			ee.addException("AmclsActionBase", methodName, AmallMessageConst.MSG_COM_CREATE_FILE_STREAM_ERROR);
			// システムエラーログ出力
			AmallSystemErrLog.createSystemErrLog(getM_systemKind(request), ee, request);
		}
	}
}
