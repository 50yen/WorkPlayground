/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmallAccessLog.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */

package jp.co.hitachi.a.m.all;

import java.sql.Date;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import jp.co.hitachi.a.m.all.AmallConst.LogTable;
import jp.co.hitachi.a.m.all.AmallConst.LogType;
import jp.co.hitachi.a.m.all.AmallConst.LoggerName;
import jp.co.hitachi.a.m.all.AmallConst.SystemType;

/**
 * AmallAccessLogクラス
 */
public class AmallAccessLog {

	/**
	 * log4j Loggerオブジェクト
	 */
	static Logger logger = null;

	/** メンバ変数 */
	/** システム種別 */
	private int systemKind = SystemType.CUSTOMER;
	/** ログ出力先テーブル */
	private String logTable = LogTable.CUSTOMER;
	/** ログインID */
	private String loginId = "";
	/** 処理日 */
	private Date processDate = null;
	/** 照会条件 */
	private String referCd = "";
	/** メッセージレベル */
	private String messageLvl = "";
	/** 業務名 */
	private String businessName = "";
	/** ログ情報ヘッダ */
	private String logInfoHead = "";
	/** ログ情報 */
	private String logInfoData = "";
	/** 更新カウンタ */
	private int updateCnt = 0;
	/** 更新者 */
	private String updateStaff = "";
	/** 更新日 */
	private Date updateDate = null;
	/** ログシーケンスNO */
	private long logSeq = 0;
	/** 枝番 */
	private long edaNo = 0;
	/** ログ出力 */
	private boolean logOutput = false;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmallAccessLog() {
		// ログ出力先テーブル:アクセスログ
		logTable = LogTable.CUSTOMER;
		// 顧客OLをデフォルトセット
		systemKind = SystemType.CUSTOMER;
	}

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param  int sKind システム種別
	 * @return 無し
	 ************************************************************************************/
	public AmallAccessLog(int sKind) {
		// ログ出力先テーブル:アクセスログ
		logTable = LogTable.CUSTOMER;
		systemKind = sKind; //システム種類セット

		String log = ""; // アクセスログ用　アペンダー名称
		switch (systemKind) {
		case SystemType.CUSTOMER: // 顧客OL
			log = LoggerName.CUSTOMER;
			break;
		case SystemType.BUSINESS: // 業務支援
			log = LoggerName.BUSINESS;
			break;
		default: // 上記以外は顧客OLの定義を使用する
			log = LoggerName.CUSTOMER;
			break;
		}
		logger = LogManager.getLogger(log); //アクセスログ用
	}

	/*************************************************************************************
	 * ログ出力先テーブル設定
	 * <p>
	 * ログ出力先テーブル設定を行う
	 * <p>
	 * @param logTable	ログ出力先テーブル
	 * @return なし
	 ************************************************************************************/
	public void setLogTable(String logTable) {
		this.logTable = logTable;
	}

	/*************************************************************************************
	 * イベント開始ログ(テーブル出力のみ)
	 * <p>
	 * イベント開始ログ(テーブル出力のみ)を行う
	 * <p>
	 * @param dba	DBハンドル
	 * @return		出力結果(=0:正常,=-1:出力先テーブル設定無)
	 * @throws AmallException
	 ************************************************************************************/
	public int putEventStartLog(AmallDbAccess dba,
			String loginId, //ログインID
			String referCd, //照会条件
			String messageLvl, //メッセージレベル
			String businessName, //業務名
			String logInfoHead, //ログ情報ヘッダ
			String logInfo, //ログ情報
			String updateStaff //更新者
	) throws AmallException {
		if (!logOutput) {
			return 0;
		}

		int rtc = 0;
		this.logInfoData = AmallUtilities.getLocalHostName() + ":" + logInfo;
		this.processDate = new Date(System.currentTimeMillis());
		this.updateDate = new Date(System.currentTimeMillis());
		this.loginId = loginId; //ログインID
		this.referCd = referCd; //照会条件
		this.messageLvl = messageLvl; //メッセージレベル
		this.businessName = businessName; //業務名
		this.logInfoHead = logInfoHead; //ログ情報ヘッダ
		//		this.logInfoData  = logInfo;		//ログ情報
		this.updateStaff = updateStaff; //更新者

		if (LogTable.CUSTOMER.equals(logTable)) {
			putAccessLog(dba);
		} else if (LogTable.BUSINESS.equals(logTable)) {
			putCustLog(dba);
		} else {
			return -1;
		}

		return rtc;
	}

	/*************************************************************************************
	 * イベント終了ログ(テーブル出力のみ)
	 * <p>
	 * イベント終了ログ(テーブル出力のみ)を行う
	 * <p>
	 * @param dba	DBハンドル
	 * @return		出力結果(=0:正常,=-1:出力先テーブル設定無)
	 * @throws AmallException
	 ************************************************************************************/
	public int putEventEndLog(AmallDbAccess dba,
			String loginId, //ログインID
			String referCd, //照会条件
			String messageLvl, //メッセージレベル
			String businessName, //業務名
			String logInfoHead, //ログ情報ヘッダ
			String logInfo, //ログ情報
			String updateStaff //更新者
	) throws AmallException {
		if (!logOutput) {
			return 0;
		}

		int rtc = 0;
		this.logInfoData = AmallUtilities.getLocalHostName() + ":" + logInfo;
		this.processDate = new Date(System.currentTimeMillis());
		this.updateDate = new Date(System.currentTimeMillis());
		this.loginId = loginId; //ログインID
		this.referCd = referCd; //照会条件
		this.messageLvl = messageLvl; //メッセージレベル
		this.businessName = businessName; //業務名
		this.logInfoHead = logInfoHead; //ログ情報ヘッダ
		//		this.logInfoData  = logInfo ;		//ログ情報
		this.updateStaff = updateStaff; //更新者

		if (LogTable.CUSTOMER.equals(logTable)) {
			putAccessLog(dba);
		} else if (LogTable.BUSINESS.equals(logTable)) {
			putCustLog(dba);
		} else {
			return -1;
		}

		return rtc;
	}

	/*************************************************************************************
	 * アクセスログ出力(自律的トラッキング)
	 * <p>
	 * アクセスログ出力(自律的トラッキング)を行う
	 * <p>
	 * @param dba	DBハンドル
	 * @return		出力結果(=0:正常)
	 * @throws AmallException
	 ************************************************************************************/
	private int putAccessLog(AmallDbAccess dba) throws AmallException {
		int rtc = 0;
		String methodName = "putAccessLog()";

		dba.createCallableStatement("{ call AmallAccessLog_Package.AmallAccessLogAacslht(?,?,?,?,?,?,?,?,?,?,?) }");

		try {
			dba.getCallableStatement().setLong(1, logSeq);
			dba.getCallableStatement().setString(2, loginId);
			dba.getCallableStatement().setDate(3, processDate);
			dba.getCallableStatement().setString(4, referCd);
			dba.getCallableStatement().setString(5, messageLvl);
			dba.getCallableStatement().setString(6, businessName);
			dba.getCallableStatement().setString(7, logInfoHead);
			dba.getCallableStatement().setString(8, logInfoData);
			dba.getCallableStatement().setLong(9, updateCnt);
			dba.getCallableStatement().setString(10, updateStaff);
			dba.getCallableStatement().setDate(11, updateDate);
			dba.getCallableStatement().registerOutParameter(1, java.sql.Types.BIGINT);
			dba.setM_LogOutFlag(false);
			dba.execute();
			dba.setM_LogOutFlag(true);
			logSeq = dba.getCallableStatement().getLong(1);

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(dba.getClassName(), methodName, LogType.ERROR, e);
			throw ee;
		} finally {
		}
		return rtc;
	}

	/*************************************************************************************
	 * 社員ログ出力(自律的トラッキング)
	 * <p>
	 * 社員ログ出力(自律的トラッキング)を行う
	 * <p>
	 * @param dba	DBハンドル
	 * @return		出力結果(=0:正常)
	 * @throws AmallException
	 ************************************************************************************/
	private int putCustLog(AmallDbAccess dba) throws AmallException {
		int rtc = 0;
		String methodName = "putCustLog()";

		dba.createCallableStatement("{ call AmallAccessLog_Package.AmallAccessLogAstflht(?,?,?,?,?,?,?,?,?,?,?) }");

		try {
			dba.getCallableStatement().setLong(1, logSeq);
			dba.getCallableStatement().setString(2, loginId);
			dba.getCallableStatement().setDate(3, processDate);
			dba.getCallableStatement().setString(4, referCd);
			dba.getCallableStatement().setString(5, messageLvl);
			dba.getCallableStatement().setString(6, businessName);
			dba.getCallableStatement().setString(7, logInfoHead);
			dba.getCallableStatement().setString(8, logInfoData);
			dba.getCallableStatement().setLong(9, updateCnt);
			dba.getCallableStatement().setString(10, updateStaff);
			dba.getCallableStatement().setDate(11, updateDate);
			dba.getCallableStatement().registerOutParameter(1, java.sql.Types.BIGINT);
			dba.setM_LogOutFlag(false);
			dba.execute();
			dba.setM_LogOutFlag(true);
			logSeq = dba.getCallableStatement().getLong(1);

		} catch (AmallException ame) {
			throw ame;
		} catch (SQLException e) {
			AmallException ee = new AmallException();
			ee.addException(dba.getClassName(), methodName, LogType.ERROR, e);
			throw ee;
		} finally {
		}
		return rtc;
	}

	/*************************************************************************************
	 * 検索/更新実行ログ
	 * <p>
	 * 検索/更新実行ログを行う
	 * <p>
	 * @param dba		DBハンドル
	 * @param sql		SQL文
	 * @param sqlData	データ
	 * @return			出力結果(=0:正常)
	 ************************************************************************************/
	public int putExecuteLog(AmallDbAccess dba,
			String sqlCmd,
			String parameterString) {
		if (!logOutput) {
			return 0;
		}

		StringBuffer s = new StringBuffer();

		s.append(Long.toString(logSeq));
		s.append(",");
		s.append(Long.toString(edaNo));
		s.append(",");
		s.append(AmallUtilities.getCsvString(sqlCmd));
		s.append(",");
		s.append(AmallUtilities.getCsvString(parameterString));

		if (LogTable.CUSTOMER.equals(logTable)) {
			logger.debug(s.toString());
		} else if (LogTable.BUSINESS.equals(logTable)) {
			logger.debug(s.toString());
		}

		edaNo++;

		return 0;
	}

	/*************************************************************************************
	 * カウントログ
	 * <p>
	 * カウントログを行う
	 * <p>
	 * @param count	カウント数
	 * @return		出力結果(=0:正常)
	 ************************************************************************************/
	public int putCountLog(String count) {
		if (!logOutput) {
			return 0;
		}

		StringBuffer s = new StringBuffer();

		s.append(Long.toString(logSeq));
		s.append(",");
		s.append(Long.toString(edaNo));
		s.append(",");
		s.append(count);

		if (LogTable.CUSTOMER.equals(logTable)) {
			logger.debug(s.toString());
		} else if (LogTable.BUSINESS.equals(logTable)) {
			logger.debug(s.toString());
		}
		edaNo++;

		return 0;
	}

	/*************************************************************************************
	 * エラー出力ログ
	 * <p>
	 * エラー出力ログを行う
	 * <p>
	 * @param errorInfo	エラー情報
	 * @return			出力結果(=0:正常)
	 ************************************************************************************/
	public int putErrorLog(String errorInfo) {
		if (!logOutput) {
			return 0;
		}

		StringBuffer s = new StringBuffer();

		s.append(Long.toString(logSeq));
		s.append(",");
		s.append(Long.toString(edaNo));
		s.append(",");
		s.append(AmallUtilities.getCsvString(errorInfo));

		if (LogTable.CUSTOMER.equals(logTable)) {
			logger.debug(s.toString());
		} else if (LogTable.BUSINESS.equals(logTable)) {
			logger.debug(s.toString());
		}
		edaNo++;

		return 0;
	}

	/*************************************************************************************
	 * 枝番取得
	 * <p>
	 * 枝番取得を行う
	 * <p>
	 * @param  なし
	 * @return edaNo
	 ************************************************************************************/
	public long getEdaNo() {
		return edaNo;
	}

	/**
	 * 枝番設定
	 * <p>
	 * 枝番設定を行う
	 * <p>
	 * @param なし
	 * @param edaNo 枝番
	 ************************************************************************************/
	public void setEdaNo(long edaNo) {
		this.edaNo = edaNo;
	}

	/*************************************************************************************
	 * ログシーケンス取得
	 * <p>
	 * ログシーケンス取得を行う
	 * <p>
	 * @param なし
	 * @return logSeq
	 ************************************************************************************/
	public long getLogSeq() {
		return logSeq;
	}

	/*************************************************************************************
	 * ログ出力チェック
	 * <p>
	 * ログ出力チェックを行う
	 * <p>
	 * @param なし
	 * @return logOutput ログ出力(=true:有,=false:無)
	 ************************************************************************************/
	public boolean isLogOutput() {
		return logOutput;
	}

	/*************************************************************************************
	 * ログ出力設定
	 * <p>
	 * ログ出力設定を行う
	 * <p>
	 * @param logOutput ログ出力(=true:有,=false:無)
	 * @return なし
	 ************************************************************************************/
	public void setLogOutput(boolean logOutput) {
		this.logOutput = logOutput;
	}

	/*************************************************************************************
	 * サイト識別設定
	 * <p>
	 * サイト識別設定を行う
	 * <p>
	 * @param systemKind サイト識別
	 * @return なし
	 ************************************************************************************/
	public void setSystemKind(int systemKind) {
		this.systemKind = systemKind;
	}

}
