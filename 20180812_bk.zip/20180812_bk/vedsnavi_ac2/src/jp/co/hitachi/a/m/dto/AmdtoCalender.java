/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) AmdtoScreenInfo.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.m.dto;

import jp.co.hitachi.a.m.cls.AmclsDtoBase;

/*****************************************************************************************
 * カレンダー情報 <br>
 *****************************************************************************************/
public class AmdtoCalender extends AmclsDtoBase {

	/** メンバ定数 */
	/** 内容種別 0:表示なし(実績なし) */
	public static final int CON_TYPE_OFF = 0;
	/** 内容種別 1:通常(実績あり) */
	public static final int CON_TYPE_ON = 1;
	/** 内容種別 2:異常(実績あり) */
	public static final int CON_TYPE_ERROR = 2;

	/** メンバ変数 */
	/** 対象日付 */
	private String m_KeyDate = null;
	/** 曜日 */
	private int m_WeekDay = 0;
	/** 週目 */
	private int m_WeekofMonth = 0;
	/** 表示文字 */
	private String m_DispDay = null;
	/** 表示文字CSSクラス */
	private String m_DispDayClass = null;
	/** 内容種別 0:表示なし 1:通常 2:異常 */
	private int m_ContentsType = 0;
	/** 内容1 */
	private String m_ContentsMain = null;
	/** 内容2 */
	private String m_ContentsSub = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタ
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public AmdtoCalender() {
		clear();
	}

	/*************************************************************************************
	 * クリア処理
	 * <p>
	 * クリア
	 * </p>
	 * @param  無し
	 * @return 無し
	 ************************************************************************************/
	public void clear() {

	}
	////////////////////////////////////////////////////////////////////
	// setter / getter の自動生成
	////////////////////////////////////////////////////////////////////

	public String getM_KeyDate() {
		return m_KeyDate;
	}

	public void setM_KeyDate(String m_KeyDate) {
		this.m_KeyDate = m_KeyDate;
	}

	public int getM_WeekDay() {
		return m_WeekDay;
	}

	public void setM_WeekDay(int m_WeekDay) {
		this.m_WeekDay = m_WeekDay;
	}

	public int getM_WeekofMonth() {
		return m_WeekofMonth;
	}

	public void setM_WeekofMonth(int m_WeekofMonth) {
		this.m_WeekofMonth = m_WeekofMonth;
	}

	public String getM_DispDay() {
		return m_DispDay;
	}

	public void setM_DispDay(String m_DispDay) {
		this.m_DispDay = m_DispDay;
	}

	public String getM_DispDayClass() {
		return m_DispDayClass;
	}

	public void setM_DispDayClass(String m_DispDayClass) {
		this.m_DispDayClass = m_DispDayClass;
	}

	public int getM_ContentsType() {
		return m_ContentsType;
	}

	public void setM_ContentsType(int m_ContentsType) {
		this.m_ContentsType = m_ContentsType;
	}

	public String getM_ContentsMain() {
		return m_ContentsMain;
	}

	public void setM_ContentsMain(String m_ContentsMain) {
		this.m_ContentsMain = m_ContentsMain;
	}

	public String getM_ContentsSub() {
		return m_ContentsSub;
	}

	public void setM_ContentsSub(String m_ContentsSub) {
		this.m_ContentsSub = m_ContentsSub;
	}


}
