/*
 * ----------------------------------------------------
 * Ass Customer Online System
 *
 * @(#) XXX Actmp01DispBean.java
 *
 * ----------------------------------------------------
 * 2018.08.01 新規作成
 * ----------------------------------------------------
 */
package jp.co.hitachi.a.c.tmp.business;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.hitachi.a.c.tmp.action.Actmp01Action;
import jp.co.hitachi.a.c.tmp.bean.Actmp01DispBean;
import jp.co.hitachi.a.m.all.AmallDbAccess;
import jp.co.hitachi.a.m.all.AmallException;
import jp.co.hitachi.a.m.all.AmallMessageConst;

/*****************************************************************************************
 * XXX Actmp01Businessクラス<br>
 *****************************************************************************************/
public class Actmp01Business extends ActmpBusinessBase {

	/** メンバ定数 */
	// XXX 名称を定義する
	/** 表示用画面Bean名 */
	private static final String DISP_BEAN = "Actmp01DispBean";

	/**
	 * FOWARD 定義
	 */
	// XXX DISPは初期表示として定義 その他のイベントも定義
	/** 画面表示 */
	public static final String FORWARD_DISP = "DISP";
	/** 処理01 */
	public static final String FORWARD_TEMP01 = "TEMP01";
	/** 処理02 */
	public static final String FORWARD_TEMP02 = "TEMP02";

	/**
	 * 画面項目ID
	 */
	// XXX 画面のフォームのIDを設定する(エラー状態時のキー値用)
	/** TEMP01 */
	public static final String ITEM_ID_TEMP01 = "temp01";
	/** TEMP01 */
	public static final String ITEM_ID_TEMP02 = "temp02";

	/** メンバ変数 */
	// XXX フォームとBeanの変数をメンバ変数で定義 フォームから画面上の入力値が取得可能
	/** アクションフォーム */
	private Actmp01Action m_Actmp01Form = null;
	/** 表示用画面Bean */
	private Actmp01DispBean m_Actmp01DispBean = null;

	/*************************************************************************************
	 * コンストラクタ
	 * <p>
	 * コンストラクタを行う
	 * </p>
	 * @param mapping アクションマッピング
	 * @param　form　　　アクションフォーム
	 * @param request　リクエスト
	 * @param response　レスポンス
	 * @param context　コンテキスト
	 * @param inGid　画面ID
	 * @param inActionMode　イベント
	 * @return 無し
	 ************************************************************************************/
	// XXX アクションフォームの型に注意
	public Actmp01Business(
			Actmp01Action form,
			HttpServletRequest request,
			HttpServletResponse response,
			String gid,
			String event)
			throws AmallException {
		super(request, response, gid, event);

		m_ClassName = Actmp01Business.class.getName();
		m_Actmp01Form = form;
		// XXX beanの型に注意
		m_Actmp01DispBean = new Actmp01DispBean();
		// XXX アクションフォームの型に注意
		setErrString(gid, m_Actmp01Form.getM_systemKind(request));
	}

	/*************************************************************************************
	 * 画面イベント処理実行
	 * <p>
	 * 画面イベント処理を実行する
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	public String execute() throws AmallException {

		// ログ用メソッド名
		String methodName = "execute()";
		// 返却ActionForward名
		String forwardStr = FORWARD_DISP;

		try {

			// GETﾊﾟﾗﾒｰﾀ値のﾁｪｯｸ
			if (m_Event.length() <= 0) {
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_COM_SCREEN_EVENT_GET_ERROR, "");
				throw ee;
			}
			// XXX 画面の表示・非表示の権限データをBeanに登録する
			// XXX ユーザー＋対象画面で使用可能な顧客データをBeanに登録する
			// XXX ユーザー＋対象画面で使用可能な店舗データをBeanに登録する
			// XXX ヘッダ情報をBeanに登録する
			// システム共通情報の作成
			createSystemCommonInfo(m_Gid, m_Actmp01DispBean);

			// DB接続
			// XXX アクションフォームの型に注意
			m_DbAccess = new AmallDbAccess(m_Actmp01Form.getM_systemKind());
			m_DbAccess.initDB();

			// XXX 各種のイベントをここに記載(リテラルを先に記載する)
			// 画面ｲﾍﾞﾝﾄ判定
			if (FORWARD_DISP.equals(m_Event)) {
				// 画面表示処理の場合
				forwardStr = disp();
			} else if (FORWARD_TEMP01.equals(m_Event)) {

			} else if (FORWARD_TEMP02.equals(m_Event)) {

			} else {

				// 上記以外のイベントの場合
				AmallException ee = new AmallException();
				ee.addException(m_ClassName, methodName, AmallMessageConst.MSG_COM_SCREEN_EVENT_GET_ERROR, m_Event);
				throw ee;
			}

			// 正常終了
			return forwardStr;

		} catch (AmallException e) {
			e.addException(m_ClassName, methodName, AmallMessageConst.MSG_COM_SCREEN_EVENT_PROC_ERROR);
			setAmallException(e);
			throw e;

		} catch (Exception e) {
			AmallException ee = new AmallException();
			ee.addException(m_ClassName, methodName, e);
			setAmallException(ee);
			throw ee;

		} finally {
			// XXX アクションFormで取得するためにBean名で設定
			// リクエストスコープにDispBean 登録
			setReqScopeAttribute(DISP_BEAN, m_Actmp01DispBean);
		}
	}

	// XXX 初期表示処理を記載(初期検索などある場合は処理が必要)
	/*************************************************************************************
	 * 初期表示処理
	 * <p>
	 * 初期表示処理を行う
	 * </p>
	 * @param  無し
	 * @return ActionForward名称
	 ************************************************************************************/
	private String disp() throws AmallException {

		if (m_DbAccess != null) {
			m_DbAccess.exitDB();
		}
		return FORWARD_DISP;
	}

	// XXX 各種イベント処理を記載

	// XXX DB処理を記載

}